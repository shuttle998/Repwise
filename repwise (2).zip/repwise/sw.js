// Offline support: the whole app is cached, so workouts can be logged with no signal (a gym basement, a flight).
// sw-manifest.js is generated on every deploy and carries a content-based version, so new deploys get a fresh cache automatically.
// Even without that build step, app files are refreshed in the background on every visit (stale-while-revalidate).
importScripts('sw-manifest.js');
const { version: VERSION, files: SHELL } = self.REPWISE_BUILD;
const SHELL_SET = new Set(SHELL.map((f) => new URL(f, self.location).pathname));

self.addEventListener('install', (e) => {
  // Cache everything first; if any file fails the install fails and the previous version keeps running, so users never get a half-updated app.
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL.map((f) => new Request(f, { cache: 'reload' })))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k.startsWith('repwise') && k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('message', (e) => { if (e.data === 'skipWaiting') self.skipWaiting(); });
self.addEventListener('fetch', (e) => {
  const req = e.request; if (req.method !== 'GET') return;
  const url = new URL(req.url); if (url.origin !== location.origin) return; // fonts, Supabase and other origins go straight to the network
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/.netlify/')) return; // server functions are never cached
  if (req.mode === 'navigate') { // pages: try the network (fresh deploys show quickly), fall back to the cached app so it opens offline
    e.respondWith(fetch(req).catch(() => caches.match(req, { ignoreSearch: true }).then((r) => r || caches.match(url.pathname.endsWith('index.html') || url.pathname === '/' ? 'index.html' : 'app.html'))));
    return;
  }
  if (SHELL_SET.has(url.pathname)) { // app files: answer from the cache at once (fast on bad signal) and refresh the cached copy in the background,
    // so even a deploy made without running the build step reaches users on their next visit.
    e.respondWith(caches.open(VERSION).then((c) => c.match(req).then((hit) => { const net = fetch(req).then((res) => { if (res.ok) c.put(req, res.clone()); return res; }); if (hit) { net.catch(() => {}); return hit; } return net; })));
    return;
  }
  e.respondWith(fetch(req).then((res) => { if (res.ok) { const copy = res.clone(); caches.open(VERSION).then((c) => c.put(req, copy)); } return res; }).catch(() => caches.match(req)));
});
