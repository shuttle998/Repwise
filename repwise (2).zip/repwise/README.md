# Repwise

Static, dependency-free web app (HTML, CSS, ES modules). No build step. Deploy the folder as-is to Netlify.

## Files
- `index.html` + `css/landing.css`: public landing page
- `app.html`: the app shell (hash routes: `#/`, `#/train`, `#/workout`, `#/progress[/records|/achievements|/report]`, `#/library[/id]`, `#/settings`, `#/pricing`)
- `js/exercises.js` exercise library · `js/generator.js` programme generator · `js/progression.js` overload engine (pure)
- `js/analytics.js` stats, PRs, achievements, weekly report (all derived from logged sessions)
- `js/store.js` state, persistence, migration from the original app, export/import
- `js/workout-logic.js` session logic · `js/views/*` screens · `js/charts.js` SVG charts
- `js/services.js` storage / billing / account adapters · `js/config.js` prices and flags
- `sw.js` offline cache (bump `VERSION` on each deploy) · `_headers` Netlify security headers

## Run and test
```
python3 -m http.server 8123      # then open http://localhost:8123
node tests/unit.mjs              # progression, generator and analytics tests
```

## Before launch
1. Set real prices in `js/config.js` and the matching numbers in the pricing section of `index.html`.
2. Payments: nothing is connected. Implement a provider in `js/services.js` (checkout + webhooks must run server-side, e.g. Netlify Functions; never put secret keys in this repo's frontend), then set `PAYMENTS_LIVE = true`. Until then Pro is a local preview toggle.
3. Accounts and cross-device sync need a backend. Today the "account" is a local profile; users can export/import JSON.
4. Exercise demonstrations are YouTube embeds listed in `js/media.js`. Open each exercise once and replace any video that is missing or not embeddable (one line each).
5. Bump `VERSION` in `sw.js` whenever you deploy.

## Data
Everything lives in `localStorage` key `repwise:v2`. The original `repwise` key is migrated (plan, weights, workout log) and left untouched.

## AI Coach (server function)
The Coach calls `netlify/functions/coach.mjs`, which holds the API key. The browser never sees it.
1. Deploy with Git or the Netlify CLI (`netlify deploy --prod`). Drag-and-drop deploys do NOT include functions.
2. Free option: create a key in Google AI Studio and add it in Netlify > Site settings > Environment variables as `GEMINI_API_KEY`. Optional `GEMINI_MODEL` (default `gemini-flash-latest`; check AI Studio for current Flash model names).
   Paid option: `ANTHROPIC_API_KEY` (optional `COACH_MODEL`). If both keys exist, `COACH_PROVIDER=gemini|anthropic` picks one.
3. Free-tier caveats: Google may use free-tier content to improve its products (the app tells users this), and the quota is shared by every user of your site, so the Coach will sometimes answer "busy". Set `COACH_PAID_TIER=true` once billing is enabled to hide the free-tier privacy note.
4. Without a key the Coach screen says it is not switched on. Nothing is faked.
5. Daily limits per plan are in `js/config.js` (`COACH`); the server also limits per visitor (`COACH_DAILY_LIMIT`, default 60). Set a spend limit if you use a paid provider.
6. The Coach receives only the summary built in `js/coach-context.js` (no name or email). Users can see it under "What the Coach can see".

## Body measurements and photos
Measurements are stored in `state.body` (kg and cm, shown in your unit) and are included in the JSON export and import.
Progress photos are stored only in the browser's IndexedDB (`js/photos.js`). They are never uploaded and are NOT part of exports, so users must keep their own copies. "Delete all data" in Settings also clears them. Cloud sync (Phase 7) would need encrypted per-user storage before photos can sync.

## Exercise library, custom exercises and the programme builder
- **Library** (`js/views/library.js`): ranked search that understands abbreviations (`db`, `bb`, `rdl`, `ohp`) and muscle words (`abs`, `lats`, `quads`); filters for muscle, equipment, training location (Home / Home with dumbbells / Gym), category and difficulty; Favourites and Recent views; last-performed date on each row.
- **Custom exercises** (`js/exercises.js`, `js/store.js`): stored in `customExercises` with ids starting `c-`. Removing one you have logged **archives** it (hidden from lists, still resolves in history); removing an unused one deletes it. Names must be unique.
- **Picker and swaps** (`js/picker.js`): one picker for the builder with search, filters, Favourites and Recent. Swap sheets (builder and in-workout) rank alternatives by movement pattern, target muscles, your equipment, difficulty vs your level and listed limitations, and show the reason for each. Scoring lives in `rankedSubstitutes`.
- **Builder** (`js/views/train.js`, Pro): reorder, sets, separate min and max reps, rest, per-session notes (shown on the programme and the workout screen), saved programmes (up to 20), build from scratch. Editing never changes logged workouts.
- Exercise demonstration videos still exist only for the exercises in `js/media.js`. Custom exercises have no video.

## Built-in exercise animations
Every library exercise has an original animation drawn in the app (no video files, nothing downloaded). One side-on figure moves between poses defined in `js/anim-data.js`; `js/anim.js` solves the knees and elbows, blends the keyframes and draws SVG.
- Each card has Pause/Play, 0.5× speed, a rep counter, and **Follow along**: pick 20/30/45/60 seconds, a 3-second lead-in counts down, then the timer runs while reps are counted from the animation. A tone and vibration play at the end (they follow the sound and vibration settings). Hold exercises (plank) count a hold instead of reps.
- Target muscles are tinted. Some exercises (lateral raise, hip abduction, sumo squat, close-grip push-up) are viewed from the side, so the sideways part of the movement is simplified; a note says so on the card.
- To fix or add one, edit its entry in `ANIMS`: `base` (what stays the same), `kf` (keyframes: hip, torso angle, feet and hands), `seq` (the loop: keyframe, seconds, cue, pause). `tests/unit.mjs` checks every pose (finite numbers, constant limb lengths, nothing below the floor).
- The YouTube videos remain available behind "Also watch a real person do it". Custom exercises have no animation.

## Nutrition, water and reports (Phase 5)
- **Nutrition** (`#/nutrition`, linked from Home and More): log meals with calories and macros (calories are worked out from macros if left blank), daily targets with a "left today" ring and macro bars, saved meals for one-tap reuse, copy yesterday's meals, and a history tab (7/30 days free, 90 days Pro). There is **no food database**: you enter the numbers yourself. Adding one (for example Open Food Facts) would need a network permission in `_headers` (`connect-src`) and a privacy note.
- **Target estimate**: optional Mifflin-St Jeor formula with an activity factor and a goal adjustment (+10% build muscle, +5% stronger, -20% lose weight, +15% gain weight), protein 1.8 g/kg (2.0 when losing weight). It is a starting point and says so.
- **Water** (`#/nutrition/water`): quick-add buttons, your own bottle size, custom amounts, undo and per-drink removal, a daily progress glass and a 14-day chart. The target is yours if you set one; otherwise about 33 ml per kg of your latest logged body weight, plus 500 ml on a day you trained. General guidance, not medical advice.
- **Reports** (Progress, Report tab): weekly and monthly. Each shows workouts, consistency, total volume, total time, strength improvements, records, muscle-group distribution, missed targets (weeks below target in a month), suggestions, and a nutrition and hydration summary when you have logged any. Pro can export CSV, print or save as PDF, and share or copy a text summary. Nutrition history exports as CSV.
- Data lives in `state.nutrition` and `state.water` (in the JSON export; old exports without them still import). Logic is in `js/nutrition.js` and `js/report-export.js`, covered by `tests/unit.mjs`.

## Phase 6: rewards, calendar and reminders

**XP, levels, streaks.** Everything is derived from your logged history (nothing is stored), so it can never drift from your workouts.
- 40 XP per workout day (one per day, at most your weekly target + 1 days per week), +1 XP per set (max 20 per workout), +20 per personal record (max 3 per day), plus XP for achievements (25 to 150) and completed challenges (weekly 30-60, monthly 60-150).
- Extra workouts beyond your plan earn nothing more. This is deliberate: it rewards consistency, not overtraining.
- Level L needs 50·L·(L-1) total XP (100, 300, 600, 1000...). Changing your weekly target recalculates XP from history.
- Weekly and monthly challenges are generated from your weekly target (hit the target, sets, muscle groups, new exercises; water and meal-logging challenges appear only if you use those features).
- Code: `js/gamify.js`, UI in `js/views/rewards.js` (Progress > Achievements, Home, workout summary).

**Calendar.** `#/calendar`: Monday-first month grid showing trained, planned, missed, rest and "made up" days, weekly counts, and the workouts for any tapped date. A planned day is "missed" only after the day passed and no extra workout that week covers it, and never before you started. Free plan shows the last 30 days of workouts. Code: `js/schedule.js`, `js/views/calendar.js`.

**Reminders.** Choose planned weekdays, reminder time, an optional evening-before heads-up, a weekly summary day/time, and milestone/programme notices (Settings > Reminders and planned days, or the Calendar page). Reminders only fire on planned days and never once you have trained.
- Honest limit: a web page cannot be woken when it is closed, and there is no server yet. Reminders fire while the app is open or in the background (in-app toast, plus a system notification if allowed); any you missed appear in the in-app Notices inbox. For real background alarms, "Add to calendar" downloads an `.ics` file (weekly repeating events with alarms) for your phone's calendar. True push notifications arrive with accounts in Phase 7.
- Code: `js/reminders.js`, `js/reminder-engine.js`, `js/views/reminders-ui.js`.

**Tests.** `node tests/unit.mjs` (91 tests).

## Phase 7: accounts, cloud sync, wearables, light mode, reliability

### Accounts and cloud sync (Supabase)
- Local-first: everything works offline and is saved on the device immediately. When you are signed in, changes sync in the background (a few seconds after a change, when you come back online, when the app regains focus, and every 5 minutes).
- Setup is optional and takes about 10 minutes: follow **`supabase/README.md`** (create a free project, run `supabase/schema.sql`, put the URL and anon key in `CONFIG.CLOUD` in `js/config.js`). With the keys empty the app runs local-only and says so in Settings.
- Security: email + password accounts with email confirmation and password reset by email link; every table has row-level security so a user can only read and write their own rows; the anon key is public by design; the service-role key is never used. Sessions are stored in this browser's localStorage and refreshed automatically.
- **Merging, not overwriting.** Workouts, meals, water entries, body entries, custom exercises, saved programmes and imported activities are merged by id, so two devices that both added data end up with all of it. Deletions are remembered (tombstones) so deleted items do not come back. Single-value sections (profile, programme, units/settings, nutrition targets, reminders, favourites) take whichever device changed them last. Updates carry a revision number; if another device wrote first, the app re-fetches, merges and retries.
- **Existing local data is migrated safely.** The first time an account meets a device with data, a full export of the local data is saved (Settings > Account > "Download it") and then merged. Signing in on a new phone brings everything over. If a different account signs in on a device that holds another account's data, you are asked before the two are combined.
- Not synced: the in-progress workout, progress photos (kept on the device), the plan preview, notices. Local data is never deleted by signing out or by deleting your account.
- **Backups and restore.** A database trigger keeps your 10 most recent snapshots (at most one per 12 hours). Settings > Account > Cloud backups lists them and can restore one (your current data downloads as a file first). Whole-project backups are Supabase's own feature (paid plans) or `pg_dump`.
- **Account deletion** is self-service (type DELETE) and removes the account and all cloud data through a SQL function. 
- Honest limits: the two-device logic is tested against an in-memory mock of Supabase, not a live project, so please run the checklist in `supabase/README.md` once with your own keys. Without a server component there is still no real background push notification (see Phase 6).

### Wearables
- **Import** (Settings > Health and devices): an Apple Health `export.zip` (or `export.xml`), or `.tcx` / `.gpx` activity files (Garmin, Polar, Strava, Fitbit and most others can export these). Parsing happens on the device; nothing is uploaded. Workouts (type, duration, distance, calories, average/max heart rate), body weight and resting heart rate are read. Re-importing never duplicates. Imported activities show in the calendar but never count towards streaks, XP or challenges.
- **Live heart rate**: connect a Bluetooth chest strap or a watch that broadcasts the standard Heart Rate service (Web Bluetooth: Chrome/Edge on Android and desktop; not iOS browsers or Firefox, and the app says so). Live BPM shows during the workout; average/min/max are saved with it.
- Why not a direct Apple Health / Health Connect / Garmin link: those are native-app or partner-API integrations that a website cannot do; this would need a native wrapper or provider developer accounts.
- Bluetooth was tested with a simulated strap in an automated browser and against the Bluetooth spec's byte formats; please try it once with your own strap.

### Appearance and polish
- Settings > Appearance: **Dark (default)**, Light, or follow the device. The choice is applied before first paint (no flash). All colours are design tokens; an automated check measures text contrast on every main screen in both themes (WCAG AA).
- Touch targets raised to 44 px, a subtle page transition (respects reduced-motion), toast and sheet colours follow the theme.

### Reliability and offline
- The **whole app is precached** (65 files, generated list) so it opens and logs workouts with no signal; cache names are derived from file contents, so every deploy refreshes users automatically and a half-failed update is never activated. `node tools/gen-precache.mjs` regenerates `sw-manifest.js` (Netlify runs it on build; the tests fail if it is stale).
- Saves keep a second automatic copy every 10 minutes; a damaged main save is recovered from it (the damaged data is also kept). The browser is asked for persistent storage. A global handler logs unexpected errors and the router shows a recovery screen instead of a blank page.
- Deploying by dragging a folder into Netlify (no build step) works: the zip ships with an up-to-date `sw-manifest.js`, and app files are also refreshed in the background on each visit. If you change files yourself, running `node tools/gen-precache.mjs` first is recommended but no longer required.

### Tests
- `npm test` (or `node tests/unit.mjs && node tests/cloud.mjs && node tests/reliability.mjs`): unit tests for logic, sync merge and parsers; sync engine against a mock Supabase; offline-completeness, recovery and security-header checks.
- `npm install && npx playwright install chromium && npm run test:e2e`: 17 browser tests (phone-width flows, two-device sync, offline mode, contrast audit). GitHub Actions runs both on every push (`.github/workflows/test.yml`).

## Classes (Pilates, yoga and other studio sessions)

- **Log or book a class** from the Calendar: pick a day, then *Log a class* (already done) or *Book a class* (future, needs a start time).
- A **done class counts as a trained day** in the calendar and the weekly target. It adds no sets, volume, XP or personal bests, and streaks and challenges still follow lifting only.
- **Booked classes** never count until you mark them done. Once the date passes, they appear under *Did you go?*. Each booked class can be exported as a calendar file (`.ics`) with an alarm one hour before.
- Each class has an impact level (low, medium, high; a default per type that you can change) and an optional 1 to 5 effort rating.
- Classes are stored with imported activities (`source: 'class'`), so sync, backup and delete already cover them. "Remove all imported activities" leaves classes alone.
- **Library filter "Easy on your…"** (knees, lower back, shoulders, wrists) uses each exercise's existing joint-stress tags. Custom exercises have no tags, so they are left out of that filter. No library exercise involves jumping, so a separate "low impact" exercise filter would show everything.
- Tests: `tests/unit.mjs` (class rules) and `tests/e2e/e2e13.js`.

## Pilates, yoga and mobility routines

- **19 moves** (Pilates mat work, yoga positions, mobility) are in the Exercise library under the category *Mind-body*, each with written steps, common mistakes and breathing guidance. **17 of them have a built-in animation** (the same simplified side-on figure as the lifting exercises, with a follow-along timer). Supine twist and figure-four have none, because they happen across the body and a side-on figure can't show them honestly; those pages show the steps and a search link. There are no videos for any of them. Poses live in `js/anim-data.js`.
- **4 timed routines** on the Train tab: Mat Pilates core (~15 min), Gentle yoga flow (~9 min), Desk reset (~6 min) and Wind-down stretch (~5 min). Start one and follow it in the normal workout screen.
- Every timed set has a **Start timer** button: it counts down and ticks the set off with a sound and vibration when it ends. One-side moves have two sets, labelled first side and other side.
- A routine is saved as a normal workout, so it counts as a trained day, towards your weekly target, streak and XP. It **never moves your lifting programme on**, writes no weight progression, and holding a stretch longer is never a personal best.
- The programme generator never picks these moves.
- Moves, routines and times live in `js/mindbody.js`. Add a move or routine there.
- Tests: `tests/unit.mjs` and `tests/e2e/e2e14.js`.

## Library extras and session structure
- **More exercises**: cardio (treadmill, running, cycling, stair climber, skipping, jumping jacks, elliptical, rowing, brisk march), warm-ups, glute activation (clamshell, fire hydrant, banded lateral walk and more), stretches, extra core (side plank, reverse crunch, Russian twist, hanging knee raise, cable crunch, Pallof press), leg extension, seated and lying leg curls, good morning, seated calf raise and forearm curls. They live in `js/library-extra.js`. Filter the library by category (Cardio, Warm-up, Stretching, Glute activation).
- **No animation or video for these yet**: they show written steps and a search link. I did not add video links I could not check.
- **Session structure** (Train tab): optionally wrap each lifting session in warm-up, glute activation, your main work, cardio and a cool-down. Extras are chosen from the muscles in that session, your equipment and your joint limits, and never change your saved programme. All are off by default.
- **Cardio only**: pick a cardio exercise and minutes on the Train tab and start a standalone session. It counts as a trained day and does not move your programme on.
- Warm-up, activation, stretch and cardio work never counts as a personal best, weekly muscle volume or a swap for a lift.

## Onboarding and programme generator (Stage 2)
- **Setup flow**: name, about you (optional), experience (Beginner, Intermediate, Advanced), how you want to train (Guided, Smart recommendations or Custom), goals, body focus, equipment, workout length, days per week, preferences (style and areas to work around), then the split. Guided skips the split step.
- **Goals**: muscle growth (hypertrophy), weight loss, strength, tone up, endurance, general fitness, athletic performance and gain weight, plus up to two secondary goals. Secondary goals only nudge the plan (heavier main lifts for strength, higher-rep accessories for endurance, an extra accessory set for muscle). An endurance, weight-loss or general-fitness goal switches on 10 minutes of cardio after lifting.
- **Equipment** is multi-select (full gym, home gym, barbells, dumbbells, kettlebells, bands, cables, Smith machine, bodyweight). The generator, swaps and session extras only use exercises you can do with what you picked. Kettlebells and the Smith machine are treated as dumbbell and barbell equivalents; there are no kettlebell-only exercises yet.
- **Length**: ranges from 15 to 120 minutes, or any custom length from 15 to 180. Longer sessions add accessory work, capped by experience level (about 7, 9 and 12 exercises), so a 120 minute session may finish sooner. Use cardio and cool-down from the Train tab for the rest.
- **Days**: 2 to 7 a week with recovery advice for each. A seventh day is always light active recovery (easy cardio and mobility).
- **Splits**: recommended, full body, upper/lower, lower/upper, push/pull/legs, bro split, glute-focused, strength, hypertrophy and custom (you choose the muscles for each day).
- **Body focus**: pick any of 12 areas. Chosen areas get an extra exercise and set where they fit. Pick them by tapping a front and back body map (or from the list below it), in onboarding and in Settings.
- **Fine-tune** (sets, rep range, rest) overrides the defaults for every weighted exercise. The result shows weekly sets per muscle against the common 10 to 20 range for growth, as a guide only.
- **Coverage**: on 3+ day programmes every major muscle (chest, back, shoulders, biceps, triceps, quads, hamstrings, glutes, calves, core) is trained at least once a week when time allows.
- **Custom path**: choose "Fill my days" or, with Pro, "Start with empty days" and add exercises yourself. When adding, "For you" lists recommendations from your equipment, limits, focus and recent sessions, each with a reason.
- **Gender** is stored as optional background only. It does not change exercise selection.
- Existing programmes and profiles are untouched. Older profiles (single equipment type, 2 to 5 days) keep working.

## Body map (Stage 3)
- `js/bodymap.js` draws simplified front and back body shapes (stylised, not anatomical). Tap or press Enter/Space on an area to select it; the list below stays in sync as the accessible alternative.
- Exercise pages show the same map with the primary muscles in solid blue and secondary muscles lighter.
- Areas: glutes, quadriceps, hamstrings, calves, back, chest, shoulders, biceps, triceps, forearms, abs (front of the stomach) and core (the sides). Lower back and deep core are not separate areas.

## Dashboard, workout editing and muscle consistency
- Home has a **Your programme** card: programme name and split, selected goals, target muscles, and the next three sessions in programme order on your planned days. The order is a projection; skipping a day shifts it.
- During a workout, **Edit workout** lets you reorder, remove and add exercises, and **Sets, reps, rest** changes those values for one exercise. Completed sets are never removed. Edits apply to that workout only; the saved programme is unchanged. Exercise cards show assisting muscles as well as primary ones.
- Progress has **Muscle training consistency** (weeks trained out of 4, sessions per week, last trained). For hypertrophy goals it adds this week's sets against the common 10–20 sets guide. Everything is counted from logged sets.
- Landing page copy now covers personalised plans, muscle focus, the exercise library and progress tracking, with a secondary button to the library.

## Anatomy illustration
The body map (`js/bodymap.js`) is redrawn with muscle-shaped regions (pecs, segmented abs, obliques, traps, lats, lower back, delts, biceps/triceps, quads, hamstrings, glutes, calves) on a fuller silhouette. Each area can own several shapes, so tapping any part of Back selects all of Back. Shapes carry tooltips and the exercise page lists primary and assisting muscles by name. It is an illustration, not a medical drawing; lower back and deep core are not separate selectable areas.
The exercise page map rotates: a button flips between front and back and dragging spins it, then it snaps to a side (it opens on the side with the main muscle). It is two flat views turning, not a 3D model, and rotation is instant when reduced motion is on.

## Developer guide and requirement checks
Structure (no bundler, plain ES modules): `js/exercises.js` and `js/library-extra.js` hold exercise data; `js/generator.js` builds programmes; `js/sessions.js` wraps sessions with warm-up/cardio/cool-down; `js/recommend.js` ranks suggestions; `js/bodymap.js` draws the muscle map; `js/anim*.js` the movement animations; `js/views/*` one file per screen; `js/store.js` is the only place that writes saved data. To add an exercise: add an `E(...)` entry in `library-extra.js`, list its id in a slot in `SLOTS` if the generator may choose it, and run `npm test`.

| Brief requirement | Where it is verified |
|---|---|
| Modular code, data kept separate from views | file layout above |
| Programmes for beginner, intermediate and advanced across goals, equipment, days and durations | `tests/unit.mjs` "generation matrix" (3 levels x 8 goals x 6 equipment sets x 6 day counts x 3 durations = 2,592 programmes) |
| Equipment respected, beginners never get Advanced exercises, no repeats in a session, valid sets and reps | same matrix |
| Every major muscle trained weekly when the equipment can train it directly (3+ days) | same matrix. In 30 minute sessions arms, calves, core and shoulders may count through compound lifts |
| Substitutions keep the muscle and equipment and never swap in a guided move | "substitutes keep the muscle" test |
| Existing saved data keeps working | "older saved profiles" test and `tests/reliability.mjs` |
| Mobile layout, no horizontal scroll, accessible controls | `tests/e2e` (375px and 1280px, contrast checks) |
| Works offline | e2e offline test and the generated `sw-manifest.js` |
| Onboarding, library, session, dashboard and map flows | `tests/e2e/e2e15` to `e2e18` |

## Deploying on Vercel
1. Push the folder to GitHub (or run `npx vercel` from it). Framework preset: **Other**. No build command; output directory `.`.
2. Project Settings > Environment Variables: `GEMINI_API_KEY` (and/or `ANTHROPIC_API_KEY`), optional `COACH_PROVIDER`, `COACH_DAILY_LIMIT`.
3. `vercel.json` carries the security headers; `api/coach.mjs` serves `/api/coach` (shares code with `netlify/functions/coach.mjs`).
4. Supabase > Authentication > URL Configuration: set the Site URL and add the Vercel URL under Redirect URLs.
5. If you change files in `js/`, `css/` or `icons/`, run `node tools/gen-precache.mjs` before deploying so the offline cache list is current.

## Deploying on Cloudflare Pages
Build command `npm run build:cf` (runs `node tools/gen-precache.mjs && node tools/build-static.mjs`), output directory `dist`. The `functions/` folder serves `/api/coach`. Secrets (`GEMINI_API_KEY`, ...) go in Pages > Settings > Variables and Secrets. Drag-and-drop upload does not compile Functions; use Git integration or `npx wrangler pages deploy dist`.
