/* Repwise: dashboard, history, achievements, weekly report, more menu. All numbers come from logged workouts. */
(function () {
  const RW = window.RW, D = RW.data, E = RW.engine, C = RW.charts, S = RW.store, UI = RW.ui;
  const esc = UI.esc, ic = UI.ic, A = UI.acts, V = UI.views;

  const tile = (val, label, extra) => '<div class="tile"><b class="num">' + val + '</b><span>' + label + '</span>' + (extra || '') + '</div>';
  const sect = (title, right) => '<div class="sect-h"><h2 class="h2">' + title + '</h2>' + (right || '') + '</div>';
  const prLine = (p) => { const bits = []; if (p.types.includes('weight')) bits.push(UI.W(p.w) + ' × ' + p.r); if (p.types.includes('e1rm')) bits.push('Est. 1RM ' + UI.W(p.e1)); if (p.types.includes('reps')) bits.push(p.r + (p.time ? ' sec' : ' reps')); return bits.join(' · '); };
  const rowWk = (w) => '<button class="row-b" data-act="wk" data-id="' + esc(w.id) + '"><span class="row-m"><b>' + esc(w.name) + '</b><span class="sm mut">' + UI.rel(w.d) + (w.legacy ? '' : ' · ' + E.setCount(w) + ' sets' + (E.volume(w) ? ' · ' + UI.vol(E.volume(w)) : '')) + '</span></span>' + ic('right', 18) + '</button>';
  const metricOf = (series) => (series.some((p) => p.e1 > 0) ? { k: 'e1', label: 'Est. 1RM', fmt: (v) => UI.W(v) } : series.some((p) => p.w > 0) ? { k: 'w', label: 'Top weight', fmt: (v) => UI.W(v) } : { k: 'reps', label: 'Best set', fmt: (v) => v + '' });

  V.dash = function () {
    const s = UI.st(), p = s.profile, W = s.workouts, now = new Date(), G = D.GOALS[p.goal], target = p.days;
    const a = S.act(), sess = s.plan.sessions, idx = s.planIdx % sess.length, next = sess[idx];
    const week = E.weekBuckets(W, now, 1)[0], streak = E.streakWeeks(W, target, now);
    const totalVol = W.reduce((t, w) => t + E.volume(w), 0), prCount = W.reduce((t, w) => t + (w.prs ? w.prs.length : 0), 0);
    const hr = now.getHours(), hello = hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening';
    const last = W[W.length - 1], todayKey = E.dkey(now), doneToday = W.some((w) => w.d === todayKey);
    const wd = (now.getDay() + 6) % 7, planned = D.SCHEDULE[p.days] || [], isPlanDay = planned.includes(wd);

    // hero
    let hero;
    if (a) {
      const dn = a.ex.reduce((t, x) => t + x.sets.filter((y) => y.done).length, 0), tt = a.ex.reduce((t, x) => t + x.sets.length, 0);
      hero = '<div class="card hero-c live"><p class="lbl"><span class="pulse"></span> Workout in progress' + (a.pausedAt ? ' (paused)' : '') + '</p><h2 class="title">' + esc(a.name) + '</h2><p class="mut"><span class="num" data-live="elapsed">' + UI.clock(UI.elapsed(a)) + '</span> · ' + dn + ' of ' + tt + ' sets done</p><div class="meter" style="margin:16px 0"><i style="width:' + (tt ? (dn / tt) * 100 : 0) + '%"></i></div><button class="btn lg block" data-act="resume">' + ic('play', 18) + ' Resume workout</button></div>';
    } else {
      const ex = next.exercises, mins = E.estMinutes(next);
      const note = doneToday ? 'You trained today. Recovery is part of the plan, so the next session can wait.' : last && (Date.now() - last.ts) / 36e5 < 20 ? 'You trained ' + Math.max(1, Math.round((Date.now() - last.ts) / 36e5)) + ' hours ago. Train again when you feel recovered.' : (s.settings.reminder && isPlanDay && week.count < target ? 'Today is a training day in your plan.' : '');
      hero = '<div class="card hero-c"><p class="lbl">' + (doneToday ? 'Next session' : 'Up next') + ' · Session ' + (idx + 1) + ' of ' + sess.length + '</p><h2 class="title">' + esc(next.name) + '</h2><p class="mut sm">' + ex.length + ' exercises · about ' + mins + ' min · ' + G.t + '</p>' +
        '<ol class="prev">' + ex.slice(0, 5).map((e) => '<li><span>' + esc(UI.name(e.exId)) + '</span><span class="num mut">' + e.sets + ' × ' + (D.BY_ID[e.exId].time ? e.reps[0] + 's' : e.reps[0] + '–' + e.reps[1]) + '</span></li>').join('') + (ex.length > 5 ? '<li class="mut"><span>+ ' + (ex.length - 5) + ' more</span></li>' : '') + '</ol>' +
        (note ? '<p class="sm mut note-l">' + ic('info', 15) + ' ' + esc(note) + '</p>' : '') +
        '<div class="hero-b"><button class="btn lg ' + (doneToday ? 'alt' : '') + '" data-act="start">' + ic('play', 18) + ' ' + (doneToday ? 'Start anyway' : 'Start workout') + '</button>' + (sess.length > 1 ? '<button class="btn lg ghost" data-act="pick">Choose another</button>' : '') + '</div></div>';
    }

    // week card
    const wkStart = E.startOfWeek(now);
    const strip = D.DAY_NAMES.map((n, i) => { const d = E.addDays(wkStart, i), k = E.dkey(d), did = W.some((w) => w.d === k); return '<li class="' + (did ? 'did' : planned.includes(i) ? 'plan' : '') + (i === wd ? ' today' : '') + '"><span>' + n[0] + '</span><i>' + (did ? ic('check', 12) : '') + '</i></li>'; }).join('');
    const weekCard = '<div class="card week-c"><div class="week-top">' + C.ring(week.count / target, 92, week.count + '/' + target, 'this week') + '<div><h2 class="h3">Weekly workouts</h2><p class="sm mut">' + (week.count >= target ? 'Weekly target reached.' : target - week.count + ' more to hit your target of ' + target + '.') + '</p></div></div><ul class="strip" aria-label="This week">' + strip + '</ul></div>';

    // tiles
    const tiles = '<div class="tiles">' + tile(W.length, 'workouts completed') + tile(streak, streak === 1 ? 'week streak' : 'weeks streak', '<em title="Consecutive weeks you hit your weekly target">' + ic('flame', 14) + '</em>') + tile(totalVol ? UI.volNum(totalVol) : '0', UI.units() + ' total volume') + tile(prCount, 'personal records') + '</div>';

    // goal
    const goalCard = '<div class="card goal-c"><p class="lbl">Your goal</p><h2 class="h2">' + G.n + '</h2><p class="sm mut">' + G.h + '. ' + p.days + ' days a week, ' + esc(D.GEAR[p.gear].toLowerCase()) + '.</p><a class="link sm" href="#/plan">View programme</a></div>';

    // strength overview
    const bests = E.allBests(W), top = Object.keys(bests).sort((x, y) => bests[y].sessions - bests[x].sessions).slice(0, 3);
    const str = top.length ? '<ul class="lifts">' + top.map((id) => {
      const ser = E.exSeries(W, id), m = metricOf(ser), vals = ser.map((q) => q[m.k]), cur = vals[vals.length - 1], first = vals[0], dlt = cur - first;
      const ex = D.BY_ID[id], txt = dlt > 0.05 ? '<span class="up">+' + (m.k === 'reps' ? dlt + (ex.time ? ' sec' : ' reps') : UI.W(dlt)) + '</span> since first log' : vals.length < 2 ? 'One session logged' : 'Same as first log';
      return '<li><div class="lift-m"><b>' + esc(ex.name) + '</b><span class="sm mut">' + m.label + ' · ' + txt + '</span></div><div class="lift-r">' + C.spark(vals) + '<b class="num">' + (m.k === 'reps' ? cur + (ex.time ? 's' : '') : UI.W(cur)) + '</b></div></li>';
    }).join('') + '</ul>' : UI.empty('No lifts logged yet', 'Finish a workout and your strongest lifts will show up here with their trend.');
    const strCard = '<div class="card">' + sect('Strength progression', '<a class="link sm" href="#/progress">Details</a>') + str + '</div>';

    // PRs
    const prs = W.filter((w) => w.prs && w.prs.length).slice(-4).reverse().flatMap((w) => w.prs.map((q) => ({ q, d: w.d }))).slice(0, 4);
    const prCard = '<div class="card">' + sect('Personal records', '<a class="link sm" href="#/achievements">All</a>') + (prs.length ? '<ul class="prs">' + prs.map((x) => '<li class="pr-i"><span class="pr-ic">' + ic('trophy', 16) + '</span><div><b>' + esc(UI.name(x.q.exId)) + '</b><div class="sm mut">' + esc(prLine(x.q)) + ' · ' + UI.rel(x.d) + '</div></div></li>').join('') + '</ul>' : UI.empty('No records yet', 'When you beat your best on an exercise you have done before, it appears here.')) + '</div>';

    // chart
    const days = E.dayBuckets(W, now, 7);
    const chartCard = '<div class="card">' + sect('Last 7 days', '<span class="sm mut">Sets completed</span>') + '<div id="ch-week" class="ch-host"></div></div>';

    // recent
    const vis = UI.visible().slice(-5).reverse();
    const recent = '<div class="card">' + sect('Recent workouts', '<a class="link sm" href="#/history">History</a>') + (vis.length ? '<div class="rows">' + vis.map(rowWk).join('') + '</div>' : UI.empty('No workouts yet', 'Your first session starts above. It takes about ' + E.estMinutes(next) + ' minutes.')) + '</div>';

    // report teaser
    const rep = W.length ? (UI.can('report') ? '<a class="card tight link-c" href="#/report"><span class="lock-i blue">' + ic('report', 20) + '</span><div><b>Weekly progress report</b><p class="sm mut">See what improved this week and what to focus on next.</p></div>' + ic('right', 18) + '</a>' : UI.lock('Weekly progress report', 'Improvements, records, consistency and next-week advice, generated from your own training.', true)) : '';

    // meals (kept from the original app)
    const m = D.MEALS[p.goal], n = W.length % 3;
    const meals = '<details class="card meals"><summary><span class="h2">Eat for today</span>' + ic('right', 18, 'chev') + '</summary><div class="meal-l">' + Object.entries(m).map(([k, v]) => '<div class="meal"><span class="lbl">' + k + '</span><span>' + esc(v[n]) + '</span></div>').join('') + '</div><p class="sm mut tip">' + esc(D.TIPS[p.goal]) + ' Meals rotate each time you finish a workout.</p></details>';

    const html = '<header class="page-h"><p class="lbl">' + now.toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' }) + '</p><h1 class="title">' + hello + (p.name ? ', ' + esc(p.name) : '') + '</h1>' + (p.name ? '' : '<a class="link sm" href="#/settings">Add your name</a>') + '</header>' +
      '<div class="grid dash"><div class="g-hero">' + hero + '</div><div class="g-week">' + weekCard + '</div><div class="g-tiles">' + tiles + '</div><div class="g-chart">' + chartCard + '</div><div class="g-goal">' + goalCard + '</div><div class="g-str">' + strCard + '</div><div class="g-pr">' + prCard + '</div><div class="g-rec">' + recent + '</div><div class="g-side">' + rep + meals + '</div></div>';
    return {
      html, title: 'Today',
      after() { C.bars(document.getElementById('ch-week'), { data: days.map((b) => ({ label: b.start.toLocaleDateString(undefined, { weekday: 'short' }).slice(0, 3), value: b.sets, tip: b.sets + ' sets' + (b.count > 1 ? ' in ' + b.count + ' workouts' : '') })), hi: 6, h: 170, aria: 'Sets completed each day for the last 7 days. ' + days.map((b) => b.start.toLocaleDateString(undefined, { weekday: 'long' }) + ' ' + b.sets).join(', ') }); },
    };
  };
  A.pick = () => {
    const s = UI.st(), sess = s.plan.sessions, nx = s.planIdx % sess.length;
    UI.sheet(UI.sheetHead('Choose a session', 'Your rotation moves on from the one you pick.') + '<ul class="pick">' + sess.map((x, i) => '<li><button class="opt" data-act="start" data-idx="' + i + '"><span>' + esc(x.name) + (i === nx ? ' <span class="chip blue">Next in rotation</span>' : '') + '<small>' + x.exercises.length + ' exercises · about ' + E.estMinutes(x) + ' min</small></span>' + ic('right', 18) + '</button></li>').join('') + '</ul>', 'Choose a session');
  };

  /* ---- history ---------------------------------------------------------------- */
  V.history = function () {
    const n = UI.s.histN || 20, vis = UI.visible().slice().reverse(), hid = UI.hidden();
    const html = '<header class="page-h"><h1 class="title">History</h1><p class="mut">' + vis.length + ' workout' + (vis.length === 1 ? '' : 's') + (UI.can('history') ? '' : ' in the last ' + D.CONFIG.freeHistoryDays + ' days') + '</p></header>' +
      (vis.length ? '<div class="card"><div class="rows">' + vis.slice(0, n).map(rowWk).join('') + '</div>' + (vis.length > n ? '<button class="btn alt block" style="margin-top:12px" data-act="hist-more">Show more</button>' : '') + '</div>' : UI.empty('No workouts yet', 'Finished workouts will be listed here.', '<a class="btn" href="#/" style="margin-top:16px">Go to dashboard</a>')) +
      (hid > 0 ? '<div class="sect">' + UI.lock(hid + ' older workout' + (hid === 1 ? '' : 's') + ' hidden', 'Your data is safe on this device. Free shows the last ' + D.CONFIG.freeHistoryDays + ' days. Pro unlocks your full history.') + '</div>' : '');
    return { html, title: 'History' };
  };
  A['hist-more'] = () => { UI.s.histN = (UI.s.histN || 20) + 20; UI.render(true); };

  /* ---- achievements ------------------------------------------------------------- */
  V.achievements = function () {
    const s = UI.st(), W = s.workouts, p = s.profile, now = new Date();
    const streak = E.streakWeeks(W, p.days, now), best = E.bestStreakWeeks(W, p.days);
    const last4 = E.weekBuckets(W, now, 4), cons = Math.round((last4.reduce((t, b) => t + Math.min(b.count, p.days), 0) / (4 * p.days)) * 100);
    const bests = E.allBests(W), ids = Object.keys(bests).sort((x, y) => (bests[y].last > bests[x].last ? 1 : bests[y].last < bests[x].last ? -1 : bests[y].sessions - bests[x].sessions));
    const pr = ids.length ? '<div class="card"><div class="tbl-w"><table class="tbl"><thead><tr><th>Exercise</th><th>Heaviest</th><th>Best 1RM est.</th><th>Most reps</th></tr></thead><tbody>' + ids.map((id) => { const b = bests[id], ex = D.BY_ID[id]; return '<tr><td><b>' + esc(ex.name) + '</b><span class="sm mut"> ' + b.sessions + ' session' + (b.sessions > 1 ? 's' : '') + '</span></td><td class="num">' + (b.w ? UI.W(b.w.v) + ' × ' + b.w.r : '–') + '</td><td class="num">' + (b.e ? UI.W(b.e.v) : '–') + '</td><td class="num">' + (b.reps ? b.reps.v + (ex.time ? 's' : '') : '–') + '</td></tr>'; }).join('') + '</tbody></table></div></div>' : '<div class="card">' + UI.empty('No personal bests yet', 'Log a few workouts and your heaviest lifts, best rep counts and estimated 1RMs are tracked here automatically.') + '</div>';
    const groups = [['Workouts', 'workouts'], ['Consistency', 'streak'], ['Volume', 'volume'], ['Records', 'prs'], ['Progress', 'raised']];
    const ach = groups.map(([t, k]) => '<h3 class="h3 sect">' + t + '</h3><div class="ach-g">' + D.ACHIEVEMENTS.filter((a) => a.kind === k).map((a) => { const got = s.ach[a.id], pg = E.achievementProgress(a, s, now), f = Math.min(1, pg.cur / pg.n); return '<div class="card tight ach ' + (got ? 'got' : '') + '"><span class="ach-ic">' + ic(got ? 'check' : 'trophy', 18) + '</span><div><b>' + esc(a.name) + '</b><p class="xs mut">' + esc(a.desc) + '</p>' + (got ? '<p class="xs up">Unlocked ' + UI.rel(got) + '</p>' : '<div class="meter blue" style="margin-top:8px"><i style="width:' + (f * 100).toFixed(0) + '%"></i></div><p class="xs mut num" style="margin-top:4px">' + (k === 'volume' ? UI.volNum(pg.cur) + ' / ' + UI.volNum(pg.n) : Math.floor(pg.cur) + ' / ' + pg.n) + '</p>') + '</div></div>'; }).join('') + '</div>'; }).join('');
    const html = '<header class="page-h"><h1 class="title">Achievements</h1><p class="mut">Records and milestones from your own training.</p></header>' +
      '<div class="tiles">' + tile(W.length, 'total workouts') + tile(streak, 'week streak') + tile(best, 'best streak (weeks)') + tile(W.length ? cons + '%' : '–', 'consistency, 4 weeks') + '</div>' +
      '<h2 class="h2 sect">Personal bests</h2>' + pr + '<p class="xs mut" style="margin-top:8px">Estimated 1RM uses the Epley formula on sets of 12 reps or fewer. A streak is consecutive weeks where you hit your weekly target of ' + p.days + '.</p>' + '<h2 class="h2 sect">Milestones</h2>' + ach;
    return { html, title: 'Achievements' };
  };

  /* ---- weekly report -------------------------------------------------------------- */
  V.report = function () {
    const s = UI.st(), now = new Date();
    if (!UI.can('report')) {
      return { title: 'Weekly report', html: '<header class="page-h"><h1 class="title">Weekly report</h1><p class="mut">A summary of your training week, built from your own logs.</p></header>' + UI.lock('Weekly progress reports', 'Included with Repwise Pro.') + '<div class="card sect"><h2 class="h3">What you get each week</h2><ul class="bul"><li>Workouts completed and training volume</li><li>Exercises that improved and new personal records</li><li>Consistency over the last four weeks</li><li>Areas that need attention</li><li>Clear recommendations for the following week</li></ul></div>' };
    }
    const first = s.workouts.length ? E.startOfWeek(new Date(s.workouts[0].ts)) : E.startOfWeek(now), minOff = -Math.round(E.days(first, E.startOfWeek(now)) / 7);
    const off = Math.max(minOff, Math.min(0, UI.s.repOff || 0)); UI.s.repOff = off;
    const ws = E.addDays(E.startOfWeek(now), 7 * off), r = E.weeklyReport(s, ws, now);
    const fmtD = (d) => d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
    const dv = r.pvol > 0 && r.vol > 0 ? Math.round((r.vol / r.pvol - 1) * 100) : null;
    const imp = r.improved.map((x) => '<li><span class="pr-ic up">' + ic('up', 16) + '</span><div><b>' + esc(UI.name(x.exId)) + '</b><div class="sm mut num">' + (x.metric === 'reps' ? x.from + ' → ' + x.to + ' reps' : x.metric === 'time' ? x.from + ' → ' + x.to + ' sec' : (x.metric === 'e1rm' ? 'Est. 1RM ' : 'Top weight ') + UI.W(x.from) + ' → ' + UI.W(x.to)) + '</div></div></li>').join('');
    const html = '<header class="page-h"><p class="lbl">Weekly report</p><h1 class="title">' + fmtD(r.start) + ' – ' + fmtD(r.end) + '</h1><div class="wk-nav"><button class="btn sm alt" data-act="rep-prev" ' + (off <= minOff ? 'disabled' : '') + '>' + ic('left', 16) + ' Previous week</button><button class="btn sm alt" data-act="rep-next" ' + (off >= 0 ? 'disabled' : '') + '>Next week ' + ic('right', 16) + '</button></div>' + (off === 0 ? '<p class="sm mut" style="margin-top:8px">This week is still in progress.</p>' : '') + '</header>' +
      '<div class="tiles">' + tile(r.completed + '/' + r.target, 'workouts') + tile(UI.volNum(r.vol), UI.units() + ' volume', dv !== null ? '<em class="' + (dv >= 0 ? 'up' : 'down') + '">' + (dv >= 0 ? '+' : '') + dv + '% vs last week</em>' : '') + tile(r.sets, 'sets') + tile(r.dur ? Math.round(r.dur / 60) : 0, 'minutes trained') + '</div>' +
      '<div class="grid rep"><div class="card"><h2 class="h2">Consistency</h2><div class="cons">' + C.ring(r.cons, 96, Math.round(r.cons * 100) + '%', 'this week') + '<div><p class="sm">Four-week average</p><p class="num cons4">' + Math.round(r.cons4 * 100) + '%</p><p class="sm mut">of planned sessions completed</p></div></div></div>' +
      '<div class="card"><h2 class="h2">Exercises improved</h2>' + (imp ? '<ul class="prs">' + imp + '</ul>' : UI.empty(r.hasData ? 'Nothing beat your earlier best' : 'No workouts this week', r.hasData ? 'Hold your weights steady and add reps. Progress is not linear.' : 'Log a workout to see what improved.')) + '</div>' +
      '<div class="card"><h2 class="h2">New personal records</h2>' + (r.prs.length ? '<ul class="prs">' + r.prs.map((q) => '<li class="pr-i"><span class="pr-ic">' + ic('trophy', 16) + '</span><div><b>' + esc(UI.name(q.exId)) + '</b><div class="sm mut">' + esc(prLine(q)) + '</div></div></li>').join('') + '</ul>' : UI.empty('No new records', 'Records need an earlier session to beat.')) + '</div>' +
      '<div class="card"><h2 class="h2">Areas to improve</h2>' + (r.areas.length ? '<ul class="bul amber">' + r.areas.map((x) => '<li>' + esc(x) + '</li>').join('') + '</ul>' : '<p class="sm mut" style="margin-top:8px">Nothing stands out this week. Keep going.</p>') + '</div></div>' +
      '<div class="card sect"><h2 class="h2">Next week</h2><ul class="bul">' + r.recs.map((x) => '<li>' + esc(x.text) + '</li>').join('') + '</ul></div>';
    return { html, title: 'Weekly report' };
  };
  A['rep-prev'] = () => { UI.s.repOff = (UI.s.repOff || 0) - 1; UI.render(); };
  A['rep-next'] = () => { UI.s.repOff = Math.min(0, (UI.s.repOff || 0) + 1); UI.render(); };

  /* ---- more (mobile menu) ------------------------------------------------------------ */
  V.more = function () {
    const s = UI.st(), L = [['#/history', 'history', 'Workout history'], ['#/achievements', 'trophy', 'Achievements'], ['#/report', 'report', 'Weekly report', !UI.can('report')], ['#/settings', 'settings', 'Settings'], ['#/pricing', 'zap', 'Plans and pricing']];
    return { title: 'More', html: '<header class="page-h"><h1 class="title">More</h1><p class="mut">' + (s.profile.name ? esc(s.profile.name) + ' · ' : '') + (UI.pro() ? 'Repwise Pro preview' : 'Free plan') + '</p></header><div class="card"><div class="rows">' + L.map((x) => '<a class="row-b" href="' + x[0] + '"><span class="row-m row-i">' + ic(x[1], 20) + '<b>' + x[2] + '</b>' + (x[3] ? '<span class="pro-tag">PRO</span>' : '') + '</span>' + ic('right', 18) + '</a>').join('') + '</div></div>' };
  };
})();
