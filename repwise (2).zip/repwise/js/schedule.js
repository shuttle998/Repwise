// Planned training days and the status of every calendar day. Pure functions: nothing here touches the DOM or storage.
import { sortS, doneItems } from './analytics.js';
import { dateKey, parseKey, addDays, startOfWeek } from './util.js';
import { classDoneDates } from './classes.js';

const DEFAULT_DAYS = { 1: [0], 2: [0, 3], 3: [0, 2, 4], 4: [0, 1, 3, 4], 5: [0, 1, 2, 3, 4], 6: [0, 1, 2, 3, 4, 5] }; // 0 = Monday
export const defaultPlanDays = (n) => [...(DEFAULT_DAYS[Math.min(6, Math.max(1, n || 3))] || DEFAULT_DAYS[3])];
export const normPlanDays = (a) => (Array.isArray(a) ? [...new Set(a.map(Number).filter((n) => Number.isInteger(n) && n >= 0 && n <= 6))].sort() : null);
/** Planned weekdays (0=Mon..6=Sun): the user's choice if set, else a sensible spread for their weekly target. */
export const plannedDays = (state) => { const c = normPlanDays(state.reminders?.days); return c && c.length ? c : defaultPlanDays(state.profile?.days); };
export const weekdayOf = (d) => (d.getDay() + 6) % 7;

// A day with a logged class counts as a trained day for the calendar and the weekly target (it adds no sets, volume or XP).
const workoutsByDate = (state) => { const m = new Map(); sortS(state.sessions || []).filter((s) => doneItems(s).length).forEach((s) => (m.get(s.date) || m.set(s.date, []).get(s.date)).push(s)); classDoneDates(state).forEach((k) => { if (!m.has(k)) m.set(k, []); }); return m; };
const firstDay = (state, by) => { const a = [...by.keys()].sort()[0], c = state.profile?.createdAt ? dateKey(new Date(state.profile.createdAt)) : null; return [a, c].filter(Boolean).sort()[0] || null; };

/**
 * Status for each day in [startKey, endKey] (inclusive).
 * done = trained. today = today, nothing logged yet. upcoming = planned, still to come. missed = planned day that passed with no workout.
 * madeup = a planned day skipped but the week's extra workout covers it (not counted as missed). rest = nothing planned. before = before the user started.
 * Missed days are only ever shown after the plan existed, so a new user never starts with a wall of red.
 */
export function dayStatuses(state, startKey, endKey, now = new Date()) {
  const by = workoutsByDate(state), plan = new Set(plannedDays(state)), today = dateKey(now), first = firstDay(state, by), D = Math.max(1, state.profile?.days || 3), out = new Map();
  for (let w = startOfWeek(parseKey(startKey)); dateKey(w) <= endKey; w = addDays(w, 7)) {
    const days = Array.from({ length: 7 }, (_, i) => dateKey(addDays(w, i)));
    const trained = days.filter((k) => by.has(k)).length;
    const extras = days.filter((k, i) => by.has(k) && !plan.has(i)).length;
    let credit = extras; const done = days.filter((k) => by.has(k)).length;
    days.forEach((k, i) => {
      let status, planned = plan.has(i);
      if (by.has(k)) status = 'done';
      else if (first && k < first) status = 'before';
      else if (k === today) status = planned ? 'today' : 'rest';
      else if (k > today) status = planned ? 'upcoming' : 'rest';
      else if (planned) { if (credit > 0) { credit--; status = 'madeup'; } else status = 'missed'; }
      else status = 'rest';
      out.set(k, { date: k, status, planned, workouts: by.get(k) || [], weekStart: days[0], weekDone: trained, weekTarget: D });
    });
  }
  const r = new Map(); out.forEach((v, k) => { if (k >= startKey && k <= endKey) r.set(k, v); }); return r;
}
/** Monday-first month grid: 6 rows max of 7 cells, each {date, inMonth, ...status}. Also weekly rows with done/target. */
export function monthGrid(state, year, month, now = new Date()) {
  const first = new Date(year, month, 1), last = new Date(year, month + 1, 0), gs = startOfWeek(first), ge = addDays(startOfWeek(last), 6);
  const st = dayStatuses(state, dateKey(gs), dateKey(ge), now), weeks = [];
  for (let w = gs; w <= ge; w = addDays(w, 7)) {
    const cells = Array.from({ length: 7 }, (_, i) => { const d = addDays(w, i), k = dateKey(d); return { ...st.get(k), date: k, day: d.getDate(), inMonth: d.getMonth() === month }; });
    weeks.push({ start: dateKey(w), cells, done: cells[0].weekDone, target: cells[0].weekTarget, hit: cells[0].weekDone >= cells[0].weekTarget });
  }
  const inM = weeks.flatMap((w) => w.cells).filter((c) => c.inMonth);
  return { year, month, weeks, totals: { done: inM.filter((c) => c.status === 'done').length, missed: inM.filter((c) => c.status === 'missed').length, upcoming: inM.filter((c) => c.status === 'upcoming' || c.status === 'today' && c.planned).length, weeksHit: weeks.filter((w) => w.hit && w.cells.some((c) => c.inMonth)).length } };
}
/** The next planned training day on or after `from` that has no workout yet. */
export function nextPlanned(state, from = new Date()) {
  const by = workoutsByDate(state), plan = plannedDays(state);
  for (let i = 0; i < 14; i++) { const d = addDays(new Date(from.getFullYear(), from.getMonth(), from.getDate()), i), k = dateKey(d); if (plan.includes(weekdayOf(d)) && !by.has(k)) return { date: k, d, inDays: i }; }
  return null;
}

/** The next `n` planned sessions, in programme order, placed on the next planned days with no workout logged. Projection only: skipping a day shifts the order. */
export function upcomingSessions(state, n = 3, now = new Date()) {
  const sess = state.program?.sessions || []; if (!sess.length) return [];
  const by = workoutsByDate(state), plan = plannedDays(state), out = [], start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  for (let i = 0; i < 28 && out.length < n; i++) { const d = addDays(start, i), k = dateKey(d); if (!plan.includes(weekdayOf(d)) || by.has(k)) continue; const idx = ((state.cursor || 0) + out.length) % sess.length; out.push({ date: k, d, inDays: i, idx, name: sess[idx].name, count: sess[idx].items.length }); }
  return out;
}
