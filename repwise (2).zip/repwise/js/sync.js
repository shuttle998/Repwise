// Pure sync logic: what is synced, how two copies of your data merge, and how deletions are remembered.
// Nothing here touches the network or the DOM, so it is fully unit-tested.
//
// Model: collections (workouts, meals, water entries, body entries, custom exercises, saved programmes, imported activities)
// are merged by id, so two devices can both add data without losing any. Deletions are remembered as tombstones so a deleted
// item does not come back from another device. Single-value sections (profile, programme, settings, targets, reminders,
// favourites) take the copy that was changed most recently. An in-progress workout, photos and plan are never synced.

export const SECTIONS = {
  profile: { get: (s) => s.profile, set: (s, v) => { s.profile = v; } },
  training: { get: (s) => ({ program: s.program, cursor: s.cursor, working: s.working }), set: (s, v) => { s.program = v.program; s.cursor = v.cursor; s.working = v.working; } },
  settings: { get: (s) => { const { units, sound, vibrate, wakeLock } = s.settings || {}; return { units, sound, vibrate, wakeLock }; }, set: (s, v) => { s.settings = { ...s.settings, ...v }; } },
  targets: { get: (s) => ({ targets: s.nutrition?.targets, calc: s.nutrition?.calc, targetMl: s.water?.targetMl, bottleMl: s.water?.bottleMl }), set: (s, v) => { s.nutrition = { ...s.nutrition, targets: v.targets, calc: v.calc }; s.water = { ...s.water, targetMl: v.targetMl, bottleMl: v.bottleMl }; } },
  reminders: { get: (s) => s.reminders, set: (s, v) => { s.reminders = v; } },
  favs: { get: (s) => s.favs, set: (s, v) => { s.favs = v; } },
};
const COLLS = { sessions: 's', customExercises: 'c', programs: 'p', body: 'b', mealSaved: 't', activities: 'a' };
const NESTED = { meals: 'm', water: 'w' }; // date -> [items]
export const SECTION_KEYS = Object.keys(SECTIONS);
const TOMB_MAX = 2000, TOMB_DAYS = 365;

const clone = (x) => (x === undefined ? undefined : JSON.parse(JSON.stringify(x)));
const arr = (x) => (Array.isArray(x) ? x : []);

/** The syncable subset of local state, in the shape stored in the cloud. */
export function extract(st) {
  const d = { v: 1, sections: {}, sessions: arr(st.sessions), customExercises: arr(st.customExercises), programs: arr(st.programs), body: arr(st.body?.entries), mealSaved: arr(st.nutrition?.saved), activities: arr(st.activities), meals: st.nutrition?.log || {}, water: st.water?.log || {}, stamps: { ...(st.sync?.stamps || {}) }, tomb: { ...(st.sync?.tomb || {}) } };
  SECTION_KEYS.forEach((k) => { d.sections[k] = SECTIONS[k].get(st); });
  return clone(d);
}
/** Writes synced data into a state object (local-only fields such as the active workout are kept). */
export function inject(st, d) {
  SECTION_KEYS.forEach((k) => { if (d.sections?.[k] !== undefined && d.sections[k] !== null) SECTIONS[k].set(st, clone(d.sections[k])); });
  st.sessions = clone(d.sessions); st.customExercises = clone(d.customExercises); st.programs = clone(d.programs);
  st.body = { ...(st.body || {}), entries: clone(d.body) }; st.nutrition = { ...(st.nutrition || {}), saved: clone(d.mealSaved), log: clone(d.meals) }; st.water = { ...(st.water || {}), log: clone(d.water) };
  st.activities = clone(d.activities);
  st.sync = { ...(st.sync || {}), stamps: { ...d.stamps }, tomb: { ...d.tomb } };
  return st;
}

/** All synced item ids as 'kind:id' keys (used to notice deletions). */
export function idKeys(st) {
  const out = new Set();
  Object.entries(COLLS).forEach(([k, kind]) => { const list = k === 'body' ? st.body?.entries : k === 'mealSaved' ? st.nutrition?.saved : st[k]; arr(list).forEach((x) => x?.id && out.add(`${kind}:${x.id}`)); });
  const nest = (log, kind) => Object.values(log || {}).forEach((l) => arr(l).forEach((x) => x?.id && out.add(`${kind}:${x.id}`)));
  nest(st.nutrition?.log, 'm'); nest(st.water?.log, 'w');
  return out;
}
/** Adds tombstones for ids that were present before and are gone now. Returns the number added. */
export function recordDeletions(prev, st, now = Date.now()) {
  st.sync ||= {}; st.sync.tomb ||= {};
  const cur = idKeys(st); let n = 0;
  prev.forEach((k) => { if (!cur.has(k)) { st.sync.tomb[k] = now; n++; } });
  cur.forEach((k) => { if (st.sync.tomb[k]) delete st.sync.tomb[k]; }); // an id that is back is alive again
  pruneTomb(st.sync.tomb, now);
  return n;
}
export function pruneTomb(tomb, now = Date.now()) {
  const cut = now - TOMB_DAYS * 864e5, keys = Object.keys(tomb);
  keys.forEach((k) => { if (tomb[k] < cut) delete tomb[k]; });
  const left = Object.keys(tomb); if (left.length > TOMB_MAX) left.sort((a, b) => tomb[a] - tomb[b]).slice(0, left.length - TOMB_MAX).forEach((k) => delete tomb[k]);
  return tomb;
}
/** Updates change stamps for sections whose content changed since `prevJson` (a map section -> JSON string). Returns the new map. */
export function stampSections(st, prevJson, now = Date.now()) {
  st.sync ||= {}; st.sync.stamps ||= {}; const next = {};
  SECTION_KEYS.forEach((k) => { const j = JSON.stringify(SECTIONS[k].get(st) ?? null); next[k] = j; if (prevJson && prevJson[k] !== undefined && prevJson[k] !== j) st.sync.stamps[k] = now; });
  return next;
}

const sameJson = (a, b) => JSON.stringify(a) === JSON.stringify(b);
function unionById(local, remote, kind, tomb, preferLocal) {
  const out = new Map();
  const put = (x, mine) => { if (!x || x.id === undefined || x.id === null) return; const id = String(x.id); if (tomb[`${kind}:${id}`]) return; if (!out.has(id) || (mine && preferLocal)) { if (!out.has(id) || !sameJson(out.get(id), x)) out.set(id, x); } };
  arr(remote).forEach((x) => put(x, false)); arr(local).forEach((x) => put(x, true));
  return [...out.values()];
}
function unionNested(local, remote, kind, tomb, preferLocal) {
  const out = {}, days = new Set([...Object.keys(local || {}), ...Object.keys(remote || {})]);
  days.forEach((d) => { const l = unionById(local?.[d], remote?.[d], kind, tomb, preferLocal); if (l.length) out[d] = l; });
  return out;
}
/**
 * Merge two data objects (from extract()). Never drops an item that was not deliberately deleted.
 * `preferLocal` decides which copy wins when the same id exists on both sides with different content.
 */
export function merge(local, remote, { preferLocal = true } = {}) {
  if (!remote) return clone(local); if (!local) return clone(remote);
  const tomb = { ...(remote.tomb || {}) }; Object.entries(local.tomb || {}).forEach(([k, t]) => { tomb[k] = Math.max(tomb[k] || 0, t); });
  const stamps = {}, sections = {};
  SECTION_KEYS.forEach((k) => {
    const a = local.stamps?.[k] || 0, b = remote.stamps?.[k] || 0, lv = local.sections?.[k], rv = remote.sections?.[k];
    const takeLocal = lv !== undefined && lv !== null && (rv === undefined || rv === null || a > b || (a === b && preferLocal));
    sections[k] = takeLocal ? lv : rv; stamps[k] = Math.max(a, b);
  });
  const d = { v: 1, sections, stamps, tomb };
  d.sessions = unionById(local.sessions, remote.sessions, 's', tomb, preferLocal); d.customExercises = unionById(local.customExercises, remote.customExercises, 'c', tomb, preferLocal);
  d.programs = unionById(local.programs, remote.programs, 'p', tomb, preferLocal); d.body = unionById(local.body, remote.body, 'b', tomb, preferLocal);
  d.mealSaved = unionById(local.mealSaved, remote.mealSaved, 't', tomb, preferLocal); d.activities = unionById(local.activities, remote.activities, 'a', tomb, preferLocal);
  d.meals = unionNested(local.meals, remote.meals, 'm', tomb, preferLocal); d.water = unionNested(local.water, remote.water, 'w', tomb, preferLocal);
  pruneTomb(d.tomb); return clone(d);
}
export const sameData = (a, b) => { const strip = (d) => { const c = clone(d); if (!c) return c; const sortId = (l) => arr(l).sort((x, y) => String(x.id).localeCompare(String(y.id))); ['sessions', 'customExercises', 'programs', 'body', 'mealSaved', 'activities'].forEach((k) => { c[k] = sortId(c[k]); }); ['meals', 'water'].forEach((k) => Object.keys(c[k] || {}).forEach((d) => { c[k][d] = sortId(c[k][d]); })); return c; }; return sameJson(strip(a), strip(b)); };
/** True when there is anything worth uploading (used to decide whether a first sync needs a safety backup). */
export const hasUserData = (d) => !!(d && (d.sessions.length || d.body.length || Object.keys(d.meals).length || Object.keys(d.water).length || d.activities.length || d.customExercises.length || d.programs.length));
