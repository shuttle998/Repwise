import { MINDBODY } from './mindbody.js';
import { EXTRA } from './library-extra.js';
// Exercise library. Names of the original app's exercises are preserved so existing weights migrate.
export const MUSCLES = ['Chest', 'Back', 'Shoulders', 'Biceps', 'Triceps', 'Quads', 'Hamstrings', 'Glutes', 'Core', 'Calves'];
export const EQUIP = ['Barbell', 'Dumbbell', 'Machine', 'Cable', 'Bodyweight', 'Band', 'Cardio machine'];
export const TYPES = ['Compound', 'Isolation', 'Core', 'Glute activation', 'Warm-up', 'Stretching', 'Cardio', 'Mind-body'];
export const DIFFS = ['Beginner', 'Intermediate', 'Advanced'];
export const TIER_RANK = { bw: 0, db: 1, gym: 2 };
export const LIMITS = { knees: 'Knees', lowback: 'Lower back', shoulders: 'Shoulders', wrists: 'Wrists' };

const X = (id, name, o) => ({ id, name, unit: 'kg', stress: [], sm: [], step: 0, start: 0, ...o });

export const EXERCISES = [
  // ---------- squat pattern ----------
  X('squat-bb', 'Barbell squat', { slot: 'squat', tier: 'gym', equip: 'Barbell', type: 'Compound', diff: 'Intermediate', pm: ['Quads', 'Glutes'], sm: ['Hamstrings', 'Core'], start: 20, step: 2.5, stress: ['knees', 'lowback'],
    cue: 'Keep your chest up and knees over your toes.',
    steps: ['Set the bar across your upper back with feet about shoulder-width apart, toes turned out slightly.', 'Take a big breath, brace your core, then sit down and back.', 'Lower until your thighs are at least parallel to the floor, knees tracking over your toes.', 'Drive up through the middle of your foot, keeping your chest tall.'],
    mistakes: ['Knees caving inwards', 'Heels lifting off the floor', 'Rounding the lower back at the bottom', 'Cutting depth short as the weight gets heavy'], subs: ['goblet', 'legpress', 'bw-squat'] }),
  X('goblet', 'Goblet squat', { slot: 'squat', tier: 'db', equip: 'Dumbbell', type: 'Compound', diff: 'Beginner', pm: ['Quads', 'Glutes'], sm: ['Core'], start: 8, step: 1, stress: ['knees'],
    cue: 'Keep your chest up and knees over your toes.',
    steps: ['Hold one dumbbell vertically against your chest with both hands.', 'Stand with feet slightly wider than shoulder-width.', 'Sit straight down between your knees, elbows inside your knees.', 'Stand up by pushing the floor away.'],
    mistakes: ['Letting the dumbbell drift away from your chest', 'Leaning forward and folding at the waist', 'Heels coming off the floor'], subs: ['bw-squat', 'split-squat'] }),
  X('bw-squat', 'Bodyweight squat', { slot: 'squat', tier: 'bw', equip: 'Bodyweight', type: 'Compound', diff: 'Beginner', pm: ['Quads', 'Glutes'], sm: ['Core'], stress: ['knees'],
    cue: 'Keep your chest up and knees over your toes.',
    steps: ['Stand with feet shoulder-width apart, arms out in front for balance.', 'Push your hips back and bend your knees to sit down.', 'Go as deep as you can with a flat back and heels down.', 'Stand tall, squeezing your glutes at the top.'],
    mistakes: ['Knees collapsing inwards', 'Rushing the reps', 'Heels lifting'], subs: ['rev-lunge', 'glute-bridge'], harder: 'goblet' }),
  // ---------- lunge pattern ----------
  X('legpress', 'Leg press', { slot: 'lunge', tier: 'gym', equip: 'Machine', type: 'Compound', diff: 'Beginner', pm: ['Quads', 'Glutes'], sm: ['Hamstrings'], start: 40, step: 5, stress: ['knees'],
    steps: ['Sit with your back and hips flat against the pad, feet shoulder-width on the platform.', 'Release the safety handles and lower the platform until your knees reach about 90 degrees.', 'Press through your whole foot until your legs are almost straight, without locking the knees.'],
    mistakes: ['Letting your hips curl off the seat at the bottom', 'Locking out the knees hard', 'Placing feet too low so the knees travel far forward'], subs: ['split-squat', 'goblet', 'rev-lunge'] }),
  X('split-squat', 'Split squat', { slot: 'lunge', tier: 'db', equip: 'Dumbbell', type: 'Compound', diff: 'Beginner', pm: ['Quads', 'Glutes'], sm: ['Hamstrings', 'Core'], start: 6, step: 1, stress: ['knees'],
    steps: ['Stand in a long stride, front foot flat, back heel raised. Hold a dumbbell in each hand.', 'Lower straight down until your back knee almost touches the floor.', 'Press through the front foot to stand. Finish all reps, then switch legs.'],
    mistakes: ['Stance too short, so the front knee shoots forward', 'Leaning the torso forward', 'Bouncing off the bottom'], subs: ['rev-lunge', 'legpress'] }),
  X('rev-lunge', 'Reverse lunge', { slot: 'lunge', tier: 'bw', equip: 'Bodyweight', type: 'Compound', diff: 'Beginner', pm: ['Quads', 'Glutes'], sm: ['Hamstrings'], stress: ['knees'],
    steps: ['Stand tall with hands on your hips.', 'Step one foot back and lower until both knees are about 90 degrees.', 'Push through the front heel to return to standing. Alternate legs.'],
    mistakes: ['Taking too short a step', 'Front knee collapsing inwards', 'Pushing off the back foot instead of the front'], subs: ['bw-squat', 'stepup-bw'], harder: 'split-squat' }),
  X('walking-lunge', 'Walking lunge', { slot: 'lunge', tier: 'db', equip: 'Dumbbell', type: 'Compound', diff: 'Intermediate', pm: ['Quads', 'Glutes'], sm: ['Hamstrings', 'Core'], start: 6, step: 1, stress: ['knees'],
    steps: ['Hold a dumbbell in each hand at your sides.', 'Step forward and lower until both knees are about 90 degrees.', 'Drive through the front foot and step the back foot through into the next lunge.'],
    mistakes: ['Steps too short', 'Torso leaning forward', 'Letting the back knee crash into the floor'], subs: ['split-squat', 'rev-lunge'] }),
  X('bulg', 'Bulgarian split squat', { slot: 'bulg', tier: 'bw', equip: 'Dumbbell', type: 'Compound', diff: 'Advanced', pm: ['Quads', 'Glutes'], sm: ['Hamstrings', 'Core'], start: 6, step: 1, stress: ['knees'],
    cue: 'Keep most of your weight on the front leg.',
    tierCfg: { gym: { start: 8, step: 2 }, db: { start: 6, step: 1 }, bw: { start: 0, step: 0 } },
    steps: ['Stand about a stride in front of a bench and rest the top of your back foot on it.', 'Lower straight down until your front thigh is about parallel to the floor.', 'Drive up through the front heel. Complete all reps, then switch legs.'],
    mistakes: ['Front foot too close to the bench', 'Putting weight on the back foot', 'Torso collapsing forward'], subs: ['split-squat', 'rev-lunge', 'stepup-db'] }),
  X('stepup-db', 'Dumbbell step-up', { slot: 'stepup', tier: 'db', equip: 'Dumbbell', type: 'Compound', diff: 'Beginner', pm: ['Quads', 'Glutes'], sm: ['Hamstrings'], start: 8, step: 2, stress: ['knees'],
    steps: ['Hold a dumbbell in each hand and stand facing a sturdy bench or box.', 'Place one whole foot on the box and drive through that heel to stand up.', 'Lower under control. Finish all reps, then switch legs.'],
    mistakes: ['Pushing off the back foot', 'Using a box so high the knee goes past 90 degrees', 'Rushing the lowering phase'], subs: ['stepup-bw', 'split-squat'] }),
  X('stepup-bw', 'Step-up onto a sturdy chair', { slot: 'stepup', tier: 'bw', equip: 'Bodyweight', type: 'Compound', diff: 'Beginner', pm: ['Quads', 'Glutes'], sm: ['Hamstrings'], stress: ['knees'],
    steps: ['Use a stable chair or bench that will not slide.', 'Place one whole foot on it and drive through that heel to stand tall.', 'Step down with control and repeat, alternating or finishing one leg first.'],
    mistakes: ['Using an unstable chair', 'Pushing off the floor foot', 'Dropping down instead of lowering'], subs: ['rev-lunge', 'bw-squat'], harder: 'stepup-db' }),
  // ---------- push ----------
  X('bench', 'Bench press', { slot: 'push', tier: 'gym', equip: 'Barbell', type: 'Compound', diff: 'Intermediate', pm: ['Chest'], sm: ['Triceps', 'Shoulders'], start: 20, step: 2.5, stress: ['shoulders'],
    steps: ['Lie on the bench with eyes under the bar, feet planted, shoulder blades pulled together.', 'Unrack the bar and lower it to the middle of your chest with elbows about 45-60 degrees from your body.', 'Press the bar back up over your shoulders.'],
    mistakes: ['Flaring elbows straight out to the sides', 'Bouncing the bar off the chest', 'Lifting hips off the bench', 'Lifting without a spotter or safety arms'], subs: ['incline-db-press', 'db-floor-press', 'pushup'] }),
  X('incline-db-press', 'Incline dumbbell press', { slot: 'push', tier: 'db', equip: 'Dumbbell', type: 'Compound', diff: 'Intermediate', pm: ['Chest', 'Shoulders'], sm: ['Triceps'], start: 8, step: 1, stress: ['shoulders'],
    steps: ['Set a bench to a low incline (about 30 degrees) and sit with a dumbbell on each thigh.', 'Kick the dumbbells up to shoulder height, palms forward.', 'Press up until your arms are straight, then lower slowly to chest level.'],
    mistakes: ['Setting the bench too steep, turning it into a shoulder press', 'Letting the dumbbells drift wide', 'Arching the lower back'], subs: ['db-floor-press', 'pushup'] }),
  X('db-floor-press', 'Dumbbell floor press', { slot: 'push', tier: 'db', equip: 'Dumbbell', type: 'Compound', diff: 'Beginner', pm: ['Chest'], sm: ['Triceps', 'Shoulders'], start: 6, step: 1,
    steps: ['Lie on the floor with knees bent and a dumbbell in each hand over your chest.', 'Lower until your upper arms touch the floor, elbows about 45 degrees from your body.', 'Press the dumbbells back up until your arms are straight.'],
    mistakes: ['Bouncing the elbows off the floor', 'Letting wrists bend back', 'Flaring elbows wide'], subs: ['pushup', 'incline-db-press'] }),
  X('pushup', 'Push-up', { slot: 'push', tier: 'bw', equip: 'Bodyweight', type: 'Compound', diff: 'Beginner', pm: ['Chest'], sm: ['Triceps', 'Shoulders', 'Core'], stress: ['wrists', 'shoulders'],
    steps: ['Start in a high plank, hands just wider than shoulders, body in a straight line.', 'Lower your chest to just above the floor, elbows about 45 degrees from your body.', 'Press the floor away until your arms are straight. Drop to your knees if you cannot keep a straight line.'],
    mistakes: ['Sagging hips or piking up', 'Flaring the elbows out to 90 degrees', 'Only going halfway down'], subs: ['db-floor-press', 'close-pushup'], harder: 'incline-db-press' }),
  X('close-pushup', 'Close-grip push-up', { slot: 'arms', tier: 'bw', equip: 'Bodyweight', type: 'Compound', diff: 'Intermediate', pm: ['Triceps'], sm: ['Chest', 'Shoulders'], stress: ['wrists', 'shoulders'],
    steps: ['Start in a high plank with hands under your chest, close together.', 'Lower with elbows brushing your ribs.', 'Press back up to straight arms.'],
    mistakes: ['Hands too close, straining the wrists', 'Elbows flaring out', 'Hips sagging'], subs: ['pushup'] }),
  // ---------- pull ----------
  X('cablerow', 'Seated cable row', { slot: 'pull', tier: 'gym', equip: 'Cable', type: 'Compound', diff: 'Beginner', pm: ['Back'], sm: ['Biceps', 'Forearms'], start: 20, step: 2.5,
    steps: ['Sit tall with feet braced and a slight bend in your knees. Hold the handle with arms extended.', 'Pull the handle to your lower ribs, squeezing your shoulder blades together.', 'Return slowly until your arms are straight without rounding forward.'],
    mistakes: ['Rocking the torso back to heave the weight', 'Shrugging shoulders toward the ears', 'Letting the stack slam between reps'], subs: ['lat-pulldown', 'db-row', 'inv-row'] }),
  X('lat-pulldown', 'Lat pulldown', { slot: 'pull', tier: 'gym', equip: 'Cable', type: 'Compound', diff: 'Beginner', pm: ['Back'], sm: ['Biceps', 'Forearms'], start: 25, step: 2.5,
    steps: ['Sit with thighs secured under the pads and grip the bar just wider than shoulders.', 'Lean back slightly and pull the bar to your upper chest, driving elbows down.', 'Let the bar rise under control until your arms are straight.'],
    mistakes: ['Pulling the bar behind the neck', 'Leaning far back and swinging', 'Using only the arms'], subs: ['cablerow', 'db-row'] }),
  X('db-row', 'One-arm dumbbell row', { slot: 'pull', tier: 'db', equip: 'Dumbbell', type: 'Compound', diff: 'Beginner', pm: ['Back'], sm: ['Biceps', 'Forearms'], start: 8, step: 1,
    steps: ['Place one hand and the same-side knee on a bench, back flat, a dumbbell in the other hand.', 'Pull the dumbbell toward your hip, leading with your elbow.', 'Lower until your arm is straight. Finish all reps, then switch arms.'],
    mistakes: ['Twisting the torso to lift the weight', 'Pulling to the chest instead of the hip', 'Rounding the back'], subs: ['inv-row', 'cablerow'] }),
  X('inv-row', 'Inverted row under a table', { slot: 'pull', tier: 'bw', equip: 'Bodyweight', type: 'Compound', diff: 'Intermediate', pm: ['Back'], sm: ['Biceps', 'Core', 'Forearms'],
    steps: ['Use a very sturdy table. Lie under it and grip the edge with both hands.', 'Keep your body straight from heels to head, then pull your chest toward the table edge.', 'Lower slowly until your arms are straight.'],
    mistakes: ['Using a table that can slide or tip', 'Hips sagging', 'Pulling with the neck instead of the back'], subs: ['db-row'], harder: 'db-row' }),
  // ---------- hinge ----------
  X('rdl-bb', 'Romanian deadlift', { slot: 'hinge', tier: 'gym', equip: 'Barbell', type: 'Compound', diff: 'Intermediate', pm: ['Hamstrings', 'Glutes'], sm: ['Back', 'Core', 'Forearms'], start: 20, step: 2.5, stress: ['lowback'],
    cue: 'Keep your back flat and push your hips back.',
    steps: ['Stand holding the bar at your thighs, feet hip-width apart, soft knees.', 'Push your hips back, sliding the bar down your legs with a flat back.', 'Lower until you feel a strong hamstring stretch, usually just below the knee.', 'Drive your hips forward to stand tall.'],
    mistakes: ['Rounding the back', 'Bending the knees into a squat', 'Letting the bar drift away from the legs'], subs: ['db-rdl', 'leg-curl', 'sl-hinge'] }),
  X('db-rdl', 'Dumbbell Romanian deadlift', { slot: 'hinge', tier: 'db', equip: 'Dumbbell', type: 'Compound', diff: 'Beginner', pm: ['Hamstrings', 'Glutes'], sm: ['Back', 'Forearms'], start: 8, step: 1, stress: ['lowback'],
    cue: 'Keep your back flat and push your hips back.',
    steps: ['Hold a dumbbell in each hand in front of your thighs.', 'Push your hips back with a flat back, dumbbells sliding down your legs.', 'Lower until you feel a hamstring stretch, then drive your hips forward.'],
    mistakes: ['Rounding the back', 'Squatting instead of hinging', 'Dumbbells drifting forward'], subs: ['sl-hinge', 'glute-bridge'] }),
  X('sl-hinge', 'Single-leg hip hinge', { slot: 'hinge', tier: 'bw', equip: 'Bodyweight', type: 'Compound', diff: 'Intermediate', pm: ['Hamstrings', 'Glutes'], sm: ['Core'],
    cue: 'Keep your back flat and push your hips back.',
    steps: ['Stand on one leg with a soft knee, hands in front. Hold a wall or chair if you need balance.', 'Hinge at the hips, reaching your free leg back as your torso lowers.', 'Return to standing by squeezing your glute. Finish all reps, then switch legs.'],
    mistakes: ['Rotating the hips open', 'Rounding the back', 'Locking the standing knee'], subs: ['glute-bridge'], harder: 'db-rdl' }),
  X('deadlift', 'Deadlift', { slot: 'hinge', tier: 'gym', equip: 'Barbell', type: 'Compound', diff: 'Advanced', pm: ['Glutes', 'Hamstrings', 'Back'], sm: ['Quads', 'Core', 'Forearms'], start: 40, step: 5, stress: ['lowback'],
    steps: ['Stand with the bar over mid-foot, hinge down and grip just outside your legs.', 'Brace your core, pull the slack out of the bar, and push the floor away.', 'Stand tall with hips and knees locking out together, then lower the bar with control.'],
    mistakes: ['Rounding the lower back', 'Jerking the bar off the floor', 'Hips shooting up before the bar moves'], subs: ['rdl-bb', 'db-rdl'] }),
  X('leg-curl', 'Leg curl machine', { slot: 'hinge', tier: 'gym', equip: 'Machine', type: 'Isolation', diff: 'Beginner', pm: ['Hamstrings'], start: 15, step: 2.5,
    steps: ['Adjust the pad so it sits just above your heels and the pivot lines up with your knees.', 'Curl your heels toward your glutes.', 'Lower slowly until your legs are almost straight.'],
    mistakes: ['Lifting the hips off the pad', 'Swinging the weight', 'Cutting the lowering phase short'], subs: ['db-rdl', 'glute-bridge'] }),
  // ---------- overhead press ----------
  X('ohp-bb', 'Overhead press', { slot: 'ohp', tier: 'gym', equip: 'Barbell', type: 'Compound', diff: 'Intermediate', pm: ['Shoulders'], sm: ['Triceps', 'Core'], start: 20, step: 2.5, stress: ['shoulders', 'lowback'],
    steps: ['Hold the bar at collarbone height with hands just outside your shoulders.', 'Squeeze your glutes and brace your core, then press the bar straight up.', 'Move your head through once the bar passes your forehead and finish with the bar over your mid-foot.'],
    mistakes: ['Leaning back and turning it into an incline press', 'Pressing the bar out in front of you', 'Flared ribs'], subs: ['db-press', 'pike'] }),
  X('db-press', 'Dumbbell shoulder press', { slot: 'ohp', tier: 'db', equip: 'Dumbbell', type: 'Compound', diff: 'Beginner', pm: ['Shoulders'], sm: ['Triceps'], start: 5, step: 1, stress: ['shoulders'],
    steps: ['Sit or stand with a dumbbell in each hand at shoulder height, palms forward.', 'Press straight up until your arms are almost straight.', 'Lower to ear level with control.'],
    mistakes: ['Arching the lower back', 'Letting the dumbbells drift forward', 'Half-range reps'], subs: ['pike', 'lat-raise'] }),
  X('pike', 'Pike push-up', { slot: 'ohp', tier: 'bw', equip: 'Bodyweight', type: 'Compound', diff: 'Intermediate', pm: ['Shoulders'], sm: ['Triceps'], stress: ['shoulders', 'wrists'],
    steps: ['Start in a downward-dog position, hips high, hands shoulder-width.', 'Bend your elbows and lower the top of your head toward the floor between your hands.', 'Press back up to the start.'],
    mistakes: ['Hips dropping into a regular push-up', 'Elbows flaring wide', 'Landing on the head'], subs: ['pushup'], harder: 'db-press' }),
  X('lat-raise', 'Dumbbell lateral raise', { slot: 'ohp', tier: 'db', equip: 'Dumbbell', type: 'Isolation', diff: 'Beginner', pm: ['Shoulders'], start: 3, step: 1, stress: ['shoulders'],
    steps: ['Stand with a light dumbbell in each hand, slight bend in the elbows.', 'Raise your arms out to the sides until they reach shoulder height.', 'Lower slowly. Keep the weight light enough to stay controlled.'],
    mistakes: ['Swinging with the torso', 'Shrugging shoulders up', 'Lifting above shoulder height'], subs: ['db-press'] }),
  // ---------- glutes ----------
  X('hipthrust-bb', 'Barbell hip thrust', { slot: 'thrust', tier: 'gym', equip: 'Barbell', type: 'Compound', diff: 'Beginner', pm: ['Glutes'], sm: ['Hamstrings'], start: 40, step: 5,
    cue: 'Pause and squeeze at the top.',
    steps: ['Sit with your upper back against a bench and the bar (with a pad) across your hips.', 'Plant your feet so your shins are vertical at the top.', 'Drive through your heels until your hips are in line with your torso, tucking your chin.', 'Pause and squeeze your glutes, then lower under control.'],
    mistakes: ['Overarching the lower back at the top', 'Feet too far forward or back', 'Rushing without a pause'], subs: ['db-thrust', 'glute-bridge'] }),
  X('db-thrust', 'Dumbbell hip thrust', { slot: 'thrust', tier: 'db', equip: 'Dumbbell', type: 'Compound', diff: 'Beginner', pm: ['Glutes'], sm: ['Hamstrings'], start: 10, step: 2,
    cue: 'Pause and squeeze at the top.',
    steps: ['Sit with your upper back on a bench or sofa edge and a dumbbell on your hips.', 'Drive through your heels until your hips are in line with your torso.', 'Pause and squeeze, then lower slowly.'],
    mistakes: ['Overarching the lower back', 'Pushing through the toes', 'Rushing the squeeze'], subs: ['glute-bridge'] }),
  X('glute-bridge', 'Glute bridge', { slot: 'thrust', tier: 'bw', equip: 'Bodyweight', type: 'Compound', diff: 'Beginner', pm: ['Glutes'], sm: ['Hamstrings'],
    cue: 'Pause and squeeze at the top.',
    steps: ['Lie on your back with knees bent and feet flat, hip-width apart.', 'Press through your heels to lift your hips until your body forms a line from shoulders to knees.', 'Pause and squeeze, then lower slowly.'],
    mistakes: ['Pushing up with the lower back', 'Feet too far from the body', 'Not pausing at the top'], subs: ['sl-hinge'], harder: 'db-thrust' }),
  X('cable-kickback', 'Cable glute kickback', { slot: 'kick', tier: 'gym', equip: 'Cable', type: 'Isolation', diff: 'Beginner', pm: ['Glutes'], start: 10, step: 2.5,
    cue: 'Slow and controlled, no swinging.',
    steps: ['Attach an ankle strap and face the cable stack, holding the frame for balance.', 'Keeping your torso still, kick your leg back and up.', 'Squeeze at the top, then return slowly. Finish all reps, then switch legs.'],
    mistakes: ['Swinging the leg', 'Arching the lower back to get more range', 'Weight too heavy to control'], subs: ['donkey', 'glute-bridge'] }),
  X('db-sumo', 'Dumbbell sumo squat', { slot: 'kick', tier: 'db', equip: 'Dumbbell', type: 'Compound', diff: 'Beginner', pm: ['Glutes', 'Quads'], sm: ['Hamstrings'], start: 10, step: 2, stress: ['knees'],
    cue: 'Slow and controlled, no swinging.',
    steps: ['Stand with feet wide and toes turned out, holding one dumbbell hanging between your legs.', 'Sit straight down with knees tracking over your toes.', 'Stand up and squeeze your glutes at the top.'],
    mistakes: ['Knees falling in', 'Leaning forward', 'Shallow depth'], subs: ['goblet', 'donkey'] }),
  X('donkey', 'Donkey kick', { slot: 'kick', tier: 'bw', equip: 'Bodyweight', type: 'Isolation', diff: 'Beginner', pm: ['Glutes'], stress: ['wrists'],
    cue: 'Slow and controlled, no swinging.',
    steps: ['Start on hands and knees with a flat back.', 'Keeping your knee bent, press one foot toward the ceiling.', 'Squeeze at the top, lower slowly, and finish all reps before switching legs.'],
    mistakes: ['Arching the lower back', 'Swinging the leg', 'Twisting the hips'], subs: ['glute-bridge'] }),
  X('abduct', 'Hip abduction machine', { slot: 'abduct', tier: 'gym', equip: 'Machine', type: 'Isolation', diff: 'Beginner', pm: ['Glutes'], start: 20, step: 5,
    cue: 'Slow and controlled, no swinging.',
    steps: ['Sit upright with your back against the pad and legs inside the pads.', 'Push your knees apart against the resistance.', 'Return slowly without letting the weights crash.'],
    mistakes: ['Using momentum', 'Leaning far forward', 'Cutting the return short'], subs: ['side-leg-raise'] }),
  X('side-leg-raise', 'Side-lying leg raise', { slot: 'abduct', tier: 'bw', equip: 'Bodyweight', type: 'Isolation', diff: 'Beginner', pm: ['Glutes'],
    cue: 'Slow and controlled, no swinging.',
    steps: ['Lie on your side with your hips stacked and your bottom leg bent for balance.', 'Raise your top leg with the toes pointing forward.', 'Lower slowly. Finish all reps, then switch sides.'],
    mistakes: ['Rolling the hips backward', 'Swinging the leg', 'Lifting too high'], subs: ['donkey'] }),
  // ---------- arms ----------
  X('cable-curl', 'Cable curl', { slot: 'arms', tier: 'gym', equip: 'Cable', type: 'Isolation', diff: 'Beginner', pm: ['Biceps'], sm: ['Forearms'], start: 10, step: 2.5,
    steps: ['Stand facing the cable with elbows tucked by your sides.', 'Curl the handle up without moving your upper arms.', 'Lower slowly until your arms are straight.'],
    mistakes: ['Swinging the body', 'Elbows drifting forward', 'Dropping the weight on the way down'], subs: ['db-curl'] }),
  X('db-curl', 'Dumbbell curl', { slot: 'arms', tier: 'db', equip: 'Dumbbell', type: 'Isolation', diff: 'Beginner', pm: ['Biceps'], sm: ['Forearms'], start: 5, step: 1,
    steps: ['Stand with a dumbbell in each hand, palms forward and elbows by your sides.', 'Curl both dumbbells up to shoulder height.', 'Lower slowly to a full stretch.'],
    mistakes: ['Swinging from the hips', 'Elbows moving forward', 'Half reps'], subs: ['cable-curl'] }),
  X('triceps-pushdown', 'Triceps pushdown', { slot: 'arms', tier: 'gym', equip: 'Cable', type: 'Isolation', diff: 'Beginner', pm: ['Triceps'], start: 15, step: 2.5,
    steps: ['Stand facing a high cable with your elbows pinned to your sides.', 'Push the handle down until your arms are straight.', 'Let it rise slowly until your forearms are just past parallel to the floor.'],
    mistakes: ['Elbows flaring out', 'Leaning over the bar to push with body weight', 'Using momentum'], subs: ['close-pushup'] }),
  // ---------- core and calves ----------
  X('plank', 'Plank', { slot: 'core', tier: 'bw', equip: 'Bodyweight', type: 'Core', diff: 'Beginner', pm: ['Core'], unit: 'sec', reps: [30, 60],
    steps: ['Rest on your forearms with elbows under your shoulders and legs straight behind you.', 'Squeeze your glutes and abs so your body forms a straight line.', 'Breathe steadily and hold for the target time.'],
    mistakes: ['Hips sagging or piking', 'Holding your breath', 'Neck dropping or craning up'], subs: ['dead-bug'] }),
  X('dead-bug', 'Dead bug', { slot: 'core', tier: 'bw', equip: 'Bodyweight', type: 'Core', diff: 'Beginner', pm: ['Core'],
    steps: ['Lie on your back with arms pointing up and hips and knees bent to 90 degrees.', 'Press your lower back into the floor, then slowly extend the opposite arm and leg.', 'Return and switch sides.'],
    mistakes: ['Lower back arching off the floor', 'Moving too fast', 'Holding your breath'], subs: ['plank'] }),
  X('calf-raise', 'Standing calf raise', { slot: 'calves', tier: 'bw', equip: 'Bodyweight', type: 'Isolation', diff: 'Beginner', pm: ['Calves'], start: 0, step: 0, reps: [12, 20],
    steps: ['Stand on the edge of a step with your heels hanging off, holding a wall for balance.', 'Rise as high as you can on your toes.', 'Lower slowly below the step for a full stretch.'],
    mistakes: ['Bouncing', 'Short range of motion', 'Bending the knees'], subs: [] }),
];

EXERCISES.push(...EXTRA); // cardio, warm-ups, glute activation, stretches and extra lifts (see library-extra.js)
EXERCISES.push(...MINDBODY); // Pilates, yoga and mobility moves (slot 'mindbody': never picked by the programme generator)
export const BY_ID = Object.fromEntries(EXERCISES.map((e) => [e.id, e]));
export const exById = (id) => BY_ID[id];
export const available = (ex, gear) => TIER_RANK[gear] >= TIER_RANK[ex.tier];
export const isLoaded = (ex, gear) => ex.unit === 'kg' && cfgFor(ex, gear).step > 0;
export function cfgFor(ex, gear) {
  const o = ex.tierCfg?.[gear];
  return { start: o ? o.start : ex.start, step: o ? o.step : ex.step };
}
export const hasLimit = (ex, limits = []) => ex.stress.some((s) => limits.includes(s));

/** Candidate exercises per generator slot and equipment tier; the first entry is the default. */
export const SLOTS = {
  squat: { gym: ['squat-bb', 'goblet'], db: ['goblet', 'split-squat'], bw: ['bw-squat', 'rev-lunge'] },
  push: { gym: ['bench', 'incline-db-press'], db: ['db-floor-press', 'incline-db-press'], bw: ['pushup', 'close-pushup'] },
  pull: { gym: ['cablerow', 'lat-pulldown'], db: ['db-row'], bw: ['inv-row'] },
  hinge: { gym: ['rdl-bb', 'db-rdl'], db: ['db-rdl'], bw: ['sl-hinge'] },
  ohp: { gym: ['ohp-bb', 'db-press'], db: ['db-press'], bw: ['pike'] },
  lunge: { gym: ['legpress', 'walking-lunge'], db: ['split-squat', 'walking-lunge'], bw: ['rev-lunge'] },
  thrust: { gym: ['hipthrust-bb', 'db-thrust'], db: ['db-thrust'], bw: ['glute-bridge'] },
  bulg: { gym: ['bulg'], db: ['bulg'], bw: ['bulg'] },
  kick: { gym: ['cable-kickback'], db: ['db-sumo'], bw: ['donkey'] },
  abduct: { gym: ['abduct'], db: ['side-leg-raise'], bw: ['side-leg-raise'] },
  stepup: { gym: ['stepup-db'], db: ['stepup-db'], bw: ['stepup-bw'] },
  arms: { gym: ['cable-curl', 'triceps-pushdown'], db: ['db-curl'], bw: ['close-pushup'] },
  core: { gym: ['plank', 'dead-bug'], db: ['plank', 'dead-bug'], bw: ['plank', 'dead-bug'] },
  // Single-muscle slots used by the newer splits, body focus and long sessions. An empty list means "nothing for that equipment":
  // the generator then tries simpler equipment before giving up on the slot.
  calves: { gym: ['calf-raise', 'seated-calf-raise'], db: ['calf-raise'], bw: ['calf-raise'] },
  quadiso: { gym: ['leg-extension'], db: [], bw: [] },
  hamiso: { gym: ['leg-curl', 'lying-leg-curl', 'seated-leg-curl'], db: [], bw: [] },
  delts: { gym: ['lat-raise'], db: ['lat-raise'], bw: [] },
  biceps: { gym: ['cable-curl', 'db-curl'], db: ['db-curl'], bw: ['band-curl'] },
  triceps: { gym: ['triceps-pushdown'], db: ['db-triceps-ext'], bw: ['close-pushup', 'band-pushdown'] },
  forearm: { gym: ['wrist-curl', 'reverse-wrist-curl'], db: ['wrist-curl', 'reverse-wrist-curl'], bw: [] },
  abs: { gym: ['cable-crunch', 'reverse-crunch'], db: ['reverse-crunch'], bw: ['reverse-crunch'] },
  obliques: { gym: ['pallof-press', 'side-plank'], db: ['side-plank'], bw: ['side-plank'] },
  deadlift: { gym: ['deadlift'], db: [], bw: [] },
};

/** Original app's names by slot+gear, used to carry weights across during migration. */
export const LEGACY_NAMES = {
  squat: { gym: 'Barbell squat', db: 'Goblet squat' }, push: { gym: 'Bench press', db: 'Dumbbell floor press' },
  pull: { gym: 'Seated cable row', db: 'One-arm dumbbell row' }, hinge: { gym: 'Romanian deadlift', db: 'Dumbbell Romanian deadlift' },
  ohp: { gym: 'Overhead press', db: 'Dumbbell shoulder press' }, lunge: { gym: 'Leg press', db: 'Split squat' },
  thrust: { gym: 'Barbell hip thrust', db: 'Dumbbell hip thrust' }, bulg: { gym: 'Bulgarian split squat', db: 'Bulgarian split squat' },
  kick: { gym: 'Cable glute kickback', db: 'Dumbbell sumo squat' }, abduct: { gym: 'Hip abduction machine' },
  stepup: { gym: 'Dumbbell step-up', db: 'Dumbbell step-up' }, arms: { gym: 'Cable curl', db: 'Dumbbell curl' },
};

/** Substitutions: explicit list first, then other exercises in the same movement slot; annotated by equipment need. */
export function substitutes(ex, gear = 'gym', limits = []) {
  const seen = new Set([ex.id]); const out = [];
  const push = (id) => { const e = BY_ID[id]; if (e && !seen.has(id)) { seen.add(id); out.push(e); } };
  (ex.subs || []).forEach(push);
  activeExercises().filter((e) => e.slot === ex.slot).forEach((e) => push(e.id));
  return out.filter((e) => available(e, gear) && !hasLimit(e, limits));
}
/** Options for people who lack this exercise's equipment (lower equipment tiers). */
export const lowerEquipment = (ex) => substitutes(ex, 'gym').filter((e) => TIER_RANK[e.tier] < TIER_RANK[ex.tier]);


// ---------- library helpers (Phase 4) ----------
/** Exercises people can pick. Archived custom exercises stay in BY_ID so old workouts still resolve, but are hidden. */
export const activeExercises = () => EXERCISES.filter((e) => !e.archived);
export const LOCATIONS = { home: 'Home, no equipment', dumbbells: 'Home with dumbbells', gym: 'Gym' };
export const locationOf = (ex) => (ex.tier === 'bw' ? 'home' : ex.tier === 'db' ? 'dumbbells' : 'gym');

const SYN = { db: 'dumbbell', bb: 'barbell', rdl: 'romanian deadlift', ohp: 'overhead press', dl: 'deadlift', bw: 'bodyweight', pushup: 'push up', pullup: 'pull up' };
const MUSCLE_WORDS = { Quads: 'quadriceps quads legs', Hamstrings: 'hamstrings legs', Calves: 'calves legs', Core: 'core abs abdominals', Back: 'back lats', Shoulders: 'shoulders delts', Glutes: 'glutes butt', Forearms: 'forearms grip' };
const norm = (s) => String(s).toLowerCase().replace(/[-_/]/g, ' ').replace(/[^a-z0-9 ]/g, '').replace(/\s+/g, ' ').trim();
/** Ranked search: every word must match. Name matches rank above muscle matches, which rank above equipment/type matches.
 *  Understands abbreviations (db, rdl, ohp) and muscle words (abs, lats, quads). */
export function searchExercises(q, pool = activeExercises()) {
  const toks = norm(q).split(' ').filter(Boolean).flatMap((t) => (SYN[t] ? norm(SYN[t]).split(' ') : [t]));
  if (!toks.length) return pool;
  const out = [];
  for (const e of pool) {
    const name = norm(e.name), nw = name.split(' '), pm = norm(e.pm.map((m) => MUSCLE_WORDS[m] || m).join(' ')).split(' '), rest = norm([...e.sm.map((m) => MUSCLE_WORDS[m] || m), e.equip, e.type, e.diff].join(' ')).split(' ');
    let score = 0, ok = true;
    for (const t of toks) {
      if (nw.some((w) => w.startsWith(t))) score += name.startsWith(t) ? 8 : 5;
      else if (name.includes(t)) score += 3;
      else if (pm.some((w) => w.startsWith(t))) score += 3;
      else if (rest.some((w) => w.startsWith(t))) score += 1;
      else { ok = false; break; }
    }
    if (ok) out.push({ e, score });
  }
  return out.sort((a, b) => b.score - a.score || a.e.name.localeCompare(b.e.name)).map((x) => x.e);
}
export const search = (q) => searchExercises(q);

/** Alternatives ranked by how well they replace `ex` for this person. Each result explains itself. */
export function rankedSubstitutes(ex, { gear = 'gym', limits = [], level = 1, avoid = [], exclude = [], allow = null } = {}) {
  const out = [], dr = (e) => DIFFS.indexOf(e.diff);
  const lacksGear = !available(ex, gear), shortM = (a) => a.slice(0, 2).join(' and ').toLowerCase();
  for (const e of activeExercises()) {
    if (e.id === ex.id || exclude.includes(e.id) || avoid.includes(e.id) || !available(e, gear) || hasLimit(e, limits) || (allow && !allow.has(e.equip))) continue;
    if (isGuided(e) !== isGuided(ex)) continue; // a stretch is not a swap for a squat, or the reverse
    const shared = e.pm.filter((m) => ex.pm.includes(m)), sameSlot = ex.slot !== 'custom' && e.slot === ex.slot;
    if (!sameSlot && !shared.length) continue;
    let score = 0; const why = [];
    if (sameSlot) { score += 5; why.push('Same movement'); }
    if (shared.length) { score += 4 * (shared.length / ex.pm.length); why.push(`Works ${shortM(shared)}`); }
    if ((ex.subs || []).includes(e.id)) { score += 3; why.push('Suggested swap'); }
    if (e.type === ex.type) score += 1;
    if (dr(e) > level + 1) score -= 3; else if (dr(e) <= dr(ex)) score += 1;
    if (TIER_RANK[e.tier] < TIER_RANK[ex.tier]) { why.push(e.tier === 'bw' ? 'No equipment needed' : 'Dumbbells only'); if (lacksGear) score += 2; }
    if (hasLimit(ex, limits)) { score += 2; why.push('Avoids your ' + limits.filter((l) => ex.stress.includes(l)).map((l) => LIMITS[l].toLowerCase()).join(' and ')); }
    out.push({ ex: e, score, reasons: why.slice(0, 3) });
  }
  return out.sort((a, b) => b.score - a.score || a.ex.name.localeCompare(b.ex.name));
}

// ---------- custom exercises ----------
export const CUSTOM_PREFIX = 'c-';
/** Guided slots: warm-ups, activation, stretches, cardio and mind-body work. They are done for time or reps without a progression
 *  target, never count as personal bests or weekly muscle volume, and are never offered as swaps for a lift. */
export const GUIDED_SLOTS = new Set(['mindbody', 'warmup', 'activation', 'stretch', 'cardio']);
export const isGuided = (ex) => !!ex && GUIDED_SLOTS.has(ex.slot);
/** Timed exercises are tracked in seconds ('sec') or minutes ('min'). */
export const isTimed = (ex) => !!ex && (ex.unit === 'sec' || ex.unit === 'min');
/** Short unit suffix for ranges: "45s", "20 min", "" for reps. */
export const unitSuffix = (ex) => (ex?.unit === 'sec' ? 's' : ex?.unit === 'min' ? ' min' : '');
/** How much one tap of + or - changes the reps field. */
export const repStep = (ex) => (ex?.unit === 'sec' ? 5 : 1);
export const TRACKING = { kg: 'Weight × reps', reps: 'Reps only (bodyweight)', sec: 'Time in seconds' };
export const isCustom = (id) => String(id).startsWith(CUSTOM_PREFIX);
/** Validates a custom exercise form. Returns { error } or { ok: cleaned fields }. */
export function validateCustom(f, existing = [], selfId = null) {
  const name = String(f.name || '').trim().replace(/\s+/g, ' ');
  if (name.length < 2 || name.length > 40) return { error: 'Name must be 2 to 40 characters.' };
  if (EXERCISES.some((e) => e.id !== selfId && !e.archived && norm(e.name) === norm(name)) || existing.some((e) => e.id !== selfId && !e.archived && norm(e.name) === norm(name))) return { error: 'An exercise with that name already exists.' };
  if (!EQUIP.includes(f.equip)) return { error: 'Choose the equipment.' };
  const MUSC = [...MUSCLES, 'Forearms'], pm = (f.pm || []).filter((m) => MUSC.includes(m)), sm = (f.sm || []).filter((m) => MUSC.includes(m) && !pm.includes(m));
  if (!pm.length) return { error: 'Choose at least one main muscle.' };
  if (!TRACKING[f.unit]) return { error: 'Choose how it is tracked.' };
  const steps = (Array.isArray(f.steps) ? f.steps : String(f.steps || '').split('\n')).map((x) => String(x).trim().slice(0, 240)).filter(Boolean).slice(0, 10);
  return { ok: { name, equip: f.equip, type: TYPES.includes(f.type) ? f.type : 'Compound', diff: DIFFS.includes(f.diff) ? f.diff : 'Intermediate', pm, sm, unit: f.unit, steps } };
}
/** Builds a full exercise record from stored custom fields, with safe defaults for everything the app reads. */
export function buildCustom(c) {
  const tier = c.equip === 'Bodyweight' ? 'bw' : c.equip === 'Dumbbell' ? 'db' : 'gym';
  return { id: c.id, name: c.name, custom: true, archived: !!c.archived, slot: 'custom', tier, equip: c.equip, type: c.type, diff: c.diff, pm: c.pm, sm: c.sm || [], unit: c.unit === 'sec' ? 'sec' : 'kg', start: 0, step: c.unit === 'kg' ? 2.5 : 0, stress: [], reps: c.unit === 'sec' ? [30, 60] : undefined, trackReps: c.unit === 'reps',
    steps: c.steps?.length ? c.steps : ['Set up, then perform the movement with control through the full range.'], mistakes: [], subs: [], cue: 'Move with control and stop if anything hurts.', harder: '' };
}
/** Replaces all custom exercises in the shared lists. Call after load, import, reset and every edit. */
export function syncCustom(list = []) {
  for (let i = EXERCISES.length - 1; i >= 0; i--) if (isCustom(EXERCISES[i].id)) { delete BY_ID[EXERCISES[i].id]; EXERCISES.splice(i, 1); }
  list.forEach((c) => { const e = buildCustom(c); EXERCISES.push(e); BY_ID[e.id] = e; });
}
