// Thin Supabase client (auth + data) over fetch. No SDK, no build step. All network access for accounts lives here.
// Errors are normalised to Error objects with a friendly `message` and a machine `code`.
import { CONFIG } from './config.js';
import { storage } from './services.js';

const AUTH_KEY = 'repwise:auth';
const base = () => String(CONFIG.CLOUD?.url || '').replace(/\/+$/, '');
export const configured = () => !!(base() && CONFIG.CLOUD?.anonKey);

const err = (code, message, status) => Object.assign(new Error(message), { code, status });
const FRIENDLY = {
  invalid_credentials: 'Email or password is incorrect.', user_already_exists: 'An account with this email already exists. Try signing in.', email_exists: 'An account with this email already exists. Try signing in.',
  weak_password: 'Choose a stronger password (at least 8 characters).', email_not_confirmed: 'Confirm your email first. Check your inbox for the link we sent.',
  over_request_rate_limit: 'Too many attempts. Wait a minute and try again.', over_email_send_rate_limit: 'Too many emails sent. Wait a few minutes and try again.', signup_disabled: 'Sign-ups are turned off for this app.',
  same_password: 'Choose a password that is different from your current one.', validation_failed: 'Check the email address and try again.',
};
async function call(path, { method = 'GET', body, token, headers = {}, signal } = {}) {
  if (!configured()) throw err('not_configured', 'Cloud sync is not set up for this app yet.');
  let res;
  try { res = await fetch(base() + path, { method, signal, headers: { apikey: CONFIG.CLOUD.anonKey, 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}), ...headers }, body: body === undefined ? undefined : JSON.stringify(body) }); }
  catch (e) { throw err(e?.name === 'AbortError' ? 'aborted' : 'offline', 'Could not reach the server. Check your connection.'); }
  let data = null; const text = await res.text(); if (text) { try { data = JSON.parse(text); } catch { data = text; } }
  if (!res.ok) {
    const code = data?.error_code || data?.code || data?.error || String(res.status), raw = data?.msg || data?.message || data?.error_description || data?.error || '';
    const msg = FRIENDLY[data?.error_code] || FRIENDLY[code] || (res.status === 429 ? FRIENDLY.over_request_rate_limit : res.status >= 500 ? 'The server had a problem. Try again in a moment.' : raw || 'Something went wrong.');
    throw err(String(code), msg, res.status);
  }
  return data;
}

// ---- session ----
let cached; // parsed auth record
export function readAuth() { if (cached !== undefined) return cached; try { cached = JSON.parse(storage.get(AUTH_KEY) || 'null'); } catch { cached = null; } return cached; }
function writeAuth(a) { cached = a; if (a) storage.set(AUTH_KEY, JSON.stringify(a)); else storage.remove(AUTH_KEY); }
const fromSession = (s) => ({ access: s.access_token, refresh: s.refresh_token, exp: s.expires_at ? s.expires_at * 1000 : Date.now() + (s.expires_in || 3600) * 1000, user: { id: s.user?.id, email: s.user?.email } });
export const currentUser = () => readAuth()?.user || null;
export const signedIn = () => !!readAuth()?.access;

/** A valid access token, refreshed if it is about to expire. Signs out locally if the refresh token is rejected. */
export async function token() {
  const a = readAuth(); if (!a) throw err('signed_out', 'Sign in to sync.');
  if (a.exp - Date.now() > 60000) return a.access;
  try { const s = await call('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: { refresh_token: a.refresh } }); const n = fromSession(s); writeAuth(n); return n.access; }
  catch (e) { if (e.status === 400 || e.status === 401 || e.status === 403) { writeAuth(null); throw err('signed_out', 'Your session expired. Sign in again.'); } throw e; }
}

// ---- auth ----
export async function signUp(email, password) {
  const s = await call('/auth/v1/signup', { method: 'POST', body: { email: email.trim(), password } });
  if (s?.access_token) { writeAuth(fromSession(s)); return { confirmed: true }; }
  return { confirmed: false }; // email confirmation is on: the user must open the link we emailed
}
export async function signIn(email, password) { const s = await call('/auth/v1/token?grant_type=password', { method: 'POST', body: { email: email.trim(), password } }); writeAuth(fromSession(s)); return currentUser(); }
export async function signOut() { const a = readAuth(); writeAuth(null); if (a?.access && configured()) { try { await call('/auth/v1/logout', { method: 'POST', token: a.access }); } catch { /* local sign-out is what matters */ } } }
export const recover = (email, redirectTo) => call('/auth/v1/recover' + (redirectTo ? '?redirect_to=' + encodeURIComponent(redirectTo) : ''), { method: 'POST', body: { email: email.trim() } });
export async function updatePassword(password, accessToken) { await call('/auth/v1/user', { method: 'PUT', token: accessToken || (await token()), body: { password } }); }
/** Handles the links Supabase emails (confirm sign-up, password recovery): they arrive as #access_token=...&type=... */
export function consumeAuthHash(hash) {
  const h = String(hash || '').replace(/^#\/?/, ''); if (!/(^|&)access_token=/.test(h)) return null;
  const q = new URLSearchParams(h), access = q.get('access_token'), type = q.get('type') || '';
  if (!access) return null;
  let user = {}; try { const p = JSON.parse(atob(access.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))); user = { id: p.sub, email: p.email }; } catch { /* ignore */ }
  const rec = { access, refresh: q.get('refresh_token') || '', exp: Date.now() + (+q.get('expires_in') || 3600) * 1000, user };
  if (type === 'recovery') return { type, access, rec }; // not signed in until a new password is set
  writeAuth(rec); return { type: type || 'signup', access, rec };
}
export function adoptSession(rec) { writeAuth(rec); }

// ---- data (one row per user, guarded by a revision number) ----
const H = { Prefer: 'return=representation' };
export async function fetchRemote(signal) {
  const a = readAuth(), t = await token(); const rows = await call(`/rest/v1/user_data?select=data,rev,updated_at&user_id=eq.${a.user.id}`, { token: t, signal });
  return rows?.[0] || null;
}
/** Insert (no row yet) or update only if `rev` still matches. Returns {rev} or {conflict:true}. */
export async function pushRemote(data, rev, signal) {
  const a = readAuth(), t = await token();
  if (rev === null || rev === undefined) {
    try { const r = await call('/rest/v1/user_data', { method: 'POST', token: t, headers: H, body: { user_id: a.user.id, data, rev: 1 }, signal }); return { rev: r?.[0]?.rev ?? 1 }; }
    catch (e) { if (e.status === 409 || /duplicate|23505/.test(e.code)) return { conflict: true }; throw e; }
  }
  const r = await call(`/rest/v1/user_data?user_id=eq.${a.user.id}&rev=eq.${rev}`, { method: 'PATCH', token: t, headers: H, body: { data, rev: rev + 1 }, signal });
  return Array.isArray(r) && r.length ? { rev: r[0].rev } : { conflict: true };
}
export async function listBackups() { const a = readAuth(), t = await token(); return (await call(`/rest/v1/user_backups?select=id,created_at,rev&user_id=eq.${a.user.id}&order=created_at.desc&limit=10`, { token: t })) || []; }
export async function getBackup(id) { const t = await token(); const r = await call(`/rest/v1/user_backups?select=data,created_at&id=eq.${encodeURIComponent(id)}`, { token: t }); return r?.[0] || null; }
/** Permanently deletes the account and all cloud data (a SQL function in supabase/schema.sql). Local data stays on this device. */
export async function deleteAccount() { const t = await token(); await call('/rest/v1/rpc/delete_my_account', { method: 'POST', token: t, body: {} }); writeAuth(null); }
