// Exercise demonstration videos.
// Videos are third-party YouTube videos shown through YouTube's own embedded player
// (youtube-nocookie.com). Repwise does not copy, download or re-host any video, so the
// creators keep control of them, and the player's "Watch on YouTube" link credits the source.
// Nothing is requested from YouTube until the person taps play.
//
// Each entry: yt = YouTube video id, t = the video's title as listed by YouTube.
// To add or replace a video, change one line here. Exercises without an entry fall back to a
// YouTube search link, so a new exercise never shows a broken player.
import { esc } from './util.js';
import { icon } from './ui.js';
import { state } from './store.js';
import { animHTML, bindAnim, hasAnim } from './anim.js';

export const VIDEOS = {
  'squat-bb': { yt: '8PMjqgR8Wa8', t: 'How to Barbell Back Squat | A Tutorial for Beginners' },
  'goblet': { yt: 'JO7D6GJ98wY', t: 'How To Do A Goblet Squat Correctly' },
  'bw-squat': { yt: 'ZLJBfYF_oO0', t: 'Bodyweight Squat: How To (3 steps to proper form)' },
  'legpress': { yt: 'K5n2vg3oZa4', t: 'How to PROPERLY Leg Press' },
  'split-squat': { yt: 'Wcmg-3iHwjQ', t: 'Dumbbell Split Squat' },
  'rev-lunge': { yt: 'uHKgeIDSCYE', t: 'Bodyweight Step Back / Reverse Lunge' },
  'walking-lunge': { yt: 'I34ysEkPK7w', t: 'Dumbbell Walking Lunge - How To' },
  'bulg': { yt: 'VPhhE6bBzZE', t: 'How To Do Bulgarian Split Squats Correctly' },
  'stepup-db': { yt: '9ZknEYboBOQ', t: 'Dumbbell Step-up - How To' },
  'stepup-bw': { yt: 'z3otsAzOb-g', t: 'How to Do: Step-up onto Chair' },
  'bench': { yt: 'XFKZ6Yw8XbE', t: 'Beginner’s Guide to the Bench Press (Step-by-Step Exercise Tutorial)' },
  'incline-db-press': { yt: 'oZVCBM9f8Eo', t: 'How To Do A Dumbbell Incline Press' },
  'db-floor-press': { yt: 'T0Y3OBF1bNI', t: 'How To Do A Dumbbell Floor Press' },
  'pushup': { yt: 'mECzqUIDWfU', t: 'How to do a proper push-up' },
  'close-pushup': { yt: 'rG-rAMxA9Lo', t: 'How To: Close Grip Pushup' },
  'cablerow': { yt: 'lJoozxC0Rns', t: 'How To Do A Seated Cable Row' },
  'lat-pulldown': { yt: 'CAwf7n6Luuc', t: 'How To: Lat Pulldown' },
  'db-row': { yt: 'ZRSGpBUVcNw', t: 'How To Do Single Arm Dumbbell Rows' },
  'inv-row': { yt: '6NTruShwwKk', t: 'Stronger Back at Home! How to Do Inverted Rows with a Table' },
  'rdl-bb': { yt: 'u87dwyD3EL0', t: 'How to Do the Barbell Romanian Deadlift (RDL)' },
  'db-rdl': { yt: 'IJdUtnxAmNo', t: 'Dumbbell Romanian Deadlift' },
  'sl-hinge': { yt: 'KuAOYDj9KHI', t: 'Single Hip Hinge - Bodyweight Exercise' },
  'deadlift': { yt: 'ZaTM37cfiDs', t: 'How To Deadlift With Perfect Technique (Step By Step)' },
  'leg-curl': { yt: 'Z5pRnXaCjpM', t: 'Seated Leg Curl: How To' },
  'ohp-bb': { yt: '3VpI0V_9D0Y', t: 'How to Do the Standing Barbell Overhead Press' },
  'db-press': { yt: 'WKEl69bIGus', t: 'How to Do the Seated Dumbbell Shoulder Press' },
  'pike': { yt: 'XckEEwa1BPI', t: 'How to do a Pike Push-Up' },
  'lat-raise': { yt: 'OK1k6NdNo1I', t: 'Dumbbell Lateral Raise - Proper Form' },
  'hipthrust-bb': { yt: 'aweBS7K71l8', t: 'How To Do A Barbell Hip Thrust' },
  'db-thrust': { yt: '29OfN4ztW_g', t: 'Dumbbell Hip Thrust (FULL TUTORIAL) - Glute Exercises for Beginners' },
  'glute-bridge': { yt: 'Q_Bpj91Yiis', t: 'Glute Bridge Exercise - The correct way of doing it' },
  'cable-kickback': { yt: 'VSgMyiOu0uE', t: 'How to Do Cable Glute Kickbacks' },
  'db-sumo': { yt: 'vBA3vyOxJv0', t: 'Dumbbell Sumo Squat' },
  'donkey': { yt: 'SJ1Xuz9D-ZQ', t: 'Donkey Kicks' },
  'abduct': { yt: '5O_Y9l__iao', t: 'Seated Hip Abduction Machine: How To' },
  'side-leg-raise': { yt: '6kGfIGy2YGg', t: 'Side Lying Leg Lifts Movement Demo (Side Leg Raise)' },
  'cable-curl': { yt: '16aEi1a68E0', t: 'How to Do the Cable Biceps Curl With Perfect Form' },
  'db-curl': { yt: 'ykJmrZ5v0Oo', t: 'How to Do a Dumbbell Biceps Curl' },
  'triceps-pushdown': { yt: 'IBGvZUzoQiQ', t: 'How to Do Tricep Pushdowns Correctly' },
  'plank': { yt: '6LqqeBtFn9M', t: 'How to do the perfect PLANK: technique and common mistakes' },
  'dead-bug': { yt: '-gRN_JyVTLY', t: 'How To Do The Dead Bug Correctly' },
  'calf-raise': { yt: 'Uyg2QR1WAq8', t: 'Standing Bodyweight Calf Raise' },
};

export const hasVideo = (exId) => !!VIDEOS[exId];
const ID_RE = /^[\w-]{11}$/;
const watchUrl = (v) => `https://www.youtube.com/watch?v=${v.yt}`;
const searchUrl = (ex) => `https://www.youtube.com/results?search_query=${encodeURIComponent(ex.name + ' proper form')}`;

/** HTML for a demonstration card body. Call bindDemo(container) once after inserting it. */
export function demoHTML(ex) {
  if (!hasAnim(ex.id)) return ex.custom ? '<p class="mut">Custom exercises have no animation. Follow the steps you wrote for it.</p>' : videoHTML(ex);
  const v = VIDEOS[ex.id];
  return animHTML(ex) + (v && ID_RE.test(v.yt) ? `<details class="more" style="margin-top:12px"><summary>Also watch a real person do it (YouTube)</summary><div style="margin-top:10px">${videoHTML(ex)}</div></details>` : '');
}
function videoHTML(ex) {
  const v = VIDEOS[ex.id];
  if (!v || !ID_RE.test(v.yt)) {
    return `<p class="mut" style="margin-bottom:12px">There is no demonstration video for this exercise yet. Follow the steps below, or search for a form video from a coach you trust.</p><a class="btn small" href="${searchUrl(ex)}" target="_blank" rel="noopener noreferrer">${icon('external')} Search YouTube</a>`;
  }
  return `<div class="demo" data-yt="${v.yt}" data-name="${esc(ex.name)}">
    <div class="demo-frame"><button class="demo-poster" data-demo-play aria-label="Play demonstration: ${esc(ex.name)}"><span class="demo-play">${icon('play')}</span><span class="demo-cap">Watch the demonstration</span></button></div>
    <div class="demo-bar" hidden role="group" aria-label="Video controls">
      <button class="btn small" data-demo-cmd="play">${icon('play')} Play</button>
      <button class="btn small" data-demo-cmd="pause">${icon('pause')} Pause</button>
      <button class="btn small" data-demo-cmd="replay">Replay</button>
      <span class="demo-speed" role="group" aria-label="Speed"><button class="fchip" data-demo-rate="0.5" aria-pressed="false">0.5×</button><button class="fchip" data-demo-rate="0.75" aria-pressed="false">0.75×</button><button class="fchip" data-demo-rate="1" aria-pressed="true">1×</button></span>
    </div>
    <p class="hint demo-msg" aria-live="polite"></p>
    <p class="demo-src">${esc(v.t)}. <a class="link" href="${watchUrl(v)}" target="_blank" rel="noopener noreferrer">Watch on YouTube</a>. Video belongs to its creator; shown through YouTube’s player.</p>
  </div>`;
}

/** Wires up every .demo inside root. Safe to call more than once on new content. */
export function bindDemo(root) {
  bindAnim(root, { settings: state.settings });
  root.querySelectorAll('.demo:not([data-bound])').forEach((el) => {
    el.dataset.bound = '1';
    let frame = null, rate = 1;
    const send = (func, args = []) => frame?.contentWindow?.postMessage(JSON.stringify({ event: 'command', func, args }), 'https://www.youtube-nocookie.com');
    const msg = el.querySelector('.demo-msg');
    const load = () => {
      if (frame) return;
      if (!navigator.onLine) { msg.textContent = 'You are offline. Demonstrations need an internet connection; the written steps still work.'; return; }
      msg.textContent = 'Loading video…';
      const id = el.dataset.yt;
      const q = new URLSearchParams({ autoplay: 1, playsinline: 1, rel: 0, modestbranding: 1, loop: 1, playlist: id, enablejsapi: 1, origin: location.origin });
      frame = document.createElement('iframe');
      frame.src = `https://www.youtube-nocookie.com/embed/${id}?${q}`;
      frame.title = `Demonstration: ${el.dataset.name}`;
      frame.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
      frame.allowFullscreen = true; frame.referrerPolicy = 'strict-origin-when-cross-origin';
      frame.addEventListener('load', () => { msg.textContent = 'If the video does not play, use Watch on YouTube below.'; el.querySelector('.demo-bar').hidden = false; });
      el.querySelector('.demo-frame').replaceChildren(frame);
    };
    el.addEventListener('click', (e) => {
      if (e.target.closest('[data-demo-play]')) return load();
      const cmd = e.target.closest('[data-demo-cmd]')?.dataset.demoCmd;
      if (cmd === 'play') send('playVideo');
      if (cmd === 'pause') send('pauseVideo');
      if (cmd === 'replay') { send('seekTo', [0, true]); send('playVideo'); }
      const r = e.target.closest('[data-demo-rate]');
      if (r) { rate = parseFloat(r.dataset.demoRate); send('setPlaybackRate', [rate]); el.querySelectorAll('[data-demo-rate]').forEach((b) => b.setAttribute('aria-pressed', b === r)); }
    });
  });
}
