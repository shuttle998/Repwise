// "Recommended for this session": ranks exercises for a session from the person's profile and history. Pure: no DOM, no storage.
// Every suggestion carries the reason it was picked. Nothing here is invented: it only uses the library, your profile and your logged workouts.
import { activeExercises, available, hasLimit, isGuided } from './exercises.js';
import { equipOk, equipmentOf, FOCUS_MUSCLES } from './generator.js';

const UPPER = ['Chest', 'Back', 'Shoulders', 'Biceps', 'Triceps', 'Forearms'], LOWER = ['Quads', 'Hamstrings', 'Glutes', 'Calves'];
const groupOf = (m) => (UPPER.includes(m) ? 'upper' : LOWER.includes(m) ? 'lower' : 'core');

/**
 * @param {object} o profile, the session's current exerciseIds, recent (array of recent session item lists, newest first), favourites
 * @returns {{ex:object, why:string, score:number}[]} best first
 */
export function recommend({ profile = {}, sessionIds = [], recent = [], favourites = [], byId }, n = 8) {
  const eq = equipmentOf(profile), gear = profile.gear || 'gym', lim = profile.limits || [], avoid = profile.avoid || [], level = profile.level ?? 1;
  const inSession = sessionIds.map((id) => byId[id]).filter(Boolean);
  const trained = new Set(inSession.flatMap((e) => e.pm)), groups = new Set(inSession.flatMap((e) => e.pm.map(groupOf)).filter((g) => g !== 'core'));
  const focus = new Set((profile.focusMuscles || []).map((k) => FOCUS_MUSCLES[k]?.m).filter(Boolean));
  const recentSet = new Set(recent.slice(0, 2).flat());
  const out = [];
  for (const e of activeExercises()) {
    if (isGuided(e) || sessionIds.includes(e.id) || avoid.includes(e.id) || !available(e, gear) || !equipOk(e, eq) || hasLimit(e, lim)) continue;
    if (level === 0 && e.diff === 'Advanced') continue;
    if (groups.size && !e.pm.some((m) => groups.has(groupOf(m)) || groupOf(m) === 'core')) continue;
    let score = 0; const why = [];
    const fresh = e.pm.filter((m) => !trained.has(m));
    if (inSession.length && fresh.length) { score += 3 * fresh.length; why.push(`trains ${fresh.join(' and ').toLowerCase()}, which this session does not cover yet`); }
    const f = e.pm.filter((m) => focus.has(m));
    if (f.length) { score += 2.5; why.push(`matches your focus on ${f.join(' and ').toLowerCase()}`); }
    if (['strength', 'athletic', 'muscle', 'gain'].includes(profile.goal) && e.type === 'Compound') { score += 1.5; why.push('a big compound lift for your goal'); }
    if (['tone', 'endurance', 'general', 'fat'].includes(profile.goal) && e.type !== 'Core') score += 0.5;
    if (favourites.includes(e.id)) { score += 1; why.push('one of your favourites'); }
    if (recentSet.has(e.id)) { score -= 2; } else if (!inSession.length || recent.length) { score += 0.5; if (recent.length && !why.length) why.push('not in your last two sessions'); }
    if (score <= 0 && !why.length) continue;
    out.push({ ex: e, why: why.length ? why[0][0].toUpperCase() + why[0].slice(1) : 'Fits your equipment and goal', score });
  }
  return out.sort((a, b) => b.score - a.score || a.ex.name.localeCompare(b.ex.name)).slice(0, n);
}
