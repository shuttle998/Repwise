// Runs before first paint (classic script, no imports): applies the saved theme so the page never flashes the wrong colours.
(function () {
  try {
    var p = localStorage.getItem('repwise:theme'), r = p === 'light' ? 'light' : p === 'system' && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
    document.documentElement.dataset.theme = r; document.documentElement.style.colorScheme = r;
    var m = document.querySelector('meta[name="theme-color"]'); if (m) m.setAttribute('content', r === 'light' ? '#f4f6f7' : '#0b0d0e');
  } catch (e) { /* default dark */ }
})();
