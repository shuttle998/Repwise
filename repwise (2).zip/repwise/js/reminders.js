// Reminder settings, what is due, the in-app inbox and the calendar (.ics) export. Pure functions.
// Honest limit: a web page cannot wake your phone when it is closed. Reminders therefore fire while the app is open or in
// the background (and as a "you missed one" banner the next time you open it), and the .ics export gives you real OS-level alarms.
import { plannedDays, normPlanDays, weekdayOf } from './schedule.js';
import { doneItems } from './analytics.js';
import { dateKey, parseKey, addDays, startOfWeek } from './util.js';

const TIME = /^([01]\d|2[0-3]):[0-5]\d$/;
export const DEFAULT_REMINDERS = { enabled: false, days: null, time: '18:00', upcoming: false, upcomingTime: '19:00', summary: true, summaryDay: 6, summaryTime: '18:00', milestones: true, programme: true };
export const normReminders = (r) => {
  const o = r && typeof r === 'object' ? r : {}, d = DEFAULT_REMINDERS, t = (v, f) => (typeof v === 'string' && TIME.test(v) ? v : f), b = (v, f) => (typeof v === 'boolean' ? v : f);
  const sd = Number(o.summaryDay);
  return { enabled: b(o.enabled, d.enabled), days: normPlanDays(o.days)?.length ? normPlanDays(o.days) : null, time: t(o.time, d.time), upcoming: b(o.upcoming, d.upcoming), upcomingTime: t(o.upcomingTime, d.upcomingTime), summary: b(o.summary, d.summary), summaryDay: Number.isInteger(sd) && sd >= 0 && sd <= 6 ? sd : d.summaryDay, summaryTime: t(o.summaryTime, d.summaryTime), milestones: b(o.milestones, d.milestones), programme: b(o.programme, d.programme) };
};
export const normInbox = (a) => (Array.isArray(a) ? a.filter((n) => n && typeof n.title === 'string' && n.id).slice(0, 50).map((n) => ({ id: String(n.id), t: Number(n.t) || 0, kind: String(n.kind || 'info'), title: String(n.title).slice(0, 120), body: String(n.body || '').slice(0, 300), read: !!n.read })) : []);

const at = (key, hhmm) => { const [h, m] = hhmm.split(':').map(Number), d = parseKey(key); d.setHours(h, m, 0, 0); return d; };
const trainedOn = (state, key) => (state.sessions || []).some((s) => s.date === key && doneItems(s).length);
const WINDOW_MS = 12 * 36e5; // a reminder that is more than 12 hours late is no longer useful

/**
 * Reminders that should be shown now: their time has passed (within 12 h), they have not been delivered, and they respect rest days.
 * Workout reminders only fire on planned days and never once you have already trained. `delivered` is a Set/array of keys.
 */
export function dueReminders(state, now = new Date(), delivered = []) {
  const r = normReminders(state.reminders), done = new Set(delivered), out = [];
  if (!r.enabled) return out;
  const today = dateKey(now), plan = plannedDays({ ...state, reminders: r }), push = (key, kind, when, title, body) => { if (when <= now && now - when <= WINDOW_MS && !done.has(key)) out.push({ key, kind, at: when.getTime(), title, body }); };
  for (const off of [-1, 0]) { // yesterday evening can still be inside the 12 h window after midnight
    const day = addDays(parseKey(today), off), k = dateKey(day);
    if (plan.includes(weekdayOf(day)) && !trainedOn(state, k)) push(`w:${k}`, 'workout', at(k, r.time), 'Workout today', `Your session is planned for today. Even a short one counts.`);
    const nxt = addDays(day, 1), nk = dateKey(nxt);
    if (r.upcoming && plan.includes(weekdayOf(nxt)) && !trainedOn(state, nk)) push(`u:${nk}`, 'upcoming', at(k, r.upcomingTime), 'Workout tomorrow', `You have a session planned tomorrow. Get your kit and rest up.`);
    if (r.summary && weekdayOf(day) === r.summaryDay) push(`s:${dateKey(startOfWeek(day))}`, 'summary', at(k, r.summaryTime), 'Your weekly summary is ready', 'See how this week went in Reports.');
  }
  return out.sort((a, b) => a.at - b.at);
}
/** The next reminder time that will occur (for the "next reminder" line in settings). */
export function nextReminder(state, now = new Date()) {
  const r = normReminders(state.reminders); if (!r.enabled) return null;
  const plan = plannedDays({ ...state, reminders: r });
  for (let i = 0; i < 14; i++) { const day = addDays(parseKey(dateKey(now)), i), k = dateKey(day), when = at(k, r.time); if (plan.includes(weekdayOf(day)) && when > now && !(i === 0 && trainedOn(state, k))) return { kind: 'workout', when }; }
  return null;
}

const ICS_DAYS = ['MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU'];
const esc = (s) => String(s).replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/[,;]/g, (c) => '\\' + c);
const fold = (l) => { const out = []; let s = l; while (s.length > 74) { out.push(s.slice(0, 74)); s = ' ' + s.slice(74); } out.push(s); return out.join('\r\n'); };
const stamp = (d) => `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}T${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}00`;
const utc = (d) => d.toISOString().replace(/[-:]/g, '').replace(/\.\d+/, '');
/** An iCalendar file with weekly repeating workout events (each with a 10-minute-before alarm) and the weekly summary. Times are floating local time. */
export function buildICS(state, now = new Date()) {
  const r = normReminders(state.reminders), plan = plannedDays({ ...state, reminders: r }), mk = (idx, h) => { const d = addDays(startOfWeek(now), idx); const [hh, mm] = h.split(':').map(Number); d.setHours(hh, mm, 0, 0); return d; };
  const ev = (uid, d, mins, title, desc, rrule, alarm) => ['BEGIN:VEVENT', `UID:${uid}@repwise`, `DTSTAMP:${utc(now)}`, `DTSTART:${stamp(d)}`, `DTEND:${stamp(new Date(d.getTime() + mins * 6e4))}`, `RRULE:${rrule}`, `SUMMARY:${esc(title)}`, `DESCRIPTION:${esc(desc)}`, 'BEGIN:VALARM', 'ACTION:DISPLAY', `DESCRIPTION:${esc(title)}`, `TRIGGER:-PT${alarm}M`, 'END:VALARM', 'END:VEVENT'];
  const dur = Math.max(20, state.profile?.duration || 45), lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Repwise//Reminders//EN', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'X-WR-CALNAME:Repwise training'];
  plan.forEach((i) => lines.push(...ev(`workout-${i}`, mk(i, r.time), dur, 'Repwise workout', 'Your planned training session.', `FREQ=WEEKLY;BYDAY=${ICS_DAYS[i]}`, 10)));
  if (r.summary) lines.push(...ev('summary', mk(r.summaryDay, r.summaryTime), 15, 'Repwise weekly summary', 'Check how your week went.', `FREQ=WEEKLY;BYDAY=${ICS_DAYS[r.summaryDay]}`, 0));
  lines.push('END:VCALENDAR');
  return lines.map(fold).join('\r\n') + '\r\n';
}
