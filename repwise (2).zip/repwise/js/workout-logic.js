// Workout session domain logic: starting, logging, recommending, finishing. No DOM here.
import { state, mutate, isPro, units, uid, addNotice } from './store.js';
import { xpDelta } from './gamify.js';
import { resetHrSamples, hrSummary } from './hr.js';
import { BY_ID, cfgFor, isLoaded, available, hasLimit, isGuided } from './exercises.js';
import { ROUTINE_BY_ID } from './mindbody.js';
import { buildSessionPlan, cardioPlan } from './sessions.js';
import { equipmentOf } from './generator.js';
import { recommend, layoffAdjust, startWeight, LEVEL_MULT, e1rm } from './progression.js';
import { exerciseSessions, prEvents, achievements, sessionVolume, sessionSets } from './analytics.js';
import { dateKey, stepKg, roundTo, clamp, fmtW } from './util.js';

export const stepFor = (ex, gear = state.profile?.gear) => { const c = cfgFor(ex, gear); return stepKg(c.step, units()); };
export const loadedFor = (ex, gear = state.profile?.gear) => isLoaded(ex, gear);

/** Planned weight + rep target for an exercise right now, from progression state, layoff and defaults. */
export function plannedFor(exId, item, today = dateKey()) {
  const ex = BY_ID[exId], gear = state.profile?.gear || 'gym', c = cfgFor(ex, gear), step = stepFor(ex, gear), loaded = loadedFor(ex, gear);
  const hist = exerciseSessions(state.sessions, exId), last = hist[0] || null;
  const w0 = state.working[exId];
  let weight = 0, note = null, reasons = w0?.reasons || [], action = w0?.action || null, title = w0?.title || null;
  if (loaded) {
    if (w0?.w > 0) {
      weight = roundTo(w0.w, step) || w0.w;
      const adj = layoffAdjust(weight, last?.date || w0.date, today, step);
      if (adj.note) { weight = adj.weight; note = adj.note; }
    } else weight = startWeight(c.start, step, LEVEL_MULT[state.profile?.level ?? 0] || 1);
  }
  const repTarget = clamp(w0?.repTarget || item.repLo, item.repLo, item.repHi);
  return { weight, repTarget, note, reasons, action, title, last, first: !hist.length && !w0, step, loaded };
}

export function buildItem(exId, base) {
  const plan = plannedFor(exId, base);
  return { ...(base.phase ? { phase: base.phase } : {}), exId, origExId: exId, repLo: base.repLo, repHi: base.repHi, restSec: base.restSec, targetSets: base.sets, skipped: false, feedback: null, hurt: false, rec: null, plan,
    sets: Array.from({ length: base.sets }, () => ({ w: plan.weight, reps: plan.repTarget, done: false })) };
}

export function startWorkout(sessionIdx) {
  const prog = state.program; if (!prog) return;
  const s = prog.sessions[sessionIdx]; if (!s || !s.items.some((it) => BY_ID[it.exId])) return;
  resetHrSamples();
  mutate((st) => {
    const gear = st.profile?.gear || 'gym', plan = buildSessionPlan(s.items.filter((it) => BY_ID[it.exId]), st.settings.extras, { gear, limits: st.profile?.limits || [], equipment: equipmentOf(st.profile || {}) });
    st.active = { id: uid(), sessionIdx, programSessionId: s.id, name: s.name, note: s.note || '', startedAt: Date.now(), pausedAt: null, pausedMs: 0, pos: 0, rest: null, items: plan.map((it) => buildItem(it.exId, it)) };
  });
}

/** Starts a cardio-only session as a normal workout. It never moves your lifting programme forward. */
export function startCardio(exId, minutes) {
  const plan = cardioPlan(exId, Math.round(Number(minutes))); if (!plan.length || !(plan[0].repLo >= 1 && plan[0].repLo <= 180)) return false;
  resetHrSamples();
  mutate((st) => { st.active = { id: uid(), sessionIdx: null, programSessionId: null, routineId: 'cardio', name: BY_ID[exId].name, note: '', startedAt: Date.now(), pausedAt: null, pausedMs: 0, pos: 0, rest: null, items: plan.map((it) => buildItem(it.exId, it)) }; });
  return true;
}

/** Starts a ready-made Pilates, yoga or mobility routine as a normal workout. It never moves your lifting programme forward. */
export function startRoutine(routineId) {
  const r = ROUTINE_BY_ID[routineId]; if (!r) return false;
  const moves = r.moves.filter((m) => BY_ID[m.id]); if (!moves.length) return false;
  resetHrSamples();
  mutate((st) => { st.active = { id: uid(), sessionIdx: null, programSessionId: null, routineId: r.id, name: r.name, note: '', startedAt: Date.now(), pausedAt: null, pausedMs: 0, pos: 0, rest: null, items: moves.map((m) => buildItem(m.id, { repLo: m.secs, repHi: m.secs, sets: m.sets, restSec: r.restSec })) }; });
  return true;
}

export const elapsedMs = (a = state.active, now = Date.now()) => a ? now - a.startedAt - a.pausedMs - (a.pausedAt ? now - a.pausedAt : 0) : 0;
export const itemDone = (it) => it.sets.filter((s) => s.done).length;
export const itemComplete = (it) => !it.skipped && it.sets.length > 0 && it.sets.every((s) => s.done);

export function togglePause() {
  mutate((st) => {
    const a = st.active, now = Date.now(); if (!a) return;
    if (a.pausedAt) { a.pausedMs += now - a.pausedAt; if (a.rest?.pausedLeft != null) { a.rest.endsAt = now + a.rest.pausedLeft; a.rest.pausedLeft = null; } a.pausedAt = null; }
    else { a.pausedAt = now; if (a.rest?.endsAt) { a.rest.pausedLeft = Math.max(0, a.rest.endsAt - now); a.rest.endsAt = null; } }
  });
}
export function startRest(sec) { mutate((st) => { st.active.rest = { total: sec, endsAt: Date.now() + sec * 1000, pausedLeft: null }; }, { silent: true }); }
export function adjustRest(delta) { mutate((st) => { const r = st.active?.rest; if (!r) return; if (r.endsAt) r.endsAt = Math.max(Date.now() + 1000, r.endsAt + delta * 1000); r.total = Math.max(15, r.total + delta); }, { silent: true }); }
export function clearRest() { mutate((st) => { if (st.active) st.active.rest = null; }, { silent: true }); }
export const restLeft = (a = state.active, now = Date.now()) => !a?.rest ? 0 : a.rest.pausedLeft != null ? a.rest.pausedLeft / 1000 : a.rest.endsAt ? Math.max(0, (a.rest.endsAt - now) / 1000) : 0;

/** Does this set beat the stored history? Returns the PR kind or null. First time ever logging is a baseline, not a PR. */
export function livePR(exId, set, sessionsBefore = state.sessions) {
  const hist = exerciseSessions(sessionsBefore, exId); if (!hist.length) return null;
  if (isGuided(BY_ID[exId])) return null;
  const loaded = BY_ID[exId]?.unit === 'kg' && set.w > 0;
  let bw = 0, be = 0, br = 0;
  hist.forEach((h) => h.sets.forEach((x) => { bw = Math.max(bw, x.w || 0); be = Math.max(be, e1rm(x.w, x.reps)); br = Math.max(br, x.reps); }));
  if (loaded) { if (set.w > bw + 1e-6) return 'weight'; if (e1rm(set.w, set.reps) > be + 0.05) return 'e1rm'; return null; }
  return set.reps > br ? 'reps' : null;
}

/** Compute and attach a recommendation for one active item from what has been logged. */
export function recFor(it, historyOverride) {
  const ex = BY_ID[it.exId], gear = state.profile?.gear || 'gym', c = cfgFor(ex, gear);
  const hist = (historyOverride || exerciseSessions(state.sessions, it.exId)).map((h) => ({ date: h.date, sets: h.sets, feedback: h.feedback }));
  const done = it.sets.filter((s) => s.done && s.reps > 0).map((s) => ({ w: s.w, reps: s.reps }));
  const u = units();
  return recommend({
    cfg: { step: stepFor(ex, gear), unit: ex.unit, loaded: loadedFor(ex, gear), repLo: it.repLo, repHi: it.repHi, targetSets: it.targetSets },
    perf: { sets: done, feedback: it.feedback || undefined, hurt: it.hurt, plannedWeight: it.plan.weight },
    history: hist, opts: { advanced: isPro(), today: dateKey(), fmtW: (kg) => fmtW(kg, u, true) },
  });
}

export function setFeedback(pos, feedback) { mutate((st) => { const it = st.active.items[pos]; it.feedback = feedback; it.rec = recFor(it); }); }
export function setHurt(pos, on = true) { mutate((st) => { const it = st.active.items[pos]; it.hurt = on; it.rec = recFor(it); }); }

export function substitute(pos, newId) {
  mutate((st) => {
    const old = st.active.items[pos]; const base = { repLo: old.repLo, repHi: old.repHi, restSec: old.restSec, sets: old.targetSets };
    const ni = buildItem(newId, base); ni.origExId = old.origExId; st.active.items[pos] = ni;
  });
}
/** Swap an exercise inside the saved programme (used by the programme editor). */
export function swapInProgram(sessionId, idx, newId) {
  mutate((st) => { const s = st.program.sessions.find((x) => x.id === sessionId); if (s && s.items[idx]) s.items[idx].exId = newId; });
}

/** Finish the workout: write the session, update progression state, advance the programme, report PRs and achievements. */
export function finishWorkout() {
  const a = state.active; if (!a) return null;
  const now = Date.now(), end = new Date(now);
  const before = state.sessions.slice(), snap = { profile: state.profile, water: state.water, nutrition: state.nutrition };
  const prBefore = prEvents(before).length, achBefore = new Set(achievements({ sessions: before, profile: state.profile }).filter((x) => x.unlocked).map((x) => x.id));
  const items = [], recs = [];
  a.items.forEach((it) => {
    const done = it.sets.filter((s) => s.done && s.reps > 0).map((s) => ({ w: it.plan.loaded ? s.w : 0, reps: s.reps }));
    if (!done.length) { items.push({ exId: it.exId, name: BY_ID[it.exId].name, skipped: true, sets: [], targetSets: it.targetSets, repLo: it.repLo, repHi: it.repHi }); return; }
    const guided = isGuided(BY_ID[it.exId]), rec = guided ? null : recFor({ ...it, feedback: it.feedback }, exerciseSessions(before, it.exId));
    items.push({ exId: it.exId, name: BY_ID[it.exId].name, sets: done, feedback: it.feedback || null, hurt: it.hurt || undefined, targetSets: it.targetSets, repLo: it.repLo, repHi: it.repHi, ...(rec ? { action: rec.action } : {}), ...(it.phase && it.phase !== 'main' ? { phase: it.phase } : {}) });
    if (!a.routineId && !guided) recs.push({ exId: it.exId, name: BY_ID[it.exId].name, rec, loaded: it.plan.loaded, repLo: it.repLo, repHi: it.repHi, unit: BY_ID[it.exId].unit });
  });
  const session = { id: a.id, date: dateKey(new Date(a.startedAt)), startedAt: a.startedAt, endedAt: now, durationSec: Math.round(elapsedMs(a, now) / 1000), name: a.name, sessionIdx: a.sessionIdx, programSessionId: a.programSessionId, items };
  if (a.routineId) session.routineId = a.routineId;
  const hr = hrSummary(); if (hr) session.hr = hr;
  const hasWork = items.some((i) => !i.skipped);
  mutate((st) => {
    if (hasWork) {
      st.sessions.push(session);
      if (!a.routineId) recs.forEach((r) => { st.working[r.exId] = { w: r.rec.weight || 0, repTarget: r.rec.repTarget, action: r.rec.action, title: r.rec.title, reasons: r.rec.reasons, date: session.date, stalled: r.rec.stalled || undefined }; });
      if (!a.routineId) { const n = st.program?.sessions.length || 1; st.cursor = (a.sessionIdx + 1) % n; }
    }
    st.active = null;
  });
  if (!hasWork) return { empty: true };
  const after = state.sessions;
  const prs = prEvents(after).filter((e) => e.sid === session.id);
  const achAfter = achievements({ sessions: after, profile: state.profile }).filter((x) => x.unlocked && !achBefore.has(x.id));
  const xp = xpDelta({ ...snap, sessions: before }, { ...snap, sessions: after }, new Date(now));
  const on = state.reminders?.milestones !== false;
  if (on) {
    achAfter.forEach((x) => addNotice({ kind: 'milestone', key: 'ach:' + x.id, title: x.title, body: 'Achievement unlocked' }));
    if (xp.levelUp) addNotice({ kind: 'level', key: 'lvl:' + xp.level, title: `Level ${xp.level}: ${xp.summary.title}`, body: 'You levelled up from consistent training.' });
    xp.completed.forEach((c) => addNotice({ kind: 'challenge', key: 'ch:' + c.id, title: 'Challenge complete', body: `${c.title} (+${c.xp} XP)` }));
  }
  return { session, volume: sessionVolume(session), sets: sessionSets(session), recs, prs, newAchievements: achAfter, prCountBefore: prBefore, xp, routine: !!a.routineId };
}

export function discardWorkout() { mutate((st) => { st.active = null; }); }
export { available, hasLimit };

// ---------- editing the running workout (add, remove, reorder, adjust) ----------
const clampN = (v, lo, hi) => Math.min(hi, Math.max(lo, Math.round(+v) || lo));
/** Add an exercise to the end of the running workout, with sets, reps and rest chosen from the exercise and the user's profile. */
export function addToActive(exId) {
  const ex = BY_ID[exId]; if (!ex || !state.active) return -1;
  const guided = isGuided(ex), timed = ex.unit === 'sec' || ex.unit === 'min';
  const base = { sets: guided ? 1 : (state.profile?.params?.sets || 3), repLo: ex.reps?.[0] || (timed ? (ex.unit === 'min' ? 5 : 30) : (state.profile?.params?.repLo || 8)), repHi: ex.reps?.[1] || (timed ? (ex.unit === 'min' ? 10 : 45) : (state.profile?.params?.repHi || 12)), restSec: guided ? 30 : (state.profile?.params?.restSec || 90) };
  mutate((st) => { st.active.items.push(buildItem(exId, base)); });
  return state.active.items.length - 1;
}
/** Remove an exercise. Refuses to leave the workout empty. Returns false when nothing changed. */
export function removeFromActive(pos) {
  if (!state.active || state.active.items.length < 2 || !state.active.items[pos]) return false;
  mutate((st) => { st.active.items.splice(pos, 1); st.active.pos = Math.min(st.active.pos || 0, st.active.items.length - 1); });
  return true;
}
/** Move an exercise up (-1) or down (+1). Returns the new index. */
export function moveInActive(pos, dir) {
  const n = state.active?.items.length || 0, to = pos + dir; if (to < 0 || to >= n) return pos;
  mutate((st) => { const a = st.active.items; [a[pos], a[to]] = [a[to], a[pos]]; });
  return to;
}
/** Change sets, rep range and rest for one exercise. Completed sets are never removed. */
export function setItemParams(pos, { sets, repLo, repHi, restSec } = {}) {
  const it = state.active?.items[pos]; if (!it) return;
  mutate((st) => {
    const x = st.active.items[pos];
    if (repLo != null || repHi != null) { let lo = clampN(repLo ?? x.repLo, 1, 600), hi = clampN(repHi ?? x.repHi, 1, 600); if (hi < lo) hi = lo; x.repLo = lo; x.repHi = hi; x.sets.forEach((s) => { if (!s.done) s.reps = clamp(s.reps, lo, hi); }); }
    if (restSec != null) x.restSec = clampN(restSec, 0, 600);
    if (sets != null) {
      const want = clampN(sets, 1, 12), doneN = x.sets.filter((s) => s.done).length, target = Math.max(want, doneN);
      while (x.sets.length < target) { const l = x.sets[x.sets.length - 1] || { w: x.plan.weight, reps: x.plan.repTarget }; x.sets.push({ w: l.w, reps: l.reps, done: false }); }
      while (x.sets.length > target) { const i = x.sets.map((s) => s.done).lastIndexOf(false); if (i < 0) break; x.sets.splice(i, 1); }
      x.targetSets = x.sets.length;
    }
  });
}
