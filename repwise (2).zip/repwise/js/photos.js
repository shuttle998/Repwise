// Private progress photos. Stored only in this browser's IndexedDB; never uploaded, never part of the
// JSON export. Photos are shrunk to at most 1280px on the long side before saving.
const DB = 'repwise-photos', STORE = 'photos', MAX_PHOTOS = 60, MAX_SIDE = 1280;
const open = () => new Promise((res, rej) => {
  if (!('indexedDB' in window)) return rej(new Error('unsupported'));
  const r = indexedDB.open(DB, 1);
  r.onupgradeneeded = () => r.result.createObjectStore(STORE, { keyPath: 'id' });
  r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error || new Error('open failed'));
});
const tx = async (mode, fn) => { const db = await open(); return new Promise((res, rej) => { const t = db.transaction(STORE, mode), out = fn(t.objectStore(STORE)); t.oncomplete = () => { db.close(); res(out?.result); }; t.onerror = t.onabort = () => { db.close(); rej(t.error || new Error('transaction failed')); }; }); };

export const photosAvailable = () => 'indexedDB' in window;
export const listPhotos = async () => ((await tx('readonly', (s) => s.getAll())) || []).sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.createdAt - a.createdAt));
export const deletePhoto = (id) => tx('readwrite', (s) => s.delete(id));
export const clearPhotos = () => tx('readwrite', (s) => s.clear());

async function shrink(file) {
  const bmp = await createImageBitmap(file).catch(() => null); if (!bmp) throw new Error('That file is not an image this browser can read.');
  const k = Math.min(1, MAX_SIDE / Math.max(bmp.width, bmp.height)), w = Math.round(bmp.width * k), h = Math.round(bmp.height * k);
  const c = document.createElement('canvas'); c.width = w; c.height = h; c.getContext('2d').drawImage(bmp, 0, 0, w, h); bmp.close?.();
  const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.85)); if (!blob) throw new Error('Could not process the image.');
  return { blob, w, h };
}
export async function addPhoto(file, date) {
  if (!file || !/^image\//.test(file.type)) throw new Error('Choose an image file.');
  if ((await listPhotos()).length >= MAX_PHOTOS) throw new Error(`You can keep up to ${MAX_PHOTOS} photos. Delete some first.`);
  const { blob, w, h } = await shrink(file), id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  try { await tx('readwrite', (s) => s.put({ id, date, blob, w, h, createdAt: Date.now() })); }
  catch (e) { throw new Error(e?.name === 'QuotaExceededError' ? 'Your browser has no space left for photos.' : 'Could not save the photo on this device.'); }
  return id;
}
