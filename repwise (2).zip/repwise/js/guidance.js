// Breathing and safety guidance. Written per movement pattern (the app's `slot`) so every
// exercise, including ones added later, gets sensible guidance without per-exercise copy.
// General training advice, not medical advice.
import { LIMITS } from './exercises.js';
import { MIND_BREATH } from './mindbody.js';

const IN_OUT = 'Breathe in on the way down, breathe out as you push or lift. Never hold your breath for the whole rep.';
const BREATH = {
  squat: 'Breathe in and brace your core at the top, hold that brace as you lower, then breathe out as you stand up.',
  lunge: IN_OUT,
  bulg: IN_OUT,
  stepup: 'Breathe out as you step up, breathe in as you lower back down.',
  push: IN_OUT,
  arms: 'Breathe out as you curl or press, breathe in as you return. Keep it steady.',
  pull: 'Breathe out as you pull toward you, breathe in as you let the weight return under control.',
  hinge: 'Breathe in and brace as you hinge back, breathe out as you drive the hips forward to stand.',
  ohp: 'Breathe in at the start, breathe out as you press or raise. Do not hold your breath through the effort.',
  thrust: 'Breathe in at the bottom, breathe out as you lift your hips and squeeze.',
  kick: 'Breathe out as you push or kick, breathe in as you return.',
  abduct: 'Breathe out as you open or lift, breathe in as you return slowly.',
  core: 'Breathe steadily. Do not hold your breath; use slow breaths while you keep your core tight.',
  calves: 'Breathe out as you rise onto your toes, breathe in as you lower.',
  mindbody: MIND_BREATH,
  warmup: 'Breathe easily and move smoothly. Start small and build the range as you loosen up.',
  activation: 'Breathe out as you squeeze or lift, breathe in as you return. Feel the glutes working, not the lower back.',
  stretch: 'Breathe slowly and let each breath out ease you a little deeper. Stay at a gentle stretch, never sharp pain. Do not bounce.',
  cardio: 'Breathe steadily. Aim for a pace where you can speak in short sentences, and slow down if you feel dizzy or unwell.',
};
const EQUIP_SAFETY = {
  Barbell: 'Set the safety arms or pins, or train with a spotter, for any lift where the bar could trap you. Check the collars are on.',
  Dumbbell: 'Clear the space around you and lower the dumbbells under control rather than dropping them.',
  Machine: 'Adjust the seat and pads to your body before the first rep and set the stops so the range is comfortable.',
  Cable: 'Check the attachment is clipped in, and step back with control so the stack never slams.',
  Band: 'Check the band for nicks or tears before each use, and keep it anchored so it cannot snap back at you.',
  'Cardio machine': 'Clip on the safety key if there is one, start slowly, and hold the rails only for balance. Step off only once the machine has stopped.',
  Bodyweight: 'Use a non-slip surface. Make the move easier (shorter range, support) if you cannot keep good form.',
};
const GENERAL = 'Warm up with lighter sets first. Stop the set if you feel sharp or joint pain, or if your form breaks down.';

export const breathing = (ex) => BREATH[ex.slot] || IN_OUT;
export function safety(ex, userLimits = []) {
  const out = [EQUIP_SAFETY[ex.equip] || '', GENERAL].filter(Boolean);
  const loads = (ex.stress || []).filter((s) => LIMITS[s]);
  if (loads.length) out.push(`This loads your ${loads.map((s) => LIMITS[s].toLowerCase()).join(' and ')}${loads.some((s) => userLimits.includes(s)) ? ', which you listed as a limitation. Go lighter or pick an alternative below if it bothers you' : '. Check with a professional first if you have pain there'}.`);
  return out;
}
