// Central product configuration. Change values here, not in views.
export const CONFIG = {
  APP_NAME: 'Repwise',
  STORAGE_KEY_V1: 'repwise',        // original single-file app
  STORAGE_KEY: 'repwise:v2',
  SCHEMA_VERSION: 2,

  // Flip to true only once a real payment provider is wired up in js/services.js.
  // While false, Pro can be previewed on this device (Settings > Plan) and nothing is charged.
  PAYMENTS_LIVE: false,

  // Display prices. Set these to your real launch pricing before going live.
  PRICING: { currency: 'USD', symbol: '$', monthly: 2.99, yearly: 17 },

  // AI Coach. The endpoint is a server function (netlify/functions/coach.mjs) that holds the API key.
  COACH: { endpoint: '/api/coach', freePerDay: 5, proPerDay: 40 },

  // Accounts and cloud sync (Supabase). Leave both empty to run local-only. Setup steps: supabase/README.md.
  // The anon key is designed to be public; your data is protected by the row-level security rules in supabase/schema.sql.
  CLOUD: { url: 'https://kotgdoslpcsgvsbkpuxn.supabase.co', anonKey: 'sb_publishable_0juWgiz8EYCh5A0WkPLPng_-gbKBQKN' },

  FREE: { historyDays: 30, periods: [7, 30] },
  KG_PER_LB: 0.45359237,
};

export const FEATURES = {
  // feature id -> minimum plan
  customProgramme: 'pro',
  advancedProgression: 'pro',
  exerciseAnalytics: 'pro',
  muscleDistribution: 'pro',
  longPeriods: 'pro',
  weeklyReport: 'pro',
  reportExport: 'pro',
  nutritionHistory: 'pro',
  fullHistory: 'pro',
  exercisePreferences: 'pro',
};
