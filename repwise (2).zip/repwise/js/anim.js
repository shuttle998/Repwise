// Built-in exercise animations: a side-on figure moves between keyframes (anim-data.js), with a rep counter
// and a follow-along timer. Nothing is downloaded; it is all drawn here as SVG.
import { esc } from './util.js';
import { icon } from './ui.js';
import { ANIMS, HILITE, hasAnim } from './anim-data.js';

export { hasAnim };
const D = Math.PI / 180, T = 38, TH = 27, SH = 27, UA = 21, FA = 19, FOOT = 10;
const DEF = { h: [0, 57], t: 0, hd: 0, f: [0, 5], fa: 30, ks: 1, fks: 1, es: -1, fes: -1 };

/** Two-bone IK. Returns the joint and the (reach-limited) end point. s = which side the joint bulges (+1 = counter-clockwise). */
export function ik(p0, p1, l1, l2, s) {
  const dx = p1[0] - p0[0], dy = p1[1] - p0[1], d = Math.hypot(dx, dy) || 0.001, ux = dx / d, uy = dy / d;
  const r = Math.min(Math.max(d, Math.abs(l1 - l2) + 0.5), l1 + l2 - 0.05), a = (l1 * l1 - l2 * l2 + r * r) / (2 * r), h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
  return { j: [p0[0] + ux * a - s * uy * h, p0[1] + uy * a + s * ux * h], end: [p0[0] + ux * r, p0[1] + uy * r] };
}
const polar = (p, len, deg) => [p[0] + len * Math.sin(deg * D), p[1] - len * Math.cos(deg * D)]; // angle from straight down, + forward

/** Joint positions for a full pose. */
export function solve(p) {
  const H = p.h, ts = p.t * D, S = [H[0] + T * Math.sin(ts), H[1] + T * Math.cos(ts)], hd = (p.t + p.hd) * D;
  const head = [S[0] + 12 * Math.sin(hd), S[1] + 12 * Math.cos(hd)];
  const leg = (foot, fa, ks) => { const r = ik(H, foot, TH, SH, ks), a = r.end; return { knee: r.j, ankle: a, toe: [a[0] + FOOT * Math.cos(fa * D), a[1] - FOOT * Math.sin(fa * D)] }; };
  const near = leg(p.f, p.fa, p.ks), far = leg(p.ff || [p.f[0] - 4, p.f[1]], p.ffa ?? p.fa, p.fks);
  const target = (k) => k.arm ? null : k.ha || (k.hs && [S[0] + k.hs[0], S[1] + k.hs[1]]) || (k.hh && [H[0] + k.hh[0], H[1] + k.hh[1]]) || [S[0], S[1] - 38];
  const arm = (a, tg, es) => { if (a) { const e = polar(S, UA, a[0]); return { elbow: e, wrist: polar(e, FA, a[1]) }; } const r = ik(S, tg, UA, FA, es); return { elbow: r.j, wrist: r.end }; };
  const na = arm(p.arm, target(p), p.es);
  const fa = p.farm || p.fha || p.fhs || p.fhh ? arm(p.farm, p.fha || (p.fhs && [S[0] + p.fhs[0], S[1] + p.fhs[1]]) || (p.fhh && [H[0] + p.fhh[0], H[1] + p.fhh[1]]) || target(p), p.fes) : arm(p.arm, p.arm ? null : [target(p)[0] - 2, target(p)[1]], p.es);
  return { H, S, head, near, far, nArm: na, fArm: fa };
}

// ---- keyframe blending
const full = (base, kf) => ({ ...DEF, ...base, ...kf });
const mix = (a, b, k) => { const o = { ...a }; for (const key in b) { const x = a[key], y = b[key]; o[key] = Array.isArray(y) && Array.isArray(x) ? y.map((v, i) => x[i] + (v - x[i]) * k) : typeof y === 'number' && typeof x === 'number' ? x + (y - x) * k : y; } return o; };
const ease = (k) => 0.5 - 0.5 * Math.cos(Math.PI * Math.min(1, Math.max(0, k)));
export const poses = (id) => { const a = ANIMS[id]; return a ? a.kf.map((k) => full(a.base, k)) : []; };

/** Pose at a time within the loop, plus the cue and loop count. */
export function frameAt(id, time) {
  const a = ANIMS[id], P = poses(id), seq = a.seq, total = seq.reduce((s, x) => s + x[1] + (x[3] || 0), 0), loops = Math.floor(time / total);
  let t = time % total, prev = P[a.seq[seq.length - 1][0]], i = 0;
  for (; i < seq.length; i++) { const [to, dur, , hold = 0] = seq[i]; if (t < dur) return { pose: mix(prev, P[to], ease(t / dur)), cue: seq[i][2], loops, step: i, k: t / dur }; t -= dur; if (t < hold) return { pose: P[to], cue: seq[i][2], loops, step: i, k: 1 }; t -= hold; prev = P[to]; }
  return { pose: prev, cue: seq[0][2], loops, step: 0, k: 0 };
}

// ---- drawing
const f1 = (n) => Math.round(n * 10) / 10;
const ln = (a, b, cls, w) => `<line class="${cls}" x1="${f1(a[0])}" y1="${f1(-a[1])}" x2="${f1(b[0])}" y2="${f1(-b[1])}"${w ? ` stroke-width="${w}"` : ''}/>`;
const pt = (p) => `${f1(p[0])},${f1(-p[1])}`;
function propsSVG(a, j, pose) {
  const out = [], hand = j.nArm.wrist, fhand = j.fArm.wrist;
  (a.props || []).forEach((p) => {
    if (p.k === 'rect') out.push(`<rect class="fur" x="${p.x}" y="${-(p.y + p.h)}" width="${p.w}" height="${p.h}" rx="2"/>`);
    else if (p.k === 'line') out.push(`<line class="fur" x1="${p.p[0]}" y1="${-p.p[1]}" x2="${p.p[2]}" y2="${-p.p[3]}" stroke-width="${p.w || 5}"/>`);
    else if (p.k === 'padTorso') { const u = [(j.S[0] - j.H[0]) / T, (j.S[1] - j.H[1]) / T], n = [-u[1], u[0]]; out.push(ln([j.H[0] - 8 * u[0] + 7 * n[0], j.H[1] - 8 * u[1] + 7 * n[1]], [j.S[0] + 8 * u[0] + 7 * n[0], j.S[1] + 8 * u[1] + 7 * n[1]], 'fur', 7)); }
    else if (p.k === 'footplate') { const d = [j.near.ankle[0] - j.H[0], j.near.ankle[1] - j.H[1]], m = Math.hypot(...d), n = [-d[1] / m, d[0] / m], c = [j.near.ankle[0] + 3 * d[0] / m, j.near.ankle[1] + 3 * d[1] / m]; out.push(ln([c[0] + 18 * n[0], c[1] + 18 * n[1]], [c[0] - 18 * n[0], c[1] - 18 * n[1]], 'fur', 5)); }
    else if (p.k === 'cable') { const from = p.from === 'farFoot' ? j.far.ankle : hand; out.push(`<line class="cable" x1="${f1(from[0])}" y1="${f1(-from[1])}" x2="${p.to[0]}" y2="${-p.to[1]}"/><circle class="fur-dot" cx="${p.to[0]}" cy="${-p.to[1]}" r="4"/>`); }
    else if (p.k === 'plate') { [fhand, hand].forEach((h, i) => { if (i && Math.hypot(h[0] - fhand[0], h[1] - fhand[1]) < 1) {} out.push(`<circle class="plate${i ? '' : ' far'}" cx="${f1(h[0])}" cy="${f1(-h[1])}" r="${p.r}"/>`); }); }
  });
  return out.join('');
}
/** SVG markup (inside the viewBox) for one pose. `hl` = set of highlighted segments. */
export function figureSVG(id, pose, hl = new Set()) {
  const a = ANIMS[id], j = solve(pose), c = (seg, far) => `${far ? 'seg far' : 'seg'}${hl.has(seg) ? ' hl' : ''}`;
  const leg = (l, far) => `${ln(j.H, l.knee, c('thigh', far), 6)}${ln(l.knee, l.ankle, c('shin', far), 5)}${ln(l.ankle, l.toe, c('foot', far), 4)}`;
  const arm = (r, far) => `${ln(j.S, r.elbow, c('uarm', far), 5)}${ln(r.elbow, r.wrist, c('farm', far), 4.5)}`;
  return `${a.props?.some((p) => p.k === 'rect' || p.k === 'line' || p.k === 'padTorso') ? propsSVG({ props: a.props.filter((p) => p.k === 'rect' || p.k === 'line' || p.k === 'padTorso') }, j, pose) : ''}
    ${leg(j.far, true)}${arm(j.fArm, true)}${ln(j.H, j.S, c('torso'), 8)}<circle class="head" cx="${f1(j.head[0])}" cy="${f1(-j.head[1])}" r="7"/>${leg(j.near)}${arm(j.nArm)}
    ${propsSVG({ props: (a.props || []).filter((p) => p.k === 'footplate' || p.k === 'cable' || p.k === 'plate') }, j, pose)}`;
}
/** View box that fits every keyframe, padded and set to a 4:3 shape so the card never changes size. */
export function viewBox(id) {
  const a = ANIMS[id]; let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
  const add = (p, r = 0) => { x0 = Math.min(x0, p[0] - r); x1 = Math.max(x1, p[0] + r); y0 = Math.min(y0, -p[1] - r); y1 = Math.max(y1, -p[1] + r); };
  poses(id).forEach((p) => { const j = solve(p); [j.H, j.S, j.near.toe, j.near.ankle, j.far.toe, j.nArm.wrist, j.fArm.wrist, j.nArm.elbow, j.near.knee].forEach((q) => add(q, 5)); add([j.head[0], j.head[1]], 8); });
  add([-26, 0]); add([26, 0]); add([0, -16]); // room under the floor line for the cue text
  (a.props || []).forEach((p) => { if (p.k === 'rect') { add([p.x, p.y]); add([p.x + p.w, p.y + p.h]); } if (p.k === 'line') { add([p.p[0], p.p[1]]); add([p.p[2], p.p[3]]); } });
  let w = x1 - x0 + 14, h = y1 - y0 + 14; const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
  if (w / h < 4 / 3) w = h * 4 / 3; else h = w * 3 / 4;
  return [f1(cx - w / 2), f1(cy - h / 2), f1(w), f1(h)];
}
export const highlightOf = (ex) => new Set(ex.pm.flatMap((m) => HILITE[m] || []));
/** A single frame as a standalone SVG string (used for thumbnails and tests). */
export function stillSVG(ex, which = 0) {
  const vb = viewBox(ex.id), P = poses(ex.id);
  return `<svg class="anim-svg" viewBox="${vb.join(' ')}" xmlns="http://www.w3.org/2000/svg"><line class="floor" x1="${vb[0]}" y1="0" x2="${vb[0] + vb[2]}" y2="0"/>${figureSVG(ex.id, P[Math.min(which, P.length - 1)], highlightOf(ex))}</svg>`;
}

// ---- audio / haptics for the timer
let audio = null;
function tone(freqs = [880, 1175], settings = {}) {
  if (settings.sound === false) return;
  try { audio = audio || new (window.AudioContext || window.webkitAudioContext)(); const t = audio.currentTime; freqs.forEach((f, i) => { const o = audio.createOscillator(), g = audio.createGain(); o.frequency.value = f; g.gain.setValueAtTime(0.0001, t + i * 0.16); g.gain.exponentialRampToValueAtTime(0.25, t + i * 0.16 + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.16 + 0.14); o.connect(g).connect(audio.destination); o.start(t + i * 0.16); o.stop(t + i * 0.16 + 0.16); }); } catch { /* audio is optional */ }
}

// ---- the card
const DURS = [20, 30, 45, 60];
/** HTML for the animated demonstration. Call bindAnim(container) after inserting. */
export function animHTML(ex) {
  const a = ANIMS[ex.id]; if (!a) return '';
  const vb = viewBox(ex.id), timed = !!a.hold || ex.unit === 'sec';
  return `<div class="anim" data-anim="${ex.id}" data-timed="${timed ? 1 : 0}" data-pmj="${esc(JSON.stringify(ex.pm))}">
    <div class="anim-stage" role="img" aria-label="Animated demonstration of ${esc(ex.name)}">
      <svg class="anim-svg" viewBox="${vb.join(' ')}" preserveAspectRatio="xMidYMid meet" aria-hidden="true"><line class="floor" x1="${vb[0]}" y1="0" x2="${vb[0] + vb[2]}" y2="0"/><g data-fig></g></svg>
      <span class="anim-cue" data-cue aria-live="off"></span><span class="anim-count" data-count hidden>0</span>
    </div>
    <div class="anim-ctl">
      <button class="btn small" data-a="toggle" aria-label="Pause animation">${icon('pause')} <span>Pause</span></button>
      <span class="demo-speed" role="group" aria-label="Speed"><button class="fchip" data-a="rate" data-r="0.5" aria-pressed="false">0.5×</button><button class="fchip" data-a="rate" data-r="1" aria-pressed="true">1×</button></span>
      <button class="btn small primary" data-a="follow">${icon('timer')} Follow along</button>
    </div>
    <div class="anim-follow" data-follow hidden>
      <div class="filters" role="group" aria-label="Duration">${DURS.map((d) => `<button class="fchip" data-a="dur" data-d="${d}" aria-pressed="${d === 30}">${d}s</button>`).join('')}</div>
      <div class="anim-clock"><b data-clock aria-live="off">30</b><span data-clock-sub class="lbl">seconds</span></div>
      <button class="btn primary block" data-a="start">${icon('play')} Start</button>
      <p class="hint" data-status aria-live="polite"></p>
    </div>
    ${a.note ? `<p class="hint anim-note">${esc(a.note)}</p>` : ''}
    <p class="hint">Highlighted: ${esc(ex.pm.join(', ').toLowerCase())}. A simplified side view for timing and position, not a substitute for the written steps.</p>
  </div>`;
}

/** Wires up every .anim inside root. Returns nothing; animations stop themselves when removed from the page. */
export function bindAnim(root, { settings = {}, onTick } = {}) {
  root.querySelectorAll('.anim:not([data-bound])').forEach((el) => {
    el.dataset.bound = '1';
    const id = el.dataset.anim, a = ANIMS[id], timed = el.dataset.timed === '1', reduce = matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    const fig = el.querySelector('[data-fig]'), cue = el.querySelector('[data-cue]'), cnt = el.querySelector('[data-count]'), clock = el.querySelector('[data-clock]'), sub = el.querySelector('[data-clock-sub]'), status = el.querySelector('[data-status]');
    let hl = new Set(); try { hl = highlightOf({ pm: JSON.parse(el.dataset.pmj || '[]') }); } catch { /* highlight is optional */ }
    let playing = !reduce, rate = 1, time = 0, last = 0, raf = 0, visible = true, mode = 'loop', dur = 30, follow = null;
    const draw = () => { const fr = frameAt(id, time); fig.innerHTML = figureSVG(id, fr.pose, hl); cue.textContent = fr.cue; return fr; };
    const setPlay = (on) => { playing = on; const b = el.querySelector('[data-a="toggle"]'); b.querySelector('span').textContent = on ? 'Pause' : 'Play'; b.setAttribute('aria-label', on ? 'Pause animation' : 'Play animation'); b.firstElementChild.outerHTML = icon(on ? 'pause' : 'play'); };
    const tick = (now) => {
      if (!el.isConnected) return;
      raf = requestAnimationFrame(tick);
      const dt = Math.min(0.1, (now - last) / 1000); last = now;
      if (!playing || !visible || document.hidden) return;
      time += dt * rate;
      const fr = draw();
      if (mode === 'follow') followTick(dt, fr); else if (!timed) { cnt.hidden = false; cnt.textContent = fr.loops + 1; } else cnt.hidden = true;
    };
    // ---- follow-along: 3 second lead-in, then a countdown with a rep count
    function followTick(dt, fr) {
      const f = follow; if (!f) return;
      f.elapsed += dt;
      if (f.elapsed < f.lead) { const n = Math.ceil(f.lead - f.elapsed); if (n !== f.n) { f.n = n; tone([660], settings); } clock.textContent = n; sub.textContent = 'get ready'; if (f.elapsed < dt * 2) { time = 0; f.loops0 = 0; } return; }
      if (!f.started) { f.started = true; time = 0; tone([880], settings); }
      const left = Math.max(0, f.total - (f.elapsed - f.lead)); clock.textContent = Math.ceil(left); sub.textContent = timed ? 'hold' : `rep ${Math.min(fr.loops + 1, 999)}`;
      cnt.hidden = timed; cnt.textContent = fr.loops + 1;
      if (left <= 0) finish(fr.loops + (fr.k > 0.5 ? 1 : 0));
    }
    function finish(reps) {
      follow = null; mode = 'loop'; tone([880, 1175, 1568], settings); if (settings.vibrate !== false && navigator.vibrate) navigator.vibrate([180, 80, 180]);
      status.textContent = timed ? `Done. ${dur} seconds.` : `Done. ${reps} rep${reps === 1 ? '' : 's'} in ${dur} seconds.`;
      clock.textContent = dur; sub.textContent = 'seconds'; el.querySelector('[data-a="start"]').innerHTML = `${icon('repeat')} Go again`; onTick?.({ done: true, reps, seconds: dur });
    }
    el.addEventListener('click', (e) => {
      const b = e.target.closest('[data-a]'); if (!b) return; const k = b.dataset.a;
      if (k === 'toggle') setPlay(!playing);
      else if (k === 'rate') { rate = +b.dataset.r; el.querySelectorAll('[data-a="rate"]').forEach((x) => x.setAttribute('aria-pressed', x === b)); }
      else if (k === 'follow') { const box = el.querySelector('[data-follow]'); box.hidden = !box.hidden; if (!box.hidden) { box.scrollIntoView?.({ block: 'nearest', behavior: reduce ? 'auto' : 'smooth' }); } else { mode = 'loop'; follow = null; } }
      else if (k === 'dur') { if (mode === 'follow') return; dur = +b.dataset.d; el.querySelectorAll('[data-a="dur"]').forEach((x) => x.setAttribute('aria-pressed', x === b)); clock.textContent = dur; status.textContent = ''; }
      else if (k === 'start') {
        if (mode === 'follow') { mode = 'loop'; follow = null; b.innerHTML = `${icon('play')} Start`; clock.textContent = dur; sub.textContent = 'seconds'; status.textContent = 'Stopped.'; return; }
        mode = 'follow'; follow = { elapsed: 0, lead: 3, total: dur, n: 0, started: false }; time = 0; rate = 1; el.querySelectorAll('[data-a="rate"]').forEach((x) => x.setAttribute('aria-pressed', x.dataset.r === '1'));
        setPlay(true); b.innerHTML = `${icon('x')} Stop`; status.textContent = '';
        try { audio = audio || new (window.AudioContext || window.webkitAudioContext)(); audio.resume?.(); } catch { /* audio is optional */ }
      }
    });
    if ('IntersectionObserver' in window) new IntersectionObserver((en) => { visible = en[0].isIntersecting; }).observe(el);
    draw(); if (reduce) setPlay(false);
    last = performance.now(); raf = requestAnimationFrame(tick);
  });
}
