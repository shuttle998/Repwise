// Rule-based insights computed only from the person's own logs, programme and profile.
// Pure functions: given the same data they return the same text. Nothing is invented, and
// wherever data is thin the wording says so. (The AI Coach in views/coach.js is separate.)
import { BY_ID, MUSCLES, isGuided } from './exercises.js';
import { exerciseSessions, prEvents, weekCounts, weekStreak, doneItems, sortS } from './analytics.js';
import { parseKey, dateKey, startOfWeek, addDays, daysBetween, fmtW } from './util.js';

const HOUR = 36e5;
/** Best available timestamp for a session. Imported legacy sessions have only a date. */
export const sessionTime = (s) => s.endedAt || s.startedAt || parseKey(s.date).getTime() + 12 * HOUR;

/** Hours since each muscle was last trained (primary muscles only), plus sets in the last 7 days. */
export function muscleRecency(ss, now = new Date()) {
  const out = Object.fromEntries(MUSCLES.map((m) => [m, { hours: null, sets7: 0 }]));
  sortS(ss).forEach((s) => {
    const h = (now.getTime() - sessionTime(s)) / HOUR; if (h < 0) return;
    doneItems(s).forEach((i) => !isGuided(BY_ID[i.exId]) && BY_ID[i.exId]?.pm.forEach((m) => {
      if (!out[m]) return;
      if (out[m].hours === null || h < out[m].hours) out[m].hours = h;
      if (h <= 168) out[m].sets7 += i.sets.length;
    }));
  });
  return out;
}

/** Recovery summary. Claims are deliberately soft: recovery varies and we only see training logs. */
export function recoveryReport(ss, now = new Date()) {
  const rec = muscleRecency(ss, now), logged = ss.filter((s) => doneItems(s).length);
  if (!logged.length) return { hasData: false };
  const recent = MUSCLES.filter((m) => rec[m].hours !== null && rec[m].hours < 48).map((m) => ({ muscle: m, hours: Math.round(rec[m].hours) }));
  const days = new Set(logged.map((s) => s.date));
  const today = dateKey(now);
  let streakDays = 0, d = days.has(today) ? parseKey(today) : addDays(parseKey(today), -1);
  while (days.has(dateKey(d)) && streakDays < 30) { streakDays++; d = addDays(d, -1); }
  const week = logged.filter((s) => s.date >= dateKey(addDays(parseKey(today), -6))).length;
  const restDay = streakDays >= 3 ? `You have trained ${streakDays} days in a row. A rest day would be sensible.` : null;
  return {
    hasData: true, recent, restDay, week, streakDays,
    note: recent.length ? `${recent.map((r) => r.muscle).join(', ')} ${recent.length === 1 ? 'was' : 'were'} trained in the last 48 hours. Many people leave 48 to 72 hours before training the same muscles hard again, but it varies. Go by how you feel.` : 'No muscle group was trained in the last 48 hours.',
  };
}

/** Which programme session to suggest today. Keeps the programme order unless it clashes with recent training. */
export function suggestToday(ss, program, cursor, now = new Date()) {
  const list = program?.sessions || []; if (!list.length) return null;
  const idx = cursor % list.length, rec = muscleRecency(ss, now);
  const fresh = (m) => rec[m]?.hours !== null && rec[m]?.hours < 48;
  const clash = (s) => [...new Set(s.items.flatMap((i) => BY_ID[i.exId]?.pm || []))].filter(fresh);
  const own = clash(list[idx]);
  const base = { idx, name: list[idx].name, alt: false, clash: own };
  if (own.length < 2 || list.length < 2) return base;
  let best = null;
  list.forEach((s, i) => { if (i === idx) return; const c = clash(s); if (c.length < own.length && (!best || c.length < best.c.length)) best = { i, c }; });
  if (!best) return base;
  return { idx: best.i, name: list[best.i].name, alt: true, planned: list[idx].name, clash: best.c, reason: `${list[idx].name} works ${own.slice(0, 3).join(', ')}, trained in the last 48 hours. ${list[best.i].name} overlaps less.` };
}

/** Ordered list of insights, most useful first. Each: { kind, tone, title, text, href? } */
export function coachInsights({ sessions, working = {}, program, profile, settings }, now = new Date()) {
  const out = [], ss = sessions.filter((s) => doneItems(s).length), target = profile?.days || 3, u = settings?.units || 'kg', kg = (n) => fmtW(n, u, true);
  if (!ss.length) return [{ kind: 'start', tone: 'info', title: 'Insights start after your first workout', text: 'Log a workout and this card begins comparing it with your plan and your earlier sessions. Nothing is shown until there is data to back it.' }];
  const today = dateKey(now);
  // 1. a recent pain flag
  Object.entries(working).forEach(([id, w]) => { if (w?.action === 'adjust' && w.date && daysBetween(parseKey(w.date), now) <= 14 && BY_ID[id]) out.push({ kind: 'pain', tone: 'warn', title: `${BY_ID[id].name}: take it easy`, text: `You flagged discomfort on this exercise recently. Keep the load light, check the technique notes, or swap to an alternative until it feels fine. See a professional if it persists.`, href: `#/library/${id}` }); });
  // 2. progression ready
  Object.entries(working).forEach(([id, w]) => { if (w?.action === 'increase_weight' && BY_ID[id]) out.push({ kind: 'increase', tone: 'good', title: `${BY_ID[id].name} is ready for more weight`, text: `Your last session hit the top of the rep range with manageable effort. Next time the app suggests ${kg(w.w)}; you review and accept it on the workout screen.`, href: `#/library/${id}` }); });
  // 3. stalled at the same weight across the last two sessions
  const lastIds = [...new Set(sortS(ss).slice(-3).flatMap((s) => doneItems(s).map((i) => i.exId)))];
  for (const id of lastIds) {
    const ex = BY_ID[id]; if (!ex || ex.unit !== 'kg') continue;
    const h = exerciseSessions(ss, id); if (h.length < 2) continue;
    const top = (x) => Math.max(...x.sets.map((q) => q.w || 0)), reps = (x) => Math.max(...x.sets.filter((q) => q.w === top(x)).map((q) => q.reps));
    if (top(h[0]) <= 0 || top(h[0]) !== top(h[1])) continue;
    const item = program?.sessions?.flatMap((s) => s.items).find((i) => i.exId === id), hi = item?.repHi || 12;
    if (reps(h[0]) >= hi) continue; // the progression engine handles this case
    out.push({ kind: 'stall', tone: 'info', title: `${ex.name} has stayed at ${kg(top(h[0]))}`, text: `Your last two sessions both used ${kg(top(h[0]))} (best set ${reps(h[1])} then ${reps(h[0])} reps). Try adding reps before adding weight; the target is ${hi} reps on every set.`, href: `#/progress?ex=${id}` });
    break;
  }
  // 4. behind on the week
  const wc = weekCounts(ss), done = wc.get(dateKey(startOfWeek(now))) || 0, left = 6 - ((now.getDay() + 6) % 7);
  if (done < target && target - done > left && left >= 0) out.push({ kind: 'pace', tone: 'info', title: 'Your weekly target is out of reach', text: `You have done ${done} of ${target} workouts and ${left === 0 ? 'this is the last day' : left + ' day' + (left === 1 ? '' : 's') + ' remain'}. Aim for what fits; consistency over weeks matters more than one week.` });
  // 5. a muscle group with no work, only once there is enough history
  const month = ss.filter((s) => daysBetween(parseKey(s.date), now) < 28);
  if (month.length >= 6) {
    const rec = muscleRecency(month, now), idle = MUSCLES.filter((m) => rec[m].sets7 === 0 && rec[m].hours === null && !(profile?.avoid || []).includes(m));
    if (idle.length) out.push({ kind: 'gap', tone: 'info', title: `No ${idle[0].toLowerCase()} work in 4 weeks`, text: `Across ${month.length} logged workouts none had ${idle[0].toLowerCase()} as a main muscle. That may be intended; if not, you can add an exercise in Train. Four weeks of logs is a limited view.`, href: '#/train' });
  }
  // 6. a recent record
  const prs = prEvents(ss).filter((e) => daysBetween(parseKey(e.date), now) <= 7 && e.date <= today);
  if (prs.length) out.push({ kind: 'pr', tone: 'good', title: 'New personal best this week', text: `${prs[prs.length - 1].name} is a new personal record. See all your records on the Progress page.`, href: '#/progress/records' });
  if (!out.length) out.push({ kind: 'steady', tone: 'info', title: 'Nothing needs attention', text: ss.length < 6 ? `${ss.length} workout${ss.length === 1 ? '' : 's'} logged. Insights get more specific after about six.` : 'Your logged training looks consistent. Keep following the plan.' });
  return out;
}

/** A short line grounded in real numbers. Never praises what did not happen. */
export function motivation(ss, profile, now = new Date()) {
  const logged = ss.filter((s) => doneItems(s).length), target = profile?.days || 3;
  if (!logged.length) return 'Your first workout is the hardest one to start. Keep it light and learn the movements.';
  const done = weekCounts(logged).get(dateKey(startOfWeek(now))) || 0, st = weekStreak(logged, target, now).current;
  if (done >= target) return `You have hit your target this week: ${done} of ${target} workouts. Recover well.`;
  if (st >= 2) return `${st} weeks in a row at your target. Keep that run going.`;
  if (done > 0) return `${done} of ${target} workouts done this week. ${target - done} to go.`;
  return `${logged.length} workout${logged.length === 1 ? '' : 's'} logged so far. Today is a good day to add another.`;
}
