// Pilates, yoga and mobility moves plus ready-made timed routines. Pure data and helpers: no DOM, no storage.
// Moves are timed (seconds). Moves marked `sides` are done once on each side, as two sets.
// They use slot 'mindbody', which the programme generator never picks, so lifting programmes are unaffected.
// Most have a built-in animation (anim-data.js). Supine twist and figure-four have none, so the library shows steps and a search link.
// General exercise guidance, not medical advice.

const M = (id, name, o) => ({ id, name, unit: 'sec', stress: [], sm: [], step: 0, start: 0, slot: 'mindbody', tier: 'bw', equip: 'Bodyweight', type: 'Mind-body', diff: 'Beginner', mind: o.kind, ...o });

export const MINDBODY = [
  // ---- Pilates (mat)
  M('pelvic-curl', 'Pelvic curl', { kind: 'pilates', pm: ['Glutes', 'Hamstrings'], sm: ['Core'], reps: [30, 45],
    steps: ['Lie on your back with knees bent, feet hip-width apart and arms by your sides.', 'Breathe in. Breathe out, tuck your pelvis and peel your spine off the mat one bone at a time until you are on a straight line from shoulders to knees.', 'Breathe in at the top. Breathe out and roll down slowly, upper back first, then lower back, then hips. Repeat smoothly for the whole time.'],
    mistakes: ['Lifting so high the ribs flare and the lower back arches', 'Pushing through the toes instead of the whole foot', 'Rushing the roll down'], subs: ['glute-bridge', 'dead-bug'] }),
  M('hundred', 'The hundred (knees bent)', { kind: 'pilates', pm: ['Core'], reps: [30, 50],
    steps: ['Lie on your back, knees bent over your hips with shins parallel to the floor. Curl your head and shoulders up if your neck is comfortable, or keep your head down.', 'Reach your arms long by your sides, just off the floor.', 'Pump your arms in small, quick beats. Breathe in for five beats, out for five. Keep your lower back heavy on the mat.'],
    mistakes: ['Neck straining forward: keep your head down instead', 'Lower back arching off the mat', 'Holding your breath'], subs: ['dead-bug', 'toe-taps'] }),
  M('toe-taps', 'Tabletop toe taps', { kind: 'pilates', pm: ['Core'], reps: [30, 45],
    steps: ['Lie on your back with knees bent over your hips, shins parallel to the floor, arms by your sides.', 'Breathe out and lower one foot to tap the floor, keeping your lower back pressed down.', 'Return to tabletop and tap with the other foot. Alternate slowly.'],
    mistakes: ['Lower back lifting off the mat', 'Dropping the knee out to the side', 'Moving fast instead of slowly'], subs: ['dead-bug'] }),
  M('single-leg-stretch', 'Single-leg stretch', { kind: 'pilates', pm: ['Core'], reps: [30, 45],
    steps: ['Lie on your back, curl your head and shoulders up if comfortable, and draw one knee in with both hands on that shin. The other leg extends long at a height you can control.', 'Breathe out and switch legs smoothly, as if cycling slowly.', 'Keep your hips still and your lower back heavy on the mat. Alternate for the whole time.'],
    mistakes: ['Neck pulling forward: rest your head down instead', 'Rocking the hips side to side', 'Extended leg too low for your lower back'], subs: ['toe-taps', 'dead-bug'] }),
  M('leg-circles', 'Leg circles', { kind: 'pilates', sides: true, pm: ['Core', 'Glutes'], reps: [20, 40],
    steps: ['Lie on your back with one leg extended on the mat and the other straight up toward the ceiling (or bent if your hamstrings are tight). Arms rest by your sides.', 'Draw small circles with the raised leg while your pelvis stays still. Switch direction halfway through.', 'Do one leg for the first set and the other leg for the second set.'],
    mistakes: ['Pelvis rocking as the leg moves', 'Circles too big to control', 'Ribs flaring up'], subs: ['dead-bug'] }),
  M('swimming', 'Swimming (prone)', { kind: 'pilates', stress: ['lowback'], pm: ['Back', 'Glutes'], reps: [20, 40],
    steps: ['Lie face down with arms reaching forward and legs long. Draw your belly gently away from the floor.', 'Lift your arms and legs slightly, only as high as feels comfortable in your lower back.', 'Flutter opposite arm and leg up and down in small, quick beats. Breathe steadily.'],
    mistakes: ['Lifting too high and crunching the lower back', 'Neck craning up: keep your gaze on the floor', 'Holding your breath'], subs: ['bird-dog'] }),
  M('bird-dog', 'Bird dog', { kind: 'pilates', stress: ['wrists', 'knees'], pm: ['Back', 'Glutes'], sm: ['Core'], reps: [30, 45],
    steps: ['Start on hands and knees, hands under shoulders, knees under hips, back flat.', 'Reach one arm forward and the opposite leg back, keeping your hips level.', 'Return with control and switch sides. Alternate for the whole time.'],
    mistakes: ['Hips rotating open', 'Lower back sagging or arching', 'Rushing instead of reaching long'], subs: ['dead-bug'] }),
  M('spine-twist', 'Seated spine twist', { kind: 'pilates', sides: true, pm: ['Core'], sm: ['Back'], reps: [20, 40],
    steps: ['Sit tall with legs crossed or extended, arms reaching out to the sides or crossed on your chest.', 'Breathe in and grow tall. Breathe out and rotate from your ribs, keeping your hips still.', 'Return to centre and repeat to the same side for the set. Use the second set for the other side.'],
    mistakes: ['Slumping back as you turn', 'Moving the hips instead of the ribs', 'Forcing the twist'], subs: ['supine-twist'] }),
  M('roll-down', 'Standing roll-down', { kind: 'pilates', stress: ['lowback'], pm: ['Hamstrings', 'Back'], sm: ['Core'], reps: [30, 45],
    steps: ['Stand tall with feet hip-width apart and knees soft.', 'Breathe out, drop your chin and roll down slowly one vertebra at a time, arms hanging.', 'Breathe in at the bottom. Breathe out and stack your spine back up, head last. Repeat slowly.'],
    mistakes: ['Dropping down fast in one piece', 'Locking the knees', 'Holding the breath at the bottom'], subs: ['seated-fold'] }),
  // ---- Yoga and mobility
  M('cat-cow', 'Cat-cow', { kind: 'yoga', stress: ['wrists', 'knees'], pm: ['Back'], sm: ['Core'], reps: [30, 60],
    steps: ['Start on hands and knees, hands under shoulders and knees under hips.', 'Breathe in, let your belly drop and lift your chest and tailbone (cow).', 'Breathe out, round your spine toward the ceiling and tuck your chin (cat). Flow slowly between the two.'],
    mistakes: ['Moving only the lower back', 'Rushing the breath', 'Locking the elbows hard'], subs: ['childs-pose'] }),
  M('childs-pose', 'Child’s pose', { kind: 'yoga', stress: ['knees'], pm: ['Back'], sm: ['Glutes'], reps: [30, 60],
    steps: ['Kneel, bring your big toes together and knees apart, and sit your hips back toward your heels.', 'Fold forward and rest your arms long in front of you or by your sides.', 'Breathe slowly into your back. Place a cushion under your hips or forehead if that is more comfortable.'],
    mistakes: ['Forcing the hips down if your knees complain: use a cushion', 'Tensing the shoulders', 'Holding your breath'], subs: ['seated-fold'] }),
  M('down-dog', 'Downward dog', { kind: 'yoga', stress: ['wrists', 'shoulders'], pm: ['Shoulders', 'Hamstrings'], sm: ['Back', 'Calves'], reps: [20, 40],
    steps: ['Start on hands and knees. Tuck your toes and lift your hips up and back, forming an upside-down V.', 'Press the floor away through your hands, keep a micro-bend in your knees and let your head hang between your arms.', 'Pedal your heels gently if it feels good. Breathe steadily.'],
    mistakes: ['Rounding the back: bend your knees more', 'Shoulders creeping to your ears', 'Hands too close to your feet'], subs: ['childs-pose', 'cat-cow'] }),
  M('low-lunge', 'Low lunge (hip stretch)', { kind: 'yoga', sides: true, stress: ['knees'], pm: ['Quads', 'Glutes'], reps: [20, 40],
    steps: ['From hands and knees, step one foot forward between your hands, back knee down on a folded mat or cushion.', 'Slide your hips gently forward until you feel a stretch at the front of the back hip. Keep your chest tall.', 'Hold with steady breathing. Do one side for the first set and the other side for the second.'],
    mistakes: ['Front knee past your toes with the heel lifting', 'Arching the lower back', 'Sinking onto the back knee without padding'], subs: ['figure-four'] }),
  M('warrior-2', 'Warrior II', { kind: 'yoga', sides: true, stress: ['knees'], diff: 'Intermediate', pm: ['Quads', 'Glutes'], sm: ['Shoulders'], reps: [20, 40],
    steps: ['Stand with feet wide apart. Turn one foot out 90 degrees and bend that knee over your ankle, back leg straight.', 'Stretch your arms out to the sides at shoulder height and look over your front hand.', 'Keep your torso stacked over your hips and breathe. Do one side for the first set and the other for the second.'],
    mistakes: ['Front knee collapsing inward', 'Leaning toward the front leg', 'Shoulders hiking up'], subs: ['figure-four'] }),
  M('cobra', 'Cobra', { kind: 'yoga', stress: ['lowback', 'wrists'], pm: ['Back'], sm: ['Core'], reps: [15, 30],
    steps: ['Lie face down with hands under your shoulders and elbows tucked in.', 'Press gently through your hands to lift your chest, keeping your hips on the floor and your elbows slightly bent.', 'Lengthen through the crown of your head and breathe. Lower with control. Stay low if your lower back complains.'],
    mistakes: ['Pressing up too high and crunching the lower back', 'Shoulders up by your ears', 'Neck craning back'], subs: ['childs-pose'] }),
  M('seated-fold', 'Seated forward fold', { kind: 'yoga', stress: ['lowback'], pm: ['Hamstrings'], sm: ['Back'], reps: [30, 60],
    steps: ['Sit with legs extended and knees slightly bent. Sit up tall on the front of your sit bones.', 'Hinge forward from your hips, keeping your spine long, and rest your hands on your legs.', 'Stop where you feel a stretch in the back of your legs and breathe. Sit on a cushion or keep the knees more bent if it is tight.'],
    mistakes: ['Rounding the back to reach further', 'Bouncing', 'Locking the knees'], subs: ['childs-pose'] }),
  M('thread-needle', 'Thread the needle', { kind: 'yoga', sides: true, stress: ['wrists', 'knees', 'shoulders'], pm: ['Shoulders', 'Back'], reps: [20, 40],
    steps: ['Start on hands and knees. Slide one arm under your body, palm up, until your shoulder and ear rest on the floor.', 'Keep your hips over your knees and breathe into your upper back.', 'Hold, then switch sides for the second set.'],
    mistakes: ['Hips shifting back toward the heels', 'Forcing the shoulder down', 'Holding your breath'], subs: ['cat-cow', 'childs-pose'] }),
  M('supine-twist', 'Supine twist', { kind: 'yoga', sides: true, pm: ['Back', 'Glutes'], reps: [30, 60],
    steps: ['Lie on your back and hug your knees in. Open your arms out to the sides like a T.', 'Drop both knees to one side, keeping your shoulders on the floor as much as is comfortable.', 'Breathe slowly. Use the second set for the other side.'],
    mistakes: ['Forcing the knees to the floor', 'Shoulder lifting high off the mat', 'Holding your breath'], subs: ['spine-twist'] }),
  M('figure-four', 'Figure-four stretch', { kind: 'yoga', sides: true, pm: ['Glutes'], reps: [30, 60],
    steps: ['Lie on your back with knees bent and feet flat. Cross one ankle over the opposite knee.', 'Lift the bottom foot off the floor and hold behind that thigh, drawing it gently toward your chest.', 'Breathe and relax your head and shoulders. Use the second set for the other side.'],
    mistakes: ['Pulling hard on the knee', 'Lifting the head and tensing the neck', 'Holding your breath'], subs: ['supine-twist'] }),
];

/** One line of guidance for the whole group, shown in the workout screen. */
export const MIND_BREATH = 'Breathe slowly and steadily through your nose if you can. In Pilates, breathe out on the effort. In yoga, let each breath lengthen the position. Never hold your breath.';

/**
 * Ready-made routines. Each move: { id, sets, secs }. A move with `sides` has two sets, one per side.
 * `restSec` is the short pause between sets (moving position).
 */
export const ROUTINES = [
  { id: 'mat-pilates', name: 'Mat Pilates core', kind: 'pilates', level: 'Beginner', restSec: 10, blurb: 'A classic mat sequence for your core, glutes and back. No equipment, low impact.',
    moves: [{ id: 'cat-cow', sets: 1, secs: 60 }, { id: 'pelvic-curl', sets: 2, secs: 45 }, { id: 'toe-taps', sets: 2, secs: 40 }, { id: 'hundred', sets: 2, secs: 45 }, { id: 'single-leg-stretch', sets: 2, secs: 45 }, { id: 'leg-circles', sets: 2, secs: 30 }, { id: 'bird-dog', sets: 2, secs: 40 }, { id: 'spine-twist', sets: 2, secs: 30 }, { id: 'swimming', sets: 2, secs: 30 }, { id: 'childs-pose', sets: 1, secs: 60 }] },
  { id: 'gentle-flow', name: 'Gentle yoga flow', kind: 'yoga', level: 'Beginner', restSec: 8, blurb: 'A slow flow for hips, hamstrings, back and shoulders. Stay within a comfortable range.',
    moves: [{ id: 'cat-cow', sets: 1, secs: 60 }, { id: 'childs-pose', sets: 1, secs: 45 }, { id: 'down-dog', sets: 2, secs: 30 }, { id: 'low-lunge', sets: 2, secs: 30 }, { id: 'warrior-2', sets: 2, secs: 30 }, { id: 'cobra', sets: 2, secs: 20 }, { id: 'seated-fold', sets: 1, secs: 45 }, { id: 'supine-twist', sets: 2, secs: 30 }] },
  { id: 'desk-reset', name: 'Desk reset', kind: 'mobility', level: 'Beginner', restSec: 8, blurb: 'A short mobility break for a stiff back, shoulders and hips.',
    moves: [{ id: 'cat-cow', sets: 1, secs: 45 }, { id: 'thread-needle', sets: 2, secs: 30 }, { id: 'roll-down', sets: 1, secs: 45 }, { id: 'low-lunge', sets: 2, secs: 30 }, { id: 'figure-four', sets: 2, secs: 30 }] },
  { id: 'wind-down', name: 'Wind-down stretch', kind: 'mobility', level: 'Beginner', restSec: 8, blurb: 'Slow stretching for the evening or a rest day.',
    moves: [{ id: 'childs-pose', sets: 1, secs: 60 }, { id: 'supine-twist', sets: 2, secs: 40 }, { id: 'figure-four', sets: 2, secs: 40 }, { id: 'seated-fold', sets: 1, secs: 60 }] },
];
export const ROUTINE_BY_ID = Object.fromEntries(ROUTINES.map((r) => [r.id, r]));
export const KIND_LABEL = { pilates: 'Pilates', yoga: 'Yoga', mobility: 'Mobility' };
/** Estimated minutes for a routine: hold time plus the pauses between sets. */
export const routineMinutes = (r) => Math.max(1, Math.round(r.moves.reduce((t, m) => t + m.sets * m.secs + m.sets * r.restSec, 0) / 60));
