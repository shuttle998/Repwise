import { esc, $ } from './util.js';

const P = {
  share: '<path d="M12 15V4M8 8l4-4 4 4M5 13v6h14v-6"/>',
  drop: '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z"/>',
  meal: '<path d="M7 3v8a2 2 0 0 0 2 2v8M5 3v6M9 3v6M17 3c-2 2-3 5-3 8h3v10"/>',
  undo: '<path d="M9 14L4 9l5-5M4 9h10a6 6 0 0 1 0 12h-3"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
  heart: '<path d="M12 21s-7-4.6-9.3-9A5.3 5.3 0 0 1 12 6.4 5.3 5.3 0 0 1 21.3 12C19 16.4 12 21 12 21z"/>',
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
  dumbbell: '<path d="M6.5 6.5v11M17.5 6.5v11M3.5 9v6M20.5 9v6M6.5 12h11"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
  book: '<path d="M4 5a2 2 0 012-2h5v17H6a2 2 0 00-2 2zM20 5a2 2 0 00-2-2h-5v17h5a2 2 0 012 2z"/>',
  sliders: '<path d="M4 6h8M18 6h2M4 12h2M12 12h8M4 18h10M20 18h0"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7"/>',
  play: '<path d="M7 4.5v15l13-7.5z" fill="currentColor"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  timer: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2M9 2h6"/>',
  swap: '<path d="M7 4L3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7"/>',
  skip: '<path d="M5 5l9 7-9 7zM19 5v14"/>',
  trophy: '<path d="M8 4h8v6a4 4 0 01-8 0zM8 6H4v2a4 4 0 004 4M16 6h4v2a4 4 0 01-4 4M12 14v4M8 21h8"/>',
  lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
  flame: '<path d="M12 3c1 4 5 5 5 10a5 5 0 01-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-4-1-6 1-9z"/>',
  right: '<path d="M9 5l7 7-7 7"/>', left: '<path d="M15 5l-7 7 7 7"/>', down: '<path d="M5 9l7 7 7-7"/>', up: '<path d="M5 15l7-7 7 7"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h0"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  upload: '<path d="M12 16V5M7 10l5-5 5 5M5 20h14"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16zM13 7l4 4"/>',
  repeat: '<path d="M3 12a9 9 0 0115-6.7L21 8M21 3v5h-5M21 12a9 9 0 01-15 6.7L3 16M3 21v-5h5"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>',
  bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
  alert: '<path d="M12 4l9 16H3zM12 10v4M12 17h0"/>',
  clip: '<path d="M9 4h6v3H9zM7 5H6a1 1 0 00-1 1v14a1 1 0 001 1h12a1 1 0 001-1V6a1 1 0 00-1-1h-1M9 12h6M9 16h4"/>',
  external: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 01-1 1H5a1 1 0 01-1-1V7a1 1 0 011-1h5"/>',
  grip: '<path d="M8 6h0M16 6h0M8 12h0M16 12h0M8 18h0M16 18h0"/>',
};
export const icon = (n, cls = '') => `<svg class="ic ${cls}" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${P[n] || ''}</svg>`;

// ---------- toasts ----------
let toastTimer;
export function toast(msg, type = 'ok', ms = 3200) {
  const host = $('#toasts'); if (!host) return;
  host.innerHTML = `<div class="toast ${type}" role="${type === 'err' ? 'alert' : 'status'}">${type === 'ok' ? icon('check') : type === 'err' ? icon('alert') : icon('info')}<span>${esc(msg)}</span></div>`;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => (host.innerHTML = ''), ms);
}

// ---------- sheet / modal ----------
let openCount = 0;
export function sheet({ title = '', html = '', onMount, wide = false, label } = {}) {
  const prev = document.activeElement, root = $('#sheets');
  const el = document.createElement('div'); el.className = 'sheet-wrap';
  el.innerHTML = `<div class="sheet-bg" data-close></div><div class="sheet${wide ? ' wide' : ''}" role="dialog" aria-modal="true" aria-label="${esc(label || title || 'Dialog')}"><div class="sheet-grab" aria-hidden="true"></div>${title ? `<div class="sheet-h"><h2>${esc(title)}</h2><button class="icon-btn" data-close aria-label="Close">${icon('x')}</button></div>` : ''}<div class="sheet-b">${html}</div></div>`;
  root.appendChild(el); openCount++;
  const main = $('#shell'); main?.setAttribute('inert', '');
  const box = el.querySelector('.sheet');
  const close = (val) => { if (!el.isConnected) return; el.classList.add('out'); setTimeout(() => el.remove(), 140); if (--openCount <= 0) { main?.removeAttribute('inert'); openCount = 0; } document.removeEventListener('keydown', key); prev?.focus?.(); res?.(val); };
  let res; const done = new Promise((r) => (res = r));
  const key = (e) => {
    if (!el.isConnected) return;
    if (e.key === 'Escape') { e.stopPropagation(); close(); }
    if (e.key === 'Tab') { const f = [...box.querySelectorAll('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])')].filter((x) => !x.disabled && x.offsetParent !== null); if (!f.length) return; const a = f[0], b = f[f.length - 1]; if (e.shiftKey && document.activeElement === a) { e.preventDefault(); b.focus(); } else if (!e.shiftKey && document.activeElement === b) { e.preventDefault(); a.focus(); } }
  };
  document.addEventListener('keydown', key);
  el.addEventListener('click', (e) => { if (e.target.closest('[data-close]')) close(); });
  onMount?.(box, close);
  (box.querySelector('[data-autofocus]') || box.querySelector('button,input,select,textarea,a') || box).focus?.();
  return { el: box, close, done };
}

export function confirmDialog({ title, text, confirm = 'Confirm', cancel = 'Cancel', danger = false }) {
  return new Promise((resolve) => {
    const s = sheet({ title, html: `<p class="mut">${esc(text)}</p><div class="btn-row"><button class="btn ghost" data-v="0">${esc(cancel)}</button><button class="btn ${danger ? 'danger' : 'primary'}" data-v="1" data-autofocus>${esc(confirm)}</button></div>`,
      onMount: (box, close) => box.querySelectorAll('[data-v]').forEach((b) => b.addEventListener('click', () => { resolve(b.dataset.v === '1'); close(); })) });
    s.done.then(() => resolve(false));
  });
}

/** A restrained milestone overlay: drawn ring + check, no confetti. */
export function celebrate({ title, lines = [], cta = 'Continue' }) {
  return new Promise((resolve) => {
    const s = sheet({ label: title, html: `<div class="cele"><svg viewBox="0 0 80 80" width="84" height="84" aria-hidden="true"><circle class="cele-ring" cx="40" cy="40" r="34" fill="none" stroke-width="4" stroke-linecap="round"/><path class="cele-check" d="M26 41l10 10 19-21" fill="none" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/></svg><h2>${esc(title)}</h2>${lines.map((l) => `<p class="cele-l"><b>${esc(l.t)}</b><span>${esc(l.s || '')}</span></p>`).join('')}<button class="btn primary" data-close data-autofocus>${esc(cta)}</button></div>` });
    s.done.then(resolve);
  });
}

export const lockCard = (title, text, cta = 'See Repwise Pro') => `<div class="card lock"><div class="lock-ic">${icon('lock')}</div><div><h3>${esc(title)}</h3><p class="mut">${esc(text)}</p><a class="btn small" href="#/pricing">${esc(cta)}</a></div></div>`;
export const proBadge = () => `<span class="pro-badge">Pro</span>`;
export const empty = (title, text, cta) => `<div class="empty"><h3>${esc(title)}</h3><p class="mut">${esc(text)}</p>${cta || ''}</div>`;
export function upgradePrompt(featureName) {
  sheet({ title: 'This is a Pro feature', html: `<p class="mut">${esc(featureName)} is part of Repwise Pro. Your workouts, history and progress on the Free plan are never taken away.</p><div class="btn-row"><button class="btn ghost" data-close>Not now</button><a class="btn primary" href="#/pricing" data-close>See Pro</a></div>` });
}
export const seg = (name, opts, cur) => `<div class="seg-c" role="group" aria-label="${esc(name)}">${opts.map(([v, l, extra]) => `<button type="button" class="seg-b" data-seg="${esc(name)}" data-v="${esc(v)}" aria-pressed="${String(cur) === String(v)}">${esc(l)}${extra || ''}</button>`).join('')}</div>`;
