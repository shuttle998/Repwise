// Programme generation: pure functions, no DOM, no storage.
import { BY_ID, SLOTS, available, hasLimit, cfgFor, LIMITS, MUSCLES, isGuided } from './exercises.js';
import { uid } from './util.js';

export const GOALS = {
  muscle: { n: 'Build muscle', h: 'Steady growth, 8 to 12 reps', sets: 3, lo: 8, hi: 12, rest: [60, 90], t: '8 to 12 reps', restT: '60 to 90 seconds' },
  strength: { n: 'Get stronger', h: 'Heavier weights, 4 to 6 reps', sets: 4, lo: 4, hi: 6, rest: [120, 180], t: '4 to 6 reps', restT: '2 to 3 minutes' },
  fat: { n: 'Lose weight', h: 'Higher reps, shorter rests', sets: 3, lo: 12, hi: 15, rest: [45, 60], t: '12 to 15 reps', restT: '45 to 60 seconds' },
  gain: { n: 'Gain weight', h: 'Big lifts, more food', sets: 4, lo: 6, hi: 10, rest: [90, 120], t: '6 to 10 reps', restT: '90 seconds to 2 minutes' },
  tone: { n: 'Tone up (body composition)', h: 'Moderate weights, 10 to 15 reps', sets: 3, lo: 10, hi: 15, rest: [45, 75], t: '10 to 15 reps', restT: '45 to 75 seconds' },
  endurance: { n: 'Build endurance', h: 'Lighter weights, 15 to 20 reps', sets: 3, lo: 15, hi: 20, rest: [30, 45], t: '15 to 20 reps', restT: '30 to 45 seconds' },
  general: { n: 'General fitness', h: 'A balanced mix, 10 to 15 reps', sets: 3, lo: 10, hi: 15, rest: [45, 75], t: '10 to 15 reps', restT: '45 to 75 seconds' },
  athletic: { n: 'Athletic performance', h: 'Strong, powerful lifts, 5 to 8 reps', sets: 4, lo: 5, hi: 8, rest: [90, 120], t: '5 to 8 reps', restT: '90 seconds to 2 minutes' },
};
/** Names for the goal steps in onboarding, in the order people expect. `muscle` is hypertrophy and `fat` is weight loss. */
export const GOAL_ORDER = ['muscle', 'fat', 'strength', 'tone', 'endurance', 'general', 'athletic', 'gain'];
export const GOAL_NAME = { muscle: 'Muscle growth (hypertrophy)', fat: 'Weight loss' };
export const FOCUS = { balanced: 'Balanced|Whole body', glutes: 'Glutes and legs|Hip thrusts, split squats, kickbacks', upper: 'Upper body|Chest, back, shoulders, arms' };
export const GEAR = { gym: 'Full gym', db: 'Dumbbells at home', bw: 'No equipment' };
export const GEAR_HINT = { gym: 'Barbells, machines, cables', db: 'A pair of dumbbells and a bench or chair', bw: 'Just your body and a sturdy table' };
export const LEVEL = { 0: 'Beginner', 1: 'Intermediate', 2: 'Advanced' };
export const LEVEL_HINT = { 0: 'New to working out, or coming back after a long break', 1: 'You exercise regularly and know the basic gym exercises', 2: 'You understand progressive overload, exercise variations and structured programmes' };
export const DURATIONS = [30, 45, 60, 75, 90, 120];
/** Duration choices for onboarding. `v` is the minutes the generator uses; custom lets the person type any value from 15 to 180. */
export const DURATION_BANDS = [{ v: 25, t: '15 to 30 min' }, { v: 40, t: '30 to 45 min' }, { v: 55, t: '45 to 60 min' }, { v: 70, t: '60 to 75 min' }, { v: 85, t: '75 to 90 min' }, { v: 105, t: '90 to 120 min' }];
export const MIN_DURATION = 15, MAX_DURATION = 180;

/** Equipment people can pick (several at once). `eq` lists the exercise equipment types each one unlocks. Bodyweight exercises are always allowed. */
export const EQUIPMENT = {
  gym: { n: 'Full gym', h: 'Barbells, machines, cables and cardio machines', eq: ['Barbell', 'Dumbbell', 'Machine', 'Cable', 'Band', 'Cardio machine'] },
  homegym: { n: 'Home gym', h: 'A rack, barbell, dumbbells and a cable or multi-station', eq: ['Barbell', 'Dumbbell', 'Cable', 'Band'] },
  barbell: { n: 'Barbells', h: 'A barbell and plates', eq: ['Barbell'] },
  db: { n: 'Dumbbells', h: 'A pair of dumbbells, ideally with a bench', eq: ['Dumbbell'] },
  kettlebell: { n: 'Kettlebells', h: 'Dumbbell exercises that also work with a kettlebell', eq: ['Dumbbell'] },
  bands: { n: 'Resistance bands', h: 'Loop or tube bands', eq: ['Band'] },
  cable: { n: 'Cable machines', h: 'A cable stack or functional trainer', eq: ['Cable'] },
  smith: { n: 'Smith machine', h: 'Treated like a barbell for squats, presses and rows', eq: ['Barbell'] },
  bw: { n: 'Bodyweight only', h: 'Just your body and a sturdy table', eq: [] },
};
const GYM_TIER = ['gym', 'homegym', 'barbell', 'cable', 'smith'], DB_TIER = ['db', 'kettlebell', 'bands'];
/** The equipment ids for a profile. Older profiles only have `gear`, which maps to one entry. */
export function equipmentOf(p) {
  const e = Array.isArray(p?.equipment) ? p.equipment.filter((x) => EQUIPMENT[x]) : [];
  if (e.length) return [...new Set(e)];
  return [{ gym: 'gym', db: 'db', bw: 'bw' }[p?.gear] || 'gym'];
}
/** The three-level tier the rest of the app understands: gym, db or bw. */
export const gearFromEquipment = (eq) => (eq.some((x) => GYM_TIER.includes(x)) ? 'gym' : eq.some((x) => DB_TIER.includes(x)) ? 'db' : 'bw');
export const allowedEquip = (eq) => new Set(['Bodyweight', ...eq.flatMap((x) => EQUIPMENT[x]?.eq || [])]);
/** True when the person can do this exercise with what they own. */
export const equipOk = (ex, eq) => allowedEquip(eq).has(ex.equip);
export const equipmentLabel = (p) => equipmentOf(p).map((x) => EQUIPMENT[x].n.toLowerCase()).join(', ');

export const GENDER = { male: 'Male', female: 'Female', na: 'Prefer not to say' };
export const BUILD = { guided: ['Guided workout', 'Not sure which exercises to pick? Repwise chooses them and builds the whole programme.'], smart: ['Smart recommendations', 'Repwise recommends a programme from your answers. You can edit anything.'], custom: ['Custom workout', 'Full control: you choose the days, exercises, sets, reps and rest.'] };

/** The twelve areas people can prioritise. `m` is the muscle the exercise library uses; `slot` is the generator slot that trains it directly. */
export const FOCUS_MUSCLES = {
  Glutes: { m: 'Glutes', slot: 'thrust', grp: 'lower' }, Quadriceps: { m: 'Quads', slot: 'quadiso', grp: 'lower' }, Hamstrings: { m: 'Hamstrings', slot: 'hamiso', grp: 'lower' }, Calves: { m: 'Calves', slot: 'calves', grp: 'lower' },
  Back: { m: 'Back', slot: 'pull', grp: 'upper' }, Chest: { m: 'Chest', slot: 'push', grp: 'upper' }, Shoulders: { m: 'Shoulders', slot: 'delts', grp: 'upper' }, Biceps: { m: 'Biceps', slot: 'biceps', grp: 'upper' },
  Triceps: { m: 'Triceps', slot: 'triceps', grp: 'upper' }, Forearms: { m: 'Forearms', slot: 'forearm', grp: 'upper' }, Abs: { m: 'Core', slot: 'abs', grp: 'any' }, Core: { m: 'Core', slot: 'obliques', grp: 'any' },
};
export const STYLE = {
  heavy: 'Big lifts first|Fewer exercises, longer rests',
  balanced: 'Balanced|A mix of main lifts and accessories',
  variety: 'More accessory work|Extra exercises when time allows',
};

const U1 = { n: 'Upper body', k: ['push', 'pull', 'ohp', 'arms'] }, U2 = { n: 'Upper body B', k: ['pull', 'push', 'ohp', 'arms'] };
const L1 = { n: 'Lower body', k: ['squat', 'hinge', 'lunge', 'core'] }, L2 = { n: 'Lower body B', k: ['hinge', 'squat', 'stepup', 'core'] };
const GH = { n: 'Glutes and hamstrings', k: ['thrust', 'hinge', 'kick', 'core'] }, GL = { n: 'Legs and glutes', k: ['squat', 'bulg', 'stepup', 'abduct'] };
const FA = { n: 'Full body A', k: ['squat', 'push', 'pull', 'core'] }, FB = { n: 'Full body B', k: ['hinge', 'ohp', 'lunge', 'core'] };
const AC = { n: 'Arms and core', k: ['push', 'pull', 'arms', 'core'] };
export const SPLIT = {
  balanced: { 2: [FA, FB], 3: [FA, FB, { n: 'Full body C', k: ['lunge', 'push', 'pull', 'arms'] }], 4: [U1, L1, U2, L2], 5: [U1, L1, U2, L2, { n: 'Full body', k: ['squat', 'push', 'pull', 'core'] }] },
  glutes: { 2: [GH, { n: 'Legs, glutes and upper', k: ['squat', 'bulg', 'push', 'pull'] }], 3: [GH, { n: 'Upper body', k: ['push', 'pull', 'ohp', 'core'] }, GL], 4: [GH, U1, GL, { n: 'Glutes and core', k: ['thrust', 'kick', 'abduct', 'core'] }], 5: [GH, U1, GL, U2, { n: 'Glutes and core', k: ['thrust', 'kick', 'abduct', 'core'] }] },
  upper: { 2: [U1, L1], 3: [U1, L1, U2], 4: [U1, L1, U2, AC], 5: [U1, L1, U2, AC, L2] },
};
const EXTRAS = {
  upper: { gym: ['lat-raise', 'triceps-pushdown', 'cable-curl'], db: ['lat-raise', 'db-curl'], bw: ['close-pushup'] },
  lower: { gym: ['leg-curl', 'calf-raise'], db: ['calf-raise'], bw: ['calf-raise'] },
  full: { gym: ['lat-raise', 'calf-raise'], db: ['lat-raise', 'calf-raise'], bw: ['calf-raise'] },
};
const UPPER_KEYS = ['push', 'pull', 'ohp', 'arms', 'delts', 'biceps', 'triceps', 'forearm'];
const REC = { n: 'Active recovery', recovery: true, k: [] };
const PPL = [{ n: 'Push', k: ['push', 'ohp', 'delts', 'triceps'] }, { n: 'Pull', k: ['pull', 'pull', 'biceps', 'forearm'] }, { n: 'Legs', k: ['squat', 'hinge', 'lunge', 'calves', 'core'] }];
const PPL2 = [{ n: 'Push B', k: ['ohp', 'push', 'delts', 'triceps'] }, { n: 'Pull B', k: ['pull', 'pull', 'biceps', 'abs'] }, { n: 'Legs B', k: ['hinge', 'squat', 'stepup', 'hamiso', 'calves'] }];
const GC = { n: 'Glutes and core', k: ['thrust', 'kick', 'abduct', 'core'] };
SPLIT.balanced[6] = [...PPL, ...PPL2]; SPLIT.balanced[7] = [...PPL, ...PPL2, REC];
SPLIT.glutes[6] = [GH, U1, GL, GC, U2, { n: 'Glutes and hamstrings B', k: ['hinge', 'thrust', 'abduct', 'core'] }]; SPLIT.glutes[7] = [...SPLIT.glutes[6], REC];
SPLIT.upper[6] = [U1, L1, U2, AC, L2, { n: 'Upper body C', k: ['pull', 'ohp', 'push', 'arms'] }]; SPLIT.upper[7] = [...SPLIT.upper[6], REC];

/** Named splits. `auto` keeps the original focus-based tables. `days` is the range of days each works well with. */
export const SPLITS = {
  auto: { n: 'Recommended for me', h: 'Repwise picks the split from your days and body focus.', days: [2, 7] },
  full: { n: 'Full body', h: 'Every session trains the whole body. Hit each muscle 2 to 3 times a week with a day of rest between sessions.', who: 'Best for beginners and for 2 to 3 days a week.', days: [2, 4] },
  upperlower: { n: 'Upper body / Lower body', h: 'Alternate upper-body and lower-body days. Each muscle is trained about twice a week.', who: 'A strong all-rounder for 4 days a week.', days: [3, 6] },
  lowerupper: { n: 'Lower body / Upper body', h: 'The same as upper/lower, but you start the week with legs and glutes.', who: 'Good if lower body is your priority and you want it trained first, when you are freshest.', days: [3, 6] },
  ppl: { n: 'Push / Pull / Legs', h: 'Push day (chest, shoulders, triceps), pull day (back, biceps), leg day. Repeat.', who: 'Works best with 3 days (once a week each) or 6 days (twice a week each).', days: [3, 7] },
  bro: { n: 'Bro split', h: 'One main muscle group per day: chest, back, shoulders, arms, legs. High volume per muscle, but each is only trained about once a week.', who: 'Suits experienced lifters with 5 days a week who like lots of work on one muscle at a time.', days: [4, 7] },
  glutes: { n: 'Glute-focused', h: 'Hip thrusts, hinges, split squats and glute isolation in most sessions, with upper body to keep things balanced.', who: 'For anyone who wants more glute and leg development.', days: [2, 7] },
  strength: { n: 'Strength training', h: 'Heavy squat, bench, deadlift and press days with low reps, long rests and a little accessory work.', who: 'Best with some lifting experience and 3 to 4 days a week.', days: [3, 5] },
  hypertrophy: { n: 'Hypertrophy training', h: 'More sets and accessory exercises, with each muscle trained twice a week. Reps and rests are adjustable.', who: 'For building muscle, from 3 to 6 days a week.', days: [3, 6] },
  custom: { n: 'Custom split', h: 'You decide what each day trains. Repwise fills each day with exercises for the muscles you choose.', who: 'For people who already know how they want to train.', days: [2, 7] },
};
export const SPLIT_ORDER = ['auto', 'full', 'upperlower', 'lowerupper', 'ppl', 'bro', 'glutes', 'strength', 'hypertrophy', 'custom'];

const FULL = [FA, FB, { n: 'Full body C', k: ['lunge', 'push', 'pull', 'arms'] }];
const STRENGTH = [{ n: 'Squat day', k: ['squat', 'push', 'pull', 'abs'] }, { n: 'Deadlift day', k: ['deadlift', 'hinge', 'ohp', 'pull'] }, { n: 'Bench day', k: ['push', 'squat', 'pull', 'triceps'] }, { n: 'Press day', k: ['ohp', 'hinge', 'pull', 'core'] }, { n: 'Accessory and core', k: ['lunge', 'pull', 'delts', 'core'] }, { n: 'Light full body', k: ['squat', 'push', 'pull', 'core'] }];
const BRO = [{ n: 'Chest', k: ['push', 'push', 'delts', 'triceps'] }, { n: 'Back', k: ['pull', 'pull', 'hinge', 'forearm'] }, { n: 'Shoulders', k: ['ohp', 'ohp', 'delts', 'abs'] }, { n: 'Arms', k: ['biceps', 'triceps', 'biceps', 'forearm'] }, { n: 'Legs', k: ['squat', 'hinge', 'lunge', 'hamiso', 'quadiso', 'calves'] }, GC];
const cycle = (list, n) => Array.from({ length: n }, (_, i) => ({ ...list[i % list.length] }));
const HYPER = { 2: [FA, FB], 3: FULL, 4: [U1, L1, U2, L2], 5: [U1, L1, PPL[0], PPL[1], PPL[2]], 6: [...PPL, ...PPL2], 7: [...PPL, ...PPL2, REC] };
const withRecovery = (list, d) => (d >= 7 && list.length >= 7 ? [...list.slice(0, 6), REC] : list);
/** Slots that train each muscle, used when someone builds a custom split. */
export const MUSCLE_SLOTS = { Chest: ['push', 'push'], Back: ['pull', 'pull'], Shoulders: ['ohp', 'delts'], Biceps: ['biceps'], Triceps: ['triceps'], Forearms: ['forearm'], Quads: ['squat', 'lunge', 'quadiso'], Hamstrings: ['hinge', 'hamiso'], Glutes: ['thrust', 'kick'], Calves: ['calves'], Core: ['core', 'abs', 'obliques'] };

/** What to tell people about rest, by training days. */
export const RECOVERY = {
  2: 'Two days leaves plenty of recovery. Space them out, for example Monday and Thursday.',
  3: 'Three days with a rest day between each (for example Monday, Wednesday, Friday) is a classic, well-recovered pattern.',
  4: 'Four days works well as two on, one off, two on, or as Monday, Tuesday, Thursday, Friday. Keep two rest days.',
  5: 'Five days leaves two rest days. Avoid training the same muscles on back-to-back days, and take one of the rest days fully off.',
  6: 'Six days leaves one rest day, so sleep and food matter. Keep one session lighter, and take a deload week every 4 to 8 weeks.',
  7: 'Seven days means no full rest day, so your seventh session is light active recovery (easy cardio and mobility). Sleep well, and take a deload week every 4 to 8 weeks.',
};

/**
 * Sets, rep range and rest for an exercise given the goal, experience and style.
 * `o.params` ({ sets, repLo, repHi, restSec }) are the person's own overrides and win over the goal defaults.
 * `o.goals2` are secondary goals: strength makes compound lifts a little heavier, endurance and muscle tweak accessory work.
 */
export function prescribe(ex, goal, level = 0, style = 'balanced', isMain = false, o = {}) {
  const g = GOALS[goal] || GOALS.muscle, pr = o.params || {}, sec = o.goals2 || [];
  if (ex.unit === 'min') { const m = Math.round((ex.reps[0] + ex.reps[1]) / 2); return { sets: 1, repLo: m, repHi: m, restSec: 0 }; } // cardio: one block of minutes
  if (isGuided(ex)) return { sets: ex.sides ? 2 : 1, repLo: ex.reps[0], repHi: ex.reps[1], restSec: 15 }; // warm-up, activation, stretch, mind-body
  if (ex.type === 'Core') return { sets: pr.sets ? Math.min(pr.sets, 4) : 2, repLo: ex.reps?.[0] ?? (ex.unit === 'sec' ? 30 : 8), repHi: ex.reps?.[1] ?? (ex.unit === 'sec' ? 60 : 12), restSec: 45 };
  if (ex.reps) { const own = pr.repLo && pr.repHi && ex.unit !== 'sec'; return { sets: pr.sets || 3, repLo: own ? pr.repLo : ex.reps[0], repHi: own ? pr.repHi : ex.reps[1], restSec: pr.restSec || 45 }; }
  let sets = g.sets, lo = g.lo, hi = g.hi, rest = Math.round((g.rest[0] + g.rest[1]) / 2 / 15) * 15;
  if (ex.type === 'Isolation') {
    sets = Math.min(3, sets);
    if (goal === 'strength') { lo = 8; hi = 12; } else { lo += 2; hi += 3; }
    rest = Math.min(rest, 75);
    if (sec.includes('endurance') && goal !== 'endurance') { hi += 3; rest = Math.max(30, rest - 15); }
    if (sec.includes('muscle') && goal !== 'muscle') sets = Math.min(4, sets + 1);
  } else {
    if (level === 0) sets = Math.min(sets, 3);
    if (level === 2 && isMain && (goal === 'muscle' || goal === 'gain') && sets < 5) sets += 1;
    if (sec.includes('strength') && goal !== 'strength') { lo = Math.max(4, lo - 2); hi = Math.max(lo + 2, hi - 3); rest += 15; }
  }
  if (style === 'heavy' && ex.type === 'Compound') rest += 15;
  if (pr.sets) sets = pr.sets;
  if (pr.repLo && pr.repHi) { lo = pr.repLo; hi = pr.repHi; }
  if (pr.restSec) rest = pr.restSec;
  return { sets, repLo: lo, repHi: hi, restSec: rest };
}
export const estMinutes = (items) => Math.round(items.reduce((a, it) => (BY_ID[it.exId]?.unit === 'min' ? a + it.sets * it.repLo : a + it.sets * (45 + it.restSec) / 60 + 0.7), 0));

const TIERS = ['gym', 'db', 'bw'];
function pickForSlot(slot, p, variant, taken) {
  const eq = equipmentOf(p), lim = p.limits || [], avoid = p.avoid || [];
  const good = (e) => e && available(e, p.gear) && equipOk(e, eq) && !hasLimit(e, lim) && !avoid.includes(e.id) && !taken.has(e.id) && !isGuided(e);
  const fromTiers = (sl, tiers) => [...new Set(tiers.flatMap((t) => SLOTS[sl]?.[t] || []))].map((id) => BY_ID[id]).filter(good);
  const mine = TIERS.slice(Math.max(0, TIERS.indexOf(p.gear)));
  let pool = fromTiers(slot, mine.slice(0, 1));
  if (!pool.length) pool = fromTiers(slot, mine); // nothing for this equipment: try simpler equipment
  if (!pool.length && ['squat', 'lunge', 'bulg', 'stepup'].includes(slot)) pool = fromTiers('thrust', mine);
  if (!pool.length) return null;
  if (p.level === 0) pool = pool.filter((e) => e.diff !== 'Advanced'); // beginners never get advanced lifts, even if that leaves the slot empty
  if (!pool.length) return null;
  const fav = pool.find((e) => (p.favour || []).includes(e.id));
  return fav || pool[variant % pool.length];
}

const LOWER_KEYS = ['squat', 'hinge', 'lunge', 'thrust', 'kick', 'abduct', 'stepup', 'bulg', 'quadiso', 'hamiso', 'calves', 'deadlift'];
const cap = (n, lo, hi) => Math.min(hi, Math.max(lo, n));

function customSessions(p, d) {
  const days = Array.isArray(p.customDays) ? p.customDays : [];
  return Array.from({ length: d }, (_, i) => {
    const c = days[i] || {}, ms = (c.muscles || []).filter((m) => MUSCLE_SLOTS[m]);
    const k = ms.length ? [...new Set(ms)].flatMap((m) => MUSCLE_SLOTS[m]) : ['squat', 'push', 'pull', 'core'];
    return { n: String(c.name || `Day ${i + 1}`).slice(0, 40), k, custom: true };
  });
}

export function sessionsFor(p) {
  const d = cap(Math.round(p.days || 3), 2, 7), sp = SPLITS[p.split] ? p.split : 'auto';
  let list;
  switch (sp) {
    case 'full': list = withRecovery(cycle(FULL, d), d); break;
    case 'upperlower': list = withRecovery(cycle([U1, L1, U2, L2], d), d); break;
    case 'lowerupper': list = withRecovery(cycle([L1, U1, L2, U2], d), d); break;
    case 'ppl': list = d <= 2 ? [U1, PPL[2]] : withRecovery(cycle([...PPL, ...PPL2], d), d); break;
    case 'bro': list = d <= 2 ? [U1, BRO[4]] : d === 3 ? [{ n: 'Chest and shoulders', k: ['push', 'push', 'ohp', 'delts'] }, { n: 'Back and arms', k: ['pull', 'pull', 'biceps', 'triceps'] }, BRO[4]] : d === 4 ? [BRO[0], BRO[1], BRO[4], { n: 'Shoulders and arms', k: ['ohp', 'delts', 'biceps', 'triceps'] }] : [...BRO.slice(0, Math.min(d, 6)), ...(d >= 7 ? [REC] : [])]; break;
    case 'glutes': list = SPLIT.glutes[d]; break;
    case 'strength': list = d === 2 ? [STRENGTH[0], STRENGTH[1]] : d === 3 ? [STRENGTH[0], STRENGTH[1], { n: 'Bench and press day', k: ['push', 'ohp', 'pull', 'triceps'] }] : [...STRENGTH.slice(0, Math.min(d, 6)), ...(d >= 7 ? [REC] : [])]; break;
    case 'hypertrophy': list = HYPER[d]; break;
    case 'custom': list = customSessions(p, d); break;
    default: list = SPLIT[p.focus || 'balanced'][d];
  }
  return list.map((s) => ({ ...s }));
}

const COVER = { Chest: ['push'], Back: ['pull'], Shoulders: ['delts', 'ohp'], Biceps: ['biceps'], Triceps: ['triceps'], Quads: ['quadiso', 'lunge', 'squat'], Hamstrings: ['hamiso', 'hinge'], Glutes: ['thrust', 'kick'], Calves: ['calves'], Core: ['abs', 'core'] };
const GROUP = { Chest: 'upper', Back: 'upper', Shoulders: 'upper', Biceps: 'upper', Triceps: 'upper', Quads: 'lower', Hamstrings: 'lower', Glutes: 'lower', Calves: 'lower', Core: 'any' };
export const MAJOR = Object.keys(COVER);
/** Which body areas a session mainly trains. A day with one stray hinge (a back day, say) is still an upper day. Full-body days count as both. */
const sessionGroups = (s) => {
  const up = s.k.filter((k) => UPPER_KEYS.includes(k)).length, lo = s.k.filter((k) => LOWER_KEYS.includes(k)).length;
  const full = s.k.some((k) => ['push', 'ohp'].includes(k)) && s.k.includes('pull') && lo >= 1;
  return { upper: up >= 2 || (full && up >= 1), lower: lo >= 2 || full, any: true };
};
const insertAt = (items) => Math.max(0, items.length - (items.length && BY_ID[items[items.length - 1].exId]?.type === 'Core' ? 1 : 0));

/** A light session of easy cardio and mobility for the seventh day. These are guided exercises: no weights, no progression. */
function recoverySession(p) {
  const eq = equipmentOf(p), ok = (id) => { const e = BY_ID[id]; return e && equipOk(e, eq) && !hasLimit(e, p.limits || []); };
  const cardio = ['treadmill', 'cycling', 'elliptical', 'march-in-place'].find(ok) || 'march-in-place';
  const ids = [cardio, ...['cat-cow', 'childs-pose', 'low-lunge', 'thread-needle', 'hip-flexor-stretch', 'figure-four-stretch', 'seated-fold'].filter(ok).slice(0, 5)];
  const items = ids.map((id) => { const e = BY_ID[id]; return e.unit === 'min' ? { exId: id, sets: 1, repLo: 15, repHi: 15, restSec: 0 } : { exId: id, sets: e.sides ? 2 : 1, repLo: Math.min(45, e.reps[0]), repHi: Math.min(45, e.reps[0]), restSec: 10 }; });
  return { id: uid(), name: 'Active recovery', items, recovery: true, note: 'Keep this easy. If you feel run down, take the day fully off instead.' };
}

const clampInt = (v, lo, hi, d) => { const n = Math.round(Number(v)); return n >= lo && n <= hi ? n : d; };
/** Cleans the person's own training parameters. Anything out of range is dropped rather than guessed. */
export function normParams(o) {
  const r = o && typeof o === 'object' ? o : {}, out = {}, sets = clampInt(r.sets, 1, 8, 0), lo = clampInt(r.repLo, 1, 40, 0), hi = clampInt(r.repHi, 1, 60, 0), rest = clampInt(r.restSec, 15, 300, 0);
  if (sets) out.sets = sets;
  if (lo && hi && hi >= lo) { out.repLo = lo; out.repHi = hi; }
  if (rest) out.restSec = rest;
  return out;
}
/**
 * Cleans a profile so the rest of the app can trust it. Older profiles (single `gear`, 2 to 5 days, four goals) stay valid.
 * When `equipment` is a non-empty list, `gear` is derived from it so both always agree.
 */
export function normProfile(p0) {
  const p = { ...(p0 || {}) };
  if (Array.isArray(p.equipment) && p.equipment.some((x) => EQUIPMENT[x])) { p.equipment = equipmentOf(p); p.gear = gearFromEquipment(p.equipment); } else { delete p.equipment; p.gear = TIERS.includes(p.gear) ? p.gear : 'gym'; }
  p.goal = GOALS[p.goal] ? p.goal : 'muscle';
  p.goals2 = (Array.isArray(p.goals2) ? p.goals2 : []).filter((g, i, a) => GOALS[g] && g !== p.goal && a.indexOf(g) === i).slice(0, 2);
  p.level = clampInt(p.level, 0, 2, 0); p.days = clampInt(p.days, 2, 7, 3); p.duration = clampInt(p.duration, MIN_DURATION, MAX_DURATION, 60);
  p.split = SPLITS[p.split] ? p.split : 'auto'; p.focus = FOCUS[p.focus] ? p.focus : 'balanced'; p.style = STYLE[p.style] ? p.style : 'balanced';
  p.focusMuscles = (Array.isArray(p.focusMuscles) ? p.focusMuscles : []).filter((x, i, a) => FOCUS_MUSCLES[x] && a.indexOf(x) === i);
  p.params = normParams(p.params);
  p.customDays = (Array.isArray(p.customDays) ? p.customDays : []).slice(0, 7).map((c, i) => ({ name: String(c?.name || `Day ${i + 1}`).trim().slice(0, 40) || `Day ${i + 1}`, muscles: (c?.muscles || []).filter((m) => MUSCLE_SLOTS[m]) }));
  if (!GENDER[p.gender]) delete p.gender;
  p.limits = (Array.isArray(p.limits) ? p.limits : []).filter((k) => LIMITS[k]);
  p.avoid = Array.isArray(p.avoid) ? p.avoid : []; p.favour = Array.isArray(p.favour) ? p.favour : [];
  return p;
}
/** The goal whose rep ranges apply. The hypertrophy and strength splits carry their own training style unless the person's goal already fits it. */
const effGoal = (p) => (p.split === 'hypertrophy' && !['muscle', 'gain', 'tone'].includes(p.goal) ? 'muscle' : p.split === 'strength' && !['strength', 'athletic'].includes(p.goal) ? 'strength' : p.goal);

/** Adds exercises for the body areas the person wants to prioritise, and fills long sessions. Time budgets and per-level caps still apply. */
function enrich(items, s, p, taken, budget, variant, po, goal, ctx) {
  if (s.custom) return; // custom days contain exactly what the person chose
  const wantFocus = p.focusMuscles.length > 0, wantFill = p.duration > 75 || (p.split !== 'auto' && estMinutes(items) < budget - 15); if (!wantFocus && !wantFill) return;
  const g = sessionGroups(s), maxItems = [7, 9, 12][p.level] + (p.duration > 90 ? 1 : 0);
  const add = (slot) => {
    if (items.length >= maxItems) return false;
    const e = pickForSlot(slot, p, variant, taken); if (!e) return false;
    const it = { exId: e.id, ...prescribe(e, goal, p.level, p.style, false, po) };
    if (estMinutes([...items, it]) > budget) return false;
    taken.add(e.id); items.splice(insertAt(items), 0, it); return true;
  };
  for (const label of p.focusMuscles) {
    const f = FOCUS_MUSCLES[label]; if (!(f.grp === 'any' || g[f.grp])) continue;
    const hit = items.find((it) => { const e = BY_ID[it.exId]; return e.pm.includes(f.m) && e.type !== 'Core' && it.sets < 5; });
    if (hit) { hit.sets++; if (estMinutes(items) > budget) hit.sets--; } // one extra set on a lift that already trains it
    add(f.slot);
  }
  if (wantFill) {
    const pushy = s.k.some((k) => ['push', 'ohp'].includes(k)), pully = s.k.includes('pull');
    const upperOrder = pushy && !pully ? ['delts', 'triceps'] : pully && !pushy ? ['biceps', p.level > 0 ? 'forearm' : null] : pushy && pully ? ['delts', 'biceps', 'triceps', p.level > 0 ? 'forearm' : null] : [];
    const order = [...(g.upper ? upperOrder : []), ...(g.lower ? ['hamiso', 'quadiso', 'calves', 'abduct'] : []), ...(items.some((it) => BY_ID[it.exId].type === 'Core') || ctx.core >= 3 ? [] : ['abs']), ...(p.duration > 90 ? ['obliques'] : [])].filter(Boolean);
    for (const slot of order) { if (estMinutes(items) >= budget - 8) break; if (!s.k.includes(slot) && add(slot) && (slot === 'abs' || slot === 'obliques')) ctx.core++; }
  }
}

/** Makes sure every major muscle is trained at least once a week when there is room, so programmes stay balanced. */
function ensureCoverage(sessions, metas, p, variant, po, goal, budget) {
  if (p.days < 3 || p.split === 'custom') return;
  const hits = new Set(); sessions.forEach((s) => s.items.forEach((it) => { const e = BY_ID[it.exId]; if (e && !isGuided(e)) e.pm.forEach((m) => hits.add(m)); }));
  for (const m of MAJOR) {
    if (hits.has(m)) continue;
    const cand = sessions.map((s, i) => ({ s, meta: metas[i] })).filter((x) => !x.s.recovery && sessionGroups(x.meta)[GROUP[m]]).sort((a, b) => a.s.items.length - b.s.items.length);
    for (const c of cand) {
      const taken = new Set(c.s.items.map((i) => i.exId)); let e = null;
      for (const slot of COVER[m]) { e = pickForSlot(slot, p, variant, taken); if (e && e.pm.includes(m)) break; e = null; }
      if (!e) continue;
      const it = { exId: e.id, ...prescribe(e, goal, p.level, p.style, false, po) };
      if (estMinutes([...c.s.items, it]) <= budget + 5) { c.s.items.splice(insertAt(c.s.items), 0, it); hits.add(m); break; }
      // No room: swap out an accessory whose muscle is also trained elsewhere this week, so the session length stays the same.
      const cnt = {}; sessions.forEach((s2) => s2.items.forEach((x) => { const ex2 = BY_ID[x.exId]; if (ex2 && !isGuided(ex2)) ex2.pm.forEach((mm) => { cnt[mm] = (cnt[mm] || 0) + 1; }); }));
      let k = -1; for (let j = c.s.items.length - 1; j > 0; j--) { const ex2 = BY_ID[c.s.items[j].exId]; if (ex2 && !isGuided(ex2) && ex2.pm.every((mm) => cnt[mm] > 1)) { k = j; break; } }
      if (k < 0) continue;
      const after = c.s.items.slice(); after.splice(k, 1, it); if (estMinutes(after) > budget + 5) continue;
      c.s.items.splice(k, 1, it); hits.add(m); break;
    }
  }
}

/** Build a programme from a profile. `variant` rotates exercise choices on regenerate. */
export function generateProgram(p0, { variant = 0 } = {}) {
  const p = normProfile(p0), duration = p.duration, style = p.style, goal = effGoal(p), po = { params: p.params, goals2: p.goals2 }, eq = equipmentOf(p);
  const budget = duration - 5; // minutes after a 5 min warm-up
  const metas = [], ctx = { core: 0 };
  const sessions = sessionsFor(p).map((s) => {
    metas.push(s);
    if (s.recovery) return recoverySession(p);
    const taken = new Set(), items = [];
    s.k.forEach((slot, i) => {
      const e = pickForSlot(slot, p, variant, taken); if (!e) return;
      taken.add(e.id);
      items.push({ exId: e.id, ...prescribe(e, goal, p.level, style, i === 0, po) });
    });
    // extras to use the available time (not for custom days: the person chose exactly what each day trains)
    if (!s.custom && p.split === 'auto') {
      const hasU = s.k.some((k) => UPPER_KEYS.includes(k)), hasL = s.k.some((k) => !UPPER_KEYS.includes(k) && k !== 'core');
      const extraKey = hasU && hasL ? 'full' : hasU ? 'upper' : 'lower';
      const extras = (EXTRAS[extraKey][p.gear] || []).map((id) => BY_ID[id]).filter((e) => e && available(e, p.gear) && equipOk(e, eq) && !hasLimit(e, p.limits) && !taken.has(e.id) && !p.avoid.includes(e.id));
      const wantExtra = style === 'variety' ? 2 : style === 'balanced' && duration >= 60 ? 1 : 0;
      let extraAdded = 0;
      for (const e of extras) {
        if (extraAdded >= wantExtra) break;
        const it = { exId: e.id, ...prescribe(e, goal, p.level, style, false, po) };
        if (estMinutes([...items, it]) <= budget) { items.splice(Math.max(0, items.length - (items.some((x) => BY_ID[x.exId].type === 'Core') ? 1 : 0)), 0, it); taken.add(e.id); extraAdded++; }
      }
    }
    // trim to fit short sessions: drop core / isolation first, never below 3
    while (estMinutes(items) > budget && items.length > 3) {
      let idx = -1;
      for (let i = items.length - 1; i >= 0; i--) { const t = BY_ID[items[i].exId].type; if (t === 'Core' || t === 'Isolation') { idx = i; break; } }
      items.splice(idx >= 0 ? idx : items.length - 1, 1);
    }
    // still too long (long rests, short session): shave sets, down to 2 per exercise
    while (estMinutes(items) > budget) {
      const cand = items.filter((it) => it.sets > 2).sort((a, b) => b.sets - a.sets)[0];
      if (!cand) break; cand.sets--;
    }
    if (style === 'heavy') { // fewer, bigger lifts
      for (let i = items.length - 1; i >= 0 && items.length > 3; i--) if (BY_ID[items[i].exId].type === 'Isolation') items.splice(i, 1);
    }
    while (estMinutes(items) > budget && items.length > 2) items.pop(); // very short sessions (15 to 25 minutes): two or three exercises
    if (!s.custom) for (const sl of ['core', 'abs', 'obliques', 'calves', 'kick']) { // never leave a session with fewer than three exercises
      if (items.length >= 3) break;
      const e = pickForSlot(sl, p, variant, taken); if (e) { taken.add(e.id); items.push({ exId: e.id, ...prescribe(e, goal, p.level, style, false, po) }); }
    }
    enrich(items, s, p, taken, budget, variant, po, goal, ctx);
    return { id: uid(), name: s.n, items };
  });
  ensureCoverage(sessions, metas, p, variant, po, goal, budget);
  return { id: uid(), name: `${GOALS[p.goal]?.n || 'Custom'} plan`, createdAt: new Date().toISOString(), variant, custom: false, split: p.split, sessions };
}

/** Which muscles a programme trains per week (primary muscle = 1 hit per session containing it). */
export function weeklyFrequency(program) {
  const f = Object.fromEntries(MUSCLES.map((m) => [m, 0]));
  program.sessions.forEach((s) => { const set = new Set(); s.items.forEach((it) => BY_ID[it.exId]?.pm.forEach((m) => set.add(m))); set.forEach((m) => f[m]++); });
  return f;
}
export const weeklySets = (program) => {
  const f = Object.fromEntries(MUSCLES.map((m) => [m, 0]));
  program.sessions.forEach((s) => s.items.forEach((it) => { const e = BY_ID[it.exId]; if (!e || isGuided(e)) return; e.pm.forEach((m) => (f[m] = (f[m] || 0) + it.sets)); e.sm.forEach((m) => { if (m in f) f[m] += it.sets * 0.5; }); }));
  return f;
};

const WHY_GOAL = {
  muscle: 'Muscle grows best with moderate loads you can lift for 8 to 12 reps, taken close to (but not to) failure, with enough volume across the week. Three sets per exercise with 60 to 90 seconds of rest keeps quality high without dragging the session out.',
  strength: 'Strength responds to heavy weights lifted for low reps with long rests, so each main lift gets 4 to 6 reps and 2 to 3 minutes of recovery between sets. Accessory work uses higher reps to support the big lifts.',
  fat: 'For losing weight, lifting protects your muscle while you eat a little less. Higher reps (12 to 15) with shorter rests keep the session brisk. Food and daily steps matter as much as the plan itself.',
  gain: 'Gaining weight on purpose works best with big compound lifts in the 6 to 10 rep range, plenty of sets, and long enough rests to keep the weights heavy. Eating enough is what turns the training into weight gained.',
  tone: 'Body composition changes come from building muscle while keeping body fat in check. Moderate weights for 10 to 15 reps with shorter rests keep the work demanding without needing very heavy loads. Food and daily activity matter as much as the plan.',
  endurance: 'Muscular endurance responds to lighter weights, 15 to 20 reps and short rests of 30 to 45 seconds. Add cardio from the Train tab if you want to build your heart and lungs too.',
  general: 'For general fitness, a balanced mix of strength work in the 10 to 15 rep range keeps every area trained without needing heavy loads or long sessions.',
  athletic: 'Athletic performance leans on strong, powerful lifts: 5 to 8 reps on the main lifts with 90 seconds to 2 minutes of rest. This plan builds the strength base. It does not include sport-specific drills, jumping or sprint work.',
};
const SEC_TEXT = { strength: 'a little heavier on the main lifts', endurance: 'higher reps on accessory work', muscle: 'an extra set on accessory work' };

/** Weekly working sets per muscle against the commonly used 10 to 20 sets range for muscle growth. Guidance, not a rule. */
export const VOLUME_RANGE = { lo: 10, hi: 20 };
export function volumeReport(program) {
  const w = weeklySets(program), f = weeklyFrequency(program);
  return MUSCLES.map((m) => ({ muscle: m, sets: Math.round(w[m] * 10) / 10, freq: f[m], status: w[m] < VOLUME_RANGE.lo ? 'low' : w[m] > VOLUME_RANGE.hi ? 'high' : 'ok' }));
}

export function explainProgram(program, p0) {
  const p = normProfile(p0), days = program.sessions.length, freq = weeklyFrequency(program), goal = effGoal(p);
  const trained = Object.entries(freq).filter(([, v]) => v > 0);
  const twice = trained.filter(([, v]) => v >= 2).map(([k]) => k.toLowerCase());
  const g = GOALS[goal] || GOALS.muscle, sp = SPLITS[p.split] || SPLITS.auto, par = p.params || {};
  const points = [];
  points.push({ title: 'Built for your goal', text: (WHY_GOAL[p.goal] || WHY_GOAL.muscle) + (p.goals2.length ? ` Your secondary goal${p.goals2.length > 1 ? 's' : ''} (${p.goals2.map((x) => GOALS[x].n.toLowerCase()).join(', ')}) ${p.goals2.length > 1 ? 'shape' : 'shapes'} the plan lightly: ${p.goals2.filter((x) => SEC_TEXT[x]).map((x) => SEC_TEXT[x]).join(', ') || 'no changes to sets and reps'}.` : '') });
  const splitName = p.split !== 'auto' ? `the ${sp.n.toLowerCase()} split` : (p.focus || 'balanced') === 'balanced' && days <= 3 ? 'full-body sessions' : 'an upper/lower style split';
  const lift = program.sessions.filter((x) => !x.recovery).length;
  points.push({ title: `${days} days a week`, text: `Your week uses ${splitName}. ${p.split !== 'auto' ? sp.h + ' ' : ''}${twice.length ? `Muscles hit at least twice a week: ${twice.join(', ')}. ` : ''}${RECOVERY[days] || ''}${p.level === 0 && days >= 5 ? ' Five or more days is a lot when you are starting out. If you feel run down, drop a day.' : ''}${lift < days ? ` The ${days === 7 ? 'seventh' : 'last'} session is light active recovery, not lifting.` : ''}` });
  const eqn = equipmentOf(p), gearText = eqn.length === 1 && !p.equipment ? { gym: 'Your plan uses barbells, machines and cables.', db: 'Everything is chosen to work with dumbbells and a bench or chair.', bw: 'Everything uses just your body weight and a sturdy table, with the reps doing the progressing.' }[p.gear] : `Exercises are limited to what you listed: ${equipmentLabel(p)}${eqn.includes('smith') ? ' (the Smith machine is treated like a barbell)' : ''}${eqn.includes('kettlebell') ? ' (dumbbell exercises are chosen so they also work with a kettlebell)' : ''}.`;
  const lim = (p.limits || []).map((k) => LIMITS[k]?.toLowerCase()).filter(Boolean);
  const focusTxt = p.focusMuscles.length ? `You asked to prioritise ${p.focusMuscles.map((x) => x.toLowerCase()).join(', ')}, so those get an extra exercise or set where they fit, while the rest of the body stays trained. ` : p.focus === 'glutes' ? 'Glute work (hip thrusts, split squats, kickbacks) is built into every lower session. ' : p.focus === 'upper' ? 'Upper-body lifts get the most weekly volume. ' : 'Each session pairs a leg or hip movement with a push and a pull. ';
  points.push({ title: 'Exercise selection', text: `${gearText} ${focusTxt}${lim.length ? `Exercises that load your ${lim.join(' and ')} heavily were left out; swap anything in the editor if something still feels wrong.` : ''}` });
  const custom = par.sets || par.repLo || par.restSec;
  points.push({ title: 'Sets, reps and rest', text: `Main lifts: ${custom ? `${par.sets ? par.sets + ' sets' : ''}${par.repLo ? `${par.sets ? ' of ' : ''}${par.repLo} to ${par.repHi} reps` : ''}${par.restSec ? `${par.sets || par.repLo ? ' with ' : ''}${par.restSec} seconds of rest` : ''} (your settings; anything you left blank follows the ${g.n.toLowerCase()} defaults)` : `${p.level === 0 ? 'up to 3' : g.sets} sets of ${g.t} with ${g.restT} of rest`}. Accessories: higher reps and shorter rests. Sessions are sized to about ${p.duration || 60} minutes including a short warm-up.${(p.duration || 60) > 90 ? ' Very long sessions are capped at a realistic number of exercises, so they may finish sooner. Use the cardio and cool-down options to fill the rest.' : ''}` });
  points.push({ title: 'Progressive overload', text: 'You start deliberately light. When you reach the top of the rep range on every set and it felt manageable, the weight goes up by one small step. If it was a grind, it stays. If you struggle two sessions in a row, it comes down. Every recommendation shows its reason.' });
  const ING = { muscle: 'building muscle', strength: 'getting stronger', fat: 'losing weight', gain: 'gaining weight', tone: 'toning up', endurance: 'building endurance', general: 'general fitness', athletic: 'athletic performance' };
  return { headline: `${days} sessions per week for ${ING[p.goal] || 'your goal'}`, points };
}
