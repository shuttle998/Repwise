// Turns a weekly or monthly report into plain text and CSV. Pure functions: same report in, same text out.
import { fmtVol, fmtDur, fmtW, MONTHS, dateKey } from './util.js';
import { MEALS } from './nutrition.js';

const prLabel = (e, u) => (e.kind === 'weight' ? `${fmtW(e.value, u, true)} x ${e.reps}` : e.kind === 'e1rm' ? `est. 1RM ${fmtW(e.value, u, true)}` : `${e.value} reps`);
const dayLbl = (d) => `${d.getDate()} ${MONTHS[d.getMonth()]}`;
export const reportTitle = (r) => (r.kind === 'month' ? `Repwise monthly report: ${r.label}` : `Repwise weekly report: ${dayLbl(r.start)} to ${dayLbl(r.end)} ${r.end.getFullYear()}`);
export const reportFile = (r, ext) => `repwise-${r.kind === 'month' ? 'month-' + r.key : 'week-' + r.key}.${ext}`;
const change = (pct) => (pct == null ? 'no previous period to compare' : `${pct >= 0 ? '+' : '-'}${Math.abs(Math.round(pct))}% vs previous`);

/** Sections: [{ title, rows: [[label, value]] }]. `nut` is nutritionSummary output or null. */
export function reportSections(r, u = 'kg', nut = null, wl = null) {
  const month = r.kind === 'month', plan = month ? r.planned : r.target, S = [];
  S.push({ title: 'Summary', rows: [
    ['Workouts completed', `${r.workouts} of ${plan} planned`], ['Consistency', `${Math.round(r.consistency * 100)}%`],
    ['Total training volume', `${fmtVol(r.volume, u)} (${change(r.volumeChangePct)})`], ['Total training time', r.seconds ? fmtDur(r.seconds) : 'not recorded'], ['Sets', String(r.sets)],
    ...(month ? [['Weeks on target', `${r.weeksHit} of ${r.weeks.length} full weeks`]] : []),
  ] });
  S.push({ title: 'Strength improvements', rows: r.improved.length ? r.improved.map((i) => [i.name, i.kind === 'e1rm' ? `est. 1RM ${fmtW(i.from, u)} to ${fmtW(i.to, u, true)}` : `best set ${i.from} to ${i.to} reps`]) : [['None', 'No exercise beat its earlier best in this period']] });
  S.push({ title: 'Personal records', rows: r.prs.length ? r.prs.map((e) => [e.name, `${prLabel(e, u)} on ${e.date}`]) : [['None', 'No new records in this period']] });
  S.push({ title: 'Muscle group distribution (sets)', rows: r.muscles.filter((m) => m.sets > 0).map((m) => [m.muscle, String(+m.sets.toFixed(1))]) });
  S.push({ title: 'Missed targets', rows: r.areas.length ? r.areas.map((a) => ['', a]) : [['None', 'Nothing flagged']] });
  S.push({ title: 'Suggested improvements', rows: r.recommendations.map((a) => ['', a]) });
  if (nut?.hasData) S.push({ title: 'Nutrition and hydration', rows: [
    ...(nut.loggedDays ? [['Days with meals logged', `${nut.loggedDays} of ${nut.days}`], ['Average calories', `${nut.avgKcal} kcal`], ['Average protein', `${nut.avgProtein} g`], ['Average carbs', `${nut.avgCarbs} g`], ['Average fat', `${nut.avgFat} g`]] : []),
    ...(nut.kcalDaysOnTarget != null ? [['Days within 10% of calorie target', `${nut.kcalDaysOnTarget} of ${nut.loggedDays}`]] : []),
    ...(nut.proteinDaysOnTarget != null ? [['Days protein target met (90%+)', `${nut.proteinDaysOnTarget} of ${nut.loggedDays}`]] : []),
    ...(nut.waterDays ? [['Days with water logged', `${nut.waterDays} of ${nut.days}`], ['Average water on those days', `${nut.avgWaterMl} ml`]] : []),
    ...(nut.waterDaysOnTarget != null ? [['Days water target met (90%+)', `${nut.waterDaysOnTarget} of ${nut.waterDays}`]] : []),
  ] });
  return S;
}
export function reportText(r, u = 'kg', nut = null) {
  const out = [reportTitle(r), ''];
  reportSections(r, u, nut).forEach((s) => { out.push(s.title.toUpperCase()); s.rows.forEach(([a, b]) => out.push(a ? `- ${a}: ${b}` : `- ${b}`)); out.push(''); });
  out.push('Built from the workouts you logged in Repwise. Not medical advice.');
  return out.join('\n');
}
const cell = (v) => { let s = String(v ?? ''); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
export function reportCSV(r, u = 'kg', nut = null) {
  const rows = [['Section', 'Item', 'Value'], ['Report', 'Title', reportTitle(r)], ['Report', 'Period', r.kind === 'month' ? r.label : `${dateKey(r.start)} to ${dateKey(r.end)}`]];
  reportSections(r, u, nut).forEach((s) => s.rows.forEach(([a, b]) => rows.push([s.title, a, b])));
  return '﻿' + rows.map((x) => x.map(cell).join(',')).join('\r\n') + '\r\n';
}
/** Day-by-day meals and water for a period, for the nutrition export. */
export function nutritionCSV(n, w, dates) {
  const rows = [['Date', 'Meal', 'Name', 'Calories', 'Protein g', 'Carbs g', 'Fat g', 'Water ml']];
  dates.forEach((d) => { (n.log[d] || []).forEach((m) => rows.push([d, MEALS[m.meal], m.name, m.kcal, m.p, m.c, m.f, ''])); const ml = (w.log[d] || []).reduce((a, e) => a + e.ml, 0); if (ml) rows.push([d, '', 'Water total', '', '', '', '', ml]); });
  return '﻿' + rows.map((x) => x.map(cell).join(',')).join('\r\n') + '\r\n';
}
export function download(name, text, type = 'text/csv;charset=utf-8') {
  const url = URL.createObjectURL(new Blob([text], { type })), a = Object.assign(document.createElement('a'), { href: url, download: name });
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 2000);
}
