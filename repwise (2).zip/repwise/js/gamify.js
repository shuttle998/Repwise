// XP, levels and challenges. Everything is derived from the workouts and logs you already have, so it can never
// drift out of sync with your history. It rewards showing up, not training more: extra workouts beyond your plan
// earn no extra XP.
import { BY_ID } from './exercises.js';
import { sortS, doneItems, sessionSets, prEvents, achievements } from './analytics.js';
import { dateKey, parseKey, addDays, startOfWeek, sum } from './util.js';

const TIER_XP = [25, 50, 100, 150];
export const XP = { workout: 40, setCap: 20, pr: 20, prCapPerDay: 3, weekExtra: 1 };
export const TITLES = ['Starter', 'Regular', 'Committed', 'Dedicated', 'Strong', 'Seasoned', 'Veteran', 'Elite', 'Master', 'Legend'];
/** Total XP needed to reach a level. Level 1 is 0 XP: 100, 300, 600, 1000, 1500, ... */
export const xpForLevel = (L) => 50 * L * (L - 1);
export const levelOf = (xp) => Math.max(1, Math.floor((1 + Math.sqrt(1 + (4 * Math.max(0, xp)) / 50)) / 2));
export const titleOf = (L) => TITLES[Math.min(TITLES.length - 1, Math.floor((L - 1) / 3))];
const wk = (k) => dateKey(startOfWeek(parseKey(k)));
const usedWater = (s) => Object.keys(s.water?.log || {}).length > 0, usedMeals = (s) => Object.keys(s.nutrition?.log || {}).length > 0;

const periodWeek = (ws) => { const a = dateKey(ws), b = dateKey(addDays(ws, 6)); return { a, b }; };
const inRange = (arr, a, b) => arr.filter((s) => s.date >= a && s.date <= b);
const muscles = (ss) => new Set(ss.flatMap((s) => doneItems(s).flatMap((i) => BY_ID[i.exId]?.pm || [])));
const daysWith = (log, a, b) => Object.keys(log || {}).filter((d) => d >= a && d <= b && log[d]?.length).length;

/** Challenges for one week. value/target/done are computed from data; `final` is true once the week is over. */
export function weeklyChallenges(state, ws, now = new Date()) {
  const { a, b } = periodWeek(ws), D = Math.min(6, Math.max(1, state.profile?.days || 3)), ss = inRange(sortS(state.sessions || []).filter((s) => doneItems(s).length), a, b), final = b < dateKey(now);
  const days = new Set(ss.map((s) => s.date)).size, list = [
    { id: `w:${a}:target`, title: 'Hit your weekly target', desc: `Train on ${D} different days this week`, value: days, target: D, xp: 60 },
    { id: `w:${a}:sets`, title: 'Put in the work', desc: `Complete ${D * 10} sets this week`, value: sum(ss.map(sessionSets)), target: D * 10, xp: 40 },
    { id: `w:${a}:muscles`, title: 'Balanced week', desc: `Train ${D >= 3 ? 4 : 3} different muscle groups`, value: muscles(ss).size, target: D >= 3 ? 4 : 3, xp: 40 },
  ];
  if (usedWater(state)) list.push({ id: `w:${a}:water`, title: 'Hydration habit', desc: 'Log water on 5 days', value: daysWith(state.water.log, a, b), target: 5, xp: 30 });
  return list.map((c) => ({ ...c, period: 'week', key: a, done: c.value >= c.target, final, pct: Math.min(1, c.value / c.target) }));
}
/** Challenges for one calendar month. */
export function monthlyChallenges(state, ms, now = new Date()) {
  const a = dateKey(ms), last = new Date(ms.getFullYear(), ms.getMonth() + 1, 0), b = dateKey(last), D = Math.min(6, Math.max(1, state.profile?.days || 3)), all = sortS(state.sessions || []).filter((s) => doneItems(s).length);
  const ss = inRange(all, a, b), days = new Set(ss.map((s) => s.date)).size, final = b < dateKey(now);
  const prior = new Set(all.filter((s) => s.date < a).flatMap((s) => doneItems(s).map((i) => i.exId))), fresh = new Set(ss.flatMap((s) => doneItems(s).map((i) => i.exId)).filter((id) => !prior.has(id)));
  let hit = 0; for (let w = startOfWeek(ms); dateKey(addDays(w, 6)) <= b; w = addDays(w, 7)) { if (dateKey(w) < a) continue; if (new Set(inRange(all, dateKey(w), dateKey(addDays(w, 6))).map((s) => s.date)).size >= D) hit++; }
  const sess = Math.round(D * 4.3 * 0.8), list = [
    { id: `m:${a.slice(0, 7)}:sessions`, title: 'Stay consistent', desc: `Train on ${sess} days this month`, value: days, target: sess, xp: 150 },
    { id: `m:${a.slice(0, 7)}:weeks`, title: 'Three good weeks', desc: 'Hit your weekly target in 3 full weeks', value: hit, target: 3, xp: 120 },
    { id: `m:${a.slice(0, 7)}:new`, title: 'Try something new', desc: 'Do 2 exercises you have not logged before', value: all.length && !prior.size ? 0 : fresh.size, target: 2, xp: 80 },
  ];
  if (usedMeals(state)) list.push({ id: `m:${a.slice(0, 7)}:meals`, title: 'Log your meals', desc: 'Log meals on 12 days', value: daysWith(state.nutrition.log, a, b), target: 12, xp: 60 });
  return list.map((c) => ({ ...c, period: 'month', key: a, done: c.value >= c.target, final, pct: Math.min(1, c.value / c.target) }));
}
export function currentChallenges(state, now = new Date()) {
  return { week: weeklyChallenges(state, startOfWeek(now), now), month: monthlyChallenges(state, new Date(now.getFullYear(), now.getMonth(), 1), now) };
}

/** Full XP breakdown. Workout XP: first workout of each day, at most (weekly target + 1) days a week, plus a few XP per set (capped). */
export function xpSummary(state, now = new Date()) {
  const ss = sortS(state.sessions || []).filter((s) => doneItems(s).length), D = Math.max(1, state.profile?.days || 3), byWeek = new Map();
  ss.forEach((s) => { const k = wk(s.date); (byWeek.get(k) || byWeek.set(k, []).get(k)).push(s); });
  let workouts = 0, sets = 0, ignored = 0; const counted = new Set();
  byWeek.forEach((list) => { const seenDay = new Set(); let n = 0; list.forEach((s) => { if (seenDay.has(s.date)) { ignored++; return; } seenDay.add(s.date); if (n >= D + XP.weekExtra) { ignored++; return; } n++; counted.add(s.id); workouts += XP.workout; sets += Math.min(XP.setCap, sessionSets(s)); }); });
  const prDay = new Map(); let prs = 0; prEvents(ss).forEach((e) => { const n = prDay.get(e.date) || 0; if (n < XP.prCapPerDay) { prDay.set(e.date, n + 1); prs += XP.pr; } });
  let ch = 0; const first = ss[0]; if (first) { for (let w = startOfWeek(parseKey(first.date)); w <= now; w = addDays(w, 7)) ch += sum(weeklyChallenges(state, w, now).filter((c) => c.done).map((c) => c.xp)); const f = parseKey(first.date); for (let m = new Date(f.getFullYear(), f.getMonth(), 1); m <= now; m = new Date(m.getFullYear(), m.getMonth() + 1, 1)) ch += sum(monthlyChallenges(state, m, now).filter((c) => c.done).map((c) => c.xp)); }
  const ach = sum(achievements({ sessions: ss, profile: state.profile }, now).filter((x) => x.unlocked).map((x) => TIER_XP[Math.min(3, x.tier)] || 25));
  const total = workouts + sets + prs + ch + ach, level = levelOf(total), base = xpForLevel(level), next = xpForLevel(level + 1);
  return { total, level, title: titleOf(level), base, next, into: total - base, need: next - base, pct: (total - base) / (next - base), parts: { workouts, sets, prs, challenges: ch, achievements: ach }, ignored };
}
/** What changed between two states: XP gained, level ups, challenges newly completed. Used on the workout summary. */
export function xpDelta(before, after, now = new Date()) {
  const a = xpSummary(before, now), b = xpSummary(after, now), cb = currentChallenges(before, now), ca = currentChallenges(after, now);
  const was = new Set([...cb.week, ...cb.month].filter((c) => c.done).map((c) => c.id));
  return { gained: b.total - a.total, total: b.total, level: b.level, levelUp: b.level > a.level, fromLevel: a.level, completed: [...ca.week, ...ca.month].filter((c) => c.done && !was.has(c.id)), summary: b };
}
