// Shared exercise picker and ranked swap sheet, used by the library, the programme builder and the workout screen.
import { state, isFav, toggleFav } from './store.js';
import { esc } from './util.js';
import { allowedEquip, equipmentOf } from './generator.js';
import { activeExercises, searchExercises, rankedSubstitutes, available, hasLimit, MUSCLES, EQUIP, LOCATIONS, locationOf, BY_ID } from './exercises.js';
import { recentExercises } from './analytics.js';
import { recommend } from './recommend.js';
import { icon, sheet } from './ui.js';

const row = (e, sub, extra = '') => `<button class="ex-row" data-pick="${e.id}" style="text-align:left;width:100%"><span><b>${esc(e.name)}</b>${e.custom ? ' <span class="chip">Custom</span>' : ''}<br><span class="mut" style="font-size:13.5px">${esc(e.pm.join(', '))} · ${esc(e.equip)}${sub ? ' · ' + sub : ''}</span>${extra}</span>${icon('right')}</button>`;

/** Searchable picker with muscle / equipment / location filters and Favourites / Recent views. */
export function pickExercise(onPick, { title = 'Choose an exercise', exclude = [], recommended = false } = {}) {
  const f = { q: '', muscle: '', equip: '', loc: '', view: recommended ? 'rec' : 'all' }, p = state.profile || {};
  sheet({ title, wide: true, html: `<input class="input" id="q" type="search" placeholder="Search exercises" aria-label="Search exercises" style="margin-bottom:10px" data-autofocus>
    <div class="seg-c" role="group" aria-label="Show" style="margin-bottom:10px">${[...(recommended ? [['rec', 'For you']] : []), ['all', 'All'], ['fav', 'Favourites'], ['recent', 'Recent']].map(([k, l]) => `<button class="seg-b" data-view="${k}" aria-pressed="${k === f.view}">${l}</button>`).join('')}</div>
    <div class="row wrap" style="gap:8px;margin-bottom:8px"><select class="input" id="fm" aria-label="Muscle" style="flex:1;min-width:120px"><option value="">Any muscle</option>${MUSCLES.map((m) => `<option>${m}</option>`).join('')}</select><select class="input" id="fe" aria-label="Equipment" style="flex:1;min-width:120px"><option value="">Any equipment</option>${EQUIP.map((m) => `<option>${m}</option>`).join('')}</select></div>
    <p class="lbl" id="pc" aria-live="polite" style="margin:6px 0"></p><div class="pick" id="pl"></div>`, onMount: (box, close) => {
    const pl = box.querySelector('#pl'), q = box.querySelector('#q');
    const render = () => {
      if (f.view === 'rec') {
        const recs = recommend({ profile: p, sessionIds: exclude, recent: state.sessions.slice(-2).reverse().map((x) => x.items.map((i) => i.exId)), favourites: activeExercises().filter((x) => isFav(x.id)).map((x) => x.id), byId: BY_ID }, 8);
        box.querySelector('#pc').textContent = recs.length ? 'Recommended for this session. Each one says why.' : 'Nothing to recommend right now. Use All to browse.';
        pl.innerHTML = recs.map((r) => row(r.ex, esc(r.why))).join(''); return;
      }
      let pool = activeExercises().filter((e) => !exclude.includes(e.id));
      if (f.view === 'fav') pool = pool.filter((e) => isFav(e.id));
      if (f.view === 'recent') { const r = recentExercises(state.sessions, 12).map((x) => x.exId); pool = r.map((id) => pool.find((e) => e.id === id)).filter(Boolean); }
      if (f.muscle) pool = pool.filter((e) => e.pm.includes(f.muscle) || e.sm.includes(f.muscle));
      if (f.equip) pool = pool.filter((e) => e.equip === f.equip);
      if (f.q) { const hit = searchExercises(f.q, pool); pool = hit; }
      pool = [...pool].sort((a, b) => (available(b, p.gear || 'gym') - available(a, p.gear || 'gym')) || 0 );
      box.querySelector('#pc').textContent = `${pool.length} exercise${pool.length === 1 ? '' : 's'}`;
      pl.innerHTML = pool.length ? pool.map((e) => row(e, !available(e, p.gear || 'gym') ? 'needs more equipment' : hasLimit(e, p.limits) ? '<span style="color:var(--warn)">loads a limited area</span>' : '')).join('') : `<p class="mut">${f.view === 'fav' ? 'No favourites yet. Tap the heart on an exercise in the library.' : f.view === 'recent' ? 'Exercises you have logged appear here.' : 'No exercises match.'}</p>`;
    };
    // searching or filtering means the person wants to browse, so leave the recommended view
    const browse = () => { if (f.view === 'rec') { f.view = 'all'; box.querySelectorAll('[data-view]').forEach((b) => b.setAttribute('aria-pressed', b.dataset.view === 'all')); } };
    q.addEventListener('input', () => { f.q = q.value; if (f.q) browse(); render(); });
    box.querySelector('#fm').addEventListener('change', (e) => { f.muscle = e.target.value; if (f.muscle) browse(); render(); });
    box.querySelector('#fe').addEventListener('change', (e) => { f.equip = e.target.value; if (f.equip) browse(); render(); });
    box.addEventListener('click', (e) => {
      const v = e.target.closest('[data-view]'); if (v) { f.view = v.dataset.view; box.querySelectorAll('[data-view]').forEach((b) => b.setAttribute('aria-pressed', b === v)); render(); return; }
      const b = e.target.closest('[data-pick]'); if (b) { onPick(b.dataset.pick); close(); }
    });
    render();
  } });
}

/** Ranked alternatives for `ex`, each with the reason it was suggested. */
export function swapSheet(ex, onPick, { title = `Swap ${ex.name}`, exclude = [], intro = '' } = {}) {
  const p = state.profile || {}, list = rankedSubstitutes(ex, { gear: p.gear || 'gym', allow: allowedEquip(equipmentOf(p)), limits: p.limits || [], level: p.level ?? 1, avoid: p.avoid || [], exclude }).slice(0, 12);
  sheet({ title, wide: true, html: `${intro ? `<p class="mut" style="margin-bottom:10px">${esc(intro)}</p>` : ''}<div class="pick">${list.length ? list.map((r) => row(r.ex, '', `<br><span class="hint">${esc(r.reasons.join(' · '))}</span>`)).join('') : '<p class="mut">No alternatives fit your equipment and limitations. Try choosing any exercise instead.</p>'}</div><button class="btn block" style="margin-top:12px" data-any>Browse all exercises</button>`,
    onMount: (box, close) => box.addEventListener('click', (e) => {
      const b = e.target.closest('[data-pick]'); if (b) { onPick(b.dataset.pick); close(); return; }
      if (e.target.closest('[data-any]')) { close(); pickExercise(onPick, { title: 'Choose an exercise', exclude: [ex.id, ...exclude] }); }
    }) });
}
export { BY_ID, LOCATIONS, locationOf, toggleFav };
