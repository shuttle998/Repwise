// Delivers due reminders while the app is open or in the background. A closed web page cannot be woken on its own,
// so anything missed is shown as an in-app notice the next time the app is opened; the .ics export covers true background alarms.
import { state, markDelivered, addNotice } from './store.js';
import { dueReminders } from './reminders.js';
import { toast } from './ui.js';

async function system(title, body, tag) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return false;
  try { const reg = await navigator.serviceWorker?.getRegistration?.(); if (reg?.showNotification) { await reg.showNotification(title, { body, tag, icon: 'favicon.svg', badge: 'favicon.svg' }); return true; } new Notification(title, { body, tag, icon: 'favicon.svg' }); return true; } catch { return false; }
}
export function checkReminders(now = new Date()) {
  const due = dueReminders(state, now, state.ui.remDelivered || []);
  if (!due.length) return 0;
  markDelivered(due.map((d) => d.key));
  due.forEach((d) => {
    addNotice({ kind: 'reminder', key: 'rem:' + d.key, title: d.title, body: d.body });
    if (document.visibilityState === 'visible') toast(`${d.title}. ${d.body}`, 'ok', 6000); else system(d.title, d.body, d.key);
  });
  return due.length;
}
let timer = null;
export function startReminderEngine() {
  if (timer) return; checkReminders();
  timer = setInterval(checkReminders, 60000);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') checkReminders(); });
}
