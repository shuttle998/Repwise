// Progressive overload engine. Pure functions: easy to test, no storage, no DOM.
//
// Model: double progression. Work inside a rep range (e.g. 8 to 12). Add reps first; add weight only
// when every set reached the top of the range AND the effort was manageable. Feedback and history can
// hold the weight, or reduce it. Increases are capped so load never jumps by more than ~10% in a week.
import { roundTo, daysBetween, parseKey } from './util.js';

export const FEEDBACK = {
  easy: { label: 'Too easy', hint: 'I could have done 3+ more reps' },
  good: { label: 'Just right', hint: '1 to 2 reps left in the tank' },
  hard: { label: 'Hard', hint: 'Last reps were a grind' },
  too_hard: { label: 'Too hard', hint: 'Failed reps or form broke down' },
};
export const ACTIONS = {
  increase_weight: 'Increase weight',
  increase_reps: 'Add reps',
  maintain: 'Keep it the same',
  reduce: 'Reduce the weight',
  adjust: 'Adjust the exercise',
};

/** Epley estimated one-rep max. Only trusted for 1 to 12 reps. */
export function e1rm(w, reps) {
  if (!(w > 0) || !(reps > 0) || reps > 12) return 0;
  return reps === 1 ? w : w * (1 + reps / 30);
}

const mode = (arr) => { const c = new Map(); arr.forEach((x) => c.set(x, (c.get(x) || 0) + 1)); let best = null, n = 0; for (const [k, v] of c) if (v > n || (v === n && k > best)) { best = k; n = v; } return best; };
const fmt = (n) => String(parseFloat(n.toFixed(2)));

/**
 * @param cfg   {step (kg), unit:'kg'|'sec', loaded:boolean, repLo, repHi, targetSets, wUnit:'kg'|'lb'}
 * @param perf  {sets:[{w,reps}] (completed sets only), feedback?, hurt?}
 * @param history  earlier performances for this exercise, newest first: [{date, sets, feedback}]
 * @param opts  {advanced:boolean, today:'YYYY-MM-DD', fmtW:(kg)=>string}
 */
export function recommend({ cfg, perf, history = [], opts = {} }) {
  const { step, unit, loaded, repLo, repHi, targetSets } = cfg;
  const fw = opts.fmtW || ((kg) => fmt(kg) + ' kg');
  const sets = (perf.sets || []).filter((s) => s.reps > 0);
  const out = (action, weight, repTarget, reasons, extra = {}) => ({ action, title: ACTIONS[action], weight, repTarget, reasons, ...extra });

  if (!sets.length) return out('maintain', perf.plannedWeight ?? 0, repLo, ['No sets were logged, so nothing changes.']);
  const W = loaded ? mode(sets.map((s) => s.w)) : 0;
  const reps = sets.map((s) => s.reps);
  const minReps = Math.min(...reps), maxReps = Math.max(...reps);
  const allDone = sets.length >= targetSets;
  const noFeedback = !perf.feedback;
  const fb = perf.feedback || 'good';
  const inRange = allDone && minReps >= repLo;
  const allTop = allDone && minReps >= repHi;
  const unitWord = unit === 'sec' ? 's' : unit === 'min' ? ' min' : ' reps';
  const reasons = [];
  if (noFeedback) reasons.push('No difficulty feedback was given, so "just right" was assumed and weight increases are limited to one step.');

  // 1. pain flag
  if (perf.hurt) {
    if (loaded) {
      const nw = Math.max(step, roundTo(W * 0.9, step));
      return out('adjust', Math.min(nw, W), repLo, [`You flagged pain. Drop to about ${fw(Math.min(nw, W))} and consider a substitute exercise.`, 'Pain is a reason to change the movement, not to push through. See a professional if it persists.'], { substitute: true });
    }
    return out('adjust', 0, repLo, ['You flagged pain. Try an easier variation or a different exercise.'], { substitute: true });
  }

  // bodyweight / timed exercises: progress reps (or seconds), then suggest a harder variation
  if (!loaded) {
    const inc = unit === 'sec' ? 5 : 1; // seconds move in 5s steps, minutes and reps in single steps
    if (fb === 'too_hard' || !inRange) {
      return out('maintain', 0, Math.max(repLo, minReps), [`${sets.length < targetSets ? 'Not every set was completed.' : 'Some sets were below the target range.'} Repeat this session and aim to complete every set of ${repLo}${unitWord} or more.`]);
    }
    if (allTop && fb !== 'hard') {
      return out('adjust', 0, repHi, [`Every set reached ${repHi}${unitWord} and it felt manageable.`, 'Make it harder: slow the lowering down, add a pause, add a set, or move to a harder variation.'], { harder: true });
    }
    if (fb === 'hard') return out('maintain', 0, minReps, [`It was hard, so repeat at ${minReps}${unitWord} before adding more.`]);
    return out('increase_reps', 0, Math.min(repHi, minReps + inc), [`Your lowest set was ${minReps}${unitWord}. Aim for ${Math.min(repHi, minReps + inc)}${unitWord} on every set next time.`]);
  }

  // weight-capping helpers
  const sevenDayBase = (() => { // lowest working weight used in the last 7 days
    const recent = history.filter((h) => opts.today && daysBetween(parseKey(h.date), parseKey(opts.today)) <= 7).map((h) => mode(h.sets.map((s) => s.w)));
    return recent.length ? Math.min(...recent) : W;
  })();
  const cap = (w) => { const lim = Math.max(roundTo(sevenDayBase * 1.1, step), sevenDayBase + step); return Math.min(w, lim); };
  const up = (n) => cap(roundTo(W + step * n, step));
  const down = (pct) => Math.max(step, Math.min(W - step, roundTo(W * (1 - pct), step)));

  const prev = history[0];
  const prevW = prev ? mode(prev.sets.map((s) => s.w)) : null;
  const prevUnder = prev && prev.sets.some((s) => s.reps < repLo) && prevW === W;

  // 2. failed / too hard
  if (fb === 'too_hard') {
    if (!inRange) return out('reduce', down(0.08), repLo, [`You said it was too hard and ${sets.length < targetSets ? 'could not finish every set' : `fell below ${repLo} reps`}.`, `Next time start at ${fw(down(0.08))} (about 8% lighter) and build back up.`]);
    return out('maintain', W, repLo, ['You hit your reps but called it too hard. Repeat this weight until it feels more controlled before adding load.']);
  }
  if (!inRange) {
    if (fb === 'hard' && prevUnder) return out('reduce', down(0.08), repLo, [`Below ${repLo} reps on this weight two sessions in a row.`, `Dropping to ${fw(down(0.08))} lets you rebuild reps with good form.`]);
    return out('maintain', W, repLo, [`${sets.length < targetSets ? 'Not every set was completed' : `A set fell below ${repLo} reps`}. Keep ${fw(W)} and work back up to ${repLo} or more on every set.`]);
  }

  // 3. advanced signals (Pro): stalls and accumulated fatigue
  if (opts.advanced && history.length >= 2) {
    const last3 = [perf, ...history.slice(0, 2)].map((h) => ({ w: mode(h.sets.filter((s) => s.reps > 0).map((s) => s.w)), tot: h.sets.reduce((a, s) => a + s.reps, 0), fb: h.feedback }));
    const sameW = last3.every((x) => x.w === W);
    const noGain = last3[0].tot <= last3[1].tot && last3[1].tot <= last3[2].tot;
    if (sameW && noGain && fb !== 'easy') {
      return out('adjust', down(0.1), repLo, [`Three sessions at ${fw(W)} without more total reps: this lift has stalled.`, `Try a lighter reset at about ${fw(down(0.1))}, or swap in a variation for a few weeks.`], { stalled: true });
    }
    if ((fb === 'hard') && prev && (prev.feedback === 'hard' || prev.feedback === 'too_hard') && prevW === W) {
      return out('reduce', down(0.05), repLo, ['Two hard sessions in a row at this weight points to accumulated fatigue.', `A small drop to ${fw(down(0.05))} lets you recover and come back stronger.`]);
    }
  }

  // 4. reps in range
  if (allTop) {
    if (fb === 'hard') return out('maintain', W, repHi, [`Every set reached ${repHi} reps, but it was a grind. Repeat ${fw(W)} until it feels manageable, then add weight.`]);
    const bigSurplus = fb === 'easy' && !noFeedback && minReps >= repHi + 2 && step * 2 <= W * 0.1;
    const nw = up(bigSurplus ? 2 : 1);
    if (nw <= W) return out('maintain', W, repHi, [`You earned an increase, but adding more would exceed the weekly 10% limit. Stay at ${fw(W)} this time.`]);
    reasons.unshift(`Every set reached ${repHi} reps${fb === 'easy' ? ' and it felt easy' : ' with reps in reserve'}.`, `Add ${fw(nw - W)} for next time: ${fw(nw)} for ${repLo}+ reps. One increase per session keeps the jump small.`);
    return out('increase_weight', nw, repLo, reasons);
  }
  if (fb === 'easy') {
    if (minReps >= repHi - 1) { const nw = up(1); if (nw > W) return out('increase_weight', nw, repLo, [`One rep from the top of the range and it felt easy. Move up to ${fw(nw)} and start again at ${repLo} reps.`]); }
    const t = Math.min(repHi, minReps + 2);
    return out('increase_reps', W, t, [`It felt easy, so add reps first: aim for ${t} on every set at ${fw(W)}.`]);
  }
  if (fb === 'hard') return out('maintain', W, minReps, [`It was hard. Repeat ${fw(W)} for ${minReps}+ reps before adding more.`]);
  const t = Math.min(repHi, minReps + 1);
  return out('increase_reps', W, t, [`Your lowest set was ${minReps}. Aim for ${t} on every set at ${fw(W)}. Weight goes up once all sets reach ${repHi}.`]);
}

/** Adjust a stored working weight for time away from this exercise. */
export function layoffAdjust(weight, lastDate, today, step) {
  if (!lastDate || !(weight > 0)) return { weight, note: null };
  const d = daysBetween(parseKey(lastDate), parseKey(today));
  const pct = d >= 56 ? 0.2 : d >= 28 ? 0.15 : d >= 14 ? 0.1 : 0;
  if (!pct) return { weight, note: null };
  const w = Math.max(step, roundTo(weight * (1 - pct), step));
  return { weight: Math.min(w, weight), note: `It has been ${d} days since you last did this, so the weight starts ${Math.round(pct * 100)}% lighter.` };
}

/** Starting weight for the first time doing an exercise. */
export const startWeight = (start, step, levelMult) => (step ? Math.max(step, roundTo(start * levelMult, step)) : 0);
export const LEVEL_MULT = [1, 1.5, 2];
