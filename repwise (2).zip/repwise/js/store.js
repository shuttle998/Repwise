// Single source of truth. State is persisted to localStorage (via the storage adapter) after every change.
import { CONFIG, FEATURES } from './config.js';
import { storage } from './services.js';
import { BY_ID, EXERCISES, LEGACY_NAMES, syncCustom, validateCustom, CUSTOM_PREFIX, EQUIP, MUSCLES, TYPES, DIFFS, TRACKING } from './exercises.js';
import { generateProgram } from './generator.js';
import { uid, dateKey } from './util.js';
import { normReminders, normInbox } from './reminders.js';
import { normClass, isClass } from './classes.js';
import { normExtras, DEFAULT_EXTRAS } from './sessions.js';
import { extract, inject, idKeys, recordDeletions, stampSections } from './sync.js';
import { normNutrition, normWater, normTargets, validateMeal, mealForHour } from './nutrition.js';

export const defaults = () => ({
  v: CONFIG.SCHEMA_VERSION,
  profile: null,          // {name, goal, focus, days, level, gear, duration, style, limits[], avoid[], favour[], createdAt}
  program: null,          // {id, name, sessions:[{id,name,items:[{exId,sets,repLo,repHi,restSec}]}], custom, variant}
  cursor: 0,              // index of the next programme session
  working: {},            // exId -> {w (kg), repTarget, action, title, reasons[], date}
  sessions: [],           // finished workouts (source of truth for every statistic)
  customExercises: [],    // [{id:'c-…', name, equip, type, diff, pm, sm, unit, steps, archived?}]
  favs: [],               // favourite exercise ids
  programs: [],           // saved programmes [{id, name, savedAt, program}]
  nutrition: { targets: { kcal: null, protein: null, carbs: null, fat: null }, log: {}, saved: [], calc: null }, // log: { 'YYYY-MM-DD': [{id,name,meal,kcal,p,c,f,t}] }
  water: { targetMl: null, bottleMl: 500, log: {} },   // log: { 'YYYY-MM-DD': [{id,ml,t}] }
  reminders: normReminders(null),  // see reminders.js
  inbox: [],              // in-app notices [{id,t,kind,title,body,read}], newest first, max 50
  activities: [],         // imported workouts from watches and health exports [{id, source, type, date, durationSec, ...}]
  sync: { stamps: {}, tomb: {}, lastSyncAt: null, rev: null, dirty: false, deviceId: null, accountId: null }, // cloud sync bookkeeping (see sync.js)
  body: { entries: [] },  // [{id, date, weight (kg), chest, waist, shoulders, arms, thighs, hips (cm)}]
  active: null,           // in-progress workout (autosaved)
  settings: { units: 'kg', sound: true, vibrate: true, notify: false, wakeLock: true, theme: 'dark', extras: { ...DEFAULT_EXTRAS } },
  plan: 'free',           // 'free' | 'pro' (pro = local preview until payments are live)
  ui: { welcomed: false, nameAsked: false, reportSeen: null, migratedFrom: null, remDelivered: [], gamSeen: null },
});

export let state = defaults();
const subs = new Set();
export const subscribe = (fn) => { subs.add(fn); return () => subs.delete(fn); };
const emit = () => subs.forEach((f) => f(state));

let saveWarned = false, lastBak = 0;
const BAK = () => CONFIG.STORAGE_KEY + ':bak';
export function save() {
  const json = JSON.stringify(state), ok = storage.set(CONFIG.STORAGE_KEY, json);
  // A second copy at most every 10 minutes: if the main copy is ever damaged (a crash mid-write, a bad import), load() recovers from it.
  if (ok && Date.now() - lastBak > 600000) { lastBak = Date.now(); storage.set(BAK(), json); }
  if (!ok && !saveWarned) { saveWarned = true; window.dispatchEvent(new CustomEvent('repwise:storage-error')); }
  return ok;
}
// Change tracking for sync: stamps for single-value sections, tombstones for deleted items, and a dirty flag.
let prevIds = new Set(), prevSec = null, fp = '', version = 0;
export const localVersion = () => version;
const fingerprint = () => { const str = JSON.stringify([state.sessions, state.customExercises, state.programs, state.body.entries, state.nutrition.saved, state.nutrition.log, state.water.log, state.activities, extract({ ...state, sessions: [], customExercises: [], programs: [], body: { entries: [] }, nutrition: { ...state.nutrition, saved: [], log: {} }, water: { ...state.water, log: {} }, activities: [] }).sections]); let h = 5381; for (let i = 0; i < str.length; i++) h = ((h * 33) ^ str.charCodeAt(i)) | 0; return str.length + ':' + h; };
export function resetTracking() { state.sync.deviceId ||= uid(); prevIds = idKeys(state); prevSec = stampSections(state, null); fp = fingerprint(); }
function track() {
  prevSec = stampSections(state, prevSec); recordDeletions(prevIds, state); prevIds = idKeys(state);
  const f = fingerprint(); if (f !== fp) { fp = f; state.sync.dirty = true; version++; }
}
export function mutate(fn, { silent = false } = {}) { fn(state); if (!silent) track(); save(); if (!silent) emit(); }
/** Local data as the cloud document. */
export const syncSnapshot = () => extract(state);
/** Replaces synced data with a merged copy, keeping local-only fields (active workout, photos, plan, inbox). */
export function applySynced(data, { rev, silent = false } = {}) {
  const keep = { active: state.active, plan: state.plan, ui: state.ui, inbox: state.inbox, sync: state.sync };
  const next = inject({ ...state }, data); state = hydrate({ ...next, ...keep, sync: { ...state.sync, ...next.sync } });
  syncCustom(state.customExercises); state.sync.rev = rev ?? state.sync.rev; state.sync.lastSyncAt = Date.now(); state.sync.dirty = false; resetTracking(); save(); if (!silent) emit();
}
export function markSynced(rev) { mutate((st) => { st.sync.rev = rev; st.sync.lastSyncAt = Date.now(); st.sync.dirty = false; }, { silent: true }); fp = fingerprint(); }
export const isDirty = () => !!state.sync.dirty;

// ---------- migration from the original single-file app ----------
export function migrateV1(old) {
  const s = defaults();
  const p = old?.p;
  if (p) {
    s.profile = { name: '', goal: p.goal || 'muscle', focus: p.focus || 'balanced', days: p.days || 3, level: p.lvl ?? 0, gear: p.gear || 'db', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: new Date().toISOString() };
    s.program = generateProgram(s.profile);
    s.cursor = (old.idx || 0) % s.program.sessions.length;
    // carry old weights across by exercise name
    const byName = Object.fromEntries(EXERCISES.map((e) => [e.name, e]));
    Object.entries(old.w || {}).forEach(([oldId, w]) => {
      const gear = ['gym', 'db', 'bw'].find((g) => oldId.endsWith(g)); if (!gear) return;
      const slot = oldId.slice(0, -gear.length);
      const name = LEGACY_NAMES[slot]?.[gear]; const ex = byName[name];
      if (ex && ex.unit === 'kg' && typeof w === 'number' && w > 0) s.working[ex.id] = { w, repTarget: null, action: 'maintain', title: 'Carried over', reasons: ['Carried over from your previous plan.'], date: null };
    });
  }
  // old logs only recorded date + session name, so they count as workouts but carry no volume
  s.sessions = (old?.log || []).filter((l) => l?.d).map((l, i) => ({ id: 'legacy' + i, date: l.d, name: l.s || 'Workout', legacy: true, items: [] }));
  s.ui.migratedFrom = 1;
  return s;
}

const hydrate = (o) => ({ ...defaults(), ...o, settings: { ...defaults().settings, ...o.settings, extras: normExtras(o.settings?.extras) }, ui: { ...defaults().ui, ...o.ui }, body: normBody(o.body), nutrition: normNutrition(o.nutrition), water: normWater(o.water), reminders: normReminders(o.reminders), inbox: normInbox(o.inbox), activities: normActivities(o.activities), sync: normSync(o.sync), customExercises: normCustom(o.customExercises), favs: normFavs(o.favs), programs: normPrograms(o.programs) });
/** Keeps only well-formed custom exercises so a hand-edited file cannot break the library. */
export function normCustom(list) {
  const seen = new Set(), MUSC = [...MUSCLES, 'Forearms'];
  return (Array.isArray(list) ? list : []).flatMap((c) => {
    if (!c || typeof c.id !== 'string' || !c.id.startsWith(CUSTOM_PREFIX) || seen.has(c.id)) return [];
    const name = String(c.name || '').trim().slice(0, 40), pm = (Array.isArray(c.pm) ? c.pm : []).filter((m) => MUSC.includes(m));
    if (name.length < 2 || !EQUIP.includes(c.equip) || !pm.length || !TRACKING[c.unit]) return [];
    seen.add(c.id);
    return [{ id: c.id, name, equip: c.equip, type: TYPES.includes(c.type) ? c.type : 'Compound', diff: DIFFS.includes(c.diff) ? c.diff : 'Intermediate', pm, sm: (Array.isArray(c.sm) ? c.sm : []).filter((m) => MUSC.includes(m) && !pm.includes(m)), unit: c.unit, steps: (Array.isArray(c.steps) ? c.steps : []).map((x) => String(x).slice(0, 240)).filter(Boolean).slice(0, 10), ...(c.archived ? { archived: true } : {}) }];
  });
}
export const normActivities = (l) => (Array.isArray(l) ? l : []).filter((a) => a && typeof a.id === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(a.date || '') && typeof a.type === 'string').slice(0, 5000);
const normSync = (x) => { const o = x && typeof x === 'object' ? x : {}, num = (v) => (Number.isFinite(v) ? v : null); return { stamps: o.stamps && typeof o.stamps === 'object' ? { ...o.stamps } : {}, tomb: o.tomb && typeof o.tomb === 'object' ? { ...o.tomb } : {}, lastSyncAt: num(o.lastSyncAt), rev: num(o.rev), dirty: !!o.dirty, deviceId: typeof o.deviceId === 'string' ? o.deviceId : null, accountId: typeof o.accountId === 'string' ? o.accountId : null }; };
const normFavs = (f) => [...new Set((Array.isArray(f) ? f : []).filter((x) => typeof x === 'string'))].slice(0, 500);
const normPrograms = (l) => (Array.isArray(l) ? l : []).filter((p) => p && typeof p.id === 'string' && typeof p.name === 'string' && Array.isArray(p.program?.sessions)).slice(0, 20);
const BODY_KEYS = ['weight', 'chest', 'waist', 'shoulders', 'arms', 'thighs', 'hips'];
/** Keeps only well-formed measurement entries so an old or hand-edited file can never break the page. */
export function normBody(b) {
  const entries = (Array.isArray(b?.entries) ? b.entries : []).filter((e) => e && /^\d{4}-\d{2}-\d{2}$/.test(e.date) && BODY_KEYS.some((k) => Number.isFinite(e[k]) && e[k] > 0)).map((e) => ({ id: String(e.id || uid()), date: e.date, ...Object.fromEntries(BODY_KEYS.filter((k) => Number.isFinite(e[k]) && e[k] > 0).map((k) => [k, e[k]])) }));
  return { entries };
}

function validShape(o) { return o && typeof o === 'object' && Array.isArray(o.sessions) && 'profile' in o && 'settings' in o; }

export function load() {
  let raw = storage.get(CONFIG.STORAGE_KEY);
  if (raw) {
    try { const o = JSON.parse(raw); if (validShape(o)) { state = hydrate(o); syncCustom(state.customExercises); resetTracking(); return 'loaded'; } }
    catch { /* fall through; keep a copy of the unreadable data */ storage.set(CONFIG.STORAGE_KEY + ':corrupt', raw); }
    // The main copy was unreadable or not a Repwise save: recover from the automatic backup copy if there is a good one.
    try { const b = JSON.parse(storage.get(BAK()) || 'null'); if (validShape(b)) { state = hydrate(b); syncCustom(state.customExercises); resetTracking(); save(); return 'recovered'; } } catch { /* no usable backup */ }
  }
  const v1 = storage.get(CONFIG.STORAGE_KEY_V1);
  if (v1) { try { state = migrateV1(JSON.parse(v1)); save(); syncCustom([]); resetTracking(); return 'migrated'; } catch { /* ignore */ } }
  state = defaults(); syncCustom([]); resetTracking();
  return 'new';
}

// ---------- plan / entitlements ----------
export const plan = () => (state.plan === 'pro' ? 'pro' : 'free');
export const isPro = () => plan() === 'pro';
export const can = (feature) => (FEATURES[feature] === 'pro' ? isPro() : true);
export const historyDays = () => (isPro() ? Infinity : CONFIG.FREE.historyDays);
export const units = () => state.settings.units;
/** Session extras (warm-up, activation, cardio, cool-down). Values are cleaned before they are stored. */
export function setExtras(patch) { mutate((st) => { st.settings.extras = normExtras({ ...st.settings.extras, ...patch }); }); }

/** Sessions visible under the current plan (free keeps all data but shows the last N days). */
export function visibleSessions(now = new Date()) {
  if (isPro()) return state.sessions;
  const lim = dateKey(new Date(now.getFullYear(), now.getMonth(), now.getDate() - CONFIG.FREE.historyDays + 1));
  return state.sessions.filter((s) => s.date >= lim);
}
export const hiddenCount = () => state.sessions.length - visibleSessions().length;

// ---------- export / import / reset ----------
export function exportJSON() { return JSON.stringify({ ...state, exportedAt: new Date().toISOString(), app: 'repwise' }, null, 2); }
export function exportCSV() {
  const rows = [['date', 'workout', 'exercise', 'set', 'weight_kg', 'reps_or_seconds', 'feedback']];
  [...state.sessions].sort((a, b) => (a.date < b.date ? -1 : 1)).forEach((s) => (s.items || []).forEach((i) => !i.skipped && (i.sets || []).forEach((x, n) => rows.push([s.date, s.name, BY_ID[i.exId]?.name || i.name || i.exId, n + 1, x.w || 0, x.reps, i.feedback || '']))));
  return rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
}
export function importJSON(text) {
  const o = JSON.parse(text);
  if (!validShape(o) || o.v !== CONFIG.SCHEMA_VERSION) throw new Error('This file is not a Repwise export.');
  if (!o.sessions.every((s) => s && typeof s.date === 'string' && Array.isArray(s.items))) throw new Error('Workout history in this file is malformed.');
  delete o.exportedAt; delete o.app;
  state = hydrate(o); syncCustom(state.customExercises); resetTracking();
  save(); emit();
}
export function resetAll() { storage.remove(CONFIG.STORAGE_KEY); storage.remove(CONFIG.STORAGE_KEY_V1); state = defaults(); syncCustom([]); resetTracking(); import('./photos.js').then((m) => m.clearPhotos()).catch(() => {}); emit(); }

// ---------- library: favourites and custom exercises ----------
export const isFav = (id) => state.favs.includes(id);
export function toggleFav(id) { mutate((st) => { st.favs = st.favs.includes(id) ? st.favs.filter((x) => x !== id) : [...st.favs, id]; }, { silent: true }); }
/** Create or update a custom exercise. Returns { error } or { id }. */
export function saveCustom(fields, id = null) {
  const v = validateCustom(fields, state.customExercises, id); if (v.error) return v;
  const cid = id || CUSTOM_PREFIX + uid();
  mutate((st) => { const rec = { id: cid, ...v.ok }, i = st.customExercises.findIndex((c) => c.id === cid); if (i >= 0) st.customExercises[i] = { ...rec, ...(st.customExercises[i].archived ? { archived: true } : {}) }; else st.customExercises.push(rec); }, { silent: true });
  syncCustom(state.customExercises); emit();
  return { id: cid };
}
/** Removes a custom exercise. If workouts used it, it is archived instead so history stays intact. Returns 'deleted' or 'archived'. */
export function removeCustom(id) {
  const used = state.sessions.some((s) => (s.items || []).some((i) => i.exId === id));
  mutate((st) => {
    st.program.sessions.forEach((s) => { s.items = s.items.filter((i) => i.exId !== id); });
    st.favs = st.favs.filter((x) => x !== id);
    if (used) { const c = st.customExercises.find((x) => x.id === id); if (c) c.archived = true; } else st.customExercises = st.customExercises.filter((x) => x.id !== id);
  }, { silent: true });
  syncCustom(state.customExercises); emit();
  return used ? 'archived' : 'deleted';
}
export { uid };

// ---------- nutrition and water ----------
/** Most recent logged body weight in kg, or null. */
export const latestWeightKg = () => { const e = [...state.body.entries].filter((x) => x.weight > 0).sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0)); return e[0]?.weight ?? null; };
/** Add a meal to a day. Returns { error } or { id }. */
export function addMeal(date, fields) {
  const v = validateMeal({ meal: mealForHour(new Date().getHours()), ...fields }); if (v.error) return v;
  const id = uid(); mutate((st) => { (st.nutrition.log[date] ||= []).push({ id, ...v.ok, t: Date.now() }); }); return { id };
}
export function updateMeal(date, id, fields) {
  const v = validateMeal(fields); if (v.error) return v;
  let hit = false; mutate((st) => { const m = st.nutrition.log[date]?.find((x) => x.id === id); if (m) { Object.assign(m, v.ok); hit = true; } }); return hit ? { id } : { error: 'That meal no longer exists.' };
}
export function removeMeal(date, id) { mutate((st) => { const l = (st.nutrition.log[date] || []).filter((x) => x.id !== id); if (l.length) st.nutrition.log[date] = l; else delete st.nutrition.log[date]; }); }
/** Copy every meal from one day to another. Returns how many were added. */
export function copyDay(from, to) { const src = state.nutrition.log[from] || []; if (!src.length || from === to) return 0; mutate((st) => { (st.nutrition.log[to] ||= []).push(...src.map((m) => ({ ...m, id: uid(), t: Date.now() }))); }); return src.length; }
/** Save a meal for one-tap reuse. Same name replaces the older copy. */
export function saveMealTemplate(fields) {
  const v = validateMeal(fields); if (v.error) return v;
  mutate((st) => { st.nutrition.saved = [{ id: uid(), ...v.ok }, ...st.nutrition.saved.filter((x) => x.name.toLowerCase() !== v.ok.name.toLowerCase())].slice(0, 50); }); return { ok: true };
}
export function removeMealTemplate(id) { mutate((st) => { st.nutrition.saved = st.nutrition.saved.filter((x) => x.id !== id); }); }
export function setNutritionTargets(t, calc) { mutate((st) => { st.nutrition.targets = normTargets(t); if (calc !== undefined) st.nutrition.calc = normNutrition({ calc }).calc; }); }
export function addWater(date, ml) {
  const v = Math.round(+ml); if (!Number.isFinite(v) || v < 10 || v > 3000) return { error: 'Enter an amount from 10 ml to 3000 ml.' };
  mutate((st) => { (st.water.log[date] ||= []).push({ id: uid(), ml: v, t: Date.now() }); }); return { ok: true };
}
export function undoWater(date) { mutate((st) => { const l = st.water.log[date] || []; l.pop(); if (!l.length) delete st.water.log[date]; }); }
export function setWaterSettings({ targetMl, bottleMl }) { mutate((st) => { const w = normWater({ ...st.water, ...(targetMl !== undefined ? { targetMl } : {}), ...(bottleMl !== undefined ? { bottleMl } : {}) }); st.water.targetMl = w.targetMl; st.water.bottleMl = w.bottleMl; }); }

// ---- Reminders and inbox ----
export function setReminders(patch) { mutate((st) => { st.reminders = normReminders({ ...st.reminders, ...patch }); }); }
/** Adds an in-app notice. `key` makes it idempotent (the same event never produces two notices). */
export function addNotice({ kind, title, body = '', key }) {
  mutate((st) => { const id = key || uid(); if (st.inbox.some((n) => n.id === id)) return; st.inbox.unshift({ id, t: Date.now(), kind: kind || 'info', title, body, read: false }); st.inbox = st.inbox.slice(0, 50); });
}
export const unreadNotices = () => state.inbox.filter((n) => !n.read).length;
export function markNoticesRead() { if (state.inbox.some((n) => !n.read)) mutate((st) => { st.inbox.forEach((n) => { n.read = true; }); }); }
export function dismissNotice(id) { mutate((st) => { st.inbox = st.inbox.filter((n) => n.id !== id); }); }
export function clearInbox() { mutate((st) => { st.inbox = []; }); }
export function markDelivered(keys) { mutate((st) => { st.ui.remDelivered = [...new Set([...(st.ui.remDelivered || []), ...keys])].slice(-60); }, { silent: true }); }

// ---- Imported activities (watches, health exports) ----
/** Adds imported activities, skipping ones already imported. Returns how many were new. */
export function importActivities(list) {
  const have = new Set(state.activities.map((a) => a.id)); const fresh = normActivities(list).filter((a) => !have.has(a.id)); if (!fresh.length) return 0;
  mutate((st) => { st.activities = [...fresh, ...st.activities].sort((a, b) => (a.start < b.start ? 1 : -1)).slice(0, 5000); }); return fresh.length;
}
export const removeActivity = (id) => mutate((st) => { st.activities = st.activities.filter((a) => a.id !== id); });
export const clearActivities = () => mutate((st) => { st.activities = st.activities.filter(isClass); }); // imported only: logged and booked classes stay

// ---- Studio and class sessions (logged or booked) ----
/** Adds a class, or replaces the one with `id`. Returns {id} or {error}. */
export function saveClass(raw, id = null) {
  const r = normClass(raw, dateKey(new Date())); if (r.error) return r;
  const old = id ? state.activities.find((a) => a.id === id && isClass(a)) : null; if (id && !old) return { error: 'That class no longer exists.' };
  const entry = { ...r.value, id: old ? old.id : 'class:' + uid() };
  mutate((st) => { st.activities = old ? st.activities.map((a) => (a.id === entry.id ? entry : a)) : [entry, ...st.activities]; st.activities.sort((a, b) => ((a.start || '') < (b.start || '') ? 1 : -1)); });
  return { id: entry.id };
}
/** Turns a booked class into a done one. `effort` (1 to 5) is optional. */
export function markClassDone(id, effort) {
  const c = state.activities.find((a) => a.id === id && isClass(a)); if (!c) return { error: 'That class no longer exists.' };
  if (c.date > dateKey(new Date())) return { error: 'This class is still in the future.' };
  return saveClass({ ...c, minutes: (c.durationSec || 0) / 60, status: 'done', effort }, id);
}
/** Adds imported weights as body entries for days that have no entry yet. Returns how many were added. */
export function importWeights(list) {
  const days = new Set(state.body.entries.map((e) => e.date)); const fresh = list.filter((w) => w.date && w.kg > 0 && !days.has(w.date)); if (!fresh.length) return 0;
  mutate((st) => { fresh.forEach((w) => st.body.entries.push({ id: 'imp-' + w.date, date: w.date, weight: w.kg })); }); return fresh.length;
}
