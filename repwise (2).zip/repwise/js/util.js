import { CONFIG } from './config.js';

const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ESC[c]);
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
export const sum = (a) => a.reduce((x, y) => x + y, 0);
export const roundTo = (x, step) => (step ? Math.round(x / step) * step : x);

// ---- dates (always local time) ----
const p2 = (n) => String(n).padStart(2, '0');
export const dateKey = (d = new Date()) => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
export const parseKey = (k) => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
export const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
export const startOfWeek = (d = new Date()) => { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); const wd = (x.getDay() + 6) % 7; return addDays(x, -wd); }; // Monday
export const daysBetween = (a, b) => Math.round((parseKey(dateKey(b)) - parseKey(dateKey(a))) / 864e5);
export const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export const DOW = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
export const fmtDay = (k) => { const d = typeof k === 'string' ? parseKey(k) : k; return `${d.getDate()} ${MONTHS[d.getMonth()]}`; };
export const fmtDayLong = (k) => { const d = typeof k === 'string' ? parseKey(k) : k; return `${DOW[(d.getDay() + 6) % 7]} ${d.getDate()} ${MONTHS[d.getMonth()]}`; };
export const relDay = (k, now = new Date()) => {
  const n = daysBetween(parseKey(k), now);
  if (n === 0) return 'Today'; if (n === 1) return 'Yesterday'; if (n < 7) return `${n} days ago`;
  return fmtDay(k);
};
export const fmtClock = (sec) => {
  sec = Math.max(0, Math.round(sec)); const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  return h ? `${h}:${p2(m)}:${p2(s)}` : `${m}:${p2(s)}`;
};
export const fmtDur = (sec) => { const m = Math.round(sec / 60); return m >= 60 ? `${Math.floor(m / 60)}h ${p2(m % 60)}m` : `${Math.max(1, m)} min`; };

// ---- units (everything is stored in kg) ----
const LB = 1 / CONFIG.KG_PER_LB;
export const kgToUnit = (kg, u) => (u === 'lb' ? kg * LB : kg);
export const unitToKg = (v, u) => (u === 'lb' ? v * CONFIG.KG_PER_LB : v);
/** step in kg that feels natural for the unit (5 lb jumps instead of 2.5 kg ≈ 5.5 lb). */
export function stepKg(stepBase, u) {
  if (!stepBase) return 0;
  if (u !== 'lb') return stepBase;
  const lb = Math.max(2.5, Math.round((stepBase * LB) / 2.5) * 2.5);
  return lb * CONFIG.KG_PER_LB;
}
const trim = (n) => String(parseFloat(n.toFixed(2)));
export function fmtW(kg, u = 'kg', withUnit = false) {
  if (kg == null || isNaN(kg)) return '–';
  const v = kgToUnit(kg, u);
  const r = u === 'lb' ? Math.round(v * 2) / 2 : Math.round(v * 4) / 4;
  return trim(r) + (withUnit ? ' ' + u : '');
}
export const fmtVol = (kg, u = 'kg') => {
  const v = kgToUnit(kg, u);
  if (v >= 1e6) return (v / 1e6).toFixed(2).replace(/\.?0+$/, '') + 'M ' + u;
  if (v >= 1e4) return (v / 1e3).toFixed(1).replace(/\.0$/, '') + 'k ' + u;
  return Math.round(v).toLocaleString('en') + ' ' + u;
};
export const plural = (n, w, p) => `${n} ${n === 1 ? w : p || w + 's'}`;
export const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

// ---- body measurements: stored in kg / cm, shown in the person's unit ----
export const IN_CM = 2.54;
export const cmToUnit = (cm, u) => (u === 'lb' ? cm / IN_CM : cm);
export const unitToCm = (v, u) => (u === 'lb' ? v * IN_CM : v);
export const lenUnit = (u) => (u === 'lb' ? 'in' : 'cm');
