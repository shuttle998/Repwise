// Nutrition and hydration: validation, daily totals, target estimates and history.
// Pure functions only (no DOM), so they are easy to test. Everything is computed from what the person logged.
// Nothing here looks up foods: people enter calories and macros themselves, or reuse a saved meal.
import { dateKey, parseKey, addDays, sum } from './util.js';

export const MEALS = { breakfast: 'Breakfast', lunch: 'Lunch', dinner: 'Dinner', snack: 'Snacks' };
export const ACTIVITY = { sedentary: ['Mostly sitting', 1.2], light: ['Light: 1 to 3 workouts a week', 1.375], moderate: ['Moderate: 3 to 5 workouts a week', 1.55], high: ['Very active: hard training most days', 1.725] };
export const kcalFromMacros = (p = 0, c = 0, f = 0) => Math.round(4 * p + 4 * c + 9 * f);
const num = (v, lo, hi, dp = 1) => { const n = typeof v === 'string' && v.trim() === '' ? NaN : +v; if (!Number.isFinite(n) || n < lo || n > hi) return null; const m = 10 ** dp; return Math.round(n * m) / m; };
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const ID = (x) => String(x || '').slice(0, 40) || Math.random().toString(36).slice(2, 10);

/** Validates one meal. Returns { error } or { ok }. kcal is worked out from macros when left blank. */
export function validateMeal(f) {
  const name = String(f.name || '').trim().replace(/\s+/g, ' ').slice(0, 60);
  if (name.length < 1) return { error: 'Give the meal a name.' };
  const p = f.p === '' || f.p == null ? 0 : num(f.p, 0, 500), c = f.c === '' || f.c == null ? 0 : num(f.c, 0, 1000), fat = f.f === '' || f.f == null ? 0 : num(f.f, 0, 500);
  if (p == null || c == null || fat == null) return { error: 'Macros must be numbers from 0 up (protein and fat to 500 g, carbs to 1000 g).' };
  let kcal = f.kcal === '' || f.kcal == null ? null : num(f.kcal, 0, 6000, 0);
  if (f.kcal !== '' && f.kcal != null && kcal == null) return { error: 'Calories must be a number from 0 to 6000.' };
  if (kcal == null) kcal = kcalFromMacros(p, c, fat);
  if (kcal === 0 && p === 0 && c === 0 && fat === 0) return { error: 'Enter calories or at least one macro.' };
  return { ok: { name, meal: MEALS[f.meal] ? f.meal : 'snack', kcal, p, c, f: fat } };
}
const normMealRec = (m) => { if (!m || typeof m !== 'object') return null; const v = validateMeal(m); return v.ok ? { id: ID(m.id), ...v.ok, t: Number.isFinite(m.t) ? m.t : 0 } : null; };

const TGT = { kcal: [800, 8000, 0], protein: [10, 500, 0], carbs: [0, 1000, 0], fat: [10, 400, 0] };
export function normTargets(t) { const o = {}; for (const k in TGT) { const v = t && t[k] != null && t[k] !== '' ? num(t[k], ...TGT[k]) : null; o[k] = v; } return o; }
export function normNutrition(n) {
  const log = {}; if (n && typeof n.log === 'object' && n.log) for (const [d, list] of Object.entries(n.log)) { if (!DATE.test(d) || !Array.isArray(list)) continue; const ms = list.map(normMealRec).filter(Boolean).slice(0, 60); if (ms.length) log[d] = ms; }
  const saved = (Array.isArray(n?.saved) ? n.saved : []).map(normMealRec).filter(Boolean).slice(0, 50).map(({ t, ...m }) => m);
  const calc = n?.calc && typeof n.calc === 'object' ? { sex: ['male', 'female', 'avg'].includes(n.calc.sex) ? n.calc.sex : 'avg', age: num(n.calc.age, 14, 100, 0), heightCm: num(n.calc.heightCm, 100, 250, 0), activity: ACTIVITY[n.calc.activity] ? n.calc.activity : 'light' } : null;
  return { targets: normTargets(n?.targets), log, saved, calc };
}
export function normWater(w) {
  const log = {}; if (w && typeof w.log === 'object' && w.log) for (const [d, list] of Object.entries(w.log)) { if (!DATE.test(d) || !Array.isArray(list)) continue; const es = list.map((e) => { const ml = e && num(e.ml, 10, 3000, 0); return ml ? { id: ID(e.id), ml, t: Number.isFinite(e.t) ? e.t : 0 } : null; }).filter(Boolean).slice(0, 200); if (es.length) log[d] = es; }
  return { targetMl: num(w?.targetMl, 500, 8000, 0), bottleMl: num(w?.bottleMl, 100, 2000, 0) || 500, log };
}

// ---- daily totals and progress
export const dayMeals = (n, date) => n.log[date] || [];
export const dayTotals = (meals) => ({ kcal: sum(meals.map((m) => m.kcal)), p: +sum(meals.map((m) => m.p)).toFixed(1), c: +sum(meals.map((m) => m.c)).toFixed(1), f: +sum(meals.map((m) => m.f)).toFixed(1), count: meals.length });
/** Progress against targets. pct is 0..1+ (not capped), left is negative when over. */
export function dayProgress(tot, t = {}) {
  const row = (value, target) => ({ value, target: target || null, pct: target ? value / target : null, left: target ? Math.round(target - value) : null });
  return { kcal: row(tot.kcal, t.kcal), protein: row(tot.p, t.protein), carbs: row(tot.c, t.carbs), fat: row(tot.f, t.fat) };
}
export const mealGroups = (meals) => Object.keys(MEALS).map((k) => ({ key: k, label: MEALS[k], items: meals.filter((m) => m.meal === k), kcal: sum(meals.filter((m) => m.meal === k).map((m) => m.kcal)) }));
/** Best guess at the meal slot from the hour of day. */
export const mealForHour = (h) => (h < 10 ? 'breakfast' : h < 15 ? 'lunch' : h < 21 ? 'dinner' : 'snack');

// ---- target estimates
/** Mifflin-St Jeor resting energy plus an activity factor, then a goal adjustment. It is an estimate; adjust it from real results. */
export function estimateTargets({ sex = 'avg', age, heightCm, weightKg, activity = 'light', goal = 'muscle' }) {
  if (![age, heightCm, weightKg].every((x) => Number.isFinite(x) && x > 0)) return null;
  const bmr = 10 * weightKg + 6.25 * heightCm - 5 * age + (sex === 'male' ? 5 : sex === 'female' ? -161 : -78);
  const tdee = bmr * ACTIVITY[activity][1], adj = { muscle: 1.1, strength: 1.05, fat: 0.8, gain: 1.15 }[goal] ?? 1;
  const kcal = Math.round(Math.max(tdee * adj, Math.min(bmr, 1200)) / 10) * 10;
  const protein = Math.round(weightKg * (goal === 'fat' ? 2.0 : 1.8)), fat = Math.round(Math.max(weightKg * 0.8, (kcal * 0.2) / 9));
  const carbs = Math.max(0, Math.round((kcal - protein * 4 - fat * 9) / 4));
  return { bmr: Math.round(bmr), tdee: Math.round(tdee), kcal, protein, fat, carbs };
}
/** Daily water target: about 33 ml per kg of body weight, plus 500 ml on a day you trained. Null until a weight is known. */
export const hydrationTarget = (weightKg, trained = false) => (Number.isFinite(weightKg) && weightKg > 0 ? Math.round((weightKg * 33 + (trained ? 500 : 0)) / 50) * 50 : null);

// ---- water
export const waterDay = (w, date) => sum((w.log[date] || []).map((e) => e.ml));
/** Target for a date: the person's own number if set, otherwise the weight-based estimate. */
export const waterTarget = (w, weightKg, trained = false) => w.targetMl || hydrationTarget(weightKg, trained);
export function dateRange(endKey, days) { const e = parseKey(endKey); return Array.from({ length: days }, (_, i) => dateKey(addDays(e, i - days + 1))); }
export const waterHistory = (w, endKey, days) => dateRange(endKey, days).map((date) => ({ date, ml: waterDay(w, date) }));
export const nutritionHistory = (n, endKey, days) => dateRange(endKey, days).map((date) => { const t = dayTotals(dayMeals(n, date)); return { date, ...t, logged: t.count > 0 }; });

/** Averages over days that have entries (days with nothing logged are not counted as zero). */
export function nutritionSummary(n, w, startKey, endKey, { weightKg = null, trainedDates = new Set() } = {}) {
  const days = []; for (let d = parseKey(startKey); dateKey(d) <= endKey; d = addDays(d, 1)) days.push(dateKey(d));
  const logged = days.map((date) => ({ date, ...dayTotals(dayMeals(n, date)) })).filter((x) => x.count > 0), t = n.targets, avg = (k) => (logged.length ? Math.round(sum(logged.map((x) => x[k])) / logged.length) : null);
  const wl = days.map((date) => ({ date, ml: waterDay(w, date) })).filter((x) => x.ml > 0);
  const kcalHit = t.kcal ? logged.filter((x) => Math.abs(x.kcal - t.kcal) / t.kcal <= 0.1).length : null, protHit = t.protein ? logged.filter((x) => x.p >= t.protein * 0.9).length : null;
  const waterHit = wl.filter((x) => { const tg = waterTarget(w, weightKg, trainedDates.has(x.date)); return tg && x.ml >= tg * 0.9; }).length;
  return { days: days.length, loggedDays: logged.length, avgKcal: avg('kcal'), avgProtein: avg('p'), avgCarbs: avg('c'), avgFat: avg('f'), kcalDaysOnTarget: kcalHit, proteinDaysOnTarget: protHit, waterDays: wl.length, avgWaterMl: wl.length ? Math.round(sum(wl.map((x) => x.ml)) / wl.length) : null, waterDaysOnTarget: wl.length && waterTarget(w, weightKg) ? waterHit : null, hasData: logged.length > 0 || wl.length > 0 };
}
