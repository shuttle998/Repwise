// Keeps this device and the cloud copy in step. Local-first: every action works offline and is saved on the device immediately;
// syncing happens in the background when you are signed in and online. Conflicts are resolved by merging, never by overwriting.
import * as cloud from './cloud.js';
import { state, exportJSON, syncSnapshot, applySynced, markSynced, isDirty, localVersion, subscribe, mutate } from './store.js';
import { merge, sameData, hasUserData } from './sync.js';
import { storage } from './services.js';

const PRE_KEY = 'repwise:pre-sync';
const listeners = new Set();
let status = { state: 'off', message: '' }, running = null, again = false, timer = null, retry = 0, started = false;
const set = (st, message = '') => { status = { state: st, message, at: Date.now() }; listeners.forEach((f) => f(status)); };
export const getStatus = () => status;
export const onStatus = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
/** The copy of this device's data taken just before the first merge with an account (a normal Repwise export file), or null. */
export const preSyncBackup = () => storage.get(PRE_KEY);

const validRemote = (d) => d && typeof d === 'object' && Array.isArray(d.sessions) && d.sections && typeof d.sections === 'object';
const fill = (d) => ({ v: 1, sections: {}, stamps: {}, tomb: {}, sessions: [], customExercises: [], programs: [], body: [], mealSaved: [], activities: [], meals: {}, water: {}, ...d });

/**
 * One full sync: combines this device and the account. The first time an account meets this device's data, a copy of the local data is
 * saved first (preSyncBackup). Nothing is ever dropped except items that were deliberately deleted.
 */
export function syncNow({ reason = 'manual' } = {}) {
  if (!cloud.signedIn() || !cloud.configured()) { set('off'); return Promise.resolve(status); }
  if (running) { again = true; return running; }
  running = (async () => {
    set('syncing');
    try {
      for (let attempt = 0; attempt < 5; attempt++) {
        const uid = cloud.currentUser().id, ver = localVersion(), remote = await cloud.fetchRemote();
        const local = syncSnapshot();
        if (!remote) { const r = await cloud.pushRemote(local, null); if (r.conflict) continue; markSynced(r.rev); mutate((st) => { st.sync.accountId = uid; }, { silent: true }); break; }
        if (!validRemote(remote.data)) throw Object.assign(new Error('The cloud copy of your data is not in a format this version understands. Nothing was changed.'), { code: 'bad_remote' });
        const rdata = fill(remote.data), firstForAccount = state.sync.accountId !== uid;
        if (firstForAccount && hasUserData(local)) storage.set(PRE_KEY, exportJSON());
        if (localVersion() !== ver) continue; // you changed something while we were talking to the server: go round again with fresh data
        const merged = merge(local, rdata, { preferLocal: isDirty() });
        if (!sameData(merged, local)) applySynced(merged, { rev: remote.rev });
        if (!sameData(merged, rdata)) { const r = await cloud.pushRemote(merged, remote.rev); if (r.conflict) continue; markSynced(r.rev); } else markSynced(remote.rev);
        mutate((st) => { st.sync.accountId = uid; }, { silent: true });
        break;
      }
      retry = 0; set('idle');
    } catch (e) {
      if (e.code === 'signed_out') set('off', e.message);
      else if (e.code === 'offline') { set('offline', 'Offline. Your changes are saved on this device and will sync when you are back online.'); backoff(); }
      else { set('error', e.message || 'Sync failed.'); backoff(); }
    } finally { running = null; if (again) { again = false; schedule(500); } }
    return status;
  })();
  return running;
}
function backoff() { retry = Math.min(retry + 1, 6); schedule([5, 15, 30, 60, 120, 300][retry - 1] * 1000); }
function schedule(ms) { clearTimeout(timer); timer = setTimeout(() => { if (cloud.signedIn() && navigator.onLine !== false) syncNow({ reason: 'auto' }); else if (cloud.signedIn()) set('offline', 'Offline. Your changes are saved on this device and will sync when you are back online.'); }, ms); }

/** Replaces the cloud copy with exactly what is on this device (used after restoring a backup). Merging would bring deleted items back. */
export async function forcePush() {
  if (!cloud.signedIn()) throw Object.assign(new Error('Sign in to sync.'), { code: 'signed_out' });
  set('syncing');
  try {
    for (let i = 0; i < 5; i++) { const remote = await cloud.fetchRemote(), r = await cloud.pushRemote(syncSnapshot(), remote ? remote.rev : null); if (r.conflict) continue; markSynced(r.rev); mutate((st) => { st.sync.accountId = cloud.currentUser().id; }, { silent: true }); set('idle'); return; }
    throw new Error('Could not save to the cloud because another device kept changing it. Try again.');
  } catch (e) { set(e.code === 'offline' ? 'offline' : 'error', e.message); throw e; }
}

/** Call once at startup. */
export function startSync() {
  if (started) return; started = true;
  if (!cloud.configured() || !cloud.signedIn()) set('off');
  subscribe(() => { if (cloud.signedIn() && cloud.configured() && isDirty() && !running) schedule(4000); });
  window.addEventListener('online', () => { if (cloud.signedIn()) syncNow({ reason: 'online' }); });
  window.addEventListener('offline', () => { if (cloud.signedIn()) set('offline', 'Offline. Your changes are saved on this device and will sync when you are back online.'); });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && cloud.signedIn() && Date.now() - (status.at || 0) > 60000) syncNow({ reason: 'visible' }); });
  setInterval(() => { if (cloud.signedIn() && document.visibilityState === 'visible' && !running) syncNow({ reason: 'interval' }); }, 5 * 60000);
  if (cloud.signedIn() && cloud.configured()) syncNow({ reason: 'startup' });
}
export const stopSyncTimers = () => clearTimeout(timer);
