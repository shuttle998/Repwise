// Front and back muscle maps drawn as simplified anatomy (muscle shapes follow the real layout, but this is an illustration, not a medical drawing).
// `select` mode: tap or press Enter/Space on an area to toggle it. `show` mode: highlights an exercise's primary and secondary muscles.
import { esc } from './util.js';

/** Area -> the muscle name the exercise library uses. Abs and Core share the library's "Core". */
export const AREA_MUSCLE = { Glutes: 'Glutes', Quadriceps: 'Quads', Hamstrings: 'Hamstrings', Calves: 'Calves', Back: 'Back', Chest: 'Chest', Shoulders: 'Shoulders', Biceps: 'Biceps', Triceps: 'Triceps', Forearms: 'Forearms', Abs: 'Core', Core: 'Core' };
/** Library muscle -> map areas that light up for it. */
export const MUSCLE_AREAS = { Quads: ['Quadriceps'], Core: ['Abs', 'Core'], Chest: ['Chest'], Back: ['Back'], Shoulders: ['Shoulders'], Biceps: ['Biceps'], Triceps: ['Triceps'], Forearms: ['Forearms'], Glutes: ['Glutes'], Hamstrings: ['Hamstrings'], Calves: ['Calves'] };

// Paths are drawn for the left half (x < 100) and mirrored for the right. One area can own several shapes (Back = traps, lats and lower back).
const SIDE = {
  front: [
    ['Shoulders', 'M60 66C49 68 42 80 42 96C43 104 49 108 56 106C57 94 62 82 70 74C68 70 64 67 60 66Z'],
    ['Chest', 'M99 80L74 75C65 82 62 97 68 108C78 118 91 118 99 112Z'],
    ['Core', 'M68 114C65 128 66 148 73 164L81 162C77 148 76 132 78 118C74 118 71 117 68 114Z'],
    ['Abs', 'M91 120H99V132H91Z'], ['Abs', 'M90 135H99V147H90Z'], ['Abs', 'M91 150H99V163H91Z'], ['Abs', 'M93 166H99V176H93Z'],
    ['Biceps', 'M43 103C39 117 38 130 40 143L52 143C54 130 56 117 56 107C52 106 47 105 43 103Z'],
    ['Forearms', 'M39 149C35 166 32 184 32 199L43 201C46 185 50 167 52 149Z'],
    ['Quadriceps', 'M72 203C65 226 65 249 72 269C80 274 90 274 97 268C100 247 100 225 98 205C90 199 80 199 72 203Z'],
    ['Calves', 'M72 281C70 299 72 320 76 338L88 338C92 320 92 299 90 281C84 277 78 277 72 281Z'],
  ],
  back: [
    ['Back', 'M99 56L88 58C80 63 72 67 66 72L72 90C83 88 92 82 99 78Z'],
    ['Shoulders', 'M60 66C49 68 42 80 42 96C43 104 49 108 56 106C57 94 62 82 70 74C68 70 64 67 60 66Z'],
    ['Back', 'M72 94C66 108 67 130 75 150C82 158 91 158 95 150L90 112C84 110 78 104 72 94Z'],
    ['Back', 'M99 104L91 110V158L99 168Z'],
    ['Triceps', 'M43 103C39 117 38 130 40 145L52 145C54 130 56 117 56 107C52 106 47 105 43 103Z'],
    ['Forearms', 'M39 151C35 168 32 185 32 199L43 201C46 186 50 168 52 151Z'],
    ['Glutes', 'M99 176C86 169 71 175 69 192C69 207 84 215 99 211Z'],
    ['Hamstrings', 'M72 220C67 241 69 259 74 271L96 271C99 253 99 236 98 218C90 214 80 214 72 220Z'],
    ['Calves', 'M72 281C68 300 72 322 78 340L88 340C94 322 96 300 92 281C86 275 78 275 72 281Z'],
  ],
};
// Half silhouette (left side, centre line x=100): head and neck are drawn separately. Arms are drawn after the torso so they overlap it.
const TORSO = 'M100 54L90 58C82 62 70 66 60 68C50 72 46 84 50 96L58 100C60 116 64 140 70 164C68 176 66 192 68 206L72 222C66 246 66 262 70 276C68 300 70 322 74 346L72 356L94 356L90 340C92 320 94 298 96 276C98 258 100 236 100 222Z';
const ARM = 'M56 70C44 74 40 92 40 112C38 134 36 160 32 184L30 202C30 208 38 210 42 204L52 152C56 130 60 110 62 96Z';
const MIDLINE = { front: 'M100 80V118M91 135H108M91 150H108M96 166H104', back: 'M100 56V212' };
const DETAIL = {
  front: 'M74 75C80 86 90 90 99 88M70 100C74 106 80 110 90 111M73 215C78 232 80 250 78 266M62 122L68 128M64 140L70 146',
  back: 'M72 94C78 100 86 104 90 112M76 150L88 134M72 218C78 236 80 252 78 268M60 78L72 86',
};
// Where each area's name sits (front/back views, viewBox units). Paired muscles are named once.
const LABEL_AT = { front: { Shoulders: [51, 88], Chest: [83, 98], Core: [73, 141], Abs: [100, 150], Biceps: [47, 126], Forearms: [41, 176], Quadriceps: [84, 238], Calves: [81, 312] }, back: { Back: [100, 132], Shoulders: [51, 88], Triceps: [47, 126], Forearms: [41, 178], Glutes: [100, 196], Hamstrings: [84, 246], Calves: [81, 314] } };
const DEFS = '<defs><linearGradient id="bmg-p" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7d8fff"/><stop offset="1" stop-color="#3a50e6"/></linearGradient><linearGradient id="bmg-s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7d8fff" stop-opacity=".55"/><stop offset="1" stop-color="#3a50e6" stop-opacity=".35"/></linearGradient><linearGradient id="bmg-m" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a3037"/><stop offset="1" stop-color="#171b1f"/></linearGradient></defs>';
const LABELS = { front: 'Front', back: 'Back' };

const region = (area, d, { mode, on, p, s, mirror }) => {
  const m = AREA_MUSCLE[area], cls = mode === 'select' ? (on.includes(area) ? ' on' : '') : p.includes(m) ? ' p' : s.includes(m) ? ' s' : '';
  const attrs = mode === 'select' ? ` data-bm="${area}" role="checkbox" aria-checked="${on.includes(area)}" aria-label="${area}" tabindex="${mirror ? -1 : 0}"` : '';
  return `<path class="bm-r${cls}" d="${d}"${attrs}${mirror ? ' transform="translate(200 0) scale(-1 1)"' : ''}><title>${area}</title></path>`;
};

function labelsFor(name, { mode, on, p, s }) {
  const lit = (a) => mode === 'select' ? on.includes(a) : p.includes(AREA_MUSCLE[a]) || s.includes(AREA_MUSCLE[a]);
  return `<g class="bm-lab" aria-hidden="true">${Object.entries(LABEL_AT[name]).filter(([a]) => lit(a) && !(mode === 'show' && a === 'Core')).map(([a, [x, y]]) => `<text x="${x}" y="${y}" text-anchor="middle">${a === 'Quadriceps' ? 'Quads' : mode === 'show' && a === 'Abs' ? 'Core' : a}</text>`).join('')}</g>`;
}
function view(name, o) {
  const both = (d, cls = '') => `<path d="${d}"${cls ? ` class="${cls}"` : ''}/><path d="${d}" transform="translate(200 0) scale(-1 1)"${cls ? ` class="${cls}"` : ''}/>`;
  const regs = SIDE[name].map(([a, d]) => region(a, d, { ...o, mirror: false }) + region(a, d, { ...o, mirror: true })).join('');
  return `<figure class="bm-fig"><svg viewBox="0 0 200 360" role="group" aria-label="${LABELS[name]} of the body">${DEFS}<g class="bm-body"><ellipse cx="100" cy="27" rx="13" ry="16"/><path d="M92 40H108V56H92Z"/>${both(TORSO)}${both(ARM)}</g>${regs}<g class="bm-ln">${both(DETAIL[name])}<path d="${MIDLINE[name]}"/></g>${labelsFor(name, o)}</svg><figcaption>${LABELS[name]}</figcaption></figure>`;
}

/** Both views side by side. Select mode: `selected` is an array of area names. Show mode: `primary` and `secondary` are library muscle names. */
export function bodyMapHTML({ mode = 'select', selected = [], primary = [], secondary = [], spin = true } = {}) {
  const o = { mode, on: selected, p: primary, s: secondary };
  const key = mode === 'show' ? `<p class="bm-key"><span class="k p"></span> Primary${primary.length ? ': ' + esc(primary.join(', ')) : ''} <span class="k s"></span> Assisting${secondary.length ? ': ' + esc(secondary.join(', ')) : ''}</p>` : '';
  if (mode === 'show' && spin) {
    const areas = primary.flatMap((m) => MUSCLE_AREAS[m] || []), back = areas.filter((a) => BACK_ONLY.has(a)).length, front = areas.filter((a) => FRONT_ONLY.has(a)).length, startBack = back > front;
    return `<div class="bm show turnable" data-turn data-face="${startBack ? 'back' : 'front'}"><div class="bm-stage"><div class="bm-turn" style="--a:${startBack ? 180 : 0}deg"><div class="bm-face">${view('front', o)}</div><div class="bm-face bm-flip">${view('back', o)}</div></div></div><div class="bm-ctl"><button class="btn small" type="button" data-turn-go aria-label="Rotate the body to the ${startBack ? 'front' : 'back'}">${'Rotate'}</button><span class="hint" aria-live="polite" data-turn-lbl>${startBack ? 'Back view' : 'Front view'} · drag to turn</span></div></div>${key}`;
  }
  return `<div class="bm ${mode}">${view('front', o)}${view('back', o)}</div>${key}`;
}
const BACK_ONLY = new Set(['Back', 'Triceps', 'Glutes', 'Hamstrings']), FRONT_ONLY = new Set(['Chest', 'Abs', 'Core', 'Biceps', 'Quadriceps']);

/** Makes every rotating body map inside `root` turn: the button flips it, dragging spins it and it snaps to front or back. A flat illustration turning, not a 3D model. */
export function bindSpin(root) {
  root.querySelectorAll('[data-turn]').forEach((el) => {
    const turn = el.querySelector('.bm-turn'), btn = el.querySelector('[data-turn-go]'), lbl = el.querySelector('[data-turn-lbl]');
    let angle = el.dataset.face === 'back' ? 180 : 0, drag = null;
    const set = (a, anim) => { turn.style.transition = anim ? '' : 'none'; turn.style.setProperty('--a', a + 'deg'); };
    const settle = (a) => { angle = Math.round(a / 180) * 180; set(angle, true); const back = (((angle / 180) % 2) + 2) % 2 === 1; el.dataset.face = back ? 'back' : 'front'; lbl.textContent = (back ? 'Back view' : 'Front view') + ' · drag to turn'; btn.setAttribute('aria-label', `Rotate the body to the ${back ? 'front' : 'back'}`); };
    btn.addEventListener('click', () => settle(angle + 180));
    turn.addEventListener('pointerdown', (e) => { drag = { x: e.clientX, a: angle }; turn.setPointerCapture?.(e.pointerId); });
    turn.addEventListener('pointermove', (e) => { if (!drag) return; set(drag.a + (e.clientX - drag.x) * 1.2, false); drag.cur = drag.a + (e.clientX - drag.x) * 1.2; });
    const end = () => { if (!drag) return; const c = drag.cur ?? angle; drag = null; settle(c); };
    turn.addEventListener('pointerup', end); turn.addEventListener('pointercancel', end);
  });
}

/** Wires taps and keys on a select-mode map inside `root`. Calls onToggle(area). Safe to call once per container. */
export function bindBodyMap(root, onToggle) {
  root.addEventListener('click', (e) => { const r = e.target.closest('[data-bm]'); if (r) onToggle(r.dataset.bm); });
  root.addEventListener('keydown', (e) => { if ((e.key === 'Enter' || e.key === ' ') && e.target.matches?.('[data-bm]')) { e.preventDefault(); onToggle(e.target.dataset.bm); } });
}
export const selectedText = (sel) => (sel.length ? esc(sel.join(', ')) : 'Nothing selected');
