// Live heart rate from a Bluetooth LE chest strap or watch that broadcasts the standard Heart Rate service (Web Bluetooth).
// Works in Chrome and Edge on Android, Windows, macOS and Linux. Not available in iOS browsers or Firefox; the app says so instead of failing.
// Data stays on the device: only the average, maximum and minimum are saved with the workout.

const SERVICE = 'heart_rate', CHAR = 'heart_rate_measurement';
export const supported = () => typeof navigator !== 'undefined' && !!navigator.bluetooth;
/** Parse a Heart Rate Measurement characteristic value (Bluetooth spec: flag bit 0 = 16-bit value). */
export function parseHeartRate(dv) { const flags = dv.getUint8(0); return flags & 1 ? dv.getUint16(1, true) : dv.getUint8(1); }

const listeners = new Set();
let dev = null, chr = null, bpm = null, startedAt = 0, samples = [], connecting = false, lastErr = '';
export const hrState = () => ({ supported: supported(), connected: !!dev?.gatt?.connected, connecting, name: dev?.name || '', bpm, error: lastErr });
export const onHr = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = () => listeners.forEach((f) => f(hrState()));
const handle = (e) => { const v = parseHeartRate(e.target.value); if (v >= 30 && v <= 230) { bpm = v; samples.push(v); if (samples.length > 20000) samples.splice(0, 1000); emit(); } };

export async function connectHr() {
  if (!supported()) throw new Error('This browser cannot connect to Bluetooth devices. Use Chrome or Edge on Android or a computer.');
  lastErr = ''; connecting = true; emit();
  try {
    dev = await navigator.bluetooth.requestDevice({ filters: [{ services: [SERVICE] }] });
    dev.addEventListener('gattserverdisconnected', () => { bpm = null; emit(); });
    const server = await dev.gatt.connect(), svc = await server.getPrimaryService(SERVICE); chr = await svc.getCharacteristic(CHAR);
    chr.addEventListener('characteristicvaluechanged', handle); await chr.startNotifications(); startedAt = Date.now();
  } catch (e) {
    dev = null; lastErr = e?.name === 'NotFoundError' ? '' : e?.name === 'SecurityError' ? 'Bluetooth is blocked for this site.' : 'Could not connect. Make sure the device is awake, close to you and not connected to another app.'; if (e?.name === 'NotFoundError') { connecting = false; emit(); return; } throw new Error(lastErr);
  } finally { connecting = false; emit(); }
}
export async function disconnectHr() { try { chr?.removeEventListener('characteristicvaluechanged', handle); await chr?.stopNotifications?.(); } catch { /* ignore */ } try { dev?.gatt?.disconnect(); } catch { /* ignore */ } dev = null; chr = null; bpm = null; emit(); }
/** Start collecting for a workout (clears earlier samples). */
export function resetHrSamples() { samples = []; }
/** Summary of heart rate since resetHrSamples(); null if there were too few readings to mean anything. */
export function hrSummary() { if (samples.length < 10) return null; const sum = samples.reduce((a, b) => a + b, 0); return { avg: Math.round(sum / samples.length), max: Math.max(...samples), min: Math.min(...samples), n: samples.length }; }
