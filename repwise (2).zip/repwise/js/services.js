// Service adapters. The app talks to these, never to localStorage / a payment SDK directly,
// so a real backend can replace them later without touching the views.
import { CONFIG } from './config.js';

/** Storage adapter. Today: localStorage with an in-memory fallback (private mode, blocked storage). */
const memory = new Map();
export const storage = {
  persistent: true,
  lastError: null,
  get(key) {
    try { const v = localStorage.getItem(key); if (v !== null) return v; } catch { this.persistent = false; }
    return memory.get(key) ?? null;
  },
  set(key, value) {
    memory.set(key, value);
    try { localStorage.setItem(key, value); this.persistent = true; this.lastError = null; return true; }
    catch (e) { this.persistent = false; this.lastError = e?.name || 'StorageError'; return false; }
  },
  remove(key) { memory.delete(key); try { localStorage.removeItem(key); } catch { /* ignore */ } },
};

/**
 * Billing adapter. NOT connected to anything. To go live:
 *  1. Create products/prices in your provider (Stripe, Paddle, Lemon Squeezy...).
 *  2. Add server-side code (e.g. Netlify Functions) that creates checkout sessions and receives webhooks.
 *     Secret keys must live only on the server. Never put them in this file.
 *  3. Implement `provider` below (startCheckout, openPortal, getEntitlement) and set CONFIG.PAYMENTS_LIVE = true.
 * Until then, no payment UI is shown and Pro can only be previewed locally.
 */
export const billing = {
  provider: null,
  get live() { return CONFIG.PAYMENTS_LIVE && !!this.provider; },
  async startCheckout(interval) { if (!this.live) throw new Error('PAYMENTS_NOT_CONFIGURED'); return this.provider.startCheckout(interval); },
  async openPortal() { if (!this.live) throw new Error('PAYMENTS_NOT_CONFIGURED'); return this.provider.openPortal(); },
  async getEntitlement() { return this.live ? this.provider.getEntitlement() : null; },
};

/** Account adapter. There is no server, so the "account" is a profile on this device. */
export const account = {
  kind: 'local',
  signedIn: false,
  // A future auth provider can implement signIn/signOut/sync and flip `kind` to 'cloud'.
};
