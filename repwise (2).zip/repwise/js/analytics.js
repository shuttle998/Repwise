// Analytics derived purely from logged sessions. Nothing here is stored or invented:
// delete a session and every number, PR and achievement recomputes.
import { BY_ID, MUSCLES, isGuided } from './exercises.js';
import { e1rm } from './progression.js';
import { dateKey, parseKey, addDays, startOfWeek, daysBetween, sum, MONTHS, fmtDay } from './util.js';

export const sortS = (ss) => [...ss].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : (a.startedAt || 0) - (b.startedAt || 0)));
export const doneItems = (s) => (s.items || []).filter((i) => !i.skipped && i.sets?.length);
const isLoadedEx = (id) => { const e = BY_ID[id]; return !!e && e.unit === 'kg'; };

export function sessionVolume(s) {
  return sum(doneItems(s).map((i) => (isLoadedEx(i.exId) || !BY_ID[i.exId] ? sum(i.sets.map((x) => (x.w > 0 ? x.w * x.reps : 0))) : 0)));
}
export const sessionSets = (s) => sum(doneItems(s).map((i) => i.sets.length));
export function totals(ss) { return { workouts: ss.length, volume: sum(ss.map(sessionVolume)), sets: sum(ss.map(sessionSets)), seconds: sum(ss.map((s) => s.durationSec || 0)) }; }

export const rangeFilter = (ss, days, now = new Date()) => (days === Infinity ? ss : ss.filter((s) => daysBetween(parseKey(s.date), now) < days && daysBetween(parseKey(s.date), now) >= 0));

// ---------- weeks, streaks ----------
const weekKey = (dateStr) => dateKey(startOfWeek(parseKey(dateStr)));
export function weekCounts(ss) { const m = new Map(); ss.forEach((s) => { const k = weekKey(s.date); m.set(k, (m.get(k) || 0) + 1); }); return m; }
const nextWeek = (k) => dateKey(addDays(parseKey(k), 7)), prevWeek = (k) => dateKey(addDays(parseKey(k), -7));

export function weekStreak(ss, target, now = new Date()) {
  target = Math.max(1, target || 3);
  const wc = weekCounts(ss), met = (k) => (wc.get(k) || 0) >= target;
  let k = dateKey(startOfWeek(now)); if (!met(k)) k = prevWeek(k);
  let current = 0; while (met(k)) { current++; k = prevWeek(k); }
  let best = 0, run = 0, prev = null;
  [...wc.keys()].filter(met).sort().forEach((w) => { run = prev && nextWeek(prev) === w ? run + 1 : 1; prev = w; best = Math.max(best, run); });
  return { current, best, metWeeks: [...wc.keys()].filter(met).length };
}

// ---------- per-exercise history ----------
export function exerciseSessions(ss, exId) {
  return sortS(ss).map((s) => { const it = doneItems(s).find((i) => i.exId === exId); return it ? { date: s.date, sets: it.sets, feedback: it.feedback, sessionId: s.id } : null; }).filter(Boolean).reverse();
}
const bestOf = (sets) => {
  let w = 0, wr = 0, e1 = 0, e1w = 0, e1r = 0, reps = 0, repsW = 0;
  sets.forEach((x) => {
    if (x.w > w || (x.w === w && x.reps > wr)) { w = x.w; wr = x.reps; }
    const e = e1rm(x.w, x.reps); if (e > e1) { e1 = e; e1w = x.w; e1r = x.reps; }
    if (x.reps > reps) { reps = x.reps; repsW = x.w; }
  });
  return { w, wr, e1, e1w, e1r, reps, repsW };
};

export function e1rmSeries(ss, exId) {
  const loaded = isLoadedEx(exId);
  return sortS(ss).map((s) => { const it = doneItems(s).find((i) => i.exId === exId); if (!it) return null; const b = bestOf(it.sets); const y = loaded ? b.e1 : b.reps; return y > 0 ? { date: s.date, y, w: loaded ? b.e1w : b.repsW, reps: loaded ? b.e1r : b.reps, top: b.w } : null; }).filter(Boolean);
}
export function topSetSeries(ss, exId) {
  return sortS(ss).map((s) => { const it = doneItems(s).find((i) => i.exId === exId); if (!it) return null; const b = bestOf(it.sets); return b.w > 0 ? { date: s.date, y: b.w, reps: b.wr } : null; }).filter(Boolean);
}

/** Personal-record events. The first time an exercise is logged sets a baseline, not a PR. */
export function prEvents(ss) {
  const best = new Map(), ev = [];
  sortS(ss).forEach((s) => doneItems(s).forEach((i) => {
    if (isGuided(BY_ID[i.exId])) return; // holding a stretch longer, or doing more warm-up reps, is not a personal best
    const b = bestOf(i.sets), prev = best.get(i.exId), loaded = isLoadedEx(i.exId), name = BY_ID[i.exId]?.name || i.name;
    if (prev) {
      if (loaded) {
        if (b.w > prev.w + 1e-6) ev.push({ sid: s.id, date: s.date, exId: i.exId, name, kind: 'weight', value: b.w, reps: b.wr });
        else if (b.e1 > prev.e1 + 0.05) ev.push({ sid: s.id, date: s.date, exId: i.exId, name, kind: 'e1rm', value: b.e1, w: b.e1w, reps: b.e1r });
      } else if (b.reps > prev.reps) ev.push({ sid: s.id, date: s.date, exId: i.exId, name, kind: 'reps', value: b.reps });
    }
    const nb = prev ? { w: Math.max(prev.w, b.w), e1: Math.max(prev.e1, b.e1), reps: Math.max(prev.reps, b.reps) } : { w: b.w, e1: b.e1, reps: b.reps };
    best.set(i.exId, nb);
  }));
  return ev;
}

export function records(ss) {
  const map = new Map();
  sortS(ss).forEach((s) => doneItems(s).forEach((i) => {
    const r = map.get(i.exId) || { exId: i.exId, name: BY_ID[i.exId]?.name || i.name, loaded: isLoadedEx(i.exId), heaviest: null, bestE1: null, mostReps: null, sessions: 0, lastDate: null };
    i.sets.forEach((x) => {
      if (x.w > 0 && (!r.heaviest || x.w > r.heaviest.w || (x.w === r.heaviest.w && x.reps > r.heaviest.reps))) r.heaviest = { w: x.w, reps: x.reps, date: s.date };
      const e = e1rm(x.w, x.reps); if (e > 0 && (!r.bestE1 || e > r.bestE1.v)) r.bestE1 = { v: e, w: x.w, reps: x.reps, date: s.date };
      if (!r.mostReps || x.reps > r.mostReps.reps) r.mostReps = { reps: x.reps, w: x.w, date: s.date };
    });
    r.sessions++; r.lastDate = s.date; map.set(i.exId, r);
  }));
  return [...map.values()].sort((a, b) => b.sessions - a.sessions);
}

/** Exercises with at least 2 sessions, most-trained first, with first→latest change. */
export function topLifts(ss, n = 4) {
  return records(ss).filter((r) => r.sessions >= 2).slice(0, n).map((r) => {
    const series = e1rmSeries(ss, r.exId); if (series.length < 2) return null;
    const first = series[0], last = series[series.length - 1];
    return { exId: r.exId, name: r.name, loaded: r.loaded, series, first: first.y, last: last.y, delta: last.y - first.y, pct: first.y ? ((last.y - first.y) / first.y) * 100 : 0 };
  }).filter(Boolean);
}

export const ANALYTIC_MUSCLES = [...MUSCLES, 'Forearms'];
export const muscleLabel = (m) => (m === 'Quads' ? 'Quadriceps' : m);
export function muscleDistribution(ss) {
  const m = Object.fromEntries(ANALYTIC_MUSCLES.map((x) => [x, 0]));
  ss.forEach((s) => doneItems(s).forEach((i) => { const e = BY_ID[i.exId]; if (!e || isGuided(e)) return; e.pm.forEach((x) => (m[x] += i.sets.length)); e.sm.forEach((x) => (m[x] += i.sets.length * 0.5)); }));
  return Object.entries(m).map(([muscle, sets]) => ({ muscle, sets })).sort((a, b) => b.sets - a.sets);
}

// ---------- chart buckets ----------
export function buckets(ss, days, now = new Date(), opts = {}) {
  const sorted = sortS(ss);
  const end = opts.to || now;
  let start = opts.from ? opts.from : days === Infinity ? (sorted.length ? parseKey(sorted[0].date) : addDays(now, -6)) : addDays(parseKey(dateKey(now)), -(days - 1));
  const span = daysBetween(start, end) + 1;
  const gran = opts.gran || (span <= 35 ? 'day' : span <= 200 ? 'week' : 'month');
  const items = [];
  const keyOf = (d) => gran === 'day' ? dateKey(d) : gran === 'week' ? dateKey(startOfWeek(d)) : dateKey(new Date(d.getFullYear(), d.getMonth(), 1));
  let cur = gran === 'week' ? startOfWeek(start) : gran === 'month' ? new Date(start.getFullYear(), start.getMonth(), 1) : start;
  while (cur <= end) {
    items.push({ key: dateKey(cur), start: new Date(cur), label: gran === 'month' ? MONTHS[cur.getMonth()] : fmtDay(cur), volume: 0, sets: 0, workouts: 0, seconds: 0 });
    cur = gran === 'day' ? addDays(cur, 1) : gran === 'week' ? addDays(cur, 7) : new Date(cur.getFullYear(), cur.getMonth() + 1, 1);
  }
  const idx = new Map(items.map((b, i) => [b.key, i]));
  ss.forEach((s) => { const i = idx.get(keyOf(parseKey(s.date))); if (i != null) { items[i].volume += sessionVolume(s); items[i].sets += sessionSets(s); items[i].workouts++; items[i].seconds += s.durationSec || 0; } });
  return { gran, items };
}
export function weekDays(ss, now = new Date()) {
  const ws = startOfWeek(now);
  return Array.from({ length: 7 }, (_, i) => { const d = addDays(ws, i), k = dateKey(d); const day = ss.filter((s) => s.date === k); return { date: d, key: k, volume: sum(day.map(sessionVolume)), sets: sum(day.map(sessionSets)), workouts: day.length, today: k === dateKey(now), future: d > now }; });
}


// ---------- filters, trends, consistency (Phase 3) ----------
/** Restrict sessions by date range ('YYYY-MM-DD' keys), exercise, or muscle (primary or secondary).
 *  With an exercise/muscle filter, each returned session keeps only the matching exercises, so volume
 *  and sets are those of the filtered work. Sessions with nothing matching are dropped. */
export function filterSessions(ss, { exId = null, muscle = null, from = null, to = null } = {}) {
  return ss.filter((s) => (!from || s.date >= from) && (!to || s.date <= to)).map((s) => {
    if (!exId && !muscle) return s;
    const items = (s.items || []).filter((i) => { if (exId) return i.exId === exId; const e = BY_ID[i.exId]; return !!e && !isGuided(e) && (e.pm.includes(muscle) || e.sm.includes(muscle)); });
    return items.some((i) => !i.skipped && i.sets?.length) ? { ...s, items, filtered: true } : null;
  }).filter(Boolean);
}
export const between = (ss, from, to) => ss.filter((s) => s.date >= from && s.date <= to);

/** Weeks in [from, to] in which the weekly target was met. The current, unfinished week is only counted once met. */
export function consistency(ss, target, from, to, now = new Date()) {
  const wc = weekCounts(ss), cur = dateKey(startOfWeek(now)); let k = startOfWeek(from), weeks = 0, met = 0;
  while (k <= to) { const key = dateKey(k), ok = (wc.get(key) || 0) >= Math.max(1, target || 3); if (ok) { weeks++; met++; } else if (key !== cur) weeks++; k = addDays(k, 7); }
  return { weeks, met, pct: weeks ? met / weeks : 0 };
}

/** Sets per muscle for the period, the period before it, and sets per week. prev is null for all-time. */
export function muscleTrend(ss, days, now = new Date()) {
  const first = sortS(ss)[0], span = days === Infinity ? (first ? daysBetween(parseKey(first.date), now) + 1 : 1) : days;
  const cur = muscleDistribution(rangeFilter(ss, days, now)), prevSs = days === Infinity ? null : ss.filter((s) => { const d = daysBetween(parseKey(s.date), now); return d >= days && d < days * 2; });
  const prev = prevSs ? Object.fromEntries(muscleDistribution(prevSs).map((x) => [x.muscle, x.sets])) : null;
  const weeks = Math.max(1, span / 7);
  return cur.map((x) => ({ muscle: x.muscle, sets: x.sets, perWeek: x.sets / weeks, prev: prev ? prev[x.muscle] : null, change: prev ? x.sets - prev[x.muscle] : null })).sort((a, b) => b.sets - a.sets);
}

/** Muscles with little or no work in the last 28 days. Needs at least 6 workouts, and says so otherwise. */
export function neglectedMuscles(ss, now = new Date(), avoid = []) {
  const month = rangeFilter(ss.filter((s) => doneItems(s).length), 28, now);
  if (month.length < 6) return { enough: false, workouts: month.length, muscles: [] };
  const dist = muscleDistribution(month).filter((x) => MUSCLES.includes(x.muscle) && !avoid.includes(x.muscle));
  const sorted = dist.map((x) => x.sets).sort((a, b) => a - b), median = sorted[Math.floor(sorted.length / 2)] || 0;
  if (median <= 0) return { enough: true, workouts: month.length, muscles: [] };
  return { enough: true, workouts: month.length, muscles: dist.filter((x) => x.sets < median * 0.25).map((x) => x.muscle) };
}

// ---------- achievements ----------
const bestStreakOf = (ss, target) => weekStreak(ss, target, new Date(8640000000000000)).best; // best only
const longestRun = (ss, min) => { const wc = weekCounts(ss), ks = [...wc.keys()].filter((k) => wc.get(k) >= min).sort(); let best = 0, run = 0, prev = null; ks.forEach((k) => { run = prev && nextWeek(prev) === k ? run + 1 : 1; prev = k; best = Math.max(best, run); }); return best; };
const bestE1 = (ss, id) => Math.max(0, ...e1rmSeries(ss, id).map((x) => x.y));
const LIFTS = [['bench', 'Bench press', [40, 60, 100]], ['squat-bb', 'Barbell squat', [60, 100, 140]], ['deadlift', 'Deadlift', [80, 120, 180]], ['ohp-bb', 'Overhead press', [30, 50, 70]]];
const DEFS = [
  ...[1, 5, 10, 25, 50, 100].map((n) => ({ id: 'w' + n, series: 'w', ic: 'check', group: 'Consistency', title: n === 1 ? 'First workout' : `${n} workouts`, desc: `Complete ${n} workout${n > 1 ? 's' : ''}`, target: n, val: (ss) => ss.length })),
  { id: 'm1', series: 'm', ic: 'flame', group: 'Consistency', title: 'A month of consistency', desc: 'Train at least once a week for 4 weeks in a row', target: 4, val: (ss) => longestRun(ss, 1) },
  ...[2, 4, 8, 12].map((n) => ({ id: 's' + n, series: 's', ic: 'flame', group: 'Consistency', title: `${n}-week streak`, desc: `Hit your weekly target ${n} weeks in a row`, target: n, val: (ss, t) => bestStreakOf(ss, t) })),
  ...[1, 4, 12].map((n) => ({ id: 'c' + n, series: 'c', ic: 'target', group: 'Consistency', title: n === 1 ? 'Weekly target hit' : `${n} weekly targets hit`, desc: `Hit your weekly target in ${n} week${n > 1 ? 's' : ''}`, target: n, val: (ss, t) => weekStreak(ss, t, new Date(8640000000000000)).metWeeks })),
  ...[[5e3, '5,000 kg lifted'], [25e3, '25,000 kg lifted'], [1e5, '100,000 kg lifted'], [5e5, '500,000 kg lifted']].map(([n, t], i) => ({ id: 'v' + (i + 1), series: 'v', ic: 'bolt', group: 'Volume', title: t, desc: `Lift a total of ${n.toLocaleString('en')} kg`, target: n, unit: 'kg', val: (ss) => totals(ss).volume })),
  ...[1, 10, 25].map((n) => ({ id: 'p' + n, series: 'p', ic: 'trophy', group: 'Strength', title: n === 1 ? 'First personal record' : `${n} personal records`, desc: `Set ${n} personal record${n > 1 ? 's' : ''}`, target: n, val: (ss) => prEvents(ss).length })),
  ...LIFTS.flatMap(([id, name, ts]) => ts.map((n) => ({ id: `e-${id}-${n}`, series: 'e-' + id, ic: 'trophy', group: 'Strength', title: `${name} ${n} kg`, desc: `Reach an estimated one-rep max of ${n} kg on ${name.toLowerCase()}`, target: n, unit: 'kg', val: (ss) => bestE1(ss, id) }))),
];
export const ACHIEVEMENT_DEFS = DEFS;

export function achievements(state, now = new Date()) {
  const ss = sortS(state.sessions || []), target = state.profile?.days || 3;
  return DEFS.map((d) => {
    const value = d.val(ss, target), unlocked = value >= d.target;
    let date = null;
    if (unlocked) { let lo = 1, hi = ss.length; while (lo < hi) { const mid = (lo + hi) >> 1; if (d.val(ss.slice(0, mid), target) >= d.target) hi = mid; else lo = mid + 1; } date = ss[lo - 1]?.date || null; }
    return { id: d.id, series: d.series, ic: d.ic, tier: DEFS.filter((x) => x.series === d.series).indexOf(d), group: d.group, title: d.title, desc: d.desc, target: d.target, unit: d.unit, value, unlocked, date, progress: Math.min(1, d.target ? value / d.target : 0) };
  });
}

// ---------- weekly report ----------
export function weeklyReport(state, anchor = new Date()) {
  const ss = sortS(state.sessions || []), ws = startOfWeek(anchor), we = addDays(ws, 6), wk = dateKey(ws), prevWk = dateKey(addDays(ws, -7));
  const inWeek = (k) => k >= wk && k <= dateKey(we);
  const week = ss.filter((s) => inWeek(s.date)), before = ss.filter((s) => s.date < wk), prevWeek = ss.filter((s) => s.date >= prevWk && s.date < wk);
  const target = state.profile?.days || 3;
  const volume = sum(week.map(sessionVolume)), prevVolume = sum(prevWeek.map(sessionVolume));
  const improved = [];
  const exIds = [...new Set(week.flatMap((s) => doneItems(s).map((i) => i.exId)))];
  exIds.forEach((id) => {
    const now = bestOf(week.flatMap((s) => doneItems(s).filter((i) => i.exId === id).flatMap((i) => i.sets)));
    const prior = before.flatMap((s) => doneItems(s).filter((i) => i.exId === id).flatMap((i) => i.sets)); if (!prior.length) return;
    const pb = bestOf(prior), loaded = isLoadedEx(id), name = BY_ID[id]?.name || id;
    if (loaded && now.e1 > pb.e1 + 0.05) improved.push({ exId: id, name, from: pb.e1, to: now.e1, kind: 'e1rm' });
    else if (!loaded && now.reps > pb.reps) improved.push({ exId: id, name, from: pb.reps, to: now.reps, kind: 'reps' });
  });
  const prs = prEvents(ss).filter((e) => inWeek(e.date));
  const dist = muscleDistribution(week);
  const areas = [], recs = [];
  if (!week.length) areas.push('No workouts were logged this week.');
  else if (week.length < target) areas.push(`You completed ${week.length} of ${target} planned sessions.`);
  if (week.length) {
    const missed = ['Chest', 'Back', 'Shoulders', 'Quads', 'Hamstrings', 'Glutes'].filter((m) => !(dist.find((d) => d.muscle === m)?.sets > 0));
    if (missed.length) areas.push(`No direct work for ${missed.join(', ').toLowerCase()} this week.`);
    const fbs = week.flatMap((s) => doneItems(s).map((i) => i.feedback)).filter(Boolean);
    if (fbs.length >= 3 && fbs.filter((f) => f === 'hard' || f === 'too_hard').length / fbs.length >= 0.5) areas.push('Over half of your exercises felt hard. Recovery (sleep, food, rest days) may be the limiter.');
  }
  exIds.forEach((id) => { const h = exerciseSessions(ss.filter((s) => s.date <= dateKey(we)), id); if (h.length >= 3) { const tops = h.slice(0, 3).map((x) => bestOf(x.sets)); if (tops[0].w === tops[1].w && tops[1].w === tops[2].w && tops[0].e1 <= tops[2].e1) areas.push(`${BY_ID[id]?.name || id} has not progressed in 3 sessions.`); } });
  const ready = Object.entries(state.working || {}).filter(([id, w]) => w.action === 'increase_weight' && exIds.includes(id)).map(([id]) => BY_ID[id]?.name).filter(Boolean);
  if (!week.length) recs.push(`Book your next ${target} sessions now. Starting is the hard part.`);
  else if (week.length < target) recs.push(`Aim for ${target} sessions next week. Pick your training days in advance.`);
  else recs.push('You hit your target. Repeat the same rhythm next week.');
  if (ready.length) recs.push(`Ready for more weight next week: ${ready.slice(0, 4).join(', ')}.`);
  if (areas.some((a) => a.includes('felt hard'))) recs.push('Hold your weights steady and add a rest day if you can.');
  if (areas.some((a) => a.startsWith('No direct work'))) recs.push('Add the missing muscle groups to a session, or run your full programme through once.');
  if (areas.some((a) => a.includes('not progressed'))) recs.push('For stalled lifts, try a 10% lighter reset or swap to a variation for a few weeks.');
  return { start: ws, end: we, key: wk, hasData: week.length > 0, workouts: week.length, target, volume, prevVolume, volumeChangePct: prevVolume > 0 ? ((volume - prevVolume) / prevVolume) * 100 : null, sets: sum(week.map(sessionSets)), improved, prs, consistency: Math.min(1, week.length / target), areas, recommendations: recs, muscles: dist, seconds: sum(week.map((s) => s.durationSec || 0)), prevSeconds: sum(prevWeek.map((s) => s.durationSec || 0)) };
}

/** Recovery hint for the next session based on recent training. */
export function recoveryInfo(ss, nextMuscles, now = new Date()) {
  const sorted = sortS(ss).filter((s) => s.startedAt); if (!sorted.length) return null;
  const last = sorted[sorted.length - 1], hrs = (now.getTime() - (last.endedAt || last.startedAt)) / 36e5;
  const recent = sorted.filter((s) => (now.getTime() - (s.endedAt || s.startedAt)) / 36e5 < 48);
  const overlap = new Set(); recent.forEach((s) => doneItems(s).forEach((i) => !isGuided(BY_ID[i.exId]) && BY_ID[i.exId]?.pm.forEach((m) => nextMuscles.includes(m) && overlap.add(m))));
  if (hrs < 20) return { level: 'caution', text: `You trained ${hrs < 2 ? 'less than 2 hours' : Math.round(hrs) + ' hours'} ago. If you can, rest and come back tomorrow.` };
  if (overlap.size >= 2) return { level: 'caution', text: `${[...overlap].slice(0, 3).join(', ')} were trained in the last 48 hours. Train today if you feel recovered; otherwise give them another day.` };
  return { level: 'ok', text: hrs < 48 ? 'Recovered and ready.' : `${Math.round(hrs / 24)} days since your last workout. Good to go.` };
}

/** Last performed date per exercise, newest first. Only exercises that still exist are returned. */
export function recentExercises(ss, n = 8) {
  const last = new Map();
  sortS(ss).forEach((s) => doneItems(s).forEach((i) => { if (BY_ID[i.exId]) last.set(i.exId, s.date); }));
  return [...last].map(([exId, date]) => ({ exId, date })).sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0)).slice(0, n);
}


// ---------- monthly report ----------
const MAJOR = ['Chest', 'Back', 'Shoulders', 'Quads', 'Hamstrings', 'Glutes'];
const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
/** Calendar-month report built only from logged workouts. `anchor` is any date in the month. */
export function monthlyReport(state, anchor = new Date()) {
  const ss = sortS(state.sessions || []), ms = new Date(anchor.getFullYear(), anchor.getMonth(), 1), me = new Date(anchor.getFullYear(), anchor.getMonth() + 1, 0);
  const today = dateKey(new Date()), sk = dateKey(ms), ek = dateKey(me), lastKey = ek < today ? ek : today, counted = sk > today ? 0 : daysBetween(ms, parseKey(lastKey)) + 1;
  const pms = new Date(ms.getFullYear(), ms.getMonth() - 1, 1), pk = dateKey(pms), pe = dateKey(new Date(ms.getFullYear(), ms.getMonth(), 0));
  const month = ss.filter((s) => s.date >= sk && s.date <= ek), before = ss.filter((s) => s.date < sk), prev = ss.filter((s) => s.date >= pk && s.date <= pe);
  const target = state.profile?.days || 3, planned = Math.max(0, Math.round((target * counted) / 7));
  // weeks that are fully inside the counted days, to judge "missed targets" fairly
  const weeks = []; for (let w = startOfWeek(ms); dateKey(w) <= lastKey; w = addDays(w, 7)) { const a = dateKey(w) < sk ? sk : dateKey(w), b = dateKey(addDays(w, 6)); if (b > lastKey || a !== dateKey(w)) continue; weeks.push({ start: a, workouts: ss.filter((s) => s.date >= a && s.date <= b).length }); }
  const missedWeeks = weeks.filter((w) => w.workouts < target), hitWeeks = weeks.length - missedWeeks.length;
  const volume = sum(month.map(sessionVolume)), prevVolume = sum(prev.map(sessionVolume)), seconds = sum(month.map((s) => s.durationSec || 0)), prevSeconds = sum(prev.map((s) => s.durationSec || 0));
  const exIds = [...new Set(month.flatMap((s) => doneItems(s).map((i) => i.exId)))], improved = [];
  exIds.forEach((id) => {
    const prior = before.flatMap((s) => doneItems(s).filter((i) => i.exId === id).flatMap((i) => i.sets)); if (!prior.length) return;
    const now = bestOf(month.flatMap((s) => doneItems(s).filter((i) => i.exId === id).flatMap((i) => i.sets))), pb = bestOf(prior), loaded = isLoadedEx(id), name = BY_ID[id]?.name || id;
    if (loaded && now.e1 > pb.e1 + 0.05) improved.push({ exId: id, name, from: pb.e1, to: now.e1, kind: 'e1rm' });
    else if (!loaded && now.reps > pb.reps) improved.push({ exId: id, name, from: pb.reps, to: now.reps, kind: 'reps' });
  });
  improved.sort((a, b) => b.to / b.from - a.to / a.from);
  const prs = prEvents(ss).filter((e) => e.date >= sk && e.date <= ek), dist = muscleDistribution(month);
  const areas = [], recs = [];
  if (!month.length) areas.push('No workouts were logged this month.');
  else if (planned && month.length < planned) areas.push(`You completed ${month.length} of about ${planned} planned sessions.`);
  if (missedWeeks.length) areas.push(`${missedWeeks.length} of ${weeks.length} full ${weeks.length === 1 ? 'week was' : 'weeks were'} below your target of ${target} sessions.`);
  if (month.length >= 4) {
    const gaps = MAJOR.filter((m) => !(dist.find((d) => d.muscle === m)?.sets > 0)); if (gaps.length) areas.push(`No direct work for ${gaps.join(', ').toLowerCase()} this month.`);
    const fbs = month.flatMap((s) => doneItems(s).map((i) => i.feedback)).filter(Boolean);
    if (fbs.length >= 6 && fbs.filter((f) => f === 'hard' || f === 'too_hard').length / fbs.length >= 0.5) areas.push('Over half of your exercises felt hard. Recovery (sleep, food, rest days) may be the limiter.');
  }
  const stalled = exIds.filter((id) => { if (!isLoadedEx(id)) return false; const h = exerciseSessions(ss.filter((s) => s.date <= ek), id); if (h.length < 3) return false; const t = h.slice(0, 3).map((x) => bestOf(x.sets)); return t[0].w > 0 && t[0].w === t[1].w && t[1].w === t[2].w && t[0].e1 <= t[2].e1; }).map((id) => BY_ID[id]?.name).filter(Boolean);
  if (stalled.length) areas.push(`Not progressed over three sessions: ${stalled.slice(0, 3).join(', ')}.`);
  if (!month.length) recs.push(`Plan your next ${target} sessions in advance. Starting is the hard part.`);
  else if (planned && month.length < planned) recs.push(`Aim for ${target} sessions a week next month. Choose your training days ahead of time.`);
  else recs.push('You kept to your plan. Repeat the same rhythm next month.');
  if (areas.some((a) => a.startsWith('No direct work'))) recs.push('Add the missing muscle groups to a session, or run your full programme through once.');
  if (stalled.length) recs.push('For stalled lifts, try a 10% lighter reset or swap to a variation for a few weeks.');
  if (areas.some((a) => a.includes('felt hard'))) recs.push('Hold your weights steady for a week and add a rest day if you can.');
  const ready = Object.entries(state.working || {}).filter(([id, w]) => w.action === 'increase_weight' && exIds.includes(id)).map(([id]) => BY_ID[id]?.name).filter(Boolean);
  if (ready.length) recs.push(`Ready for more weight: ${ready.slice(0, 4).join(', ')}.`);
  return { kind: 'month', start: ms, end: me, key: sk.slice(0, 7), label: `${MONTH_NAMES[ms.getMonth()]} ${ms.getFullYear()}`, startKey: sk, endKey: ek, lastKey, partial: ek > today, hasData: month.length > 0, workouts: month.length, planned, target, weeks, weeksHit: hitWeeks, weeksMissed: missedWeeks.length, volume, prevVolume, volumeChangePct: prevVolume > 0 ? ((volume - prevVolume) / prevVolume) * 100 : null, seconds, prevSeconds, sets: sum(month.map(sessionSets)), improved, prs, consistency: planned ? Math.min(1, month.length / planned) : 0, areas, recommendations: recs, muscles: dist, sessionDates: month.map((s) => s.date) };
}

/** How consistently each muscle was trained over the last `weeks` whole-or-partial weeks ending now. Counts sessions with a logged set where the muscle is primary; secondary work is ignored here. */
export function muscleFrequency(ss, now = new Date(), weeks = 4) {
  const start = addDays(startOfWeek(now), -7 * (weeks - 1)), startK = dateKey(start), rows = new Map();
  for (const s of ss) {
    if (s.date < startK) continue; const wk = weekKey(s.date), seen = new Set();
    for (const it of doneItems(s)) { const ex = BY_ID[it.exId]; if (!ex || isGuided(ex)) continue; for (const m of ex.pm) { if (seen.has(m)) continue; seen.add(m); const r = rows.get(m) || { muscle: m, sessions: 0, weeks: new Set(), sets: new Map(), last: '' }; r.sessions++; r.weeks.add(wk); if (s.date > r.last) r.last = s.date; rows.set(m, r); } }
    for (const it of doneItems(s)) { const ex = BY_ID[it.exId]; if (!ex || isGuided(ex)) continue; const n = it.sets.length; for (const m of ex.pm) { const r = rows.get(m); if (r) r.sets.set(wk, (r.sets.get(wk) || 0) + n); } for (const m of ex.sm || []) { const r = rows.get(m); if (r) r.sets.set(wk, (r.sets.get(wk) || 0) + n / 2); } }
  }
  const cur = weekKey(dateKey(now));
  return [...rows.values()].map((r) => ({ muscle: r.muscle, sessions: r.sessions, weeksTrained: r.weeks.size, weeks, perWeek: r.sessions / weeks, last: r.last, setsThisWeek: r.sets.get(cur) || 0 })).sort((a, b) => b.sessions - a.sessions);
}
