// Builds the compact, factual summary the AI Coach is allowed to see. Everything comes from the
// person's own logs and settings. The name is never included. The Coach view shows this exact JSON on request.
import { BY_ID, LIMITS } from './exercises.js';
import { GOALS, LEVEL, GEAR } from './generator.js';
import { exerciseSessions, prEvents, totals, muscleDistribution, rangeFilter, doneItems, sortS, weekStreak } from './analytics.js';
import { coachInsights, recoveryReport } from './insights.js';
import { kgToUnit, dateKey } from './util.js';

export function buildContext(state, now = new Date()) {
  const p = state.profile || {}, u = state.settings?.units || 'kg', ss = sortS(state.sessions.filter((s) => doneItems(s).length));
  const w = (kg) => Math.round(kgToUnit(kg, u) * 4) / 4;
  const top = (sets) => { const b = [...sets].sort((a, c) => (c.w || 0) - (a.w || 0) || c.reps - a.reps)[0]; return b ? { weight: w(b.w || 0), reps: b.reps } : null; };
  const progExIds = [...new Set((state.program?.sessions || []).flatMap((s) => s.items.map((i) => i.exId)))].filter((id) => BY_ID[id]);
  const t = totals(ss), rec = recoveryReport(ss, now);
  return {
    today: dateKey(now), units: u,
    profile: { goal: GOALS[p.goal]?.n || p.goal, experience: LEVEL[p.level] || p.level, equipment: GEAR[p.gear] || p.gear, trainingDaysPerWeek: p.days, sessionMinutes: p.duration, limitations: (p.limits || []).map((l) => LIMITS[l] || l), exercisesToAvoid: (p.avoid || []).map((id) => BY_ID[id]?.name || id) },
    programme: (state.program?.sessions || []).map((s) => ({ name: s.name, exercises: s.items.map((i) => ({ name: BY_ID[i.exId]?.name || i.exId, sets: i.sets, repRange: i.repLo === i.repHi ? `${i.repLo}` : `${i.repLo}-${i.repHi}` })) })),
    totals: { workouts: t.workouts, totalSets: t.sets, currentWeekStreak: weekStreak(ss, p.days, now).current, workoutsLast7Days: rangeFilter(ss, 7, now).length, workoutsLast28Days: rangeFilter(ss, 28, now).length },
    recentWorkouts: ss.slice(-10).map((s) => ({ date: s.date, name: s.name, minutes: s.durationSec ? Math.round(s.durationSec / 60) : null, exercises: doneItems(s).map((i) => ({ name: BY_ID[i.exId]?.name || i.exId, sets: i.sets.length, bestSet: top(i.sets), feedback: i.feedback || null })) })),
    exerciseHistory: progExIds.map((id) => ({ name: BY_ID[id].name, sessions: exerciseSessions(ss, id).slice(0, 4).map((h) => ({ date: h.date, bestSet: top(h.sets), sets: h.sets.length })) })).filter((e) => e.sessions.length),
    personalRecords: prEvents(ss).filter((e) => e.kind === 'weight').slice(-8).map((e) => ({ exercise: e.name, weight: w(e.value), reps: e.reps, date: e.date })),
    setsPerMuscleLast28Days: muscleDistribution(rangeFilter(ss, 28, now)).filter((m) => m.sets > 0).map((m) => ({ muscle: m.muscle, sets: Math.round(m.sets * 10) / 10 })),
    recentlyTrainedMuscles: rec.hasData ? rec.recent : [],
    flaggedPain: Object.entries(state.working || {}).filter(([, v]) => v?.action === 'adjust').map(([id]) => BY_ID[id]?.name || id),
    appInsights: coachInsights({ ...state, sessions: ss }, now).map((i) => i.title),
    dataNote: ss.length < 6 ? 'Fewer than 6 workouts are logged, so trends are unreliable.' : undefined,
  };
}
