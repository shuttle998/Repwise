/* Repwise data: exercise library, goals, splits, meals, plans, config.
   Pure data, no DOM. Works in the browser (window.RW) and in Node (tests). */
(function (root) {
  const RW = (root.RW = root.RW || {});

  const RANK = { bw: 0, db: 1, gym: 2 };
  const GEAR = { gym: 'Full gym', db: 'Dumbbells at home', bw: 'No equipment' };
  const TIER_LABEL = { bw: 'Bodyweight', db: 'Dumbbells', gym: 'Full gym' };
  const LEVEL = { 0: 'Beginner', 1: 'Some experience', 2: 'Experienced' };
  const MUSCLES = ['Chest', 'Back', 'Shoulders', 'Biceps', 'Triceps', 'Quads', 'Hamstrings', 'Glutes', 'Calves', 'Core'];
  const LIMITS = { knee: 'Knees', lowback: 'Lower back', shoulder: 'Shoulders', wrist: 'Wrists' };

  /* ---- Exercise library ------------------------------------------------
     p: movement slot used by the programme generator
     tier: lowest equipment tier needed (bw < db < gym)
     w0: starting load in kg for an "experience 1x" lifter (number, or per gear)
     step: smallest sensible jump in kg (number, or per gear)
     r: rep range override, tr: hold range in seconds (time-based)
     m: machine/cable, pd: dumbbell weight is per hand, stress: joints to protect */
  const X = [];
  function E(id, name, p, tier, mu, sec, type, diff, w0, step, equip, how, err, o) {
    X.push(Object.assign({ id, name, p, tier, mu, sec, type, diff, w0, step, equip, how: how.split(';'), err: err.split(';'), stress: [] }, o || {}));
  }

  // squat slot
  E('barbell-squat', 'Barbell back squat', 'squat', 'gym', 'Quads', ['Glutes', 'Core'], 'compound', 'Intermediate', 20, 2.5, 'Barbell, squat rack',
    'Set the bar across your upper back with feet about shoulder-width apart;Brace your core, then sit down and back until your thighs are at least parallel to the floor;Drive through your whole foot to stand up, keeping your chest tall',
    'Knees collapsing inward;Heels lifting off the floor;Rounding the lower back at the bottom', { stress: ['knee', 'lowback'] });
  E('smith-squat', 'Smith machine squat', 'squat', 'gym', 'Quads', ['Glutes'], 'compound', 'Beginner', 20, 2.5, 'Smith machine',
    'Place the bar on your upper back with feet slightly in front of the bar;Lower under control until thighs are parallel;Press up without letting your heels lift',
    'Feet directly under the bar, which strains the knees;Dropping too fast;Cutting depth short', { m: 1, stress: ['knee'] });
  E('goblet-squat', 'Goblet squat', 'squat', 'db', 'Quads', ['Glutes', 'Core'], 'compound', 'Beginner', 8, 1, 'One dumbbell',
    'Hold one dumbbell vertically against your chest;Sit between your knees keeping your torso upright;Stand by pushing the floor away',
    'Letting the dumbbell drift away from the chest;Folding forward at the hips;Knees caving in', { stress: ['knee'] });
  E('bw-squat', 'Bodyweight squat', 'squat', 'bw', 'Quads', ['Glutes'], 'compound', 'Beginner', 0, 0, 'None',
    'Stand with feet shoulder-width apart and arms out in front;Sit back and down until thighs are parallel;Stand up fully and squeeze your glutes',
    'Heels lifting;Knees caving in;Rushing the reps', { r: [12, 20], stress: ['knee'] });

  // push slot
  E('bench-press', 'Bench press', 'push', 'gym', 'Chest', ['Triceps', 'Shoulders'], 'compound', 'Intermediate', 20, 2.5, 'Barbell, bench',
    'Lie with eyes under the bar, feet flat, shoulder blades pinched together;Lower the bar to your mid-chest with forearms vertical;Press up and slightly back to the start',
    'Bouncing the bar off the chest;Flaring elbows straight out to the sides;Lifting hips off the bench', { stress: ['shoulder'] });
  E('incline-db-press', 'Incline dumbbell press', 'push', 'gym', 'Chest', ['Shoulders', 'Triceps'], 'compound', 'Intermediate', 8, 2, 'Dumbbells, incline bench',
    'Set the bench at about 30 degrees and start with dumbbells over your shoulders;Lower until your elbows are just below the bench line;Press up until your arms are straight',
    'Bench set too steep, which turns it into a shoulder press;Letting the dumbbells drift wide;Arching the lower back', { pd: 1, stress: ['shoulder'] });
  E('db-floor-press', 'Dumbbell floor press', 'push', 'db', 'Chest', ['Triceps'], 'compound', 'Beginner', 6, 1, 'Dumbbells',
    'Lie on the floor with knees bent and a dumbbell in each hand;Lower until your upper arms touch the floor;Press up until your arms are straight',
    'Slamming elbows into the floor;Uneven pressing between arms;Letting wrists bend back', { pd: 1 });
  E('pushup', 'Push-up', 'push', 'bw', 'Chest', ['Triceps', 'Shoulders', 'Core'], 'compound', 'Beginner', 0, 0, 'None',
    'Place hands slightly wider than your shoulders with your body in a straight line;Lower your chest to just above the floor;Push back up without letting your hips sag',
    'Hips sagging or piking;Elbows flared out to 90 degrees;Half reps', { r: [8, 20], stress: ['wrist'] });

  // pull slot
  E('cable-row', 'Seated cable row', 'pull', 'gym', 'Back', ['Biceps'], 'compound', 'Beginner', 20, 2.5, 'Cable machine',
    'Sit tall with a slight bend in your knees and arms straight;Pull the handle to your lower ribs, squeezing your shoulder blades together;Return slowly until your arms are straight',
    'Leaning back to swing the weight;Shrugging shoulders toward ears;Letting the stack slam between reps', { m: 1 });
  E('barbell-row', 'Barbell row', 'pull', 'gym', 'Back', ['Biceps', 'Core'], 'compound', 'Intermediate', 20, 2.5, 'Barbell',
    'Hinge until your torso is near 45 degrees with a flat back;Pull the bar to your lower ribs;Lower under control without standing up',
    'Rounding the back;Using body momentum;Pulling to the chest instead of the ribs', { stress: ['lowback'] });
  E('db-row', 'One-arm dumbbell row', 'pull', 'db', 'Back', ['Biceps'], 'compound', 'Beginner', 8, 1, 'Dumbbell, bench or sturdy surface',
    'Support one hand and knee on a bench with a flat back;Pull the dumbbell toward your hip, elbow close to your body;Lower until your arm is fully straight',
    'Twisting the torso to lift;Cutting the range of motion;Shrugging the shoulder up', { pd: 1 });
  E('inverted-row', 'Inverted row under a table', 'pull', 'bw', 'Back', ['Biceps'], 'compound', 'Intermediate', 0, 0, 'A sturdy table or low bar',
    'Lie under a sturdy table and grip the edge with arms straight;Keep your body in a straight line and pull your chest to the edge;Lower slowly',
    'Hips sagging;Using a table that is not stable;Pulling with the neck instead of the back', { r: [6, 15] });

  // hinge slot
  E('rdl', 'Romanian deadlift', 'hinge', 'gym', 'Hamstrings', ['Glutes', 'Back'], 'compound', 'Intermediate', 20, 2.5, 'Barbell',
    'Stand holding the bar at hip height with a soft bend in your knees;Push your hips back, sliding the bar down your thighs until you feel a hamstring stretch;Drive your hips forward to stand',
    'Rounding the back;Bending the knees too much so it becomes a squat;Letting the bar drift away from the legs', { stress: ['lowback'] });
  E('deadlift', 'Conventional deadlift', 'hinge', 'gym', 'Hamstrings', ['Glutes', 'Back'], 'compound', 'Advanced', 40, 2.5, 'Barbell, plates',
    'Stand with the bar over mid-foot and grip just outside your legs;Brace, flatten your back and push the floor away;Lock out with hips and knees together, then lower with control',
    'Jerking the bar off the floor;Rounding the lower back;Hips shooting up before the chest', { stress: ['lowback'] });
  E('db-rdl', 'Dumbbell Romanian deadlift', 'hinge', 'db', 'Hamstrings', ['Glutes'], 'compound', 'Beginner', 8, 1, 'Dumbbells',
    'Hold dumbbells in front of your thighs;Push hips back with a flat back until you feel your hamstrings stretch;Squeeze your glutes to stand tall',
    'Rounding the back;Squatting instead of hinging;Dumbbells swinging away from the legs', { pd: 1, stress: ['lowback'] });
  E('single-leg-hinge', 'Single-leg hip hinge', 'hinge', 'bw', 'Hamstrings', ['Glutes', 'Core'], 'compound', 'Beginner', 0, 0, 'None',
    'Stand on one leg with a soft knee;Hinge forward, reaching back with the other leg;Stand up by squeezing your glute',
    'Twisting the hips open;Locking the standing knee;Rushing and losing balance', { r: [8, 15] });

  // overhead press slot
  E('overhead-press', 'Overhead press', 'ohp', 'gym', 'Shoulders', ['Triceps', 'Core'], 'compound', 'Intermediate', 20, 2.5, 'Barbell',
    'Hold the bar at your collarbone with your glutes and core tight;Press straight up, moving your head through at the top;Lower to the collarbone with control',
    'Leaning back excessively;Pressing the bar out in front;Flared ribs', { stress: ['shoulder', 'lowback'] });
  E('db-shoulder-press', 'Dumbbell shoulder press', 'ohp', 'db', 'Shoulders', ['Triceps'], 'compound', 'Beginner', 5, 1, 'Dumbbells',
    'Start with dumbbells at shoulder height, palms forward;Press up until your arms are straight;Lower until your upper arms are parallel to the floor',
    'Arching the lower back;Clanging the dumbbells together;Shrugging at the top', { pd: 1, stress: ['shoulder'] });
  E('pike-pushup', 'Pike push-up', 'ohp', 'bw', 'Shoulders', ['Triceps'], 'compound', 'Intermediate', 0, 0, 'None',
    'Start in a downward-dog position with hips high;Lower the top of your head toward the floor between your hands;Press back up',
    'Hips dropping so it becomes a push-up;Flaring the elbows;Cutting the range short', { r: [5, 15], stress: ['shoulder', 'wrist'] });

  // lunge / quad accessory slot
  E('leg-press', 'Leg press', 'lunge', 'gym', 'Quads', ['Glutes'], 'compound', 'Beginner', 40, 5, 'Leg press machine',
    'Sit with your back flat against the pad and feet shoulder-width on the platform;Lower until your knees reach about 90 degrees;Press through your whole foot without locking out the knees',
    'Letting the lower back lift off the pad;Locking the knees hard at the top;Going so deep the hips roll under', { m: 1, stress: ['knee'] });
  E('split-squat', 'Split squat', 'lunge', 'db', 'Quads', ['Glutes'], 'compound', 'Beginner', 6, 1, 'Dumbbells',
    'Take a long stance with your back heel lifted;Lower your back knee toward the floor;Drive through the front foot to stand',
    'Short stance that pushes the knee far forward;Leaning the torso forward;Front heel lifting', { pd: 1, stress: ['knee'] });
  E('reverse-lunge', 'Reverse lunge', 'lunge', 'bw', 'Quads', ['Glutes'], 'compound', 'Beginner', 0, 0, 'None',
    'Stand tall, then step one foot back;Lower until both knees are about 90 degrees;Push through the front foot to return',
    'Front knee caving inward;Stepping back too short;Bouncing off the back knee', { r: [8, 16], stress: ['knee'] });

  // glute slots
  E('hip-thrust', 'Barbell hip thrust', 'thrust', 'gym', 'Glutes', ['Hamstrings'], 'compound', 'Intermediate', 40, 5, 'Barbell, bench',
    'Rest your upper back on a bench with the bar across your hips;Drive your hips up until your torso is level;Pause and squeeze at the top, then lower',
    'Overarching the lower back at the top;Feet too far from or too close to the hips;Not pausing at the top');
  E('db-hip-thrust', 'Dumbbell hip thrust', 'thrust', 'db', 'Glutes', ['Hamstrings'], 'compound', 'Beginner', 10, 2, 'Dumbbell, bench or sofa',
    'Rest your upper back on a bench with a dumbbell across your hips;Drive your hips up until your torso is level;Pause and squeeze, then lower',
    'Overarching the lower back;Letting the dumbbell roll;Not pausing at the top');
  E('glute-bridge', 'Glute bridge', 'thrust', 'bw', 'Glutes', ['Hamstrings', 'Core'], 'compound', 'Beginner', 0, 0, 'None',
    'Lie on your back with knees bent and feet flat;Push through your heels to lift your hips;Squeeze at the top and lower slowly',
    'Pushing through the toes;Arching the lower back;Rushing the reps', { r: [12, 20] });
  E('bulgarian-split-squat', 'Bulgarian split squat', 'bulg', 'bw', 'Quads', ['Glutes'], 'compound', 'Intermediate', { gym: 8, db: 6, bw: 0 }, { gym: 2, db: 1, bw: 0 }, 'Bench or sturdy chair, optional dumbbells',
    'Rest your back foot on a bench behind you;Lower straight down until your front thigh is near parallel;Drive through the front foot to stand',
    'Front foot too close to the bench;Putting weight on the back foot;Letting the front knee cave in', { pd: 1, stress: ['knee'] });
  E('cable-kickback', 'Cable glute kickback', 'kick', 'gym', 'Glutes', ['Hamstrings'], 'isolation', 'Beginner', 10, 2.5, 'Cable machine, ankle strap',
    'Strap your ankle to the cable and hold the frame, hinging slightly;Kick the leg back by squeezing your glute;Return slowly without letting the weight rest',
    'Swinging with momentum;Arching the lower back;Twisting the hips', { m: 1 });
  E('db-sumo-squat', 'Dumbbell sumo squat', 'kick', 'db', 'Glutes', ['Quads'], 'compound', 'Beginner', 10, 2, 'One dumbbell',
    'Stand with feet wide and toes turned out, dumbbell hanging between your legs;Sit straight down keeping your knees tracking over the toes;Stand and squeeze your glutes at the top',
    'Knees falling inward;Leaning forward;Rushing the reps', { stress: ['knee'] });
  E('donkey-kick', 'Donkey kick', 'kick', 'bw', 'Glutes', ['Hamstrings'], 'isolation', 'Beginner', 0, 0, 'None',
    'Start on hands and knees with a flat back;Lift one leg with the knee bent, pushing the heel toward the ceiling;Lower with control and repeat',
    'Swinging the leg;Arching the lower back;Rotating the hips open', { r: [12, 20], stress: ['wrist'] });
  E('hip-abduction', 'Hip abduction machine', 'abduct', 'gym', 'Glutes', [], 'isolation', 'Beginner', 20, 5, 'Hip abduction machine',
    'Sit with your back against the pad and knees against the pads;Push your knees apart against the resistance;Return slowly without letting the stack rest',
    'Using momentum;Leaning far forward;Cutting the range of motion', { m: 1 });
  E('side-lying-leg-raise', 'Side-lying leg raise', 'abduct', 'bw', 'Glutes', [], 'isolation', 'Beginner', 0, 0, 'None',
    'Lie on your side with your body in a straight line;Lift your top leg slightly behind you, toes pointing forward;Lower slowly',
    'Rolling the hips backward;Lifting too high;Swinging the leg', { r: [12, 20] });
  E('step-up', 'Step-up', 'stepup', 'bw', 'Quads', ['Glutes'], 'compound', 'Beginner', { gym: 8, db: 6, bw: 0 }, { gym: 2, db: 1, bw: 0 }, 'Sturdy bench or chair, optional dumbbells',
    'Place your whole foot on a sturdy step about knee height;Push through that heel to stand tall;Lower slowly instead of dropping down',
    'Pushing off the back foot;Using a wobbly chair;Leaning far forward', { pd: 1, stress: ['knee'] });

  // arms / core slots
  E('cable-curl', 'Cable curl', 'arms', 'gym', 'Biceps', [], 'isolation', 'Beginner', 10, 2.5, 'Cable machine',
    'Stand facing the cable with elbows by your sides;Curl the handle up without moving your elbows;Lower slowly until arms are straight', 'Swinging the torso;Elbows drifting forward;Dropping the weight on the way down', { m: 1 });
  E('db-curl', 'Dumbbell curl', 'arms', 'db', 'Biceps', ['Shoulders'], 'isolation', 'Beginner', 5, 1, 'Dumbbells',
    'Stand with a dumbbell in each hand, elbows pinned to your sides;Curl up and turn your palms toward your shoulders;Lower slowly', 'Swinging the body;Elbows drifting forward;Half reps', { pd: 1 });
  E('close-grip-pushup', 'Close-grip push-up', 'arms', 'bw', 'Triceps', ['Chest', 'Shoulders'], 'compound', 'Beginner', 0, 0, 'None',
    'Place your hands under your shoulders with elbows close to your ribs;Lower your chest to the floor;Push up while keeping your body in a straight line', 'Hips sagging;Elbows flaring out;Half reps', { r: [6, 15], stress: ['wrist'] });
  E('plank', 'Plank', 'core', 'bw', 'Core', ['Shoulders'], 'core', 'Beginner', 0, 0, 'None',
    'Rest on your forearms with elbows under your shoulders;Keep your body in one line by squeezing your glutes and abs;Breathe steadily and hold', 'Hips sagging or piking;Holding your breath;Looking up and straining the neck', { time: 1, tr: [20, 60] });
  E('dead-bug', 'Dead bug', 'core', 'bw', 'Core', [], 'core', 'Beginner', 0, 0, 'None',
    'Lie on your back with arms up and knees bent at 90 degrees;Lower the opposite arm and leg toward the floor while your lower back stays flat;Return and switch sides', 'Lower back arching off the floor;Moving too fast;Holding your breath', { r: [8, 16] });

  // extras for longer sessions
  E('lat-pulldown', 'Lat pulldown', 'vpull', 'gym', 'Back', ['Biceps'], 'compound', 'Beginner', 20, 2.5, 'Lat pulldown machine',
    'Grip the bar slightly wider than your shoulders and sit tall;Pull the bar to your upper chest, driving your elbows down;Let the bar rise slowly until your arms are straight', 'Leaning back to swing;Pulling the bar behind the neck;Shrugging the shoulders', { m: 1, stress: ['shoulder'] });
  E('db-pullover', 'Dumbbell pullover', 'vpull', 'db', 'Back', ['Chest', 'Triceps'], 'isolation', 'Intermediate', 8, 1, 'One dumbbell, bench',
    'Lie across a bench holding one dumbbell over your chest;Lower it back over your head with slightly bent arms;Pull it back over your chest using your lats', 'Bending the elbows too much;Arching the lower back;Using a weight that is too heavy', { stress: ['shoulder'] });
  E('superman', 'Superman hold', 'vpull', 'bw', 'Back', ['Glutes'], 'isolation', 'Beginner', 0, 0, 'None',
    'Lie face down with your arms extended;Lift your arms, chest and legs a few centimetres;Hold briefly, then lower with control', 'Craning the neck up;Jerking into the lift;Lifting too high and compressing the lower back', { r: [10, 20], stress: ['lowback'] });
  E('lateral-raise', 'Lateral raise', 'lateral', 'db', 'Shoulders', [], 'isolation', 'Beginner', 3, 1, 'Light dumbbells',
    'Stand with a dumbbell in each hand and a slight bend in your elbows;Raise your arms out to the sides to shoulder height;Lower slowly', 'Using momentum;Lifting above shoulder height;Shrugging', { pd: 1 });
  E('triceps-pushdown', 'Triceps pushdown', 'triceps', 'gym', 'Triceps', [], 'isolation', 'Beginner', 10, 2.5, 'Cable machine',
    'Stand close to the cable with elbows tucked at your sides;Press the handle down until your arms are straight;Return slowly until your forearms are just past parallel', 'Elbows flaring out;Leaning over the handle;Using body weight to push', { m: 1 });
  E('db-overhead-triceps', 'Overhead triceps extension', 'triceps', 'db', 'Triceps', [], 'isolation', 'Beginner', 5, 1, 'One dumbbell',
    'Hold one dumbbell overhead with both hands;Lower it behind your head by bending your elbows;Extend your arms to return', 'Elbows flaring wide;Arching the back;Lowering too fast', { stress: ['shoulder'] });
  E('bench-dip', 'Bench dip', 'triceps', 'bw', 'Triceps', ['Chest', 'Shoulders'], 'compound', 'Intermediate', 0, 0, 'Sturdy bench or chair',
    'Place your hands on the edge of a bench behind you with legs out;Lower until your elbows are about 90 degrees;Press up until your arms are straight', 'Going too deep and straining the shoulders;Sliding far away from the bench;Flaring the elbows', { r: [6, 15], stress: ['shoulder', 'wrist'] });
  E('calf-raise', 'Calf raise', 'calf', 'bw', 'Calves', [], 'isolation', 'Beginner', { gym: 20, db: 10, bw: 0 }, { gym: 5, db: 2, bw: 0 }, 'Step or platform, optional weight',
    'Stand with the balls of your feet on a step;Rise as high as you can on your toes;Lower slowly until your heels are below the step', 'Bouncing;Short range of motion;Rolling the ankles outward', { r: [12, 20], pd: 1 });
  E('leg-curl', 'Lying leg curl', 'hamcurl', 'gym', 'Hamstrings', [], 'isolation', 'Beginner', 15, 2.5, 'Leg curl machine',
    'Lie face down and line the pad up above your heels;Curl your heels toward your glutes;Lower slowly until your legs are nearly straight', 'Lifting the hips off the pad;Using momentum;Cutting the range of motion', { m: 1 });
  E('face-pull', 'Face pull', 'rear', 'gym', 'Shoulders', ['Back'], 'isolation', 'Beginner', 10, 2.5, 'Cable machine, rope',
    'Set the cable at head height and grab the rope with both hands;Pull the rope toward your face, splitting it apart;Return slowly', 'Leaning back;Pulling too low;Using too much weight', { m: 1 });
  E('reverse-fly', 'Reverse dumbbell fly', 'rear', 'db', 'Shoulders', ['Back'], 'isolation', 'Beginner', 3, 1, 'Light dumbbells',
    'Hinge forward with a flat back and dumbbells hanging down;Raise your arms out to the sides with a slight bend in the elbows;Lower slowly', 'Swinging with the lower back;Shrugging;Going too heavy', { pd: 1 });

  const BY_ID = {};
  X.forEach((e) => (BY_ID[e.id] = e));

  /* ---- Goals ------------------------------------------------------------ */
  const GOALS = {
    muscle: { n: 'Build muscle', h: 'Steady growth, 8 to 12 reps', sets: 3, reps: [8, 12], iso: [10, 15], rest: 75, t: '8 to 12 reps', restText: '60 to 90 seconds' },
    strength: { n: 'Get stronger', h: 'Heavier weights, 5 reps', sets: 4, reps: [4, 6], iso: [8, 12], rest: 150, t: '4 to 6 reps', restText: '2 to 3 minutes' },
    fat: { n: 'Lose weight', h: 'Higher reps, lighter meals', sets: 3, reps: [12, 15], iso: [15, 20], rest: 50, t: '12 to 15 reps', restText: '45 to 60 seconds' },
    gain: { n: 'Gain weight', h: 'Big lifts, more food', sets: 4, reps: [6, 10], iso: [10, 15], rest: 105, t: '6 to 10 reps', restText: '90 seconds to 2 minutes' },
  };
  const FOCUS = {
    balanced: 'Balanced|Whole body',
    glutes: 'Glutes and legs|Hip thrusts, split squats, kickbacks',
    upper: 'Upper body|Chest, back, shoulders, arms',
  };
  const FOCUS_NAME = { balanced: 'Balanced', glutes: 'Glutes and legs', upper: 'Upper body' };

  /* ---- Splits (kept from the original app) ------------------------------- */
  const U1 = { n: 'Upper body', k: ['push', 'pull', 'ohp', 'arms'] };
  const U2 = { n: 'Upper body B', k: ['pull', 'push', 'ohp', 'arms'] };
  const L1 = { n: 'Lower body', k: ['squat', 'hinge', 'lunge', 'core'] };
  const L2 = { n: 'Lower body B', k: ['hinge', 'squat', 'stepup', 'core'] };
  const SPLIT = {
    balanced: {
      3: [{ n: 'Full body A', k: ['squat', 'push', 'pull', 'core'] }, { n: 'Full body B', k: ['hinge', 'ohp', 'lunge', 'core'] }, { n: 'Full body C', k: ['lunge', 'push', 'pull', 'arms'] }],
      4: [U1, L1, U2, L2],
      5: [U1, L1, U2, L2, { n: 'Full body', k: ['squat', 'push', 'pull', 'core'] }],
    },
    glutes: {
      3: [{ n: 'Glutes and hamstrings', k: ['thrust', 'hinge', 'kick', 'core'] }, { n: 'Upper body', k: ['push', 'pull', 'ohp', 'core'] }, { n: 'Legs and glutes', k: ['squat', 'bulg', 'stepup', 'abduct'] }],
      4: [{ n: 'Glutes and hamstrings', k: ['thrust', 'hinge', 'kick', 'core'] }, U1, { n: 'Legs and glutes', k: ['squat', 'bulg', 'stepup', 'abduct'] }, { n: 'Glutes and core', k: ['thrust', 'kick', 'abduct', 'core'] }],
      5: [{ n: 'Glutes and hamstrings', k: ['thrust', 'hinge', 'kick', 'core'] }, U1, { n: 'Legs and glutes', k: ['squat', 'bulg', 'stepup', 'abduct'] }, U2, { n: 'Glutes and core', k: ['thrust', 'kick', 'abduct', 'core'] }],
    },
    upper: {
      3: [U1, L1, U2],
      4: [U1, L1, U2, { n: 'Arms and core', k: ['push', 'pull', 'arms', 'core'] }],
      5: [U1, L1, U2, { n: 'Arms and core', k: ['push', 'pull', 'arms', 'core'] }, L2],
    },
  };
  // Extra slots appended when a longer session is requested
  const EXTRAS = {
    upper: ['rear', 'lateral', 'triceps', 'vpull'],
    lower: ['hamcurl', 'calf', 'abduct', 'kick'],
    full: ['vpull', 'lateral', 'calf', 'rear'],
  };
  // Training days spread across the week with recovery gaps (0 = Monday)
  const SCHEDULE = { 2: [0, 3], 3: [0, 2, 4], 4: [0, 1, 3, 4], 5: [0, 1, 2, 4, 5] };
  const DAY_NAMES = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  /* ---- Nutrition (kept from the original app) ---------------------------- */
  const TIPS = {
    muscle: 'Aim for a palm-sized portion of protein at every meal, and eat your biggest carb meal 2 to 3 hours before you train.',
    fat: 'Keep the protein, trim rice and swallow to about a fist, fill half the plate with vegetables, and walk 20 to 30 minutes on rest days. Lose weight slowly and keep eating enough to train. If you have a health condition, check with a doctor first.',
    gain: 'Eat every 3 to 4 hours, put a protein on every plate, and add groundnuts, avocado or a little extra oil. Gain slowly, a few hundred grams a week. If you are underweight and do not know why, see a doctor.',
  };
  TIPS.strength = TIPS.muscle;
  const MEALS = {
    muscle: { Breakfast: ['Omelette with vegetables and boiled yam', 'Akara with pap and milk', 'Moi moi with boiled eggs and pap'], Lunch: ['Jollof rice, grilled chicken and fried plantain', 'Beans and plantain with fish', 'Rice and stew with turkey and ugwu'], Dinner: ['Eba with okra soup and fish', 'Yam porridge with fish and vegetables', 'Pounded yam with egusi and assorted meat'], Snack: ['Plain yoghurt with groundnuts', 'Boiled eggs and a banana', 'Roasted corn and groundnuts'] },
    fat: { Breakfast: ['Oats with milk and groundnuts', 'Boiled eggs with a small portion of yam and tomato sauce', 'Moi moi with light pap'], Lunch: ['Beans with a small plantain and fish', 'Grilled fish with a fist of jollof rice and salad', 'Chicken pepper soup with boiled yam'], Dinner: ['Efo riro with fish and a small portion of eba', 'Vegetable soup with grilled chicken', 'Okra soup with fish and a small portion of amala'], Snack: ['Garden egg with groundnuts', 'Orange or pawpaw', 'Boiled corn'] },
    gain: { Breakfast: ['Yam and egg sauce with fried plantain and a cup of milk', 'Oats cooked in milk with groundnuts and banana', 'Bread with 3 eggs, avocado and tea with milk'], 'Mid-morning': ['Groundnuts, banana and a cup of kunu', 'Moi moi with pap', 'Peanut butter on bread with milk'], Lunch: ['Jollof rice with chicken thigh, plantain and coleslaw', 'Rice and beans with fried fish and plantain', 'Ofada rice with ayamase stew and turkey'], Evening: ['Suya with bread', 'Boiled eggs and a ripe plantain', 'Boiled corn with coconut and groundnuts'], Dinner: ['Pounded yam with egusi and assorted meat', 'Amala with ewedu, gbegiri and beef', 'Eba with ogbono soup and fish'] },
  };
  MEALS.strength = MEALS.muscle;

  /* ---- Plans and billing structure --------------------------------------- */
  // Prices below are a proposal, change them here only. Payments are not live.
  const CONFIG = {
    paymentsLive: false,
    allowProPreview: true, // lets you try Pro on this device before payments exist. Set false at launch.
    currency: 'USD',
    price: { monthly: 4.99, yearly: 39.99 },
    freeHistoryDays: 30,
  };
  const FEATURES = {
    free: ['Basic workout generation', 'Workout tracking with rest timer', 'Basic progressive overload', '30 days of workout history', 'Basic progress dashboard'],
    pro: ['Advanced workout personalisation', 'Detailed strength analytics', 'Unlimited workout history', 'Advanced progression recommendations', 'Custom training programmes', 'Advanced performance insights', 'Weekly progress reports'],
  };
  // Single place that decides what each plan can do
  const ENTITLEMENTS = {
    free: { history: false, analytics: false, report: false, editor: false, detail: false, longPeriods: false },
    pro: { history: true, analytics: true, report: true, editor: true, detail: true, longPeriods: true },
  };
  /* Billing adapter. To go live, set provider to an object with
     startCheckout(planId) and a way to tell the app which plan the account has
     (confirmed by your server, never by the browser). */
  const BILLING = {
    provider: null,
    available() { return !!this.provider; },
    async startCheckout() { throw new Error('No payment provider is connected yet.'); },
  };

  /* ---- Achievements ------------------------------------------------------ */
  const ACHIEVEMENTS = [
    { id: 'w1', name: 'First workout', desc: 'Finish your first logged workout', kind: 'workouts', n: 1 },
    { id: 'w5', name: 'Getting going', desc: 'Finish 5 workouts', kind: 'workouts', n: 5 },
    { id: 'w10', name: 'Double digits', desc: 'Finish 10 workouts', kind: 'workouts', n: 10 },
    { id: 'w25', name: 'Habit formed', desc: 'Finish 25 workouts', kind: 'workouts', n: 25 },
    { id: 'w50', name: 'Fifty strong', desc: 'Finish 50 workouts', kind: 'workouts', n: 50 },
    { id: 'w100', name: 'Century', desc: 'Finish 100 workouts', kind: 'workouts', n: 100 },
    { id: 's1', name: 'Full week', desc: 'Hit your weekly target', kind: 'streak', n: 1 },
    { id: 's4', name: 'Four-week streak', desc: 'Hit your weekly target 4 weeks running', kind: 'streak', n: 4 },
    { id: 's8', name: 'Eight-week streak', desc: 'Hit your weekly target 8 weeks running', kind: 'streak', n: 8 },
    { id: 's12', name: 'Twelve-week streak', desc: 'Hit your weekly target 12 weeks running', kind: 'streak', n: 12 },
    { id: 'v1', name: '5,000 kg lifted', desc: 'Total training volume of 5,000 kg', kind: 'volume', n: 5000 },
    { id: 'v2', name: '25,000 kg lifted', desc: 'Total training volume of 25,000 kg', kind: 'volume', n: 25000 },
    { id: 'v3', name: '100,000 kg lifted', desc: 'Total training volume of 100,000 kg', kind: 'volume', n: 100000 },
    { id: 'pr1', name: 'First personal record', desc: 'Beat your previous best on any exercise', kind: 'prs', n: 1 },
    { id: 'pr10', name: 'Ten personal records', desc: 'Set 10 personal records', kind: 'prs', n: 10 },
    { id: 'up5', name: 'Moving up', desc: 'Increase the weight on 5 different exercises', kind: 'raised', n: 5 },
  ];

  Object.assign(RW, {
    data: { RANK, GEAR, TIER_LABEL, LEVEL, MUSCLES, LIMITS, EXERCISES: X, BY_ID, GOALS, FOCUS, FOCUS_NAME, SPLIT, EXTRAS, SCHEDULE, DAY_NAMES, TIPS, MEALS, CONFIG, FEATURES, ENTITLEMENTS, BILLING, ACHIEVEMENTS },
  });
  if (typeof module !== 'undefined') module.exports = RW;
})(typeof self !== 'undefined' ? self : globalThis);
