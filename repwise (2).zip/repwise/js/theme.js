// Appearance: dark (default), light, or follow the device. The choice is mirrored in its own tiny localStorage key so
// js/theme-boot.js can apply it before the first paint (no flash of the wrong theme).
const KEY = 'repwise:theme', COLORS = { dark: '#0b0d0e', light: '#f4f6f7' };
export const THEMES = [['dark', 'Dark'], ['light', 'Light'], ['system', 'System']];
export const normTheme = (t) => (t === 'light' || t === 'system' ? t : 'dark');
const mq = () => (typeof matchMedia === 'function' ? matchMedia('(prefers-color-scheme: light)') : null);
export const resolve = (pref) => (pref === 'system' ? (mq()?.matches ? 'light' : 'dark') : normTheme(pref));
let current = 'dark';
export function applyTheme(pref) {
  pref = normTheme(pref); current = pref; const r = resolve(pref), d = document.documentElement;
  d.dataset.theme = r; d.style.colorScheme = r;
  document.querySelectorAll('meta[name="theme-color"]').forEach((m) => m.setAttribute('content', COLORS[r]));
  document.querySelectorAll('meta[name="color-scheme"]').forEach((m) => m.setAttribute('content', r));
  try { localStorage.setItem(KEY, pref); } catch { /* ignore */ }
  return r;
}
export function initTheme(pref) { applyTheme(pref); mq()?.addEventListener?.('change', () => { if (current === 'system') applyTheme('system'); }); }
