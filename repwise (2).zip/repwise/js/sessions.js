// Session structure: warm-up, glute activation, main work, cardio and cool-down. Pure functions: no DOM, no storage.
// The extras wrap a programme session when it starts. They never change the saved programme.
import { BY_ID, EXERCISES, available, hasLimit } from './exercises.js';
import { equipOk } from './generator.js';

export const PHASES = { warmup: 'Warm-up', activation: 'Activation', main: 'Main work', cardio: 'Cardio', cooldown: 'Cool-down' };
export const DEFAULT_EXTRAS = { warmup: false, activation: false, cooldown: false, cardio: 0, cardioId: 'treadmill' };
export const CARDIO_IDS = () => EXERCISES.filter((e) => e.slot === 'cardio').map((e) => e.id);

/** Cleans stored extras: booleans for the three toggles, whole minutes 0 to 60 for cardio, a known cardio exercise. */
export function normExtras(o) {
  const r = o && typeof o === 'object' ? o : {}, m = Math.round(Number(r.cardio));
  return { warmup: r.warmup === true, activation: r.activation === true, cooldown: r.cooldown === true, cardio: m >= 1 && m <= 60 ? m : 0, cardioId: CARDIO_IDS().includes(r.cardioId) ? r.cardioId : DEFAULT_EXTRAS.cardioId };
}
export const anyExtras = (x) => !!x && (x.warmup || x.activation || x.cooldown || x.cardio > 0);

const LOWER = ['Quads', 'Hamstrings', 'Glutes', 'Calves'], UPPER = ['Chest', 'Back', 'Shoulders', 'Biceps', 'Triceps'];
const WARM_LOWER = ['leg-swings', 'hip-circles', 'bodyweight-squat-warm', 'worlds-greatest-stretch'], WARM_UPPER = ['arm-circles', 'scap-pushup', 'band-pull-apart'], WARM_CORE = ['inchworm', 'cat-cow'];
const ACTIVATE = ['clamshell', 'banded-lateral-walk', 'fire-hydrant', 'glute-bridge-hold', 'standing-hip-abduction'];
const COOL = { Quads: 'quad-stretch', Hamstrings: 'hamstring-stretch', Glutes: 'figure-four-stretch', Calves: 'calf-stretch', Chest: 'chest-doorway-stretch', Shoulders: 'shoulder-cross-stretch', Triceps: 'triceps-stretch', Back: 'childs-pose', Core: 'cobra' };

const musclesOf = (ids) => { const t = {}; ids.forEach((id) => { const e = BY_ID[id]; if (e) { e.pm.forEach((m) => (t[m] = (t[m] || 0) + 2)); e.sm.forEach((m) => (t[m] = (t[m] || 0) + 1)); } }); return t; };
const ok = (id, gear, limits, equipment) => { const e = BY_ID[id]; return !!e && available(e, gear) && !hasLimit(e, limits) && (!equipment || equipOk(e, equipment)); };
const pick = (pool, n, gear, limits, used, equipment) => { const out = []; for (const id of pool) { if (out.length >= n) break; if (ok(id, gear, limits, equipment) && !used.has(id)) { out.push(id); used.add(id); } } return out; };
const item = (exId, phase, sets, lo, hi, restSec = 15) => ({ exId, phase, sets, repLo: lo, repHi: hi, restSec });

/**
 * Builds the full list of items for a session: warm-up, activation, the programme's own exercises, cardio, cool-down.
 * `main` is the session's items. Warm-up and cool-down are chosen from the muscles the session trains. Equipment and joint limits are respected.
 */
export function buildSessionPlan(main, extras, { gear = 'gym', limits = [], equipment = null } = {}) {
  const x = normExtras(extras), mainIds = main.map((m) => m.exId), t = musclesOf(mainIds), used = new Set(mainIds), out = [];
  const has = (list) => list.some((m) => t[m]);
  const lower = has(LOWER), upper = has(UPPER);
  if (x.warmup) {
    const ids = [...(lower ? pick(WARM_LOWER, upper ? 2 : 3, gear, limits, used, equipment) : []), ...(upper ? pick(WARM_UPPER, lower ? 1 : 3, gear, limits, used, equipment) : [])];
    if (!ids.length) ids.push(...pick([...WARM_CORE, ...WARM_UPPER], 2, gear, limits, used, equipment));
    ids.forEach((id) => { const e = BY_ID[id]; out.push(item(id, 'warmup', e.sides ? 2 : 1, e.reps[0], e.reps[1])); });
  }
  if (x.activation && (t.Glutes || t.Hamstrings || t.Quads)) pick(ACTIVATE, 2, gear, limits, used, equipment).forEach((id) => { const e = BY_ID[id]; out.push(item(id, 'activation', e.sides ? 2 : 2, e.reps[0], e.reps[1])); });
  main.forEach((m) => out.push({ ...m, phase: 'main' }));
  if (x.cardio > 0 && ok(x.cardioId, gear, limits, equipment)) out.push(item(x.cardioId, 'cardio', 1, x.cardio, x.cardio, 0));
  if (x.cooldown) {
    const ranked = Object.entries(t).sort((a, b) => b[1] - a[1]).map(([m]) => COOL[m]).filter(Boolean), seen = new Set();
    ranked.forEach((id) => { if (seen.size >= 4 || seen.has(id) || !ok(id, gear, limits, equipment)) return; seen.add(id); const e = BY_ID[id]; out.push(item(id, 'cooldown', e.sides ? 2 : 1, Math.min(30, e.reps[0]), Math.min(30, e.reps[0]), 10)); });
  }
  return out;
}

/** A standalone cardio session: one exercise for a set number of minutes. */
export const cardioPlan = (exId, minutes) => BY_ID[exId]?.slot === 'cardio' ? [item(exId, 'cardio', 1, minutes, minutes, 0)] : [];
export const phaseLabel = (p) => PHASES[p] || '';
