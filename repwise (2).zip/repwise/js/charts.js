// Dependency-free SVG charts, drawn at the real pixel width so text stays readable on phones.
import { esc, fmtDay } from './util.js';

const NS = 'http://www.w3.org/2000/svg';
export function niceTicks(max, n = 4) {
  if (!(max > 0)) return { max: 1, ticks: [0, 1] };
  const raw = max / n, mag = 10 ** Math.floor(Math.log10(raw)), f = raw / mag;
  const step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * mag;
  const top = Math.ceil(max / step) * step, ticks = [];
  for (let v = 0; v <= top + 1e-9; v += step) ticks.push(+v.toFixed(6));
  return { max: top, ticks };
}
const compact = (v) => (Math.abs(v) >= 1e6 ? +(v / 1e6).toFixed(1) + 'M' : Math.abs(v) >= 1e3 ? +(v / 1e3).toFixed(1) + 'k' : String(+v.toFixed(1)));

function tooltipFor(host) {
  let tip = host.querySelector('.ch-tip');
  if (!tip) { tip = document.createElement('div'); tip.className = 'ch-tip'; tip.hidden = true; host.appendChild(tip); }
  return tip;
}
function showTip(host, tip, x, y, title, value, sub) {
  tip.textContent = '';
  const v = document.createElement('b'); v.textContent = value; tip.appendChild(v);
  const t = document.createElement('span'); t.textContent = title; tip.appendChild(t);
  if (sub) { const s = document.createElement('span'); s.className = 'ch-sub'; s.textContent = sub; tip.appendChild(s); }
  tip.hidden = false;
  const hw = host.clientWidth, w = tip.offsetWidth;
  tip.style.left = Math.min(Math.max(4, x - w / 2), hw - w - 4) + 'px';
  tip.style.top = Math.max(0, y - tip.offsetHeight - 10) + 'px';
}
function table(caption, rows) { return `<table class="sr-only"><caption>${esc(caption)}</caption><tbody>${rows.slice(0, 80).map(([a, b]) => `<tr><th scope="row">${esc(a)}</th><td>${esc(b)}</td></tr>`).join('')}</tbody></table>`; }

function mount(host, draw) {
  host.classList.add('chart');
  let last = 0;
  const run = () => { const w = Math.floor(host.clientWidth); if (w < 40 || w === last) return; last = w; draw(w); };
  run();
  if (typeof ResizeObserver !== 'undefined') { const ro = new ResizeObserver(() => run()); ro.observe(host); host._ro = ro; }
  else window.addEventListener('resize', run);
}

/** Line chart. points: [{x: ms, y, title, sub}] */
export function lineChart(host, { points, yFmt = compact, height = 200, aria = 'Line chart', area = true, yMin = 0 }) {
  mount(host, (W) => {
    const H = height, m = { l: 40, r: 14, t: 12, b: 26 }, iw = W - m.l - m.r, ih = H - m.t - m.b;
    const ys = points.map((p) => p.y), dataMax = Math.max(...ys), dataMin = yMin === 'auto' ? Math.min(...ys) : 0;
    const pad = yMin === 'auto' ? (dataMax - dataMin || dataMax * 0.1 || 1) * 0.15 : 0;
    const lo = yMin === 'auto' ? Math.max(0, dataMin - pad) : 0;
    const { max, ticks } = niceTicks(dataMax + pad - lo, 4); const top = lo + max;
    const xs = points.map((p) => p.x), x0 = Math.min(...xs), x1 = Math.max(...xs);
    const X = (v) => m.l + (x1 === x0 ? iw / 2 : ((v - x0) / (x1 - x0)) * iw), Y = (v) => m.t + ih - ((v - lo) / (top - lo || 1)) * ih;
    const path = points.map((p, i) => `${i ? 'L' : 'M'}${X(p.x).toFixed(1)},${Y(p.y).toFixed(1)}`).join('');
    const grid = ticks.map((t) => `<line class="ch-grid" x1="${m.l}" x2="${W - m.r}" y1="${Y(lo + t)}" y2="${Y(lo + t)}"/><text class="ch-tick" x="${m.l - 8}" y="${Y(lo + t) + 4}" text-anchor="end">${esc(yFmt(lo + t))}</text>`).join('');
    const nx = Math.min(points.length, W < 420 ? 3 : 5), xl = [];
    for (let i = 0; i < nx; i++) { const p = points[nx === 1 ? 0 : Math.round((i * (points.length - 1)) / (nx - 1))]; xl.push(`<text class="ch-tick" x="${X(p.x)}" y="${H - 6}" text-anchor="${i === 0 && nx > 1 ? 'start' : i === nx - 1 && nx > 1 ? 'end' : 'middle'}">${esc(fmtDay(new Date(p.x)))}</text>`); }
    const dots = points.length <= 40 ? points.map((p) => `<circle class="ch-dot" cx="${X(p.x)}" cy="${Y(p.y)}" r="3.5"/>`).join('') : '';
    host.innerHTML = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(aria)}">${grid}${area && points.length > 1 ? `<path class="ch-area" d="${path}L${X(x1)},${Y(lo)}L${X(x0)},${Y(lo)}Z"/>` : ''}<path class="ch-line" d="${path}"/>${dots}<line class="ch-cross" y1="${m.t}" y2="${H - m.b}" x1="0" x2="0" hidden/><circle class="ch-hot" r="5" hidden/></svg>${table(aria, points.map((p) => [p.title, yFmt(p.y)]))}`;
    const svg = host.querySelector('svg'), cross = svg.querySelector('.ch-cross'), hot = svg.querySelector('.ch-hot'), tip = tooltipFor(host);
    const move = (e) => {
      const r = svg.getBoundingClientRect(), px = e.clientX - r.left; let best = 0, bd = 1e9;
      points.forEach((p, i) => { const d = Math.abs(X(p.x) - px); if (d < bd) { bd = d; best = i; } });
      const p = points[best]; cross.removeAttribute('hidden'); hot.removeAttribute('hidden');
      cross.setAttribute('x1', X(p.x)); cross.setAttribute('x2', X(p.x)); hot.setAttribute('cx', X(p.x)); hot.setAttribute('cy', Y(p.y));
      showTip(host, tip, X(p.x), Y(p.y), p.title, yFmt(p.y), p.sub);
    };
    const leave = () => { cross.setAttribute('hidden', ''); hot.setAttribute('hidden', ''); tip.hidden = true; };
    svg.addEventListener('pointermove', move); svg.addEventListener('pointerdown', move); svg.addEventListener('pointerleave', leave);
  });
}

/** Bar chart. items: [{label, value, title, sub, hi}] */
export function barChart(host, { items, yFmt = compact, height = 180, aria = 'Bar chart', ref = null, minLabelGap = 56 }) {
  mount(host, (W) => {
    const H = height, m = { l: 40, r: 8, t: 12, b: 26 }, iw = W - m.l - m.r, ih = H - m.t - m.b;
    const dataMax = Math.max(...items.map((i) => i.value), ref?.value || 0, 0);
    const { max, ticks } = niceTicks(dataMax || 1, 4);
    const Y = (v) => m.t + ih - (v / max) * ih, slot = iw / items.length, bw = Math.max(3, Math.min(34, slot - Math.min(8, slot * 0.3)));
    const grid = ticks.map((t) => `<line class="ch-grid" x1="${m.l}" x2="${W - m.r}" y1="${Y(t)}" y2="${Y(t)}"/><text class="ch-tick" x="${m.l - 8}" y="${Y(t) + 4}" text-anchor="end">${esc(yFmt(t))}</text>`).join('');
    const every = Math.max(1, Math.ceil(minLabelGap / slot));
    const bars = items.map((it, i) => {
      const cx = m.l + slot * i + slot / 2, h = it.value > 0 ? Math.max(3, (it.value / max) * ih) : 0, x = cx - bw / 2, y = m.t + ih - h, r = Math.min(4, bw / 2, h);
      const d = h ? `M${x},${y + h}V${y + r}Q${x},${y} ${x + r},${y}H${x + bw - r}Q${x + bw},${y} ${x + bw},${y + r}V${y + h}Z` : '';
      return `${h ? `<path class="ch-bar${it.hi ? ' is-hi' : ''}" data-i="${i}" d="${d}"/>` : `<rect class="ch-zero" x="${x}" y="${m.t + ih - 2}" width="${bw}" height="2" rx="1"/>`}${i % every === 0 ? `<text class="ch-tick" x="${cx}" y="${H - 6}" text-anchor="middle">${esc(it.label)}</text>` : ''}`;
    }).join('');
    const refLine = ref ? `<line class="ch-ref" x1="${m.l}" x2="${W - m.r}" y1="${Y(ref.value)}" y2="${Y(ref.value)}"/><text class="ch-tick ch-reftext" x="${W - m.r}" y="${Y(ref.value) - 5}" text-anchor="end">${esc(ref.label)}</text>` : '';
    host.innerHTML = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(aria)}">${grid}${bars}${refLine}</svg>${table(aria, items.map((i) => [i.title || i.label, yFmt(i.value)]))}`;
    const svg = host.querySelector('svg'), tip = tooltipFor(host);
    const move = (e) => {
      const r = svg.getBoundingClientRect(), px = e.clientX - r.left - m.l, i = Math.floor(px / slot);
      if (i < 0 || i >= items.length) { tip.hidden = true; return; }
      const it = items[i], cx = m.l + slot * i + slot / 2;
      svg.querySelectorAll('.ch-bar').forEach((b) => b.classList.toggle('is-on', +b.dataset.i === i));
      showTip(host, tip, cx, Y(it.value), it.title || it.label, yFmt(it.value), it.sub);
    };
    svg.addEventListener('pointermove', move); svg.addEventListener('pointerdown', move);
    svg.addEventListener('pointerleave', () => { tip.hidden = true; svg.querySelectorAll('.ch-bar.is-on').forEach((b) => b.classList.remove('is-on')); });
  });
}

/** Progress ring (static SVG string). */
export function ring(value, max, { size = 112, stroke = 10, label = '', sub = '' } = {}) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r, f = Math.max(0, Math.min(1, max ? value / max : 0));
  return `<div class="ring" style="width:${size}px;height:${size}px" role="img" aria-label="${esc(label || `${value} of ${max}`)}"><svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" aria-hidden="true"><circle class="ring-bg" cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke}" fill="none"/><circle class="ring-fg${f >= 1 ? ' is-full' : ''}" cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-width="${stroke}" fill="none" stroke-linecap="round" stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${(c * (1 - f)).toFixed(1)}" transform="rotate(-90 ${size / 2} ${size / 2})"/></svg><div class="ring-t"><b>${esc(label)}</b>${sub ? `<span>${esc(sub)}</span>` : ''}</div></div>`;
}

export function sparkline(values, { w = 96, h = 32 } = {}) {
  if (values.length < 2) return '';
  const min = Math.min(...values), max = Math.max(...values), rng = max - min || 1;
  const pts = values.map((v, i) => `${((i / (values.length - 1)) * (w - 4) + 2).toFixed(1)},${(h - 4 - ((v - min) / rng) * (h - 8)).toFixed(1)}`);
  return `<svg class="spark" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true"><polyline points="${pts.join(' ')}" fill="none" class="spark-l" stroke-linecap="round" stroke-linejoin="round"/><circle cx="${pts[pts.length - 1].split(',')[0]}" cy="${pts[pts.length - 1].split(',')[1]}" r="2.5" class="spark-d"/></svg>`;
}

/** Horizontal bars as plain HTML (accessible by default). items: [{label, value, text}] */
export function hbars(items, { max } = {}) {
  const m = max ?? Math.max(...items.map((i) => i.value), 0.0001);
  return `<ul class="hbars">${items.map((i) => `<li><span class="hb-l">${esc(i.label)}</span><span class="hb-t" aria-hidden="true"><i style="width:${Math.max(i.value > 0 ? 2 : 0, (i.value / m) * 100).toFixed(1)}%"></i></span><span class="hb-v">${esc(i.text)}</span></li>`).join('')}</ul>`;
}
export { NS };
