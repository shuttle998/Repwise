// Weekly and monthly fitness reports, with export. Everything shown is computed from logged data.
import { state, mutate, isPro, can, units, latestWeightKg } from '../store.js';
import { esc, fmtW, fmtVol, fmtDur, plural, dateKey, startOfWeek, addDays, parseKey, MONTHS, DOW } from '../util.js';
import { icon, empty, lockCard, toast } from '../ui.js';
import { hbars, ring } from '../charts.js';
import * as A from '../analytics.js';
import { nutritionSummary } from '../nutrition.js';
import { reportText, reportCSV, reportFile, reportTitle, download } from '../report-export.js';

const prLabel = (e, u) => e.kind === 'weight' ? `${fmtW(e.value, u, true)} × ${e.reps}` : e.kind === 'e1rm' ? `est. 1RM ${fmtW(e.value, u, true)}` : `${e.value} reps`;
let mode = 'week';

export default function reportView(pane) {
  const now = new Date(), thisWk = startOfWeek(now), prevWk = addDays(thisWk, -7), thisMo = new Date(now.getFullYear(), now.getMonth(), 1), prevMo = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const S = () => ({ sessions: state.sessions, profile: state.profile, working: state.working });
  const hasPrevWk = A.weeklyReport(S(), prevWk).hasData, hasPrevMo = A.monthlyReport(S(), prevMo).hasData;
  let wk = pane._wk || (hasPrevWk ? prevWk : thisWk), mo = pane._mo || (hasPrevMo ? prevMo : thisMo);
  const dates = state.sessions.map((s) => s.date).sort(), firstDay = dates.length ? parseKey(dates[0]) : now;

  const nutOf = (r) => { const sk = r.kind === 'month' ? r.startKey : dateKey(r.start), ek = r.kind === 'month' ? r.endKey : dateKey(r.end), trained = new Set(state.sessions.map((s) => s.date)); return nutritionSummary(state.nutrition, state.water, sk, ek, { weightKg: latestWeightKg(), trainedDates: trained }); };
  let current = null;

  const draw = () => {
    const u = units(), pro = isPro(), month = mode === 'month';
    const r = month ? A.monthlyReport(S(), mo) : A.weeklyReport(S(), wk); r.kind = month ? 'month' : 'week'; current = r;
    if (!month && dateKey(wk) === dateKey(prevWk) && r.hasData && state.ui.reportSeen !== r.key) mutate((st) => { st.ui.reportSeen = r.key; }, { silent: true });
    const nut = nutOf(r), plan = month ? r.planned : r.target;
    const range = month ? r.label : `${r.start.getDate()} ${MONTHS[r.start.getMonth()]} – ${r.end.getDate()} ${MONTHS[r.end.getMonth()]}`;
    const isCur = month ? dateKey(mo) === dateKey(thisMo) : dateKey(wk) === dateKey(thisWk);
    const sub = month ? (isCur ? 'This month so far' : dateKey(mo) === dateKey(prevMo) ? 'Last month' : 'Month report') : (isCur ? 'This week so far' : dateKey(wk) === dateKey(prevWk) ? 'Last week' : 'Week report');
    const atStart = month ? mo <= new Date(firstDay.getFullYear(), firstDay.getMonth(), 1) : wk <= startOfWeek(firstDay);
    const per = month ? 'month' : 'week';
    pane.innerHTML = `<div class="seg-c" role="group" aria-label="Report period" style="margin-bottom:12px">${[['week', 'Weekly'], ['month', 'Monthly']].map(([k, l]) => `<button class="seg-b" data-mode="${k}" aria-pressed="${mode === k}">${l}</button>`).join('')}</div>
      <div class="wk-nav"><button class="icon-btn" data-step="-1" aria-label="Previous ${per}" ${atStart ? 'disabled' : ''}>${icon('left')}</button><div style="text-align:center"><b>${esc(range)}</b><div class="lbl">${sub}</div></div><button class="icon-btn" data-step="1" aria-label="Next ${per}" ${isCur ? 'disabled' : ''}>${icon('right')}</button></div>
      ${!r.hasData ? `${empty(`No workouts this ${per}`, 'A report is built from your logged workouts. Nothing is estimated.', '<a class="btn primary" href="#/train">Start a workout</a>')}${nut.hasData ? nutCard(nut) : ''}` : `<div class="stack" id="rep-body">
        <div class="grid-fit">
          <div class="card row" style="gap:16px">${ring(Math.min(r.workouts, plan || 1), plan || 1, { size: 84, stroke: 8, label: `${r.workouts}/${plan}`, sub: 'sessions' })}<div><b>Consistency</b><div class="mut" style="font-size:14px">${Math.round(r.consistency * 100)}% of your ${per}ly target${month && r.partial ? ' so far' : ''}</div></div></div>
          <div class="card"><span class="lbl">Training volume</span><div class="num" style="font-size:26px;font-weight:600;margin-top:4px">${esc(fmtVol(r.volume, u))}</div><div class="s ${r.volumeChangePct == null ? 'mut' : r.volumeChangePct >= 0 ? 'up' : 'down'}" style="font-size:13.5px">${r.volumeChangePct == null ? `No previous ${per} to compare` : `${r.volumeChangePct >= 0 ? '+' : '−'}${Math.abs(Math.round(r.volumeChangePct))}% vs previous ${per}`}</div></div>
          <div class="card"><span class="lbl">Training time</span><div class="num" style="font-size:26px;font-weight:600;margin-top:4px">${r.seconds ? esc(fmtDur(r.seconds)) : '–'}</div><div class="mut" style="font-size:13.5px">${r.seconds ? `${plural(r.workouts, 'workout')}, ${esc(fmtDur(Math.round(r.seconds / r.workouts)))} on average` : 'Not recorded for these workouts'}</div></div>
          <div class="card"><span class="lbl">Sets completed</span><div class="num" style="font-size:26px;font-weight:600;margin-top:4px">${r.sets}</div><div class="mut" style="font-size:13.5px">${plural(r.prs.length, 'personal record')}</div></div>
        </div>
        ${month ? weeksCard(r, state.profile?.days || 3) : ''}
        ${pro ? `<section class="card"><div class="card-h"><h3>Strength improvements</h3></div>${r.improved.length || r.prs.length ? `<ul class="rep-list good">${r.prs.map((e) => `<li>${icon('trophy')}<span><b>${esc(e.name)}</b> new record: ${esc(prLabel(e, u))}</span></li>`).join('')}${r.improved.filter((i) => !r.prs.some((p) => p.exId === i.exId)).map((i) => `<li>${icon('check')}<span><b>${esc(i.name)}</b> ${i.kind === 'e1rm' ? `est. 1RM ${esc(fmtW(i.from, u))} → ${esc(fmtW(i.to, u, true))}` : `best set ${i.from} → ${i.to} reps`}</span></li>`).join('')}</ul>` : `<p class="mut">No exercise beat its earlier best this ${per}. That is normal during a steady or recovery block.</p>`}</section>
        <section class="card"><div class="card-h"><h3>Missed targets and areas to work on</h3></div>${r.areas.length ? `<ul class="rep-list watch">${r.areas.map((a) => `<li>${icon('alert')}<span>${esc(a)}</span></li>`).join('')}</ul>` : `<p class="mut">Nothing flagged. Solid ${per}.</p>`}</section>
        <section class="card"><div class="card-h"><h3>Suggested improvements</h3></div><ul class="rep-list next">${r.recommendations.map((a) => `<li>${icon('target')}<span>${esc(a)}</span></li>`).join('')}</ul></section>
        <section class="card"><div class="card-h"><h3>Muscle group distribution</h3><span class="lbl">Sets</span></div>${hbars(r.muscles.filter((m) => m.sets > 0).map((m) => ({ label: m.muscle, value: m.sets, text: String(+m.sets.toFixed(1)) })))}</section>
        ${nut.hasData ? nutCard(nut) : ''}`
        : `${lockCard(`Full ${per}ly report`, `Pro adds strength improvements, missed targets, suggestions, muscle distribution and exports.`)}${nut.hasData ? nutCard(nut) : ''}`}
      </div>
      ${pro ? `<section class="card" id="rep-export" style="margin-top:16px"><div class="card-h"><h3>Export this report</h3></div><div class="btn-row"><button class="btn small" data-x="csv">${icon('download')} CSV</button><button class="btn small" data-x="print">${icon('download')} Print or save as PDF</button><button class="btn small" data-x="share">${icon('share')} Share or copy text</button></div><p class="hint" style="margin-top:8px">CSV opens in Excel or Sheets. Print has a Save as PDF option.</p></section>` : lockCard('Export reports', 'Pro lets you download a CSV, save a PDF or share a text summary of any weekly or monthly report.')}`}`;
  };
  const nutCard = (n) => `<section class="card"><div class="card-h"><h3>Nutrition and hydration</h3><a class="link" href="#/nutrition">Open</a></div><div class="grid2">${n.loggedDays ? `<div class="stat"><span class="lbl">Avg calories</span><b>${n.avgKcal}</b><span class="sub">${n.loggedDays} of ${n.days} days logged</span></div><div class="stat"><span class="lbl">Avg protein</span><b>${n.avgProtein} g</b><span class="sub">${n.proteinDaysOnTarget != null ? `target met ${n.proteinDaysOnTarget} of ${n.loggedDays} days` : 'no protein target set'}</span></div>` : ''}${n.waterDays ? `<div class="stat"><span class="lbl">Avg water</span><b>${(n.avgWaterMl / 1000).toFixed(1)} L</b><span class="sub">${n.waterDaysOnTarget != null ? `target met ${n.waterDaysOnTarget} of ${n.waterDays} days` : `${n.waterDays} days logged`}</span></div>` : ''}</div></section>`;
  const weeksCard = (r, target) => `<section class="card"><div class="card-h"><h3>Weekly target</h3><span class="lbl">${r.weeksHit} of ${r.weeks.length} full weeks hit</span></div>${r.weeks.length ? `<div class="wk-chips">${r.weeks.map((w) => { const d = parseKey(w.start), ok = w.workouts >= target; return `<div class="wk-chip ${ok ? 'on' : ''}"><b>${w.workouts}/${target}</b><span>${d.getDate()} ${MONTHS[d.getMonth()]}</span><span class="sr-only">${ok ? 'target met' : 'below target'}</span></div>`; }).join('')}</div>` : '<p class="mut">No full week has finished yet this month.</p>'}</section>`;

  pane.addEventListener('click', async (e) => {
    const m = e.target.closest('[data-mode]'), st = e.target.closest('[data-step]'), x = e.target.closest('[data-x]');
    if (m) { mode = m.dataset.mode; return draw(); }
    if (st) { if (mode === 'month') { mo = new Date(mo.getFullYear(), mo.getMonth() + +st.dataset.step, 1); pane._mo = mo; } else { wk = addDays(wk, 7 * +st.dataset.step); pane._wk = wk; } return draw(); }
    if (!x || !can('reportExport') || !current) return;
    const u = units(), nut = nutOf(current), k = x.dataset.x;
    if (k === 'csv') { download(reportFile(current, 'csv'), reportCSV(current, u, nut)); toast('CSV downloaded'); }
    else if (k === 'print') { document.body.classList.add('printing-report'); document.title = reportTitle(current); const done = () => { document.body.classList.remove('printing-report'); document.title = 'Repwise'; window.removeEventListener('afterprint', done); }; window.addEventListener('afterprint', done); setTimeout(() => window.print(), 50); setTimeout(done, 60000); }
    else if (k === 'share') {
      const text = reportText(current, u, nut);
      try { if (navigator.share) { await navigator.share({ title: reportTitle(current), text }); return; } } catch (err) { if (err?.name === 'AbortError') return; }
      try { await navigator.clipboard.writeText(text); toast('Report copied'); } catch { download(reportFile(current, 'txt'), text, 'text/plain;charset=utf-8'); toast('Report saved as a text file'); }
    }
  });
  draw();
}
