import { state, setReminders, mutate, markNoticesRead, dismissNotice, clearInbox } from '../store.js';
import { normReminders, buildICS, nextReminder } from '../reminders.js';
import { plannedDays } from '../schedule.js';
import { esc, DOW, dateKey, fmtDayLong } from '../util.js';
import { icon, sheet, toast } from '../ui.js';
import { checkReminders } from '../reminder-engine.js';

const tgl = (k, label, desc, on) => `<button class="toggle" role="switch" aria-checked="${on}" data-rt="${k}"><span><b>${esc(label)}</b><span class="s">${esc(desc)}</span></span><span class="sw"></span></button>`;
const time = (id, v, label) => `<div class="field" style="margin:8px 0 0"><label for="${id}">${esc(label)}</label><input class="input" type="time" id="${id}" value="${esc(v)}" style="max-width:160px"></div>`;
function download(name, text) { const url = URL.createObjectURL(new Blob([text], { type: 'text/calendar' })); const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); }

export function openReminders(onChange) {
  const body = () => {
    const r = normReminders(state.reminders), plan = plannedDays(state), nx = nextReminder(state), perm = 'Notification' in window ? Notification.permission : 'unsupported';
    return `<p class="mut" style="margin-bottom:12px">Pick your training days, then choose how you want to be reminded. Reminders only fire on planned days and never after you have already trained.</p>
    <div class="field"><span class="lbl">Planned training days</span><div class="row wrap" style="gap:6px" role="group" aria-label="Planned training days">${DOW.map((d, i) => `<button type="button" class="chip dayp" data-day="${i}" aria-pressed="${plan.includes(i)}">${d}</button>`).join('')}</div><p class="hint">${state.reminders.days ? 'Custom days.' : `Suggested for ${state.profile.days} days a week.`} Anything else is a rest day.</p></div>
    <div class="list">${tgl('enabled', 'Workout reminders', nx ? `Next: ${fmtDayLong(dateKey(nx.when))} at ${r.time}` : 'Reminds you on planned days', r.enabled)}</div>
    ${r.enabled ? `${time('rt-time', r.time, 'Reminder time')}<div class="list" style="margin-top:8px">${tgl('upcoming', 'Evening-before heads-up', 'A nudge the evening before a planned session', r.upcoming)}${tgl('summary', 'Weekly progress summary', 'Once a week, with a link to your report', r.summary)}</div>${r.upcoming ? time('rt-up', r.upcomingTime, 'Heads-up time') : ''}${r.summary ? `<div class="field" style="margin:8px 0 0"><label for="rt-sd">Summary day</label><select class="input" id="rt-sd" style="max-width:160px">${DOW.map((d, i) => `<option value="${i}" ${r.summaryDay === i ? 'selected' : ''}>${d}</option>`).join('')}</select></div>${time('rt-st', r.summaryTime, 'Summary time')}` : ''}` : ''}
    <div class="list" style="margin-top:8px">${tgl('milestones', 'Milestone and level notices', 'Achievements, levels and completed challenges in your inbox', r.milestones)}${tgl('programme', 'Programme updates', 'A notice when your programme is rebuilt', r.programme)}</div>
    <div class="note" style="margin-top:14px">${icon('info')}<span><b>How reminders are delivered.</b> Repwise has no server yet, so a closed browser cannot be woken. Reminders appear while the app is open or in the background${perm === 'granted' ? ' (system notifications are on)' : perm === 'denied' ? ' (system notifications are blocked in your browser)' : ''}, and any you missed show in your inbox next time. For alarms that work with the app closed, add them to your phone calendar.</span></div>
    <div class="btn-row" style="margin-top:12px"><button class="btn" data-ics>${icon('download')} Add to calendar</button><button class="btn primary" data-close>Done</button></div>`;
  };
  const s = sheet({ title: 'Reminders and planned days', wide: true, html: '<div id="rm"></div>', onMount: (box) => {
    const host = box.querySelector('#rm'), draw = () => { host.innerHTML = body(); };
    draw();
    box.addEventListener('click', async (e) => {
      const t = (q) => e.target.closest(q);
      if (t('[data-day]')) { const i = +t('[data-day]').dataset.day, cur = plannedDays(state), next = cur.includes(i) ? cur.filter((d) => d !== i) : [...cur, i].sort(); if (!next.length) return toast('Keep at least one training day', 'err'); setReminders({ days: next }); return draw(); }
      if (t('[data-rt]')) {
        const k = t('[data-rt]').dataset.rt, on = !state.reminders[k];
        if (k === 'enabled' && on && 'Notification' in window && Notification.permission === 'default') { try { await Notification.requestPermission(); } catch { /* ignore */ } }
        setReminders({ [k]: on }); if (k === 'enabled' && on) toast(Notification?.permission === 'granted' ? 'Reminders on' : 'Reminders on. They will show inside the app.'); return draw();
      }
      if (t('[data-ics]')) { download('repwise-training.ics', buildICS(state)); return toast('Calendar file downloaded. Open it to add your training days.'); }
    });
    box.addEventListener('change', (e) => {
      const m = { 'rt-time': 'time', 'rt-up': 'upcomingTime', 'rt-st': 'summaryTime', 'rt-sd': 'summaryDay' }[e.target.id]; if (!m) return;
      if (e.target.type === 'time' && !e.target.value) return; setReminders({ [m]: e.target.id === 'rt-sd' ? +e.target.value : e.target.value }); draw(); checkReminders();
    });
  } });
  s.done.then(() => onChange?.());
}

const ICON = { milestone: 'trophy', level: 'bolt', challenge: 'target', reminder: 'timer', summary: 'chart', programme: 'dumbbell', info: 'info' };
export function inboxHTML() {
  const n = state.inbox;
  return n.length ? `<div class="list">${n.slice(0, 20).map((x) => `<div class="li ${x.read ? '' : 'unread'}"><div class="row" style="gap:10px;align-items:flex-start">${icon(ICON[x.kind] || 'info')}<div><div class="t">${esc(x.title)}</div><div class="s">${esc(x.body)}${x.body ? ' · ' : ''}${esc(new Date(x.t).toLocaleDateString('en', { day: 'numeric', month: 'short' }))}</div></div></div><button class="btn small ghost" data-dis="${esc(x.id)}" aria-label="Dismiss ${esc(x.title)}">${icon('x')}</button></div>`).join('')}</div>` : '<p class="mut">No notices yet. Milestones, levels and reminders will appear here.</p>';
}
export function openInbox(onChange) {
  const s = sheet({ title: 'Notices', html: `<div id="ib">${inboxHTML()}</div><div class="btn-row" style="margin-top:12px">${state.inbox.length ? '<button class="btn ghost" data-clear>Clear all</button>' : ''}<button class="btn primary" data-close>Close</button></div>`, onMount: (box) => {
    markNoticesRead();
    box.addEventListener('click', (e) => { const d = e.target.closest('[data-dis]'); if (d) { dismissNotice(d.dataset.dis); box.querySelector('#ib').innerHTML = inboxHTML(); } if (e.target.closest('[data-clear]')) { clearInbox(); box.querySelector('#ib').innerHTML = inboxHTML(); e.target.closest('[data-clear]').remove(); } });
  } });
  s.done.then(() => onChange?.());
}
