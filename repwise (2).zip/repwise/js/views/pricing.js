import { state, mutate, isPro } from '../store.js';
import { CONFIG } from '../config.js';
import { billing } from '../services.js';
import { esc } from '../util.js';
import { icon, toast, seg } from '../ui.js';

export const title = 'Plans';
export const FREE_FEATURES = ['Basic workout generation', 'Workout tracking with rest timer', 'Basic progressive overload', 'Last 30 days of workout history', 'Basic progress dashboard', 'Exercise library and achievements'];
export const PRO_FEATURES = ['Everything in Free', 'Advanced workout personalisation', 'Custom training programmes and editor', 'Detailed strength analytics', 'Unlimited workout history', 'Advanced progression recommendations', 'Advanced performance insights', 'Weekly progress reports'];

export default function pricing(root) {
  let interval = 'yearly';
  const { symbol, monthly, yearly } = CONFIG.PRICING;
  const save = Math.round((1 - yearly / (monthly * 12)) * 100);
  const draw = () => {
    const pro = isPro(), live = billing.live;
    root.innerHTML = `<div class="page-h" style="text-align:center"><h1>Train free. Go further with Pro.</h1><p>The Free plan is a complete strength tracker. Pro adds deeper analytics and personalisation.</p></div>
      <div class="row" style="justify-content:center;margin-bottom:20px">${seg('interval', [['monthly', 'Monthly'], ['yearly', `Yearly · save ${save}%`]], interval)}</div>
      <div class="plans"><section class="card plan"><div><h2 style="font-size:20px">Free</h2><p class="mut">Everything you need to train and progress.</p></div><div class="price">${symbol}0<small> forever</small></div><ul>${FREE_FEATURES.map((f) => `<li>${icon('check')}<span>${esc(f)}</span></li>`).join('')}</ul><button class="btn block" disabled>${pro ? 'Included' : 'Your current plan'}</button></section>
      <section class="card plan pro"><div><h2 style="font-size:20px">Repwise Pro <span class="pro-badge">Pro</span></h2><p class="mut">Advanced tools for lifters who want every edge.</p></div><div class="price">${symbol}${interval === 'yearly' ? (yearly / 12).toFixed(2) : monthly.toFixed(2)}<small> / month${interval === 'yearly' ? `, billed ${symbol}${yearly.toFixed(2)} yearly` : ''}</small></div><ul>${PRO_FEATURES.map((f) => `<li>${icon('check')}<span>${esc(f)}</span></li>`).join('')}</ul>
      ${live ? `<button class="btn primary block" data-buy>Upgrade to Pro</button>` : pro ? `<button class="btn block" data-off>Turn off Pro preview</button>` : `<button class="btn primary block" data-preview>Preview Pro on this device</button>`}</section></div>
      <p class="billing-note">${live ? 'Cancel any time.' : 'Payments are not live yet, so nothing can be purchased and no card details are collected. Pro can be previewed on this device for free. Final pricing may change at launch.'}</p>
      <p class="billing-note">Your workouts and history stay yours on every plan. Free shows the last 30 days; older workouts stay saved.</p>`;
  };
  root.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-seg]'); if (b) { interval = b.dataset.v; return draw(); }
    if (e.target.closest('[data-preview]')) { mutate((st) => { st.plan = 'pro'; }); toast('Pro preview is on'); draw(); }
    if (e.target.closest('[data-off]')) { mutate((st) => { st.plan = 'free'; }); toast('Back on the Free plan'); draw(); }
    if (e.target.closest('[data-buy]')) { try { await billing.startCheckout(interval); } catch { toast('Checkout is not available right now.', 'err'); } }
  });
  draw();
}
