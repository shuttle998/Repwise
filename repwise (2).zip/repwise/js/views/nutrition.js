// Nutrition (meals, calories, macros, saved meals) and the water tracker, with history.
import { state, subscribe, mutate, units, isPro, can, historyDays, latestWeightKg, addMeal, updateMeal, removeMeal, copyDay, saveMealTemplate, removeMealTemplate, setNutritionTargets, addWater, undoWater, setWaterSettings } from '../store.js';
import { esc, plural, dateKey, parseKey, addDays, relDay, fmtDayLong, kgToUnit, unitToKg, cmToUnit, unitToCm, lenUnit, MONTHS, DOW } from '../util.js';
import { icon, sheet, toast, confirmDialog, upgradePrompt, lockCard, empty } from '../ui.js';
import { ring, barChart } from '../charts.js';
import * as N from '../nutrition.js';
import { nutritionCSV, download } from '../report-export.js';
import { GOALS } from '../generator.js';

export const title = 'Nutrition';
let day = dateKey(), range = 7;
const TABS = [['', 'Meals'], ['water', 'Water'], ['history', 'History']];
const litres = (ml) => (ml >= 1000 ? `${+(ml / 1000).toFixed(2)} L` : `${ml} ml`);
const trainedOn = (d) => state.sessions.some((s) => s.date === d);
const numAttr = (v) => (v == null || v === '' ? '' : String(v));

export default function nutrition(root, { params }) {
  const sub = params[0] || '', today = dateKey();
  if (day > today) day = today;
  const nav = () => {
    const prev = dateKey(addDays(parseKey(day), -1)), next = dateKey(addDays(parseKey(day), 1));
    return `<div class="day-nav"><button class="icon-btn" data-day="${prev}" aria-label="Previous day">${icon('left')}</button><div style="text-align:center"><b>${esc(day === today ? 'Today' : relDay(day))}</b><div class="lbl">${esc(fmtDayLong(day))}</div></div><button class="icon-btn" data-day="${next}" aria-label="Next day" ${day >= today ? 'disabled' : ''}>${icon('right')}</button></div>`;
  };

  // ---------- meals ----------
  function meals() {
    const n = state.nutrition, list = N.dayMeals(n, day), tot = N.dayTotals(list), pr = N.dayProgress(tot, n.targets), hasT = Object.values(n.targets).some(Boolean), w = state.water;
    const kc = pr.kcal, over = kc.target && kc.value > kc.target;
    const macro = (label, r, color) => `<div class="macro"><div class="row"><span>${label}</span><span class="num">${Math.round(r.value)}${r.target ? ` / ${r.target} g` : ' g'}</span></div>${r.target ? `<div class="bar ${r.value > r.target * 1.1 ? 'over' : ''}" role="progressbar" aria-label="${label}" aria-valuemin="0" aria-valuemax="${r.target}" aria-valuenow="${Math.round(r.value)}"><i style="width:${Math.min(100, (r.value / r.target) * 100)}%"></i></div>` : ''}</div>`;
    const yest = dateKey(addDays(parseKey(day), -1)), canCopy = !list.length && (n.log[yest] || []).length;
    return `${nav()}
      <section class="card" aria-label="Daily summary"><div class="nut-ring">${ring(kc.target ? Math.min(kc.value, kc.target) : 0, kc.target || 1, { size: 104, stroke: 10, label: String(Math.round(kc.value)), sub: 'kcal' })}
        <div style="flex:1;min-width:0"><b>${kc.target ? (over ? `${Math.abs(kc.left)} kcal over` : `${kc.left} kcal left`) : plural(tot.count, 'meal') + ' logged'}</b><div class="hint">${kc.target ? `Target ${kc.target} kcal` : 'Set a target to see what is left.'}</div><button class="btn small" style="margin-top:8px" data-targets>${icon('target')} ${hasT ? 'Edit targets' : 'Set targets'}</button></div></div>
        <div style="margin-top:14px">${macro('Protein', pr.protein)}${macro('Carbs', pr.carbs)}${macro('Fat', pr.fat)}</div></section>
      ${n.saved.length ? `<section class="card" aria-label="Saved meals"><div class="card-h"><h3>Saved meals</h3><span class="lbl">Tap to add</span></div><div class="quick">${n.saved.slice(0, 8).map((m) => `<button class="btn small" data-quick="${esc(m.id)}" style="flex:0 1 auto">${icon('plus')} ${esc(m.name)} · ${m.kcal}</button>`).join('')}</div>${n.saved.length > 8 ? `<p class="hint" style="margin-top:8px">${n.saved.length - 8} more in Manage.</p>` : ''}<button class="btn small ghost" style="margin-top:8px" data-manage>Manage saved meals</button></section>` : ''}
      <section class="card" aria-label="Meals"><div class="card-h"><h3>Meals</h3><button class="btn small primary" data-add="">${icon('plus')} Add meal</button></div>
        ${list.length ? N.mealGroups(list).map((g) => `<div class="meal-sec"><div class="row sb"><b>${g.label}</b><span class="lbl">${g.kcal ? g.kcal + ' kcal' : ''}</span></div>${g.items.length ? `<div class="list">${g.items.map((m) => `<button class="li" data-edit="${esc(m.id)}" style="width:100%;text-align:left"><div><div class="t">${esc(m.name)}</div><div class="s">P ${m.p} · C ${m.c} · F ${m.f}</div></div><div class="r num">${m.kcal} kcal</div></button>`).join('')}</div>` : `<button class="btn small ghost" data-add="${g.key}">${icon('plus')} Add ${g.label.toLowerCase()}</button>`}</div>`).join('') : empty('No meals logged', 'Add what you ate, or tap a saved meal.', canCopy ? `<button class="btn" data-copy="${yest}">${icon('copy')} Copy yesterday’s meals</button>` : '')}
      </section>
      <section class="card row sb" aria-label="Water today"><div><b>Water</b><div class="hint num">${litres(N.waterDay(w, day))}${targetOf(day).ml ? ' of ' + litres(targetOf(day).ml) : ''}</div></div><div class="row" style="gap:8px"><button class="btn small" data-water="${w.bottleMl}">${icon('drop')} +${w.bottleMl} ml</button><a class="btn small ghost" href="#/nutrition/water">Open</a></div></section>
      <p class="foot-note">Calories and macros are what you enter. Repwise does not look up foods. Not medical advice.</p>`;
  }

  // ---------- water ----------
  const targetOf = (d) => { const w = state.water, kg = latestWeightKg(), tr = trainedOn(d), own = !!w.targetMl, ml = N.waterTarget(w, kg, tr); return { ml, own, kg, trained: tr, base: kg ? N.hydrationTarget(kg, false) : null }; };
  function water() {
    const w = state.water, tg = targetOf(day), ml = N.waterDay(w, day), pct = tg.ml ? ml / tg.ml : 0, entries = [...(w.log[day] || [])].reverse();
    const hist = N.waterHistory(w, today, 14), hit = tg.ml ? hist.filter((h) => h.ml >= tg.ml * 0.9).length : null, logged = hist.filter((h) => h.ml > 0);
    const q = [...new Set([150, 250, 500, w.bottleMl])].sort((a, b) => a - b);
    return `${nav()}
      <section class="card" aria-label="Water today"><div class="row" style="gap:18px"><div class="water-glass" role="img" aria-label="${Math.round(pct * 100)} percent of today’s water target"><i style="height:${Math.min(100, pct * 100)}%"></i></div>
        <div style="flex:1;min-width:0"><div class="num" style="font-size:30px;font-weight:700">${litres(ml)}</div><div class="mut">${tg.ml ? `of ${litres(tg.ml)} · ${Math.round(pct * 100)}%` : 'No target yet'}</div>
        <div class="hint" style="margin-top:6px">${tg.ml ? (tg.own ? 'Your own target.' : `Estimated from your weight (33 ml per kg)${tg.trained ? ', plus 500 ml because you trained' : ''}.`) : 'Set a target, or log a body weight to get an estimate.'}</div></div></div>
        <div class="quick" style="margin-top:16px">${q.map((v) => `<button class="btn" data-water="${v}" aria-label="Add ${v} millilitres">${icon('plus')} ${v}<span class="hint" style="margin-left:2px">ml</span></button>`).join('')}</div>
        <div class="row wrap" style="gap:8px;margin-top:10px"><button class="btn small" data-water-custom>${icon('edit')} Custom amount</button><button class="btn small ghost" data-water-undo ${entries.length ? '' : 'disabled'}>${icon('undo')} Undo last</button><button class="btn small ghost" data-water-set>${icon('target')} Target and bottle</button></div></section>
      <section class="card"><div class="card-h"><h3>Today’s log</h3><span class="lbl">${plural(entries.length, 'drink')}</span></div>${entries.length ? `<div class="list">${entries.map((e) => `<div class="li"><div><div class="t num">${e.ml} ml</div><div class="s">${e.t ? new Date(e.t).toLocaleTimeString('en', { hour: 'numeric', minute: '2-digit' }) : ''}</div></div><button class="icon-btn" data-water-del="${esc(e.id)}" aria-label="Remove ${e.ml} ml">${icon('trash')}</button></div>`).join('')}</div>` : '<p class="mut">Nothing logged for this day.</p>'}</section>
      <section class="card"><div class="card-h"><h3>Last 14 days</h3><span class="lbl">${logged.length ? `${hit != null ? `target met ${hit} of ${hist.length} days` : plural(logged.length, 'day') + ' logged'}` : ''}</span></div><div id="wchart"></div>${logged.length ? `<p class="hint" style="margin-top:8px">Average on days you logged: ${litres(Math.round(logged.reduce((a, x) => a + x.ml, 0) / logged.length))}.</p>` : ''}</section>
      <p class="foot-note">Needs vary with heat, exercise and health. If you have a condition that limits fluids, follow your clinician’s advice. Not medical advice.</p>`;
  }

  // ---------- history ----------
  function history() {
    const n = state.nutrition, pro = isPro(), days = range, cap = historyDays(), h = N.nutritionHistory(n, today, days), logged = h.filter((x) => x.logged), t = n.targets;
    const avg = (k) => (logged.length ? Math.round(logged.reduce((a, x) => a + x[k], 0) / logged.length) : null);
    const kcalHit = t.kcal ? logged.filter((x) => Math.abs(x.kcal - t.kcal) / t.kcal <= 0.1).length : null, protHit = t.protein ? logged.filter((x) => x.p >= t.protein * 0.9).length : null;
    return `<div class="seg-c" role="group" aria-label="Range" style="margin-bottom:14px">${[7, 30, 90].map((d) => `<button class="seg-b" data-range="${d}" aria-pressed="${range === d}">${d} days${d > cap && !pro ? ' ' + icon('lock') : ''}</button>`).join('')}</div>
      ${range > cap ? lockCard('Longer nutrition history', `Free shows the last ${cap} days. Pro keeps every day.`) : `${logged.length ? `<div class="grid2"><div class="stat"><span class="lbl">Avg calories</span><b>${avg('kcal')}</b><span class="sub">${plural(logged.length, 'day')} logged</span></div><div class="stat"><span class="lbl">Avg protein</span><b>${avg('p')} g</b><span class="sub">${protHit != null ? `target met ${protHit} of ${logged.length}` : 'no target set'}</span></div></div>
      <section class="card"><div class="card-h"><h3>Calories</h3><span class="lbl">${kcalHit != null ? `within 10% of target ${kcalHit} of ${logged.length} days` : 'per day'}</span></div><div id="kchart"></div></section>
      <section class="card"><div class="card-h"><h3>Protein</h3><span class="lbl">grams per day</span></div><div id="pchart"></div></section>
      <section class="card"><div class="card-h"><h3>Carbs and fat</h3><span class="lbl">average per logged day</span></div><div class="grid2"><div class="stat"><span class="lbl">Carbs</span><b>${avg('c')} g</b></div><div class="stat"><span class="lbl">Fat</span><b>${avg('f')} g</b></div></div></section>
      ${pro ? `<button class="btn small" data-export>${icon('download')} Download meals and water (CSV)</button>` : lockCard('Export nutrition', 'Pro lets you download your meals and water as a CSV.')}` : empty('No meals in this period', 'Log meals on the Meals tab and your averages and charts appear here.')}`}
      <p class="foot-note">Days with nothing logged are left out of averages, not counted as zero.</p>`;
  }

  // ---------- sheets ----------
  const field = (label, name, val, attrs = '') => `<label class="field"><span class="lbl">${label}</span><input class="input" name="${name}" value="${esc(numAttr(val))}" ${attrs}></label>`;
  function mealSheet(m, slot) {
    const v = m || { name: '', meal: slot || N.mealForHour(new Date().getHours()), kcal: '', p: '', c: '', f: '' };
    sheet({ title: m ? 'Edit meal' : 'Add meal', wide: true, html: `<form id="mf" class="stack" novalidate>
      ${field('Name', 'name', v.name, 'maxlength="60" required data-autofocus')}
      <label class="field"><span class="lbl">Meal</span><select class="input" name="meal">${Object.entries(N.MEALS).map(([k, l]) => `<option value="${k}" ${k === v.meal ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
      <div class="grid2">${field('Calories', 'kcal', v.kcal, 'inputmode="numeric" placeholder="auto"')}${field('Protein (g)', 'p', v.p || '', 'inputmode="decimal"')}${field('Carbs (g)', 'c', v.c || '', 'inputmode="decimal"')}${field('Fat (g)', 'f', v.f || '', 'inputmode="decimal"')}</div>
      <p class="hint" id="auto" aria-live="polite">Leave calories blank to work them out from the macros (4 / 4 / 9 per gram).</p>
      <label class="fchk fchip" style="justify-self:start"><input type="checkbox" name="save"> Save for quick add</label>
      <p class="note warn" id="merr" role="alert" hidden></p>
      <button class="btn primary block" type="submit">${m ? 'Save changes' : 'Add meal'}</button>${m ? `<button class="btn danger block" type="button" data-del>${icon('trash')} Delete meal</button>` : ''}</form>`,
      onMount: (box, close) => {
        const f = box.querySelector('#mf'), auto = box.querySelector('#auto');
        const upd = () => { const k = f.kcal.value.trim(); const p = +f.p.value || 0, c = +f.c.value || 0, fa = +f.f.value || 0; auto.textContent = !k && (p || c || fa) ? `Calories will be ${N.kcalFromMacros(p, c, fa)} from your macros.` : 'Leave calories blank to work them out from the macros (4 / 4 / 9 per gram).'; };
        f.addEventListener('input', upd);
        f.addEventListener('submit', (e) => {
          e.preventDefault(); const d = Object.fromEntries(new FormData(f)), r = m ? updateMeal(day, m.id, d) : addMeal(day, d);
          if (r.error) { const n = box.querySelector('#merr'); n.textContent = r.error; n.hidden = false; return; }
          if (d.save) saveMealTemplate(d); close(); toast(m ? 'Meal updated' : 'Meal added');
        });
        box.querySelector('[data-del]')?.addEventListener('click', async () => { if (await confirmDialog({ title: 'Delete this meal?', text: m.name, confirm: 'Delete', danger: true })) { removeMeal(day, m.id); close(); toast('Meal deleted'); } });
      } });
  }
  function targetsSheet() {
    const t = state.nutrition.targets, c = state.nutrition.calc || {}, u = units(), lw = latestWeightKg(), goal = state.profile?.goal || 'muscle';
    sheet({ title: 'Daily targets', wide: true, html: `<form id="tf" class="stack" novalidate>
      <div class="grid2">${field('Calories', 'kcal', t.kcal, 'inputmode="numeric"')}${field('Protein (g)', 'protein', t.protein, 'inputmode="numeric"')}${field('Carbs (g)', 'carbs', t.carbs, 'inputmode="numeric"')}${field('Fat (g)', 'fat', t.fat, 'inputmode="numeric"')}</div>
      <details class="more"><summary>Estimate from my details</summary><div class="stack" style="margin-top:12px">
        <div class="grid2"><label class="field"><span class="lbl">Sex</span><select class="input" name="sex"><option value="avg" ${c.sex !== 'male' && c.sex !== 'female' ? 'selected' : ''}>Prefer not to say</option><option value="male" ${c.sex === 'male' ? 'selected' : ''}>Male</option><option value="female" ${c.sex === 'female' ? 'selected' : ''}>Female</option></select></label>${field('Age', 'age', c.age, 'inputmode="numeric"')}
        ${field(`Height (${lenUnit(u)})`, 'height', c.heightCm ? +cmToUnit(c.heightCm, u).toFixed(1) : '', 'inputmode="decimal"')}${field(`Weight (${u})`, 'weight', lw ? +kgToUnit(lw, u).toFixed(1) : '', 'inputmode="decimal"')}</div>
        <label class="field"><span class="lbl">Activity</span><select class="input" name="activity">${Object.entries(N.ACTIVITY).map(([k, [l]]) => `<option value="${k}" ${(c.activity || 'light') === k ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
        <button class="btn" type="button" data-est>Estimate for “${esc(GOALS[goal]?.n || 'my goal')}”</button><p class="hint" id="est" aria-live="polite">Uses the Mifflin-St Jeor formula and your goal. It is a starting point: adjust it using how your weight and energy respond over a few weeks.</p></div></details>
      <p class="note warn" id="terr" role="alert" hidden></p><button class="btn primary block" type="submit">Save targets</button></form>`,
      onMount: (box, close) => {
        const f = box.querySelector('#tf'), est = box.querySelector('#est');
        box.querySelector('[data-est]').addEventListener('click', () => {
          const kg = unitToKg(+f.weight.value, u), r = N.estimateTargets({ sex: f.sex.value, age: +f.age.value, heightCm: unitToCm(+f.height.value, u), weightKg: kg, activity: f.activity.value, goal });
          if (!r) { est.textContent = 'Enter your age, height and weight first.'; return; }
          f.kcal.value = r.kcal; f.protein.value = r.protein; f.carbs.value = r.carbs; f.fat.value = r.fat;
          est.textContent = `Resting energy about ${r.bmr} kcal, about ${r.tdee} kcal with your activity. Targets filled in above: you can still edit them.`;
        });
        f.addEventListener('submit', (e) => {
          e.preventDefault(); const d = Object.fromEntries(new FormData(f)), bad = ['kcal', 'protein', 'carbs', 'fat'].find((k) => d[k] !== '' && N.normTargets({ [k]: d[k] })[k] == null);
          if (bad) { const n = box.querySelector('#terr'); n.textContent = bad === 'kcal' ? 'Calories must be between 800 and 8000.' : `${bad[0].toUpperCase() + bad.slice(1)} is outside a sensible range.`; n.hidden = false; return; }
          const calc = d.age && d.height ? { sex: d.sex, age: +d.age, heightCm: unitToCm(+d.height, u), activity: d.activity } : undefined;
          setNutritionTargets(d, calc); close(); toast('Targets saved');
        });
      } });
  }
  function manageSheet() {
    sheet({ title: 'Saved meals', wide: true, html: `<div class="list">${state.nutrition.saved.map((m) => `<div class="li"><div><div class="t">${esc(m.name)}</div><div class="s">${m.kcal} kcal · P ${m.p} · C ${m.c} · F ${m.f}</div></div><button class="icon-btn" data-rm="${esc(m.id)}" aria-label="Delete ${esc(m.name)}">${icon('trash')}</button></div>`).join('') || '<p class="mut">No saved meals.</p>'}</div>`,
      onMount: (box) => box.addEventListener('click', (e) => { const b = e.target.closest('[data-rm]'); if (!b) return; removeMealTemplate(b.dataset.rm); b.closest('.li').remove(); }) });
  }
  function customWater() {
    sheet({ title: 'Add water', html: `<form id="wf" class="stack" novalidate>${field('Amount (ml)', 'ml', '', 'inputmode="numeric" placeholder="e.g. 330" data-autofocus')}<p class="note warn" id="werr" role="alert" hidden></p><button class="btn primary block" type="submit">Add</button></form>`,
      onMount: (box, close) => box.querySelector('#wf').addEventListener('submit', (e) => { e.preventDefault(); const r = addWater(day, new FormData(e.target).get('ml')); if (r.error) { const n = box.querySelector('#werr'); n.textContent = r.error; n.hidden = false; return; } close(); }) });
  }
  function waterSettings() {
    const w = state.water, u = units(), lw = latestWeightKg(), est = lw ? N.hydrationTarget(lw) : null;
    sheet({ title: 'Water target and bottle', html: `<form id="ws" class="stack" novalidate>${field('Daily target (ml)', 'target', w.targetMl, 'inputmode="numeric" placeholder="blank = estimate from weight"')}
      <p class="hint">${est ? `Estimate for your last logged weight: ${est} ml (33 ml per kg), plus 500 ml on days you train.` : 'Log a body weight on the Progress page (Body tab) to get an estimate, or type your own target.'}</p>${field('Bottle or glass size (ml)', 'bottle', w.bottleMl, 'inputmode="numeric"')}<p class="note warn" id="serr" role="alert" hidden></p><button class="btn primary block" type="submit">Save</button></form>`,
      onMount: (box, close) => box.querySelector('#ws').addEventListener('submit', (e) => {
        e.preventDefault(); const d = Object.fromEntries(new FormData(e.target)), nt = d.target === '' ? null : +d.target, nb = +d.bottle;
        if (nt != null && !(nt >= 500 && nt <= 8000)) { const n = box.querySelector('#serr'); n.textContent = 'Target must be between 500 and 8000 ml, or blank.'; n.hidden = false; return; }
        if (!(nb >= 100 && nb <= 2000)) { const n = box.querySelector('#serr'); n.textContent = 'Bottle size must be between 100 and 2000 ml.'; n.hidden = false; return; }
        setWaterSettings({ targetMl: nt, bottleMl: nb }); close(); toast('Saved');
      }) });
  }

  // ---------- page ----------
  const draw = () => {
    root.innerHTML = `<div class="page-h"><h1>Nutrition</h1><p>Meals, macros and water, from what you log.</p></div>
      <nav class="tabs" aria-label="Nutrition sections">${TABS.map(([k, l]) => `<a href="#/nutrition${k ? '/' + k : ''}" ${k === sub ? 'aria-current="page"' : ''}>${l}</a>`).join('')}</nav>
      <div class="stack">${sub === 'water' ? water() : sub === 'history' ? history() : meals()}</div>`;
    if (sub === 'water') { const h = root.querySelector('#wchart'), hist = N.waterHistory(state.water, today, 14), tg = targetOf(today).ml; if (h) barChart(h, { items: hist.map((x) => ({ label: String(parseKey(x.date).getDate()), value: x.ml, title: relDay(x.date), sub: litres(x.ml), hi: x.date === today })), yFmt: (v) => (v >= 1000 ? +(v / 1000).toFixed(1) + 'L' : v), height: 170, aria: 'Water per day, last 14 days', ref: tg ? { value: tg, label: 'target' } : null, minLabelGap: 22 }); }
    if (sub === 'history' && range <= historyDays()) {
      const h = N.nutritionHistory(state.nutrition, today, range), t = state.nutrition.targets, items = (k) => h.map((x) => ({ label: range > 30 ? (parseKey(x.date).getDate() === 1 ? MONTHS[parseKey(x.date).getMonth()] : '') : String(parseKey(x.date).getDate()), value: Math.round(x[k]), title: relDay(x.date), sub: x.logged ? `${Math.round(x[k])}` : 'Not logged', hi: x.date === today }));
      const kc = root.querySelector('#kchart'), pc = root.querySelector('#pchart');
      if (kc) barChart(kc, { items: items('kcal'), height: 170, aria: `Calories per day, last ${range} days`, ref: t.kcal ? { value: t.kcal, label: 'target' } : null, minLabelGap: 22 });
      if (pc) barChart(pc, { items: items('p'), height: 150, aria: `Protein per day, last ${range} days`, ref: t.protein ? { value: t.protein, label: 'target' } : null, minLabelGap: 22 });
    }
  };
  root.addEventListener('click', async (e) => {
    const c = (s) => e.target.closest(s);
    if (c('[data-day]') && !c('[data-day]').disabled) { day = c('[data-day]').dataset.day; return draw(); }
    if (c('[data-add]')) return mealSheet(null, c('[data-add]').dataset.add || undefined);
    if (c('[data-edit]')) { const m = N.dayMeals(state.nutrition, day).find((x) => x.id === c('[data-edit]').dataset.edit); return m && mealSheet(m); }
    if (c('[data-quick]')) { const m = state.nutrition.saved.find((x) => x.id === c('[data-quick]').dataset.quick); if (m) { addMeal(day, { ...m, meal: N.mealForHour(new Date().getHours()) }); toast(`${m.name} added`); } return; }
    if (c('[data-manage]')) return manageSheet();
    if (c('[data-copy]')) { const k = copyDay(c('[data-copy]').dataset.copy, day); return toast(k ? `Copied ${plural(k, 'meal')}` : 'Nothing to copy'); }
    if (c('[data-targets]')) return targetsSheet();
    if (c('[data-water]')) { const r = addWater(day, +c('[data-water]').dataset.water); if (r.error) toast(r.error, 'err'); return; }
    if (c('[data-water-custom]')) return customWater();
    if (c('[data-water-undo]')) return undoWater(day);
    if (c('[data-water-set]')) return waterSettings();
    if (c('[data-water-del]')) { const id = c('[data-water-del]').dataset.waterDel; return mutate((st) => { const l = (st.water.log[day] || []).filter((x) => x.id !== id); if (l.length) st.water.log[day] = l; else delete st.water.log[day]; }); }
    if (c('[data-range]')) { range = +c('[data-range]').dataset.range; return draw(); }
    if (c('[data-export]')) { if (!can('reportExport')) return upgradePrompt('Exporting nutrition'); const ds = N.dateRange(today, range); download(`repwise-nutrition-${today}.csv`, nutritionCSV(state.nutrition, state.water, ds)); toast('CSV downloaded'); }
  });
  draw();
  return subscribe(() => { if (root.isConnected) draw(); });
}
