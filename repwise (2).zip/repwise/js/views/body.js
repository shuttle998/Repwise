// Body measurements and optional private progress photos.
import { state, mutate, units, uid } from '../store.js';
import { esc, dateKey, parseKey, fmtDayLong, fmtDay, kgToUnit, unitToKg, cmToUnit, unitToCm, lenUnit, plural } from '../util.js';
import { icon, empty, toast, sheet, confirmDialog, seg } from '../ui.js';
import { lineChart } from '../charts.js';
import { photosAvailable, listPhotos, addPhoto, deletePhoto, clearPhotos } from '../photos.js';

const METRICS = [['weight', 'Body weight'], ['chest', 'Chest'], ['waist', 'Waist'], ['shoulders', 'Shoulders'], ['arms', 'Arms'], ['thighs', 'Thighs'], ['hips', 'Hips']];
const LABEL = Object.fromEntries(METRICS);
const RANGES = [[30, '30 days'], [90, '90 days'], [365, '1 year'], ['all', 'All']];
let metric = 'weight', range = 90;

export default function body(pane) {
  const u = units(), lu = lenUnit(u), urls = [];
  const show = (k, v) => (k === 'weight' ? `${(+kgToUnit(v, u).toFixed(1))} ${u}` : `${+cmToUnit(v, u).toFixed(1)} ${lu}`);
  const entries = () => [...state.body.entries].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  let cmpA = null, cmpB = null, photos = null, photoErr = null, editing = null;

  const draw = () => {
    const all = entries(), today = dateKey();
    const cut = range === 'all' ? '0000-00-00' : dateKey(new Date(parseKey(today).getTime() - (range - 1) * 864e5));
    const inRange = all.filter((e) => e.date >= cut), pts = inRange.filter((e) => e[metric] > 0);
    const ed = editing && all.find((e) => e.id === editing);
    const A = all.find((e) => e.id === cmpA) || inRange[0] || null, B = all.find((e) => e.id === cmpB) || inRange[inRange.length - 1] || null;
    pane.innerHTML = `<div class="stack">
      <section class="card"><div class="card-h"><h3>${ed ? 'Edit entry' : 'Log measurements'}</h3></div>
        <form id="bf" novalidate><div class="grid-fit" style="margin-bottom:12px">
          <label class="fld"><span class="lbl">Date</span><input class="input" type="date" name="date" max="${today}" value="${ed ? ed.date : today}" required></label>
          ${METRICS.map(([k, l]) => `<label class="fld"><span class="lbl">${l} (${k === 'weight' ? u : lu})</span><input class="input" inputmode="decimal" autocomplete="off" name="${k}" placeholder="optional" value="${ed && ed[k] ? +(k === 'weight' ? kgToUnit(ed[k], u) : cmToUnit(ed[k], u)).toFixed(1) : ''}"></label>`).join('')}
        </div><p class="hint" id="bf-err" role="alert" style="color:var(--bad,#ff6b6b);min-height:1.2em"></p>
        <div class="row wrap" style="gap:8px"><button class="btn primary">${ed ? 'Save changes' : 'Save entry'}</button>${ed ? '<button type="button" class="btn ghost" data-cancel>Cancel</button>' : ''}</div>
        <p class="hint" style="margin-top:8px">Fill in whatever you measured. Saving a date that already has an entry updates it.</p></form></section>

      <section class="card"><div class="card-h"><h3>Trend</h3><span class="lbl">${esc(LABEL[metric])}</span></div>
        <div class="row wrap sb" style="gap:10px;margin-bottom:12px"><select class="input" id="metric" aria-label="Measurement" style="max-width:200px;min-height:40px">${METRICS.map(([k, l]) => `<option value="${k}" ${k === metric ? 'selected' : ''}>${l}</option>`).join('')}</select>${seg('brange', RANGES, range)}</div>
        ${!all.length ? empty('No measurements yet', 'Log your first entry above and a chart appears here. Nothing is shown until you add real values.') : pts.length ? '<div id="bc"></div><p class="hint" id="bnote" style="margin-top:8px"></p>' : empty(`No ${LABEL[metric].toLowerCase()} entries in this range`, 'Choose a longer range, or log a value for it.')}</section>

      <section class="card"><div class="card-h"><h3>Compare two dates</h3></div>
        ${all.length >= 2 ? `<div class="row wrap" style="gap:10px;margin-bottom:12px"><label class="fld"><span class="lbl">From</span><select class="input" id="ca" style="min-height:40px">${all.map((e) => `<option value="${e.id}" ${A && e.id === A.id ? 'selected' : ''}>${esc(fmtDayLong(e.date))}</option>`).join('')}</select></label><label class="fld"><span class="lbl">To</span><select class="input" id="cb" style="min-height:40px">${all.map((e) => `<option value="${e.id}" ${B && e.id === B.id ? 'selected' : ''}>${esc(fmtDayLong(e.date))}</option>`).join('')}</select></label></div>${A && B ? compareTable(A, B) : ''}` : empty('Two entries needed', 'Log measurements on two different dates to compare them.')}</section>

      <section class="card"><div class="card-h"><h3>History</h3><span class="lbl">${plural(all.length, 'entry', 'entries')}</span></div>
        ${all.length ? `<div class="list">${[...all].reverse().slice(0, 15).map((e) => `<div class="li"><div><div class="t">${esc(fmtDayLong(e.date))}</div><div class="s">${METRICS.filter(([k]) => e[k]).map(([k, l]) => `${l} ${show(k, e[k])}`).join(' · ')}</div></div><div class="row" style="gap:4px"><button class="icon-btn" data-edit="${e.id}" aria-label="Edit entry for ${esc(fmtDayLong(e.date))}">${icon('edit')}</button><button class="icon-btn" data-del="${e.id}" aria-label="Delete entry for ${esc(fmtDayLong(e.date))}">${icon('trash')}</button></div></div>`).join('')}</div>${all.length > 15 ? `<p class="hint" style="margin-top:8px">Showing the latest 15 of ${all.length}.</p>` : ''}` : '<p class="mut">Nothing logged yet.</p>'}</section>

      <section class="card" id="ph"><div class="card-h"><h3>Progress photos</h3><span class="lbl">Private</span></div>${photoBody()}</section>
    </div>`;
    const host = pane.querySelector('#bc');
    if (host && pts.length) {
      const conv = (e) => (metric === 'weight' ? kgToUnit(e[metric], u) : cmToUnit(e[metric], u)), unit = metric === 'weight' ? u : lu;
      lineChart(host, { points: pts.map((e) => ({ x: parseKey(e.date).getTime(), y: conv(e), title: fmtDayLong(e.date), sub: `${+conv(e).toFixed(1)} ${unit}` })), yFmt: (v) => String(+v.toFixed(1)), aria: `${LABEL[metric]} over time`, height: 210, yMin: 'auto' });
      const a = pts[0], b = pts[pts.length - 1];
      pane.querySelector('#bnote').textContent = pts.length > 1 ? `${show(metric, a[metric])} on ${fmtDay(a.date)} → ${show(metric, b[metric])} on ${fmtDay(b.date)} (${plural(pts.length, 'entry', 'entries')}).` : 'One entry so far. Add another to see a trend.';
    }
  };

  function compareTable(a, b) {
    const rows = METRICS.filter(([k]) => a[k] && b[k]);
    if (a.id === b.id) return '<p class="mut">Pick two different dates.</p>';
    if (!rows.length) return '<p class="mut">These two dates have no measurement in common.</p>';
    return `<div class="tbl-wrap"><table class="tbl"><thead><tr><th scope="col">Measurement</th><th scope="col">${esc(fmtDay(a.date))}</th><th scope="col">${esc(fmtDay(b.date))}</th><th scope="col">Change</th></tr></thead><tbody>${rows.map(([k, l]) => { const d = k === 'weight' ? kgToUnit(b[k] - a[k], u) : cmToUnit(b[k] - a[k], u); return `<tr><th scope="row">${l}</th><td class="num">${show(k, a[k])}</td><td class="num">${show(k, b[k])}</td><td class="num">${d > 0 ? '+' : d < 0 ? '−' : ''}${Math.abs(+d.toFixed(1))} ${k === 'weight' ? u : lu}</td></tr>`; }).join('')}</tbody></table></div>`;
  }

  // ---------- photos ----------
  function photoBody() {
    if (!photosAvailable()) return '<p class="mut">This browser cannot store photos privately, so the feature is switched off.</p>';
    const intro = '<p class="mut" style="margin-bottom:12px">Photos stay on this device only. They are never uploaded and are not part of exports or backups, so keep your own copy of any you want to keep. Deleting is permanent.</p>';
    if (photos === null) return intro + '<div class="loading" style="min-height:80px"><div class="spin" role="status" aria-label="Loading photos"></div></div>';
    const add = `<div class="row wrap" style="gap:8px;margin-bottom:12px"><label class="btn small primary" style="cursor:pointer">${icon('plus')} Add photo<input type="file" accept="image/*" id="pf" class="sr-only"></label>${photos.length >= 2 ? '<button class="btn small" data-pcmp>Compare two photos</button>' : ''}${photos.length ? '<button class="btn small danger" data-pclear>Delete all photos</button>' : ''}</div>`;
    return intro + add + (photoErr ? `<p class="hint" role="alert" style="color:var(--bad,#ff6b6b)">${esc(photoErr)}</p>` : '') + (photos.length ? `<div class="pgrid">${photos.map((p, i) => `<button class="pth" data-pview="${p.id}" aria-label="Open photo from ${esc(fmtDayLong(p.date))}"><img src="${thumb(p)}" alt="" loading="lazy"><span>${esc(fmtDay(p.date))}</span></button>`).join('')}</div>` : '<p class="mut">No photos yet. Add one to start a visual record.</p>');
  }
  const thumb = (p) => { const url = URL.createObjectURL(p.blob); urls.push(url); return url; };
  const refreshPhotos = async () => { try { photos = await listPhotos(); } catch { photos = []; photoErr = 'Could not read your photos from this device.'; } urls.splice(0).forEach((x) => URL.revokeObjectURL(x)); const s = pane.querySelector('#ph'); if (s) s.innerHTML = `<div class="card-h"><h3>Progress photos</h3><span class="lbl">Private</span></div>${photoBody()}`; };
  if (photosAvailable()) refreshPhotos();

  // ---------- events ----------
  pane.addEventListener('submit', (e) => {
    if (e.target.id !== 'bf') return; e.preventDefault();
    const f = new FormData(e.target), date = f.get('date'), err = pane.querySelector('#bf-err'), entry = {};
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date > dateKey()) { err.textContent = 'Choose a date that is today or earlier.'; return; }
    for (const [k] of METRICS) {
      const raw = String(f.get(k) || '').trim().replace(',', '.'); if (!raw) continue;
      const v = Number(raw); if (!Number.isFinite(v) || v <= 0) { err.textContent = `${LABEL[k]} must be a positive number.`; return; }
      const stored = k === 'weight' ? unitToKg(v, u) : unitToCm(v, u);
      if ((k === 'weight' && (stored < 20 || stored > 400)) || (k !== 'weight' && (stored < 10 || stored > 250))) { err.textContent = `${LABEL[k]} looks out of range. Check the number and the unit (${k === 'weight' ? u : lu}).`; return; }
      entry[k] = Math.round(stored * 100) / 100;
    }
    if (!Object.keys(entry).length) { err.textContent = 'Enter at least one measurement.'; return; }
    let updated = false;
    mutate((st) => { const ex = st.body.entries.find((x) => x.date === date || x.id === editing); if (ex) { updated = true; if (editing) { Object.keys(ex).forEach((k) => { if (k !== 'id') delete ex[k]; }); ex.date = date; Object.assign(ex, entry); } else Object.assign(ex, entry); } else st.body.entries.push({ id: uid(), date, ...entry }); }, { silent: true });
    editing = null; cmpA = cmpB = null; toast(updated ? 'Entry updated.' : 'Entry saved.'); draw();
  });
  pane.addEventListener('click', async (e) => {
    const t = (s) => e.target.closest(s);
    if (t('[data-seg="brange"]')) { range = t('[data-seg]').dataset.v === 'all' ? 'all' : +t('[data-seg]').dataset.v; return draw(); }
    if (t('[data-edit]')) { editing = t('[data-edit]').dataset.edit; draw(); return pane.querySelector('#bf').scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    if (t('[data-cancel]')) { editing = null; return draw(); }
    if (t('[data-del]')) { const id = t('[data-del]').dataset.del, en = state.body.entries.find((x) => x.id === id); if (en && await confirmDialog({ title: 'Delete this entry?', text: `The measurements for ${fmtDayLong(en.date)} will be removed. This cannot be undone.`, confirm: 'Delete', danger: true })) { mutate((st) => { st.body.entries = st.body.entries.filter((x) => x.id !== id); }, { silent: true }); cmpA = cmpB = null; if (editing === id) editing = null; toast('Entry deleted.'); draw(); } return; }
    if (t('[data-pview]')) return viewPhoto(t('[data-pview]').dataset.pview);
    if (t('[data-pcmp]')) return comparePhotos();
    if (t('[data-pclear]')) { if (await confirmDialog({ title: 'Delete all photos?', text: `All ${photos.length} photos will be permanently removed from this device.`, confirm: 'Delete all', danger: true })) { try { await clearPhotos(); toast('All photos deleted.'); } catch { toast('Could not delete the photos.', 'err'); } photoErr = null; refreshPhotos(); } }
  });
  pane.addEventListener('change', async (e) => {
    if (e.target.id === 'metric') { metric = e.target.value; return draw(); }
    if (e.target.id === 'ca') { cmpA = e.target.value; return draw(); }
    if (e.target.id === 'cb') { cmpB = e.target.value; return draw(); }
    if (e.target.id === 'pf') {
      const file = e.target.files?.[0]; e.target.value = ''; if (!file) return; photoErr = null;
      try { await addPhoto(file, dateKey()); toast('Photo saved on this device.'); } catch (err) { photoErr = err.message; }
      refreshPhotos();
    }
  });

  function viewPhoto(id) {
    const p = photos.find((x) => x.id === id); if (!p) return; const url = URL.createObjectURL(p.blob);
    sheet({ title: fmtDayLong(p.date), wide: true, html: `<img src="${url}" alt="Progress photo from ${esc(fmtDayLong(p.date))}" style="width:100%;max-height:70vh;object-fit:contain;border-radius:12px;background:#000"><div class="btn-row" style="margin-top:12px"><button class="btn danger" data-d>${icon('trash')} Delete photo</button></div>`,
      onMount: (box, close) => { box.querySelector('[data-d]').addEventListener('click', async () => { if (await confirmDialog({ title: 'Delete this photo?', text: 'It will be permanently removed from this device.', confirm: 'Delete', danger: true })) { try { await deletePhoto(id); toast('Photo deleted.'); } catch { toast('Could not delete the photo.', 'err'); } URL.revokeObjectURL(url); close(); refreshPhotos(); } }); } });
  }
  function comparePhotos() {
    const urlsC = [], opt = (sel) => photos.map((p, i) => `<option value="${p.id}" ${i === sel ? 'selected' : ''}>${esc(fmtDayLong(p.date))}</option>`).join('');
    const sh = sheet({ title: 'Compare photos', wide: true, html: `<div class="row" style="gap:8px;margin-bottom:12px"><label class="fld" style="flex:1"><span class="lbl">Before</span><select class="input" id="pa">${opt(photos.length - 1)}</select></label><label class="fld" style="flex:1"><span class="lbl">After</span><select class="input" id="pb">${opt(0)}</select></label></div><div class="pcmp" id="pcv"></div>`,
      onMount: (box) => { const go = () => { urlsC.splice(0).forEach((x) => URL.revokeObjectURL(x)); box.querySelector('#pcv').innerHTML = ['#pa', '#pb'].map((s) => { const p = photos.find((x) => x.id === box.querySelector(s).value), url = URL.createObjectURL(p.blob); urlsC.push(url); return `<figure><img src="${url}" alt="Photo from ${esc(fmtDayLong(p.date))}"><figcaption>${esc(fmtDayLong(p.date))}</figcaption></figure>`; }).join(''); }; box.querySelectorAll('select').forEach((s) => s.addEventListener('change', go)); go(); } });
    sh.done.then(() => urlsC.forEach((x) => URL.revokeObjectURL(x)));
  }

  draw();
  return () => urls.forEach((x) => URL.revokeObjectURL(x));
}
