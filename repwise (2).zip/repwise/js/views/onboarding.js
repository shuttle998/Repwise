import { mutate, state, can, setExtras } from '../store.js';
import { esc } from '../util.js';
import { GOALS, GOAL_ORDER, GOAL_NAME, LEVEL, LEVEL_HINT, STYLE, SPLITS, SPLIT_ORDER, RECOVERY, EQUIPMENT, GENDER, BUILD, FOCUS_MUSCLES, DURATION_BANDS, MIN_DURATION, MAX_DURATION, MUSCLE_SLOTS, generateProgram, explainProgram, estMinutes, sessionsFor, normProfile, equipmentOf, volumeReport, VOLUME_RANGE } from '../generator.js';
import { LIMITS, BY_ID } from '../exercises.js';
import { startWorkout } from '../workout-logic.js';
import { icon } from '../ui.js';
import { configured as cloudOn, signedIn } from '../cloud.js';
import { openAuth } from './account-ui.js';
import { bodyMapHTML, bindBodyMap } from '../bodymap.js';

export const title = 'Set up';
const ALL_STEPS = ['name', 'gender', 'level', 'pref', 'goal', 'focus', 'gear', 'duration', 'days', 'prefs', 'plan'];

const group = (key, entries, { cls = '', multi = false, cur }) => `<div class="opts ${cls}${multi ? ' multi' : ''}" data-k="${key}" ${multi ? 'role="group"' : 'role="radiogroup"'}>${entries.map(([v, t, h]) => `<button type="button" class="opt" data-v="${esc(v)}" aria-pressed="${multi ? cur.includes(v) : String(cur) === String(v)}"><span>${esc(t)}${h ? `<small>${esc(h)}</small>` : ''}</span><i></i></button>`).join('')}</div>`;
const split = (s) => s.split('|');
const MUSCLE_CHOICES = Object.keys(MUSCLE_SLOTS);

export default function onboarding(root, { go }) {
  const d = { name: '', gender: '', level: 0, pref: 'smart', goal: 'muscle', goals2: [], focusMuscles: [], equipment: [], duration: 60, customDur: false, days: 3, style: 'balanced', limits: [], split: 'auto', params: {}, customDays: [] };
  let step = 0, result = null, err = '';
  const steps = () => ALL_STEPS.filter((s) => s !== 'plan' || d.pref !== 'guided');
  const cur = () => steps()[step];

  const splitPreview = () => { const s = sessionsFor(normProfile({ ...d, equipment: d.equipment })); return `Your week: ${s.map((x) => esc(x.n)).join(', ')}.`; };
  const durText = () => (d.duration > 90 ? 'Very long sessions are capped at a realistic number of exercises, so they may finish sooner. You can use the cardio and cool-down options on the Train tab to fill the time.' : d.duration < 30 ? 'Short sessions keep to the most important exercises.' : '');
  const customDays = () => Array.from({ length: d.days }, (_, i) => d.customDays[i] || { name: `Day ${i + 1}`, muscles: [] });

  const body = () => {
    switch (cur()) {
      case 'name': return `${cloudOn() && !signedIn() ? '<p class="hint" style="margin-bottom:12px">Already use Repwise on another device? <button type="button" class="link" data-signin style="background:none;border:0;font:inherit;cursor:pointer">Sign in</button> to bring your data here.</p>' : ''}<h1>Let's set up your training</h1><p class="lead">A few quick questions and your programme is ready. You can change everything later.</p><div class="field"><label for="nm">What should we call you?</label><input class="input" id="nm" maxlength="30" autocomplete="given-name" placeholder="Your first name" value="${esc(d.name)}" data-autofocus></div>`;
      case 'gender': return `<h1>About you</h1><p class="lead">Optional. You can skip this.</p>${group('gender', Object.entries(GENDER), { cur: d.gender })}<p class="hint" style="margin-top:12px">We keep this as background information only. It does not decide which exercises you get.</p>`;
      case 'level': return `<h1>How experienced are you?</h1><p class="lead">Be honest. Starting light is how you progress fastest.</p>${group('level', Object.entries(LEVEL).map(([k, v]) => [k, v, LEVEL_HINT[k]]), { cur: d.level })}`;
      case 'pref': return `<h1>How do you want to train?</h1><p class="lead">Pick how much you want to decide yourself.</p>${group('pref', Object.entries(BUILD).map(([k, v]) => [k, v[0], v[1]]), { cur: d.pref })}`;
      case 'goal': {
        const others = GOAL_ORDER.filter((g) => g !== d.goal);
        return `<h1>What is your main goal?</h1><p class="lead">This sets your rep ranges, rest times and how we progress you.</p>${group('goal', GOAL_ORDER.map((k) => [k, GOAL_NAME[k] || GOALS[k].n, GOALS[k].h]), { cur: d.goal })}
        <div class="field" style="margin-top:20px"><span class="lbl">Anything else you want? (optional, up to 2)</span>${group('goals2', others.map((k) => [k, GOAL_NAME[k] || GOALS[k].n]), { cls: 'c2', multi: true, cur: d.goals2 })}</div>`;
      }
      case 'focus': return `<h1>Any area you want to build up?</h1><p class="lead">Optional. Tap the areas you want extra work on. Everything else is still trained.</p><div id="bmhost">${bodyMapHTML({ mode: 'select', selected: d.focusMuscles })}</div><p class="hint" id="bmsel" aria-live="polite" style="text-align:center;margin:8px 0 16px">${d.focusMuscles.length ? 'Selected: ' + esc(d.focusMuscles.join(', ')) : 'Nothing selected. Skip to train everything evenly.'}</p><span class="lbl">Or pick from the list</span>${group('focusMuscles', Object.keys(FOCUS_MUSCLES).map((k) => [k, k]), { cls: 'c2', multi: true, cur: d.focusMuscles })}<p class="hint" style="margin-top:12px">The body shapes are simplified. Abs is the front of the stomach and Core is the sides.</p>`;
      case 'gear': return `<h1>What equipment do you have?</h1><p class="lead">Pick everything you can use. We only choose exercises you can actually do.</p>${group('equipment', Object.entries(EQUIPMENT).map(([k, v]) => [k, v.n, v.h]), { multi: true, cur: d.equipment })}${err ? `<p class="note warn" role="alert" style="margin-top:12px">${esc(err)}</p>` : ''}`;
      case 'duration': {
        const onBand = DURATION_BANDS.find((b) => b.v === d.duration && !d.customDur);
        return `<h1>How long is each workout?</h1><p class="lead">Pick a range, or enter your own length.</p>${group('dband', [...DURATION_BANDS.map((b) => [b.v, b.t]), ['custom', 'Custom length']], { cls: 'c2', cur: d.customDur ? 'custom' : onBand ? onBand.v : '' })}
        ${d.customDur ? `<div class="field" style="margin-top:12px"><label for="cdur">Minutes (${MIN_DURATION} to ${MAX_DURATION})</label><input class="input" id="cdur" type="number" inputmode="numeric" min="${MIN_DURATION}" max="${MAX_DURATION}" value="${d.duration || ''}"></div>` : ''}${err ? `<p class="note warn" role="alert" style="margin-top:12px">${esc(err)}</p>` : ''}<p class="hint" id="durnote" style="margin-top:12px">${esc(durText())}</p>`;
      }
      case 'days': return `<h1>How many days can you train?</h1><p class="lead">Pick what you can keep up every week, not what sounds impressive.</p>${group('days', [2, 3, 4, 5, 6, 7].map((n) => [n, String(n)]), { cls: 'c4', cur: d.days })}<p class="hint" id="splitprev" style="margin-top:14px">${splitPreview()}</p><p class="hint" id="recov">${esc(RECOVERY[d.days])}${d.level === 0 && d.days >= 5 ? ' Five or more days is a lot when you are starting out.' : ''}</p>`;
      case 'prefs': return `<h1>A few preferences</h1><p class="lead">Optional, but they make the plan fit you.</p>
        <div class="field"><span class="lbl">Style</span>${group('style', Object.entries(STYLE).map(([k, v]) => [k, ...split(v)]), { cur: d.style })}</div>
        <div class="field"><span class="lbl">Anything to work around? (optional)</span>${group('limits', Object.entries(LIMITS).map(([k, v]) => [k, v]), { cls: 'c2', multi: true, cur: d.limits })}<p class="hint">We avoid exercises that load these areas heavily. This is not medical advice.</p></div>`;
      case 'plan': return d.pref === 'custom' ? customBody() : smartBody();
    }
  };

  const smartBody = () => {
    const pr = d.params;
    return `<h1>Choose your split</h1><p class="lead">A split is how your week is divided between muscle groups. Not sure? Keep the recommendation.</p>
      ${group('split', SPLIT_ORDER.map((k) => { const s = SPLITS[k], fit = d.days >= s.days[0] && d.days <= s.days[1]; return [k, s.n + (k === 'auto' ? '' : fit ? '' : ' (best with ' + s.days[0] + ' to ' + s.days[1] + ' days)'), s.h + (s.who ? ' ' + s.who : '')]; }).filter(([k]) => k !== 'custom'), { cur: d.split })}
      <details class="fine" style="margin-top:18px" ${d.level === 2 ? 'open' : ''}><summary><b>Fine-tune sets, reps and rest</b> (optional)</summary>
        <p class="hint" style="margin:8px 0 12px">Leave blank to use the defaults for your goal. Your numbers apply to every weighted exercise.</p>
        <div class="grid2"><label class="field"><span class="lbl">Sets per exercise (1 to 8)</span><input class="input" type="number" inputmode="numeric" min="1" max="8" data-par="sets" value="${pr.sets || ''}" placeholder="Default"></label>
        <label class="field"><span class="lbl">Rest in seconds (15 to 300)</span><input class="input" type="number" inputmode="numeric" min="15" max="300" data-par="restSec" value="${pr.restSec || ''}" placeholder="Default"></label></div>
        <div class="grid2"><label class="field"><span class="lbl">Fewest reps</span><input class="input" type="number" inputmode="numeric" min="1" max="40" data-par="repLo" value="${pr.repLo || ''}" placeholder="Default"></label>
        <label class="field"><span class="lbl">Most reps</span><input class="input" type="number" inputmode="numeric" min="1" max="60" data-par="repHi" value="${pr.repHi || ''}" placeholder="Default"></label></div>
        ${err ? `<p class="note warn" role="alert">${esc(err)}</p>` : ''}</details>`;
  };
  const customBody = () => `<h1>Plan your days</h1><p class="lead">Name each day and pick the muscles it trains. Repwise can fill each day with exercises for you, or you can start empty and add your own.</p>
    ${customDays().map((c, i) => `<div class="card flat" style="margin-bottom:12px;padding:14px"><label class="field"><span class="lbl">Day ${i + 1} name</span><input class="input" data-cd-name="${i}" maxlength="40" value="${esc(c.name)}"></label>
      <span class="lbl">Muscles</span><div class="filters" role="group" aria-label="Day ${i + 1} muscles">${MUSCLE_CHOICES.map((m) => `<label class="fchip fchk"><input type="checkbox" data-cd="${i}" value="${m}" ${c.muscles.includes(m) ? 'checked' : ''}><span>${m}</span></label>`).join('')}</div></div>`).join('')}
    ${can('customProgramme') ? '' : '<p class="hint">Starting with empty days and adding your own exercises is a Pro feature (preview it from the Plan page). Filling the days for you is free.</p>'}`;

  const draw = () => {
    if (result) return drawResult();
    const n = steps().length, last = step === n - 1, custom = last && cur() === 'plan' && d.pref === 'custom';
    root.innerHTML = `<div class="ob"><div class="ob-top">${step > 0 ? `<button class="icon-btn" data-back aria-label="Back">${icon('left')}</button>` : ''}<div class="ob-bar" role="progressbar" aria-valuemin="1" aria-valuemax="${n}" aria-valuenow="${step + 1}" aria-label="Setup progress"><i style="width:${((step + 1) / n) * 100}%"></i></div><span class="lbl">${step + 1} of ${n}</span></div><div class="ob-step">${body()}</div>
      <div class="ob-foot">${custom ? `${can('customProgramme') ? '<button class="btn" data-build="empty">Start with empty days</button>' : ''}<button class="btn primary" data-build="fill">Fill my days</button>` : `<button class="btn primary" data-next>${last ? (cur() === 'plan' ? 'Generate my programme' : 'Build my programme') : 'Continue'}</button>`}</div></div>`;
    root.querySelector('[data-autofocus]')?.focus({ preventScroll: true });
  };

  const finish = (mode = 'fill') => {
    const profile = normProfile({ ...d, split: d.pref === 'custom' ? 'custom' : d.split, customDays: customDays(), name: d.name.trim(), avoid: [], favour: [], createdAt: new Date().toISOString() });
    delete profile.customDur;
    let program = generateProgram(profile);
    if (mode === 'empty') program = { ...program, custom: true, sessions: program.sessions.map((s) => ({ ...s, items: [] })) };
    const wantsCardio = [profile.goal, ...profile.goals2].some((g) => ['endurance', 'fat', 'general'].includes(g));
    const cardio = wantsCardio && !state.settings.extras.cardio && mode !== 'empty';
    mutate((st) => { st.profile = profile; st.program = program; st.cursor = 0; st.working = {}; st.ui.nameAsked = true; st.ui.welcomed = true; if (mode === 'empty') st.ui.editNext = true; });
    if (cardio) setExtras({ cardio: 10, cardioId: equipmentOf(profile).includes('gym') ? 'treadmill' : 'march-in-place' });
    result = { profile, program, mode, cardio, why: mode === 'empty' ? null : explainProgram(program, profile) };
    drawResult(); window.scrollTo(0, 0);
  };
  const drawResult = () => {
    const { profile, program, why, mode, cardio } = result, empty = mode === 'empty';
    const vol = !empty && ['muscle', 'gain', 'tone'].includes(profile.goal) || profile.split === 'hypertrophy' ? volumeReport(program) : null;
    root.innerHTML = `<div class="ob"><div class="ob-step"><span class="chip ok">${icon('check')} ${empty ? 'Your days are ready' : 'Your programme is ready'}</span><h1 style="margin-top:14px">${profile.name ? esc(profile.name) + ', here is your plan' : 'Here is your plan'}</h1>
      <p class="lead">${empty ? 'Open the editor to add exercises to each day.' : `${esc(why.headline)}, about ${profile.duration} minutes each. ${esc(GOALS[profile.goal].h)}.`}</p>
      <div class="card flat">${program.sessions.map((s) => `<div class="sess"><h3><span>${esc(s.name)}</span><span class="mut num" style="font-size:13px">${s.items.length ? `~${estMinutes(s.items) + 5} min` : 'Empty'}</span></h3><ul>${s.items.map((it) => `<li><span>${esc(BY_ID[it.exId].name)}</span><span class="num">${it.sets} × ${it.repLo === it.repHi ? it.repLo : it.repLo + '–' + it.repHi}${BY_ID[it.exId].unit === 'sec' ? 's' : BY_ID[it.exId].unit === 'min' ? ' min' : ''}</span></li>`).join('')}</ul></div>`).join('')}</div>
      ${why ? `<h2 class="sec">Why this plan suits you</h2><div class="card why">${why.points.map((p) => `<div><h3>${esc(p.title)}</h3><p>${esc(p.text)}</p></div>`).join('')}</div>` : ''}
      ${vol ? `<h2 class="sec">Weekly sets per muscle</h2><div class="card pad"><p class="hint" style="margin-bottom:8px">A common guide for muscle growth is about ${VOLUME_RANGE.lo} to ${VOLUME_RANGE.hi} hard sets per muscle each week. It is a guide, not a rule. Edit the plan or change your sets if a muscle is short.</p><ul class="vol">${vol.map((v) => `<li data-vol="${v.status}"><span>${esc(v.muscle)}</span><span class="num">${v.sets} sets, ${v.freq}×/week${v.status === 'low' ? ' · low' : v.status === 'high' ? ' · high' : ''}</span></li>`).join('')}</ul></div>` : ''}
      ${cardio ? '<p class="hint" style="margin-top:12px">Because of your goals, 10 minutes of cardio after lifting is switched on. You can change it in Session structure on the Train tab.</p>' : ''}
      <p class="foot-note">Not medical advice. Check with a doctor if you have a health condition. Your data stays on this device.</p></div>
      <div class="btn-row" style="margin-top:16px;gap:8px;flex-wrap:wrap"><button class="btn small" data-edit>${empty ? 'Add exercises' : 'Edit programme'}</button><button class="btn small" data-library>Browse all exercises</button></div></div>
      <div class="ob-foot"><button class="btn ghost" data-dash>Dashboard</button>${empty ? '<button class="btn primary" data-edit>Add exercises</button>' : '<button class="btn primary" data-start>Start first workout</button>'}</div></div>`;
  };

  /** Toggles a body area and updates the map, the chips and the summary line without redrawing the page. */
  const toggleFocus = (area) => {
    d.focusMuscles = d.focusMuscles.includes(area) ? d.focusMuscles.filter((x) => x !== area) : [...d.focusMuscles, area];
    const host = root.querySelector('#bmhost'); if (!host) return;
    const had = document.activeElement?.dataset?.bm; host.innerHTML = bodyMapHTML({ mode: 'select', selected: d.focusMuscles }); if (had) host.querySelector(`[data-bm="${had}"]`)?.focus({ preventScroll: true });
    root.querySelector('#bmsel').textContent = d.focusMuscles.length ? 'Selected: ' + d.focusMuscles.join(', ') : 'Nothing selected. Skip to train everything evenly.';
    root.querySelectorAll('[data-k=focusMuscles] .opt').forEach((b) => b.setAttribute('aria-pressed', d.focusMuscles.includes(b.dataset.v)));
  };
  bindBodyMap(root, toggleFocus);
  root.addEventListener('click', (e) => {
    if (e.target.closest('[data-signin]')) return void openAuth('signin', { go });
    const opt = e.target.closest('.opt');
    if (opt) {
      const g = opt.closest('.opts'), k = g.dataset.k, raw = opt.dataset.v, num = raw !== '' && !isNaN(raw);
      err = '';
      if (k === 'focusMuscles') return void toggleFocus(raw);
      if (k === 'limits') { d[k] = d[k].includes(raw) ? d[k].filter((x) => x !== raw) : [...d[k], raw]; opt.setAttribute('aria-pressed', d[k].includes(raw)); return; }
      if (k === 'goals2') { if (d.goals2.includes(raw)) d.goals2 = d.goals2.filter((x) => x !== raw); else if (d.goals2.length < 2) d.goals2 = [...d.goals2, raw]; opt.setAttribute('aria-pressed', d.goals2.includes(raw)); return; }
      if (k === 'equipment') { d.equipment = raw === 'bw' ? (d.equipment.includes('bw') ? [] : ['bw']) : d.equipment.includes(raw) ? d.equipment.filter((x) => x !== raw) : [...d.equipment.filter((x) => x !== 'bw'), raw]; g.querySelectorAll('.opt').forEach((b) => b.setAttribute('aria-pressed', d.equipment.includes(b.dataset.v))); return; }
      if (k === 'dband') { if (raw === 'custom') d.customDur = true; else { d.customDur = false; d.duration = +raw; } draw(); return; }
      if (k === 'goal') { d.goal = raw; d.goals2 = d.goals2.filter((x) => x !== raw); draw(); return; }
      d[k] = num && k !== 'split' ? +raw : raw; g.querySelectorAll('.opt').forEach((b) => b.setAttribute('aria-pressed', b === opt));
      if (k === 'days') { root.querySelector('#splitprev').innerHTML = splitPreview(); root.querySelector('#recov').textContent = RECOVERY[d.days] + (d.level === 0 && d.days >= 5 ? ' Five or more days is a lot when you are starting out.' : ''); }
      return;
    }
    if (e.target.closest('[data-back]')) { step = Math.max(0, step - 1); err = ''; draw(); }
    else if (e.target.closest('[data-next]')) next();
    else if (e.target.closest('[data-build]')) finish(e.target.closest('[data-build]').dataset.build);
    else if (e.target.closest('[data-edit]')) { mutate((st) => { st.ui.editNext = true; }); go('train'); }
    else if (e.target.closest('[data-library]')) go('library');
    else if (e.target.closest('[data-start]')) { startWorkout(0); go('workout'); }
    else if (e.target.closest('[data-dash]')) go('');
  });
  root.addEventListener('input', (e) => {
    if (e.target.id === 'cdur') { const v = Math.round(Number(e.target.value)); if (v >= MIN_DURATION && v <= MAX_DURATION) { d.duration = v; err = ''; root.querySelector('#durnote').textContent = durText(); } else d.duration = 0; }
    const par = e.target.dataset?.par; if (par) { const v = Math.round(Number(e.target.value)); if (e.target.value === '' || !(v > 0)) delete d.params[par]; else d.params[par] = v; }
    const nm = e.target.dataset?.cdName; if (nm !== undefined) { const c = customDays(); c[+nm] = { ...c[+nm], name: e.target.value }; d.customDays = c; }
  });
  root.addEventListener('change', (e) => {
    const i = e.target.dataset?.cd; if (i === undefined) return;
    const c = customDays(), cur2 = c[+i]; c[+i] = { ...cur2, muscles: e.target.checked ? [...new Set([...cur2.muscles, e.target.value])] : cur2.muscles.filter((m) => m !== e.target.value) }; d.customDays = c;
  });
  const next = () => {
    err = '';
    if (cur() === 'name') d.name = root.querySelector('#nm')?.value.trim().slice(0, 30) || '';
    if (cur() === 'gear' && !d.equipment.length) { err = 'Choose at least one option so we know what you can use.'; return draw(); }
    if (cur() === 'duration' && !(d.duration >= MIN_DURATION && d.duration <= MAX_DURATION)) { err = `Enter a length between ${MIN_DURATION} and ${MAX_DURATION} minutes.`; return draw(); }
    if (cur() === 'plan' && d.pref !== 'custom') { const p = d.params; if ((p.repLo || p.repHi) && !(p.repLo && p.repHi && p.repHi >= p.repLo)) { err = 'Enter both a fewest and a most reps value, with most at least as high as fewest. Or clear both.'; return draw(); } }
    if (step === steps().length - 1) return finish('fill');
    step++; draw(); window.scrollTo(0, 0);
  };
  root.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.id === 'nm') { e.preventDefault(); next(); } });
  draw();
}
