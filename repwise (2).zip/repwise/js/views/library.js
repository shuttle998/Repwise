import { state, units, isFav, toggleFav, saveCustom, removeCustom } from '../store.js';
import { esc, fmtW, relDay, plural } from '../util.js';
import { BY_ID, unitSuffix, MUSCLES, EQUIP, TYPES, DIFFS, TIER_RANK, lowerEquipment, available, hasLimit, LIMITS, LOCATIONS, locationOf, activeExercises, searchExercises, rankedSubstitutes, TRACKING } from '../exercises.js';
import { GOALS, prescribe } from '../generator.js';
import { icon, empty, sheet, toast, confirmDialog } from '../ui.js';
import * as A from '../analytics.js';
import { demoHTML, bindDemo } from '../media.js';
import { breathing, safety } from '../guidance.js';
import { bodyMapHTML, bindSpin } from '../bodymap.js';

export const title = 'Exercise library';
const F = { q: '', muscle: '', equip: '', type: '', diff: '', loc: '', easy: '', view: 'all', cat: '', limit: 30 };
const PAGE = 30;
const GUIDED_CAT = new Set(['stretch', 'warmup', 'activation', 'mindbody']);
/** Workout categories shown above the list. Each one is a test on an exercise's main muscle or slot. */
const CATS = [['', 'All'], ['Chest', (e) => e.pm.includes('Chest')], ['Back', (e) => e.pm.includes('Back')], ['Shoulders', (e) => e.pm.includes('Shoulders')], ['Arms', (e) => e.pm.some((m) => ['Biceps', 'Triceps', 'Forearms'].includes(m))], ['Legs', (e) => e.pm.some((m) => ['Quads', 'Hamstrings', 'Calves'].includes(m))], ['Glutes', (e) => e.pm.includes('Glutes')], ['Core', (e) => e.pm.includes('Core') && !GUIDED_CAT.has(e.slot)], ['Cardio', (e) => e.slot === 'cardio'], ['Mobility and stretching', (e) => GUIDED_CAT.has(e.slot)]];
const catTest = (k) => CATS.find((c) => c[0] === k)?.[1];
const FORM_MUSC = [...MUSCLES, 'Forearms'];
const rng = (p, ex) => `${p.sets} × ${p.repLo === p.repHi ? p.repLo : p.repLo + '–' + p.repHi}${unitSuffix(ex)}`;

const heart = (id) => `<button class="icon-btn fav" data-fav="${id}" aria-pressed="${isFav(id)}" aria-label="${isFav(id) ? 'Remove from favourites' : 'Add to favourites'}">${icon('heart')}</button>`;

/** Create / edit sheet for a custom exercise. */
export function customForm(ex, done) {
  const v = ex || { name: '', equip: 'Dumbbell', type: 'Compound', diff: 'Intermediate', pm: [], sm: [], unit: 'kg', steps: [] };
  const opts = (list, cur) => list.map((o) => `<option ${o === cur ? 'selected' : ''}>${o}</option>`).join('');
  const checks = (name, cur) => `<div class="filters" role="group" aria-label="${name === 'pm' ? 'Main muscles' : 'Secondary muscles'}">${FORM_MUSC.map((m) => `<label class="fchip fchk"><input type="checkbox" name="${name}" value="${m}" ${cur.includes(m) ? 'checked' : ''}> ${m}</label>`).join('')}</div>`;
  sheet({ title: ex ? 'Edit exercise' : 'New custom exercise', wide: true, html: `<form id="cf" class="stack" novalidate>
    <label class="field"><span class="lbl">Name</span><input class="input" name="name" maxlength="40" value="${esc(v.name)}" required data-autofocus></label>
    <div class="grid2"><label class="field"><span class="lbl">Equipment</span><select class="input" name="equip">${opts(EQUIP, v.equip)}</select></label><label class="field"><span class="lbl">Category</span><select class="input" name="type">${opts(TYPES, v.type)}</select></label>
    <label class="field"><span class="lbl">Difficulty</span><select class="input" name="diff">${opts(DIFFS, v.diff)}</select></label><label class="field"><span class="lbl">Tracked as</span><select class="input" name="unit">${Object.entries(TRACKING).map(([k, l]) => `<option value="${k}" ${k === v.unit ? 'selected' : ''}>${l}</option>`).join('')}</select></label></div>
    <div><span class="lbl">Main muscles</span>${checks('pm', v.pm)}</div><div><span class="lbl">Secondary muscles (optional)</span>${checks('sm', v.sm)}</div>
    <label class="field"><span class="lbl">Steps (optional, one per line)</span><textarea class="input" name="steps" rows="4" maxlength="1500">${esc((v.steps || []).join('\n'))}</textarea></label>
    <p class="note warn" id="cerr" role="alert" hidden></p><button class="btn primary block" type="submit">${ex ? 'Save changes' : 'Create exercise'}</button></form>`,
    onMount: (box, close) => box.querySelector('#cf').addEventListener('submit', (e) => {
      e.preventDefault(); const fd = new FormData(e.target);
      const r = saveCustom({ name: fd.get('name'), equip: fd.get('equip'), type: fd.get('type'), diff: fd.get('diff'), unit: fd.get('unit'), pm: fd.getAll('pm'), sm: fd.getAll('sm'), steps: String(fd.get('steps') || '').split('\n') }, ex?.id || null);
      if (r.error) { const n = box.querySelector('#cerr'); n.textContent = r.error; n.hidden = false; return; }
      close(); toast(ex ? 'Exercise updated' : 'Exercise created'); done?.(r.id);
    }) });
}

export default function library(root, { params, go }) {
  const id = params[0];
  if (id && BY_ID[id]) return detail(root, BY_ID[id], go);
  const chips = (key, vals, label) => `<div class="fgroup"><span class="lbl">${label}</span><div class="filters" role="group" aria-label="${label}">${['', ...vals].map((v) => `<button class="fchip" data-f="${key}" data-v="${esc(v)}" aria-pressed="${F[key] === v}">${(key === 'easy' && LIMITS[v]) || (typeof v === 'string' && LOCATIONS[v]) || v || 'All'}</button>`).join('')}</div></div>`;
  const catRow = () => `<div class="filters cats" role="group" aria-label="Workout category" style="margin-top:12px">${CATS.map(([k, v]) => `<button class="fchip" data-cat="${esc(k)}" aria-pressed="${F.cat === k}">${typeof v === 'string' ? v : k}</button>`).join('')}</div>`;
  const nF = () => ['muscle', 'equip', 'type', 'diff', 'loc', 'easy'].filter((k) => F[k]).length;
  root.innerHTML = `<div class="page-h"><div class="row sb wrap" style="gap:8px"><h1>Exercise library</h1><button class="btn small" data-new>${icon('plus')} Custom exercise</button></div><p id="sub"></p></div>
    <div class="search"><span>${icon('search')}</span><input class="input" id="q" type="search" placeholder="Try “db row”, “abs” or “rdl”" aria-label="Search exercises" value="${esc(F.q)}"></div>
 ${catRow()}
    <div class="seg-c" role="group" aria-label="Show" style="margin-top:12px">${[['all', 'All'], ['fav', 'Favourites'], ['recent', 'Recent']].map(([k, l]) => `<button class="seg-b" data-view="${k}" aria-pressed="${F.view === k}">${l}</button>`).join('')}</div>
    <details class="card flat" style="margin-top:12px;padding:6px 16px" ${nF() ? 'open' : ''}><summary style="min-height:44px;display:flex;align-items:center;cursor:pointer;font-weight:600">Filters${nF() ? ` (${nF()})` : ''}</summary><div id="filters">${chips('muscle', MUSCLES, 'Muscle group')}${chips('equip', EQUIP, 'Equipment')}${chips('loc', Object.keys(LOCATIONS), 'Training location')}${chips('type', TYPES, 'Category')}${chips('diff', DIFFS, 'Difficulty')}${chips('easy', Object.keys(LIMITS), 'Easy on your…')}<p class="hint">“Easy on” hides exercises that put notable stress on that area, based on each exercise’s joint tags. Your own custom exercises have no tags, so they are left out. It is a guide, not medical advice.</p></div></details>
    <div class="row sb" style="margin:16px 0 4px"><p class="lbl" id="count" aria-live="polite" style="margin:0"></p><button class="btn small ghost" data-clear hidden>Clear all</button></div><div class="card" id="list" style="padding:4px 18px"></div>`;
  const list = root.querySelector('#list');
  const lastDone = Object.fromEntries(A.recentExercises(state.sessions, 500).map((r) => [r.exId, r.date]));
  const matches = () => {
    let pool = activeExercises();
    if (F.view === 'fav') pool = pool.filter((e) => isFav(e.id));
    if (F.view === 'recent') pool = pool.filter((e) => lastDone[e.id]).sort((a, b) => (lastDone[a.id] < lastDone[b.id] ? 1 : -1));
    if (F.cat) pool = pool.filter(catTest(F.cat));
    pool = pool.filter((e) => (!F.muscle || e.pm.includes(F.muscle) || e.sm.includes(F.muscle)) && (!F.equip || e.equip === F.equip) && (!F.type || e.type === F.type) && (!F.diff || e.diff === F.diff) && (!F.loc || locationOf(e) === F.loc) && (!F.easy || (!e.custom && !e.stress.includes(F.easy))));
    return F.q ? searchExercises(F.q, pool) : pool;
  };
  const draw = () => {
    const m = matches(), gear = state.profile?.gear || 'gym', total = activeExercises().length;
    root.querySelector('#count').textContent = plural(m.length, 'exercise') + (m.length !== total ? ` of ${total}` : '');
    root.querySelector('#sub').textContent = `${total} exercises with technique, targets and substitutions.`;
    root.querySelector('[data-clear]').hidden = !(F.q || nF() || F.view !== 'all' || F.cat);
    const shown = m.slice(0, F.limit);
    list.innerHTML = m.length ? shown.map((e) => `<div class="ex-card" data-card="${e.id}"><div class="ex-row"><a href="#/library/${e.id}" class="grow" style="min-width:0;flex:1"><b>${esc(e.name)}</b>${e.custom ? ' <span class="chip">Custom</span>' : ''}<br><span class="mut" style="font-size:13.5px">${esc(e.pm.join(', '))} · ${esc(e.equip)} · ${esc(e.diff)}${lastDone[e.id] ? ' · last ' + esc(relDay(lastDone[e.id])) : ''}</span></a><span class="row" style="gap:4px">${available(e, gear) ? '' : '<span class="chip">Needs more equipment</span>'}<button class="icon-btn" data-peek="${e.id}" aria-expanded="false" aria-label="Quick view of ${esc(e.name)}">${icon('down')}</button>${heart(e.id)}</span></div><div class="peek" hidden></div></div>`).join('') + (m.length > shown.length ? `<div style="padding:14px 0;text-align:center"><button class="btn" data-more>Show ${Math.min(PAGE, m.length - shown.length)} more <span class="mut">(${m.length - shown.length} left)</span></button></div>` : '')
      : empty(F.view === 'fav' && !F.q && !nF() ? 'No favourites yet' : F.view === 'recent' && !F.q && !nF() ? 'Nothing logged yet' : 'No exercises match', F.view === 'fav' && !F.q && !nF() ? 'Tap the heart on any exercise to keep it here.' : F.view === 'recent' && !F.q && !nF() ? 'Exercises you have logged show up here, newest first.' : 'Try removing a filter or searching a different word.', '<button class="btn small" data-clear>Clear all</button>');
  };
  const reset = () => { Object.assign(F, { q: '', muscle: '', equip: '', type: '', diff: '', loc: '', easy: '', view: 'all', cat: '', limit: PAGE }); library(root, { params, go }); };
  if (root.__li) { root.removeEventListener('input', root.__li); root.removeEventListener('click', root.__lc); }
  root.__li = (e) => { if (e.target.id === 'q') { F.q = e.target.value; F.limit = PAGE; draw(); } };
  root.__lc = (e) => {
    const ct = e.target.closest('[data-cat]'), pk = e.target.closest('[data-peek]');
    if (ct) { F.cat = ct.dataset.cat; F.limit = PAGE; root.querySelectorAll('[data-cat]').forEach((b) => b.setAttribute('aria-pressed', b === ct)); draw(); return; }
    if (e.target.closest('[data-more]')) { F.limit += PAGE; draw(); return; }
    if (pk) { const card = pk.closest('.ex-card'), box = card.querySelector('.peek'), open = box.hidden, ex = BY_ID[pk.dataset.peek]; if (open && !box.innerHTML) box.innerHTML = `<div class="peek-in"><div class="peek-map">${bodyMapHTML({ mode: 'show', primary: ex.pm, secondary: ex.sm, spin: false })}</div><div class="peek-txt"><p><b>Targets:</b> ${esc(ex.pm.join(', '))}${ex.sm.length ? `<br><b>Assists:</b> ${esc(ex.sm.join(', '))}` : ''}</p><p class="mut">${esc(ex.steps?.[0] || '')}</p><a class="btn small primary" href="#/library/${ex.id}">Open exercise</a></div></div>`; box.hidden = !open; pk.setAttribute('aria-expanded', String(open)); pk.classList.toggle('open', open); return; }
    const c = e.target.closest('[data-f]'), v = e.target.closest('[data-view]'), h = e.target.closest('[data-fav]');
    if (c) { F[c.dataset.f] = c.dataset.v; root.querySelectorAll(`[data-f="${c.dataset.f}"]`).forEach((b) => b.setAttribute('aria-pressed', b === c)); F.limit = PAGE; draw(); }
    else if (v) { F.view = v.dataset.view; root.querySelectorAll('[data-view]').forEach((b) => b.setAttribute('aria-pressed', b === v)); F.limit = PAGE; draw(); }
    else if (h) { toggleFav(h.dataset.fav); const on = isFav(h.dataset.fav); h.setAttribute('aria-pressed', on); h.setAttribute('aria-label', on ? 'Remove from favourites' : 'Add to favourites'); if (F.view === 'fav') draw(); }
    else if (e.target.closest('[data-new]')) customForm(null, (nid) => go(`library/${nid}`));
    else if (e.target.closest('[data-clear]')) reset();
  };
  root.addEventListener('input', root.__li); root.addEventListener('click', root.__lc);
  draw();
}

function detail(root, ex, go) {
  const u = units(), p = state.profile, gear = p?.gear || 'gym';
  const rec = A.records(state.sessions).find((r) => r.exId === ex.id);
  const lower = lowerEquipment(ex).filter((e) => !e.archived), ranked = rankedSubstitutes(ex, { gear: 'gym', limits: p?.limits || [], level: p?.level ?? 1, avoid: p?.avoid || [] }).filter((r) => !lower.includes(r.ex)).slice(0, 6);
  const rx = Object.entries(GOALS).map(([k, g]) => [k, g.n, prescribe(ex, k, p?.level ?? 1, p?.style || 'balanced', true), g.restT]);
  const link = (e, why = '') => `<a class="ex-row" href="#/library/${e.id}"><span><b>${esc(e.name)}</b><br><span class="mut" style="font-size:13.5px">${esc(e.equip)} · ${esc(e.diff)}${available(e, gear) ? '' : ' · needs more equipment'}</span>${why ? `<br><span class="hint">${esc(why)}</span>` : ''}</span>${icon('right')}</a>`;
  root.innerHTML = `<a class="back" href="#/library">${icon('left')} Library</a>
    <div class="page-h" style="padding-top:4px"><div class="row sb wrap" style="gap:8px"><h1>${esc(ex.name)}</h1>${heart(ex.id)}</div><p>${ex.custom ? '<span class="chip">Custom</span> ' : ''}<span class="chip blue">${esc(ex.diff)}</span> <span class="chip">${esc(ex.equip)}</span> <span class="chip">${esc(ex.type)}</span></p></div>
    <div class="cols"><div class="stack">
      <section class="card"><div class="card-h"><h3>Demonstration</h3></div>${demoHTML(ex)}</section>
      <section class="card"><div class="card-h"><h3>How to do it</h3></div><div class="pos"><div><span class="lbl">Starting position</span><p>${esc(ex.steps[0])}</p></div>${ex.steps.length > 1 ? `<div><span class="lbl">Finishing position</span><p>${esc(ex.steps[ex.steps.length - 1])}</p></div>` : ''}</div><ol class="ol">${ex.steps.map((s) => `<li>${esc(s)}</li>`).join('')}</ol>${ex.cue ? `<p class="note" style="margin-top:14px">${icon('info')}<span>${esc(ex.cue)}</span></p>` : ''}</section>
      <section class="card"><div class="card-h"><h3>Common mistakes</h3></div><ul class="bul">${ex.mistakes.map((s) => `<li>${esc(s)}</li>`).join('')}</ul></section>
      <section class="card"><div class="card-h"><h3>Breathing</h3></div><p>${esc(breathing(ex))}</p></section>
      <section class="card"><div class="card-h"><h3>Safety</h3></div><ul class="bul">${safety(ex, p?.limits || []).map((s) => `<li>${esc(s)}</li>`).join('')}</ul></section>
    </div><div class="stack">
      <section class="card"><div class="card-h"><h3>Target muscles</h3></div>${bodyMapHTML({ mode: 'show', primary: ex.pm, secondary: ex.sm })}<p style="margin-top:10px"><b>Primary:</b> ${esc(ex.pm.join(', '))}</p>${ex.sm.length ? `<p class="mut" style="margin-top:4px"><b>Secondary:</b> ${esc(ex.sm.join(', '))}</p>` : ''}${ex.stress.length ? `<p class="note warn" style="margin-top:10px">${icon('alert')}<span>Loads your ${esc(ex.stress.map((s) => LIMITS[s].toLowerCase()).join(' and '))}${hasLimit(ex, p?.limits || []) ? ', which you listed as a limitation' : ''}.</span></p>` : ''}</section>
      <section class="card"><div class="card-h"><h3>Sets and reps</h3><span class="lbl">By goal</span></div><table class="rx"><tbody>${rx.map(([k, n, pr, rest]) => `<tr ${p?.goal === k ? 'style="color:var(--ink)"' : ''}><th scope="row" ${p?.goal === k ? 'style="color:var(--ink)"' : ''}>${esc(n)}${p?.goal === k ? ' (yours)' : ''}</th><td>${rng(pr, ex)}</td></tr>`).join('')}</tbody></table><p class="hint" style="margin-top:8px">Rest ${ex.type === 'Core' ? '45' : ex.type === 'Isolation' ? '45 to 75' : '60 to 180'} seconds depending on your goal.</p></section>
      ${rec ? `<section class="card"><div class="card-h"><h3>Your history</h3></div><p>${plural(rec.sessions, 'session')}, last ${relDay(rec.lastDate)}</p>${rec.heaviest ? `<p class="mut">Heaviest: ${fmtW(rec.heaviest.w, u, true)} × ${rec.heaviest.reps}</p>` : ''}${rec.bestE1 ? `<p class="mut">Estimated 1RM: ${fmtW(rec.bestE1.v, u, true)}</p>` : ''}<a class="link" href="#/progress?ex=${ex.id}">See progression</a></section>` : ''}
      ${lower.length ? `<section class="card" style="padding-bottom:6px"><div class="card-h"><h3>No ${esc(ex.equip.toLowerCase() === 'bodyweight' ? 'equipment' : ex.equip.toLowerCase())}? Try these</h3></div>${lower.map(link).join('')}</section>` : ''}
      ${ranked.length ? `<section class="card" style="padding-bottom:6px"><div class="card-h"><h3>Alternatives</h3></div>${ranked.map((r) => link(r.ex, r.reasons.join(' · '))).join('')}</section>` : ''}
      ${ex.custom ? `<section class="card"><div class="card-h"><h3>Custom exercise</h3></div><div class="btn-row"><button class="btn small" data-edit>${icon('edit')} Edit</button><button class="btn small danger" data-remove>${icon('trash')} Remove</button></div><p class="hint" style="margin-top:8px">Removing one you have logged keeps it in your history and hides it from lists.</p></section>` : ''}
    </div></div>`;
  bindDemo(root); bindSpin(root);
  if (root.__lib) root.removeEventListener('click', root.__lib);
  root.__lib = async (e) => {
    const h = e.target.closest('[data-fav]');
    if (h) { toggleFav(ex.id); const on = isFav(ex.id); h.setAttribute('aria-pressed', on); h.setAttribute('aria-label', on ? 'Remove from favourites' : 'Add to favourites'); }
    else if (e.target.closest('[data-edit]')) customForm(ex, () => detail(root, BY_ID[ex.id], go));
    else if (e.target.closest('[data-remove]')) {
      if (await confirmDialog({ title: 'Remove this exercise?', text: `${ex.name} is taken out of your programme and the library. Logged workouts keep it in your history.`, confirm: 'Remove', danger: true })) { const r = removeCustom(ex.id); toast(r === 'archived' ? 'Removed. History kept.' : 'Exercise deleted'); go('library'); }
    }
  };
  root.addEventListener('click', root.__lib);
}
