import { state, saveClass, markClassDone, removeActivity } from '../store.js';
import { CLASS_TYPES, CLASS_BY_ID, IMPACT, EFFORT, DEFAULT_MIN, classLine, buildClassICS, isClass } from '../classes.js';
import { esc, dateKey, fmtDayLong } from '../util.js';
import { icon, sheet, toast, confirmDialog } from '../ui.js';

function download(name, text) { const url = URL.createObjectURL(new Blob([text], { type: 'text/calendar' })); const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 2000); }

/** Sheet to log a class you did, or book one ahead. `existing` edits a saved class. */
export function openClassForm({ date, existing = null, status = 'done' } = {}, onChange) {
  const today = dateKey(new Date()), v = existing || { type: 'pilates', date: date || today, time: '', durationSec: DEFAULT_MIN.pilates * 60, status, impact: 'low', studio: '', note: '' };
  const opts = (list, cur, f) => list.map((o) => `<option value="${esc(f.v(o))}" ${f.v(o) === cur ? 'selected' : ''}>${esc(f.l(o))}</option>`).join('');
  sheet({ title: existing ? 'Edit class' : 'Add a class', wide: true, html: `<form id="clf" class="stack" novalidate>
    <div class="field"><span class="lbl">Status</span><div class="filters" role="radiogroup" aria-label="Status">
      <label class="fchip fchk"><input type="radio" name="status" value="done" ${v.status !== 'booked' ? 'checked' : ''}><span>I did this class</span></label>
      <label class="fchip fchk"><input type="radio" name="status" value="booked" ${v.status === 'booked' ? 'checked' : ''}><span>Booked ahead</span></label></div></div>
    <label class="field"><span class="lbl">Type of class</span><select class="input" name="type">${opts(CLASS_TYPES, v.type, { v: (t) => t.id, l: (t) => t.label })}</select></label>
    <label class="field"><span class="lbl">Studio or gym (optional)</span><input class="input" name="studio" maxlength="60" value="${esc(v.studio || '')}" autocomplete="off"></label>
    <div class="grid2"><label class="field"><span class="lbl">Date</span><input class="input" type="date" name="date" value="${esc(v.date)}" required></label>
      <label class="field"><span class="lbl" id="tl">Start time</span><input class="input" type="time" name="time" value="${esc(v.time || '')}"></label></div>
    <div class="grid2"><label class="field"><span class="lbl">Length (minutes)</span><input class="input" type="number" name="minutes" inputmode="numeric" min="5" max="300" value="${Math.round((v.durationSec || 3000) / 60)}" required></label>
      <label class="field"><span class="lbl">How much jumping and landing?</span><select class="input" name="impact">${opts(Object.keys(IMPACT), v.impact, { v: (k) => k, l: (k) => IMPACT[k] })}</select></label></div>
    <label class="field" id="ef"><span class="lbl">How hard did it feel? (optional)</span><select class="input" name="effort"><option value="">Skip</option>${opts(Object.keys(EFFORT), String(v.effort || ''), { v: (k) => k, l: (k) => `${k}. ${EFFORT[k]}` })}</select></label>
    <label class="field"><span class="lbl">Note (optional)</span><textarea class="input" name="note" rows="2" maxlength="300">${esc(v.note || '')}</textarea></label>
    <p class="hint">A class you did counts as a trained day in your calendar and weekly target. It adds no sets, XP or personal bests, and your streak and challenges still follow your lifting.</p>
    <p class="note warn" id="clerr" role="alert" hidden></p><button class="btn primary block" type="submit">${existing ? 'Save changes' : 'Save class'}</button></form>`,
    onMount: (box, close) => {
      const f = box.querySelector('#clf'), sync = () => { const b = f.status.value === 'booked'; box.querySelector('#ef').hidden = b; box.querySelector('#tl').textContent = b ? 'Start time (required)' : 'Start time (optional)'; f.time.required = b; };
      f.type.addEventListener('change', () => { f.impact.value = CLASS_BY_ID[f.type.value].impact; if (!existing) f.minutes.value = DEFAULT_MIN[f.type.value]; });
      f.addEventListener('change', (e) => { if (e.target.name === 'status') sync(); }); sync();
      f.addEventListener('submit', (e) => {
        e.preventDefault(); const fd = new FormData(f);
        const r = saveClass({ type: fd.get('type'), studio: fd.get('studio'), date: fd.get('date'), time: fd.get('time'), minutes: fd.get('minutes'), impact: fd.get('impact'), status: fd.get('status'), effort: fd.get('effort'), note: fd.get('note') }, existing?.id || null);
        if (r.error) { const n = box.querySelector('#clerr'); n.textContent = r.error; n.hidden = false; return; }
        close(); toast(fd.get('status') === 'booked' ? 'Class booked in your calendar' : 'Class saved'); onChange?.();
      });
    } });
}

/** The “how hard was it” step when marking a booked class as done. */
function markDone(c, onChange) {
  sheet({ title: 'Did you go?', html: `<form id="md" class="stack"><p class="mut">${esc(classLine(c))} on ${esc(fmtDayLong(c.date))}.</p>
    <label class="field"><span class="lbl">How hard did it feel? (optional)</span><select class="input" name="effort"><option value="">Skip</option>${Object.keys(EFFORT).map((k) => `<option value="${k}">${k}. ${EFFORT[k]}</option>`).join('')}</select></label>
    <button class="btn primary block" type="submit">Yes, mark as done</button></form>`,
    onMount: (box, close) => box.querySelector('#md').addEventListener('submit', (e) => { e.preventDefault(); const r = markClassDone(c.id, new FormData(e.target).get('effort')); if (r.error) return toast(r.error, 'err'); close(); toast('Marked as done'); onChange?.(); }) });
}

/** Buttons for one class entry. */
export const classButtons = (c, today) => `<div class="btn-row" style="margin-top:8px;gap:6px;flex-wrap:wrap">${c.status === 'booked' ? `${c.date <= today ? `<button class="btn small primary" data-cl-done="${esc(c.id)}">I went</button>` : ''}<button class="btn small" data-cl-ics="${esc(c.id)}">${icon('download')} Add to calendar</button>` : ''}<button class="btn small" data-cl-edit="${esc(c.id)}">Edit</button><button class="btn small ghost" data-cl-del="${esc(c.id)}">Delete</button></div>`;

/** Handles clicks on the buttons above. Returns true if the click was handled. */
export function classClick(e, onChange) {
  const t = (s) => e.target.closest(s), find = (id) => state.activities.find((a) => a.id === id && isClass(a));
  let el;
  if ((el = t('[data-cl-add]'))) { openClassForm({ date: el.dataset.clAdd, status: el.dataset.clStatus || 'done' }, onChange); return true; }
  if ((el = t('[data-cl-edit]'))) { const c = find(el.dataset.clEdit); if (c) openClassForm({ existing: c }, onChange); return true; }
  if ((el = t('[data-cl-done]'))) { const c = find(el.dataset.clDone); if (c) markDone(c, onChange); return true; }
  if ((el = t('[data-cl-ics]'))) { const c = find(el.dataset.clIcs); if (c) { download('repwise-class.ics', buildClassICS(c)); toast('Calendar file downloaded. Open it to add the class to your calendar app.'); } return true; }
  if ((el = t('[data-cl-del]'))) { const c = find(el.dataset.clDel); if (c) confirmDialog({ title: 'Delete this class?', text: `${classLine(c)} on ${fmtDayLong(c.date)} will be removed.`, confirm: 'Delete', danger: true }).then((ok) => { if (ok) { removeActivity(c.id); toast('Class deleted'); onChange?.(); } }); return true; }
  return false;
}
