// Shared markup for levels, XP, streaks and challenges (Progress > Achievements, Home, workout summary).
import { esc, plural } from '../util.js';
import { icon } from '../ui.js';
import { xpSummary, currentChallenges } from '../gamify.js';
import { weekStreak } from '../analytics.js';

const bar = (pct, label) => `<div class="pbar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(pct * 100)}" aria-label="${esc(label)}"><i style="width:${Math.max(0, Math.min(1, pct)) * 100}%"></i></div>`;

export function levelCard(state, now = new Date(), { link = false } = {}) {
  const x = xpSummary(state, now), st = weekStreak(state.sessions, state.profile?.days || 3, now);
  return `<section class="card lvl" aria-label="Level and XP"><div class="row sb" style="align-items:flex-start;gap:12px"><div class="lvl-badge" aria-hidden="true">${x.level}</div><div style="flex:1;min-width:0"><div class="lbl">Level ${x.level}</div><b class="lvl-t">${esc(x.title)}</b><div class="s mut num" style="font-size:13.5px">${x.total} XP · ${x.need - x.into} to level ${x.level + 1}</div></div>${link ? `<a class="link" href="#/progress/achievements">Details</a>` : ''}</div>${bar(x.pct, 'Progress to next level')}
  <div class="lvl-meta"><span class="chip">${icon('flame')} ${plural(st.current, 'week')} on target</span><span class="chip">Best ${st.best}</span></div></section>`;
}
export function challengeRow(c) {
  return `<div class="chl ${c.done ? 'on' : ''}"><div class="row sb" style="gap:10px"><div style="min-width:0"><b>${esc(c.title)}</b><div class="s mut" style="font-size:13.5px">${esc(c.desc)}</div></div><span class="chip ${c.done ? 'ok' : ''}">${c.done ? icon('check') + ' Done' : '+' + c.xp + ' XP'}</span></div>${bar(c.pct, c.title + ' progress')}<div class="s mut num" style="font-size:12.5px">${Math.min(c.value, c.target)} / ${c.target}${c.done ? ` · +${c.xp} XP earned` : c.final ? ' · ended' : ''}</div></div>`;
}
export function challengesCard(state, now = new Date()) {
  const c = currentChallenges(state, now), m = now.toLocaleString('en', { month: 'long' });
  return `<h2 class="sec">This week</h2><div class="card stack">${c.week.map(challengeRow).join('')}</div><h2 class="sec">${esc(m)}</h2><div class="card stack">${c.month.map(challengeRow).join('')}</div>`;
}
export function xpExplain(state, now = new Date()) {
  const x = xpSummary(state, now), p = x.parts;
  return `<details class="more"><summary>How XP works</summary><div class="hint" style="padding:6px 0 0">XP is worked out from your history, so it always matches your workouts. <b>Workouts ${p.workouts}</b> (40 each, one per day, up to your weekly target plus one), <b>sets ${p.sets}</b> (1 each, up to 20 per workout), <b>records ${p.prs}</b>, <b>challenges ${p.challenges}</b>, <b>achievements ${p.achievements}</b>. Extra workouts beyond your plan earn nothing more, because rest is part of progress.${x.ignored ? ` ${plural(x.ignored, 'workout')} did not add XP for that reason.` : ''} Changing your weekly target recalculates XP.</div></details>`;
}
/** Block shown on the workout summary: XP earned, level-ups and challenges completed. */
export function summaryXP(xp) {
  if (!xp) return '';
  const rows = [];
  if (xp.levelUp) rows.push(`<div class="li"><div><div class="t">Level ${xp.level}: ${esc(xp.summary.title)}</div><div class="s">You moved up from level ${xp.fromLevel}</div></div>${icon('trophy', 'up')}</div>`);
  xp.completed.forEach((c) => rows.push(`<div class="li"><div><div class="t">${esc(c.title)}</div><div class="s">${c.period === 'week' ? 'Weekly' : 'Monthly'} challenge complete</div></div><span class="chip ok">+${c.xp} XP</span></div>`));
  return `<div class="card" style="margin-bottom:12px"><div class="card-h"><h3>Experience</h3><span class="lbl num">Level ${xp.level}</span></div><div class="row sb"><b class="num" style="font-size:22px">${xp.gained >= 0 ? '+' : ''}${xp.gained} XP</b><span class="mut num" style="font-size:13.5px">${xp.total} total</span></div>${bar(xp.summary.pct, 'Progress to next level')}${rows.length ? `<div class="list" style="margin-top:10px">${rows.join('')}</div>` : ''}</div>`;
}
