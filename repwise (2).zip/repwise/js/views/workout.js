import { state, mutate, units, isPro, can } from '../store.js';
import { esc, fmtW, fmtVol, fmtClock, fmtDur, relDay, clamp, roundTo, unitToKg, kgToUnit, plural, stepKg } from '../util.js';
import { BY_ID, isTimed, isGuided, unitSuffix, repStep } from '../exercises.js';
import { swapSheet, pickExercise } from '../picker.js';
import { FEEDBACK, ACTIONS } from '../progression.js';
import { summaryXP } from './rewards.js';
import { hrState, onHr, connectHr, disconnectHr, supported as btOk } from '../hr.js';
import { icon, sheet, confirmDialog, celebrate, toast } from '../ui.js';
import * as W from '../workout-logic.js';
import { demoHTML, bindDemo } from '../media.js';
import { breathing, safety } from '../guidance.js';
import { PHASES } from '../sessions.js';

export const title = 'Workout';
const rngText = (it) => (it.repLo === it.repHi ? it.repLo : `${it.repLo}–${it.repHi}`);

function lastText(last, u, loaded, sec, sfx = sec ? 's' : '') {
  if (!last) return null;
  const parts = last.sets.map((s) => (loaded ? `${fmtW(s.w, u)}×${s.reps}` : `${s.reps}${sfx}`));
  const same = loaded && last.sets.every((s) => s.w === last.sets[0].w);
  return same ? `${fmtW(last.sets[0].w, u, true)} × ${last.sets.map((s) => s.reps).join(', ')}` : parts.join(', ');
}

// --- alerts: sound, vibration, notification when rest ends ---
let audio;
function beep() {
  if (!state.settings.sound) return;
  try { audio = audio || new (window.AudioContext || window.webkitAudioContext)(); const t = audio.currentTime; [0, 0.18].forEach((d, i) => { const o = audio.createOscillator(), g = audio.createGain(); o.frequency.value = i ? 988 : 740; g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(0.25, t + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.16); o.connect(g).connect(audio.destination); o.start(t + d); o.stop(t + d + 0.18); }); } catch { /* audio unavailable */ }
}
function restOverAlert() {
  beep();
  if (state.settings.vibrate && navigator.vibrate) navigator.vibrate([180, 80, 180]);
  if (state.settings.notify && document.hidden && 'Notification' in window && Notification.permission === 'granted') { try { new Notification('Rest is over', { body: 'Time for your next set.', tag: 'repwise-rest' }); } catch { /* ignore */ } }
}

/** A short soft tick when a timer starts. */
function beepSoft() { if (state.settings.vibrate && navigator.vibrate) navigator.vibrate(30); }

export default function workout(root, { go }) {
  if (!state.active) { go('train'); return; }
  let summary = null, wake = null, tickId = null, notified = null, hold = null; // hold: running countdown for a timed set {i, pos, end}
  const u = () => units();
  const A = () => state.active;
  let pos = clamp(A().pos || 0, 0, A().items.length - 1);

  root.innerHTML = `<div class="w-head" id="wh"></div><div id="hrw"></div><div id="wb"></div><div class="w-foot" id="wf"></div><div id="wp"></div>`;
  const $hr = root.querySelector('#hrw'), $h = root.querySelector('#wh'), $b = root.querySelector('#wb'), $f = root.querySelector('#wf'), $p = root.querySelector('#wp');
  const totalSets = () => A().items.reduce((a, it) => a + (it.skipped ? 0 : it.sets.length), 0), doneSets = () => A().items.reduce((a, it) => a + (it.skipped ? 0 : W.itemDone(it)), 0);
  const setPos = (n) => { pos = clamp(n, 0, A().items.length - 1); mutate((st) => { st.active.pos = pos; }, { silent: true }); drawBody(true); drawFoot(); window.scrollTo({ top: 0 }); };

  // ---------- heart rate (Bluetooth strap or watch, if the browser supports it) ----------
  function drawHr() {
    if (!btOk() || summary) { $hr.innerHTML = ''; return; }
    const h = hrState();
    $hr.innerHTML = h.connected ? `<div class="hrbar"><span class="hr-live" aria-live="off">${icon('heart')} <b class="num">${h.bpm ?? '…'}</b> bpm</span><span class="mut">${esc(h.name || 'Heart rate monitor')}</span><button class="btn small ghost" data-hr="off">Disconnect</button></div>` : `<div class="hrbar"><button class="btn small" data-hr="on" ${h.connecting ? 'disabled' : ''}>${icon('heart')} ${h.connecting ? 'Connecting…' : 'Connect heart rate monitor'}</button>${h.error ? `<span class="s" style="color:var(--warn)">${esc(h.error)}</span>` : ''}</div>`;
  }
  const offHr = onHr(drawHr);

  // ---------- header ----------
  function drawHead() {
    const a = A(); const pct = totalSets() ? (doneSets() / totalSets()) * 100 : 0;
    $h.innerHTML = `<div class="row"><a class="icon-btn" href="#/" aria-label="Leave workout screen (workout keeps running)">${icon('left')}</a><div class="w-title"><b>${esc(a.name)}</b><span id="el">${fmtClock(W.elapsedMs() / 1000)}</span> <span>· ${doneSets()}/${totalSets()} sets</span></div><button class="icon-btn" data-pause aria-label="${a.pausedAt ? 'Resume' : 'Pause'} workout">${icon(a.pausedAt ? 'play' : 'pause')}</button><button class="btn small ok" data-finish>Finish</button></div> ${a.note ? `<p class="wnote">${esc(a.note)}</p>` : ''}<div class="w-prog" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(pct)}" aria-label="Workout progress"><i style="width:${pct}%"></i></div>`;
    $p.innerHTML = a.pausedAt ? `<div class="paused" role="dialog" aria-label="Workout paused"><h2>Workout paused</h2><p class="mut">Your timer is stopped. Nothing is lost.</p><button class="btn primary" data-pause style="min-width:200px">${icon('play')} Resume</button></div>` : '';
  }

  // ---------- exercise card ----------
  function setRow(it, s, i, ex) {
    const unitU = u(), loaded = it.plan.loaded, sec = isTimed(ex), tm = ex.unit === 'min', stepW = it.plan.step || stepKg(1, unitU);
    const pr = s.done && W.livePR(it.exId, s) ? W.livePR(it.exId, s) : null;
    return `<div class="srow ${s.done ? 'done' : ''} ${loaded ? '' : 'bw'}"><div class="sh"><b>Set ${i + 1}${ex.sides ? (i % 2 ? ' · other side' : ' · first side') : ''}</b><span>${pr ? `<span class="pr">${icon('trophy')} New PR</span> ` : ''}target ${rngText(it)}${tm ? ' min' : sec ? 's' : ' reps'}</span></div><div class="ctl">
      ${loaded ? `<div class="stp"><button data-adj="w:${i}:-1" aria-label="Decrease weight">${icon('minus')}</button><label><input inputmode="decimal" data-in="w:${i}" value="${fmtW(s.w, unitU)}" aria-label="Set ${i + 1} weight in ${unitU}"><small>${unitU}</small></label><button data-adj="w:${i}:1" aria-label="Increase weight">${icon('plus')}</button></div>` : ''}
      <div class="stp"><button data-adj="r:${i}:-1" aria-label="Decrease ${tm ? 'minutes' : sec ? 'seconds' : 'reps'}">${icon('minus')}</button><label><input inputmode="numeric" data-in="r:${i}" value="${s.reps}" aria-label="Set ${i + 1} ${tm ? 'minutes' : sec ? 'seconds' : 'reps'}"><small>${tm ? 'min' : sec ? 'sec' : 'reps'}</small></label><button data-adj="r:${i}:1" aria-label="Increase ${tm ? 'minutes' : sec ? 'seconds' : 'reps'}">${icon('plus')}</button></div>
      <button class="chk" data-done="${i}" aria-pressed="${s.done}" aria-label="${s.done ? 'Undo set' : 'Complete set'} ${i + 1}">${icon('check')}</button></div>
      ${sec && !s.done ? `<button class="btn small hold" data-hold="${i}" aria-live="off">${hold && hold.i === i && hold.pos === pos ? 'Stop timer' : `${icon('timer')} Start ${s.reps}${tm ? ' min' : 's'} timer`}</button>` : ''}</div>`;
  }
  function drawBody(animate = false) {
    const a = A(), it = a.items[pos], ex = BY_ID[it.exId], unitU = u(), pl = it.plan, sec = isTimed(ex), sfx = unitSuffix(ex), mind = isGuided(ex);
    const complete = W.itemComplete(it), last = lastText(pl.last, unitU, pl.loaded, sec, sfx);
    const rec = it.rec;
    const dots = a.items.map((x, i) => `<button class="dot ${i === pos ? 'cur' : ''} ${W.itemComplete(x) ? 'done' : ''} ${x.skipped ? 'skip' : ''}" data-goto="${i}" aria-label="Exercise ${i + 1}: ${esc(BY_ID[x.exId].name)}${W.itemComplete(x) ? ', complete' : x.skipped ? ', skipped' : ''}" ${i === pos ? 'aria-current="step"' : ''}>${W.itemComplete(x) ? icon('check') : i + 1}</button>`).join('');
    $b.innerHTML = `<div class="dots" role="group" aria-label="Exercises">${dots}</div><div class="row sb" style="margin:-2px 0 10px"><span class="hint">${Math.round(doneSets() / Math.max(1, totalSets()) * 100)}% of sets done</span><button class="btn small ghost" data-editw>${icon('sliders')} Edit workout</button></div>
    <article class="card ex-card${animate ? ' anim' : ''}" aria-label="${esc(ex.name)}">
      <div class="lbl">Exercise ${pos + 1} of ${a.items.length}${it.phase && it.phase !== 'main' ? ` · ${PHASES[it.phase]}` : ''}</div><h1 class="ex-name">${esc(ex.name)}</h1>
      <div class="ex-meta"><span class="chip blue">${esc(ex.pm.join(' · '))}</span><span class="chip">${esc(ex.equip)}</span>${ex.sm?.length ? `<span class="chip">Assists: ${esc(ex.sm.join(' · '))}</span>` : ''}${it.origExId !== it.exId ? `<span class="chip warn">Substituted for ${esc(BY_ID[it.origExId].name)}</span>` : ''}</div>
      <p class="mut">${it.targetSets === 1 ? '1 set' : it.targetSets + ' sets'} × ${rngText(it)}${ex.unit === 'min' ? ' minutes' : sec ? ' seconds' : ' reps'} · rest ${it.restSec}s</p>
      ${it.skipped ? `<div class="empty" style="margin-top:14px"><h3>Skipped</h3><p class="mut">This exercise won't be logged. Your weight and progress for it stay the same.</p><button class="btn small" data-unskip>Undo skip</button></div>` : `
      <div class="rec"><p><b>${pl.loaded ? `Recommended: ${fmtW(pl.weight, unitU, true)}` : `Aim for ${pl.repTarget}${sfx || ' reps'}${ex.unit === 'min' ? '' : ' per set'}`}</b>${pl.title && !pl.first ? ` · ${esc(pl.title)}` : ''}</p>
        <p>${pl.first ? (pl.loaded ? 'First time with this exercise. Start deliberately light and focus on clean reps. You can add weight once it feels easy.' : (mind ? 'New to this move. Go slowly, stay within a comfortable range and keep breathing.' : 'First time with this exercise. Focus on clean reps.')) : esc(pl.reasons?.[0] || 'Repeat your last performance.')}</p>${pl.note ? `<p>${esc(pl.note)}</p>` : ''}</div>
      ${last ? `<div class="prev">Last time: <b>${esc(last)}</b> · ${relDay(pl.last.date)}</div>` : ''}
      ${ex.cue ? `<p class="mut" style="font-size:14px">Tip: ${esc(ex.cue)}</p>` : ''}
      <div class="sets">${it.sets.map((s, i) => setRow(it, s, i, ex)).join('')}</div>
      ${!mind && (complete || (W.itemDone(it) > 0 && it.feedback)) ? `<div class="fb"><h3>How did it feel?</h3><div class="opts" role="radiogroup" aria-label="Difficulty">${Object.entries(FEEDBACK).map(([k, v]) => `<button class="opt" data-fb="${k}" aria-pressed="${it.feedback === k}"><span>${v.label}<small>${v.hint}</small></span><i></i></button>`).join('')}</div>
        ${!mind && rec ? `<div class="rec" style="margin-top:12px"><p><span class="act ${rec.action}">${esc(rec.title)}</span> ${rec.weight && pl.loaded ? `<b>${rec.action === 'maintain' || rec.action === 'increase_reps' ? 'Keep' : 'Next:'} ${fmtW(rec.weight, unitU, true)}</b> ×` : ''} <b>${rec.repTarget}${sec ? 's' : '+ reps'}</b></p>${rec.reasons.map((r) => `<p>${esc(r)}</p>`).join('')}</div>` : '<p class="hint" style="margin-top:10px">Pick one to see what to do next time.</p>'}</div>` : ''}
      <div class="ex-actions"><button class="btn small" data-sub>${icon('swap')} Substitute</button><button class="btn small" data-addset>${icon('plus')} Add set</button><button class="btn small" data-adjust>${icon('sliders')} Sets, reps, rest</button><button class="btn small" data-info>${icon('play')} Demo & technique</button><button class="btn small" data-hurt>${icon('alert')} Something hurts</button><button class="btn small ghost" data-skip>${icon('skip')} Skip</button></div>`}
    </article>`;
  }

  // ---------- footer: rest timer + navigation ----------
  function drawFoot() {
    const a = A(), last = pos === a.items.length - 1, it = a.items[pos], r = a.rest;
    $f.innerHTML = `<div>${r ? `<div class="rest" id="rest"><div class="t" id="rt"></div><button class="btn small" data-rest="-15" aria-label="15 seconds less">−15</button><button class="btn small" data-rest="15" aria-label="15 seconds more">+15</button><button class="btn small ghost" data-rest-skip>Skip</button></div><div class="rest-bar"><i id="rb" style="width:100%"></i></div>` : ''}
      <div class="w-nav"><button class="btn" data-prev ${pos === 0 ? 'disabled' : ''} aria-label="Previous exercise">${icon('left')}</button><button class="btn ${W.itemComplete(it) || it.skipped ? 'primary' : ''}" data-${last ? 'finish' : 'next'}>${last ? 'Finish workout' : 'Next exercise'}</button><button class="btn" data-next ${last ? 'disabled' : ''} aria-label="Next exercise">${icon('right')}</button></div></div>`;
    tickRest();
  }
  function tickHold() {
    if (!hold) return;
    if (hold.pos !== pos) { hold = null; return drawBody(); }
    const a = A(); if (a.pausedAt) { hold.end += 250; return; }
    const left = Math.ceil((hold.end - Date.now()) / 1000), b = root.querySelector(`[data-hold="${hold.i}"]`);
    if (left > 0) { if (b) b.textContent = `Stop timer · ${left >= 120 ? Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0') : left + 's'} left`; return; }
    const i = hold.i; hold = null; beep(); if (state.settings.vibrate && navigator.vibrate) navigator.vibrate([180, 80, 180]); if (!A().items[pos].sets[i].done) toggleDone(i); else drawBody();
  }
  function tickRest() {
    const a = A(); if (!a) return; const el = $f.querySelector('#rt'); const el2 = root.querySelector('#el'); if (el2) el2.textContent = fmtClock(W.elapsedMs() / 1000);
    if (!el || !a.rest) return;
    const left = W.restLeft(), box = $f.querySelector('#rest'), bar = $f.querySelector('#rb');
    if (a.pausedAt) { el.innerHTML = `${fmtClock(Math.ceil(left))}<small>Paused</small>`; return; }
    if (left <= 0) { box.classList.add('over'); el.innerHTML = `Go<small>Rest is over</small>`; bar.style.width = '0%'; if (notified !== a.rest.endsAt) { notified = a.rest.endsAt; restOverAlert(); setTimeout(() => { if (state.active?.rest?.endsAt === notified) { W.clearRest(); drawFoot(); } }, 6000); } return; }
    box.classList.remove('over'); el.innerHTML = `${fmtClock(Math.ceil(left))}<small>Rest</small>`; bar.style.width = (left / a.rest.total) * 100 + '%';
  }

  // ---------- actions ----------
  const setVal = (i, key, v) => mutate((st) => { st.active.items[pos].sets[i][key] = v; }, { silent: true });
  function adjust(kind, i, dir) {
    const it = A().items[pos], s = it.sets[i], step = repStep(BY_ID[it.exId]);
    if (kind === 'w') { const step = it.plan.step || stepKg(1, u()); const nw = Math.max(0, roundTo(s.w + dir * step, step)); mutate((st) => { const items = st.active.items[pos]; items.sets.forEach((x, j) => { if (j >= i && !x.done) x.w = nw; }); items.sets[i].w = nw; }, { silent: true }); }
    else setVal(i, 'reps', Math.max(0, s.reps + dir * step));
    drawBody();
  }
  function toggleDone(i) {
    const it = A().items[pos], s = it.sets[i]; let pr = null;
    if (!s.done && !(s.reps > 0)) return toast('Enter the reps you completed', 'err');
    mutate((st) => { const x = st.active.items[pos].sets[i]; x.done = !x.done; x.doneAt = x.done ? Date.now() : undefined; if (!x.done) { st.active.items[pos].rec = null; } }, { silent: true });
    if (A().items[pos].sets[i].done) {
      pr = W.livePR(it.exId, A().items[pos].sets[i]);
      if (pr) toast(pr === 'weight' ? 'New weight record!' : pr === 'e1rm' ? 'New estimated 1RM record!' : 'New rep record!');
      const lastOfAll = A().items.every((x, j) => x.skipped || x.sets.every((y) => y.done));
      if (!lastOfAll) W.startRest(it.restSec);
      if (W.itemComplete(A().items[pos]) && it.feedback) mutate((st) => { st.active.items[pos].rec = W.recFor(st.active.items[pos]); }, { silent: true });
    }
    drawHead(); drawBody(); drawFoot();
    if (W.itemComplete(A().items[pos])) setTimeout(() => root.querySelector('.fb')?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }), 80);
  }
  function chooseSub() {
    const it = A().items[pos], ex = BY_ID[it.origExId] || BY_ID[it.exId];
    swapSheet(ex, (id) => { W.substitute(pos, id); drawBody(); drawFoot(); toast(`Switched to ${BY_ID[id].name}`); }, { exclude: [it.exId, ...A().items.map((x) => x.exId)], title: 'Substitute exercise', intro: 'Ranked by target muscle, movement, your equipment and limitations. Sets, reps and rest stay the same; the weight starts from your history for the new exercise.' });
  }
  function hurt() {
    const it = A().items[pos];
    sheet({ title: 'Something hurts?', html: `<p class="mut">Stop if it is sharp or joint pain. Pushing through pain is not progress. This is not medical advice.</p><div class="stack" style="margin-top:14px">${it.plan.loaded ? '<button class="btn block" data-a="lower">Lower the remaining sets by 10%</button>' : ''}<button class="btn block" data-a="swap">Swap for another exercise</button><button class="btn block" data-a="skip">Skip this exercise</button></div>`,
      onMount: (box, close) => box.addEventListener('click', (e) => { const b = e.target.closest('[data-a]'); if (!b) return; close();
        if (b.dataset.a === 'lower') { const step = it.plan.step; mutate((st) => { const x = st.active.items[pos]; x.sets.forEach((s) => { if (!s.done) s.w = Math.max(step, roundTo(s.w * 0.9, step)); }); }, { silent: true }); W.setHurt(pos, true); drawBody(); toast('Weight lowered. Flagged for your next session.'); }
        else if (b.dataset.a === 'swap') { W.setHurt(pos, true); chooseSub(); } else { W.setHurt(pos, true); mutate((st) => { st.active.items[pos].skipped = true; }, { silent: true }); drawHead(); setPos(Math.min(pos + 1, A().items.length - 1)); } }) });
  }
  function info() {
    const ex = BY_ID[A().items[pos].exId];
    sheet({ title: ex.name, wide: true, onMount: (box) => bindDemo(box), html: `<div class="card flat" style="padding:12px 14px 4px;margin-bottom:14px">${demoHTML(ex)}</div><p class="hint" style="margin-bottom:10px">Your timer keeps running while this is open.</p><h3 style="margin:6px 0 8px">How to do it</h3><ol class="ol">${ex.steps.map((s) => `<li>${esc(s)}</li>`).join('')}</ol><h3 style="margin:18px 0 8px">Common mistakes</h3><ul class="bul">${ex.mistakes.map((s) => `<li>${esc(s)}</li>`).join('')}</ul><h3 style="margin:18px 0 8px">Breathing</h3><p>${esc(breathing(ex))}</p><h3 style="margin:18px 0 8px">Safety</h3><ul class="bul">${safety(ex, state.profile?.limits || []).map((s) => `<li>${esc(s)}</li>`).join('')}</ul>` });
  }

  // ---------- edit the running workout ----------
  function editWorkout() {
    const list = () => A().items.map((x, i) => `<li class="li" style="gap:8px"><div style="min-width:0;flex:1"><div class="t">${i + 1}. ${esc(BY_ID[x.exId].name)}${i === pos ? ' <span class="chip blue">Current</span>' : ''}</div><div class="s">${x.skipped ? 'Skipped' : `${W.itemDone(x)}/${x.sets.length} sets`} · ${x.sets.length} × ${rngText(x)} · rest ${x.restSec}s</div></div><div class="row" style="gap:4px"><button class="icon-btn" data-mv="${i}:-1" aria-label="Move ${esc(BY_ID[x.exId].name)} up" ${i === 0 ? 'disabled' : ''}>${icon('up')}</button><button class="icon-btn" data-mv="${i}:1" aria-label="Move ${esc(BY_ID[x.exId].name)} down" ${i === A().items.length - 1 ? 'disabled' : ''}>${icon('down')}</button><button class="icon-btn" data-rm="${i}" aria-label="Remove ${esc(BY_ID[x.exId].name)}" ${A().items.length < 2 ? 'disabled' : ''}>${icon('trash')}</button></div></li>`).join('');
    sheet({ title: 'Edit workout', html: `<p class="mut" style="margin-bottom:10px">Reorder, remove or add exercises. Logged sets are kept.</p><ul class="list" id="ew" style="list-style:none;padding:0">${list()}</ul><button class="btn block" data-addex style="margin-top:12px">${icon('plus')} Add exercise</button>`,
      onMount: (box, close) => { const redraw = () => { box.querySelector('#ew').innerHTML = list(); drawHead(); drawBody(); drawFoot(); };
        box.addEventListener('click', (e) => {
          const mv = e.target.closest('[data-mv]'), rm = e.target.closest('[data-rm]');
          if (mv) { const [i, d] = mv.dataset.mv.split(':').map(Number), cur = A().items[pos]; W.moveInActive(i, d); const ni = A().items.indexOf(A().items.find((x) => x.exId === cur.exId && x.origExId === cur.origExId)); pos = ni >= 0 ? ni : pos; mutate((st) => { st.active.pos = pos; }, { silent: true }); redraw(); }
          else if (rm) { const i = +rm.dataset.rm; if (!W.removeFromActive(i)) return; if (i < pos) pos--; pos = clamp(pos, 0, A().items.length - 1); mutate((st) => { st.active.pos = pos; }, { silent: true }); redraw(); toast('Exercise removed'); }
          else if (e.target.closest('[data-addex]')) { close(); pickExercise((id) => { const n = W.addToActive(id); if (n >= 0) { setPos(n); drawHead(); toast(`Added ${BY_ID[id].name}`); } }, { title: 'Add exercise', exclude: A().items.map((x) => x.exId), recommended: true }); }
        }); } });
  }
  function adjustItem() {
    const it = A().items[pos], ex = BY_ID[it.exId], unitLbl = ex.unit === 'min' ? 'minutes' : ex.unit === 'sec' ? 'seconds' : 'reps';
    sheet({ title: `${ex.name}: sets, reps, rest`, html: `<div class="stack" style="gap:12px"><label class="fld"><span class="lbl">Sets</span><input class="input" id="aj-s" type="number" inputmode="numeric" min="1" max="12" value="${it.sets.length}"></label><div class="grid2"><label class="fld"><span class="lbl">Min ${unitLbl}</span><input class="input" id="aj-lo" type="number" inputmode="numeric" min="1" value="${it.repLo}"></label><label class="fld"><span class="lbl">Max ${unitLbl}</span><input class="input" id="aj-hi" type="number" inputmode="numeric" min="1" value="${it.repHi}"></label></div><label class="fld"><span class="lbl">Rest between sets (seconds)</span><input class="input" id="aj-r" type="number" inputmode="numeric" min="0" max="600" step="5" value="${it.restSec}"></label><p class="hint">Completed sets are never removed. Changes apply to this workout only.</p><button class="btn primary block" data-save>Save</button></div>`,
      onMount: (box, close) => box.addEventListener('click', (e) => { if (!e.target.closest('[data-save]')) return; const g = (id) => box.querySelector(id).value, lo = +g('#aj-lo'), hi = +g('#aj-hi'); if (!(lo >= 1) || !(hi >= 1)) return toast('Enter a rep range of 1 or more', 'err'); W.setItemParams(pos, { sets: +g('#aj-s'), repLo: lo, repHi: hi, restSec: +g('#aj-r') }); close(); drawHead(); drawBody(); drawFoot(); toast('Updated'); }) });
  }
  async function finish() {
    const a = A(), done = doneSets(), skipped = a.items.filter((x) => x.skipped || W.itemDone(x) === 0).length;
    const text = done ? `${done} of ${totalSets()} sets logged${skipped ? `, ${plural(skipped, 'exercise')} without sets` : ''}. Your progression is updated from what you logged.` : 'No sets are logged yet. Finishing now saves nothing.';
    const res = await new Promise((resolve) => { const s = sheet({ title: done ? 'Finish workout?' : 'Nothing logged yet', html: `<p class="mut">${esc(text)}</p><div class="btn-row"><button class="btn ghost" data-v="keep" data-autofocus>Keep going</button>${done ? '<button class="btn ok" data-v="finish">Finish</button>' : '<button class="btn danger" data-v="discard">Discard</button>'}</div>`, onMount: (box, close) => box.querySelectorAll('[data-v]').forEach((b) => b.addEventListener('click', () => { resolve(b.dataset.v); close(); })) }); s.done.then(() => resolve('keep')); });
    if (res === 'discard') { W.discardWorkout(); go(''); return; }
    if (res !== 'finish') return;
    clearInterval(tickId); const r = W.finishWorkout();
    if (!r || r.empty) { go(''); return; }
    summary = r; drawSummary(); window.scrollTo(0, 0);
    const lines = [...r.prs.map((e) => ({ t: `New record: ${e.name}`, s: e.kind === 'weight' ? `${fmtW(e.value, u(), true)} × ${e.reps}` : e.kind === 'e1rm' ? `Estimated 1RM ${fmtW(e.value, u(), true)}` : `${e.value} reps` })), ...r.newAchievements.map((x) => ({ t: x.title, s: 'Achievement unlocked' }))];
    if (lines.length) await celebrate({ title: r.newAchievements.length ? 'Milestone reached' : r.prs.length > 1 ? 'New personal records' : 'New personal record', lines: lines.slice(0, 5), cta: 'See summary' });
  }
  function drawSummary() {
    const r = summary, unitU = u(), s = r.session;
    document.body.classList.remove('in-workout');
    $h.remove(); $f.remove(); $p.remove();
    $b.innerHTML = `<div class="page-h"><span class="chip ok">${icon('check')} Workout complete</span><h1 style="margin-top:12px">${esc(s.name)}</h1><p>Saved to your history.</p></div>
      <div class="sum-grid"><div class="stat"><span class="lbl">Time</span><b>${fmtDur(s.durationSec)}</b></div><div class="stat"><span class="lbl">Sets</span><b>${r.sets}</b></div><div class="stat"><span class="lbl">Volume</span><b>${fmtVol(r.volume, unitU)}</b></div></div>
      ${r.prs.length ? `<div class="card" style="margin-bottom:12px"><div class="card-h"><h3>New records</h3></div><div class="list">${r.prs.map((e) => `<div class="li"><div class="t">${esc(e.name)}</div><span class="pr">${icon('trophy')} ${e.kind === 'weight' ? fmtW(e.value, unitU, true) + ' × ' + e.reps : e.kind === 'e1rm' ? 'est. 1RM ' + fmtW(e.value, unitU, true) : e.value + ' reps'}</span></div>`).join('')}</div></div>` : ''}
      ${r.session.hr ? `<div class="card" style="margin-bottom:12px"><div class="card-h"><h3>Heart rate</h3></div><div class="row sb"><span><b class="num" style="font-size:22px">${r.session.hr.avg}</b> <span class="mut">bpm average</span></span><span class="mut num">${r.session.hr.min}–${r.session.hr.max} bpm</span></div></div>` : ''}
      ${summaryXP(r.xp)}
      ${r.newAchievements.length ? `<div class="card" style="margin-bottom:12px"><div class="card-h"><h3>Achievements unlocked</h3></div><div class="list">${r.newAchievements.map((x) => `<div class="li"><div><div class="t">${esc(x.title)}</div><div class="s">${esc(x.desc)}</div></div>${icon('trophy', 'up')}</div>`).join('')}</div></div>` : ''}
      ${r.routine ? '' : `<div class="card"><div class="card-h"><h3>Next time</h3><span class="lbl">Based on how it went</span></div>${r.recs.length ? r.recs.map((x) => `<div class="recrow"><div class="t"><span>${esc(x.name)}</span><span class="act ${x.rec.action}">${esc(x.rec.title)}</span></div><p>${x.loaded && x.rec.weight ? `<b>${fmtW(x.rec.weight, unitU, true)}</b> × ${x.rec.repTarget}+ reps. ` : `Aim for ${x.rec.repTarget}${x.unit === 'sec' ? 's' : ' reps'}. `}${esc(x.rec.reasons[0] || '')}</p></div>`).join('') : '<p class="mut">Nothing to adjust.</p>'}</div>`}
      <div class="btn-row"><a class="btn ghost" href="#/progress">View progress</a><a class="btn primary" href="#/">Done</a></div>`;
  }

  // ---------- events ----------
  root.addEventListener('click', async (e) => {
    const t = (s) => e.target.closest(s);
    if (summary) return;
    if (t('[data-hr]')) { if (t('[data-hr]').dataset.hr === 'off') return void disconnectHr(); try { await connectHr(); } catch (err) { toast(err.message, 'err', 6000); } return; }
    if (t('[data-pause]')) { W.togglePause(); drawHead(); drawFoot(); return; }
    if (t('[data-finish]')) return finish();
    if (t('[data-next]')) return setPos(pos + 1);
    if (t('[data-prev]')) return setPos(pos - 1);
    if (t('[data-goto]')) return setPos(+t('[data-goto]').dataset.goto);
    if (t('[data-adj]')) { const [k, i, d] = t('[data-adj]').dataset.adj.split(':'); return adjust(k, +i, +d); }
    if (t('[data-hold]')) { const i = +t('[data-hold]').dataset.hold; if (hold && hold.i === i && hold.pos === pos) hold = null; else { const secs = A().items[pos].sets[i]?.reps; if (!(secs > 0)) return toast('Enter the seconds first', 'err'); hold = { i, pos, end: Date.now() + secs * (BY_ID[A().items[pos].exId].unit === 'min' ? 60000 : 1000) }; beepSoft(); } return drawBody(); }
    if (t('[data-done]')) { if (hold && hold.pos === pos && hold.i === +t('[data-done]').dataset.done) hold = null; return toggleDone(+t('[data-done]').dataset.done); }
    if (t('[data-fb]')) { W.setFeedback(pos, t('[data-fb]').dataset.fb); drawBody(); return; }
    if (t('[data-editw]')) return editWorkout();
    if (t('[data-adjust]')) return adjustItem();
    if (t('[data-sub]')) return chooseSub();
    if (t('[data-hurt]')) return hurt();
    if (t('[data-info]')) return info();
    if (t('[data-addset]')) { mutate((st) => { const x = st.active.items[pos], l = x.sets[x.sets.length - 1] || { w: x.plan.weight, reps: x.plan.repTarget }; x.sets.push({ w: l.w, reps: l.reps, done: false }); }, { silent: true }); drawBody(); drawHead(); return; }
    if (t('[data-skip]')) { mutate((st) => { st.active.items[pos].skipped = true; }, { silent: true }); drawHead(); if (pos < A().items.length - 1) setPos(pos + 1); else { drawBody(); drawFoot(); } return; }
    if (t('[data-unskip]')) { mutate((st) => { st.active.items[pos].skipped = false; }, { silent: true }); drawHead(); drawBody(); return; }
    if (t('[data-rest]')) { W.adjustRest(+t('[data-rest]').dataset.rest); tickRest(); return; }
    if (t('[data-rest-skip]')) { W.clearRest(); drawFoot(); return; }
  });
  root.addEventListener('change', (e) => {
    const inp = e.target.closest('[data-in]'); if (!inp || summary) return;
    const [k, i] = inp.dataset.in.split(':'), idx = +i, it = A().items[pos], s = it.sets[idx], v = parseFloat(String(inp.value).replace(',', '.'));
    if (!isFinite(v) || v < 0) { inp.value = k === 'w' ? fmtW(s.w, u()) : s.reps; return toast('Enter a number of 0 or more', 'err'); }
    if (k === 'w') { const kg = unitToKg(v, u()); mutate((st) => { const items = st.active.items[pos]; items.sets[idx].w = kg; items.sets.forEach((x, j) => { if (j > idx && !x.done) x.w = kg; }); }, { silent: true }); root.querySelectorAll('[data-in^="w:"]').forEach((el) => { const j = +el.dataset.in.split(':')[1]; if (j > idx && !it.sets[j].done) el.value = fmtW(kg, u()); }); }
    else setVal(idx, 'reps', Math.round(v));
    { const hb = root.querySelector(`[data-hold="${idx}"]`); if (hb && !(hold && hold.i === idx)) hb.innerHTML = `${icon('timer')} Start ${Math.round(v)}${BY_ID[A().items[pos].exId].unit === 'min' ? ' min' : 's'} timer`; }
    inp.value = k === 'w' ? fmtW(A().items[pos].sets[idx].w, u()) : A().items[pos].sets[idx].reps;
  });
  root.addEventListener('focusin', (e) => { if (e.target.matches?.('[data-in]')) e.target.select?.(); });
  root.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.matches?.('[data-in]')) e.target.blur(); });

  // ---------- wake lock + timers ----------
  async function lock() { try { if (state.settings.wakeLock && 'wakeLock' in navigator && !wake && document.visibilityState === 'visible') { wake = await navigator.wakeLock.request('screen'); wake.addEventListener('release', () => { wake = null; }); } } catch { /* unsupported or denied */ } }
  const vis = () => { if (document.visibilityState === 'visible') { lock(); if (!summary) { drawHead(); tickRest(); } } };
  document.addEventListener('visibilitychange', vis); lock();
  document.body.classList.add('in-workout');
  drawHead(); drawBody(); drawFoot(); drawHr();
  tickId = setInterval(() => { if (!summary && state.active) { tickRest(); tickHold(); } }, 250);
  return () => { offHr(); clearInterval(tickId); document.removeEventListener('visibilitychange', vis); try { wake?.release(); } catch { /* ignore */ } document.body.classList.remove('in-workout'); };
}
