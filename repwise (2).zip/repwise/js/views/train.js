import { state, mutate, isPro, can, subscribe, units, uid, setExtras } from '../store.js';
import { esc, plural, fmtW, clamp } from '../util.js';
import { BY_ID, isTimed, unitSuffix, repStep } from '../exercises.js';
import { pickExercise, swapSheet } from '../picker.js';
import { GOALS, generateProgram, explainProgram, estMinutes, prescribe, weeklyFrequency } from '../generator.js';
import { icon, sheet, confirmDialog, toast, upgradePrompt, proBadge } from '../ui.js';
import { startWorkout, startRoutine, startCardio, plannedFor, swapInProgram } from '../workout-logic.js';
import { CARDIO_IDS } from '../sessions.js';
import { ROUTINES, KIND_LABEL, routineMinutes } from '../mindbody.js';

export const title = 'Train';
const rng = (it) => (it.repLo === it.repHi ? it.repLo : `${it.repLo}–${it.repHi}`) + unitSuffix(BY_ID[it.exId]);

export default function train(root, { go }) {
  let editing = !!state.ui.editNext && can('customProgramme'), showWhy = false;
  if (state.ui.editNext) mutate((st) => { st.ui.editNext = false; }, { silent: true });
  const p = () => state.profile;

  function draw() {
    const prog = state.program, u = units(), a = state.active, why = explainProgram(prog, p());
    const freq = weeklyFrequency(prog);
    root.innerHTML = `
      <div class="page-h"><h1>Your programme</h1><p>${esc(prog.name)} · ${plural(prog.sessions.length, 'session')} a week${prog.custom ? ' · customised' : ''} · <a class="link" href="#/coach">Ask the Coach</a></p></div>
      ${a ? `<div class="banner" style="margin-bottom:12px"><span>${icon('play')} <b>${esc(a.name)}</b> is in progress.</span><a class="btn small primary" href="#/workout">Resume</a></div>` : ''}
      <div class="row wrap" style="margin-bottom:16px;gap:8px">
        <button class="btn small" data-regen>${icon('repeat')} Regenerate</button>
        <button class="btn small ${editing ? 'primary' : ''}" data-edit>${icon('edit')} ${editing ? 'Done editing' : 'Edit programme'}${isPro() ? '' : proBadge()}</button>
        <button class="btn small ghost" data-why>${icon('info')} Why this plan</button>
      </div>
      ${showWhy ? `<div class="card why" style="margin-bottom:16px"><div><h3>${esc(why.headline)}</h3></div>${why.points.map((x) => `<div><h3>${esc(x.title)}</h3><p>${esc(x.text)}</p></div>`).join('')}<div><h3>Weekly frequency</h3><p>${Object.entries(freq).filter(([, v]) => v).map(([k, v]) => `${esc(k)} ${v}×`).join(' · ')}</p></div></div>` : ''}
      <div class="stack">${prog.sessions.map((s, si) => editing ? editor(s, si) : view(s, si, u)).join('')}</div>
      ${editing ? '' : extrasHTML() + routinesHTML()}
      ${editing ? `<div class="btn-row"><button class="btn" data-add-session>${icon('plus')} Add session</button></div>${saved()}` : ''}
      <p class="foot-note">Changing your programme never deletes workout history. Weights and progress follow each exercise.</p>`;
  }

  /** Warm-up, activation, cardio and cool-down around your lifting sessions, plus a cardio-only session. */
  const extrasHTML = () => { const x = state.settings.extras, cardio = CARDIO_IDS().map((id) => BY_ID[id]), tg = (k, l) => `<label class="fchip fchk"><input type="checkbox" data-extra="${k}" ${x[k] ? 'checked' : ''}><span>${l}</span></label>`;
    return `<section class="card" style="margin-top:16px" aria-label="Session structure"><div class="card-h"><h3>Session structure</h3></div>
    <p class="mut" style="margin-bottom:12px">Add these around every lifting session: warm-up, then glute activation, your main work, cardio, then a cool-down. They are picked from the muscles you train, your equipment and your joint limits. They never change your saved programme.</p>
    <div class="filters" role="group" aria-label="Session extras">${tg('warmup', 'Warm-up')}${tg('activation', 'Glute activation')}${tg('cooldown', 'Cool-down')}</div>
    <div class="grid2 stack-m" style="margin-top:12px"><label class="field"><span class="lbl">Cardio after lifting</span><select class="input" data-extra-cardio-id>${cardio.map((e) => `<option value="${esc(e.id)}" ${e.id === x.cardioId ? 'selected' : ''}>${esc(e.name)}</option>`).join('')}</select></label>
      <label class="field"><span class="lbl">Minutes (0 = none)</span><input class="input" type="number" inputmode="numeric" min="0" max="60" data-extra-cardio value="${x.cardio}"></label></div>
    <div class="grid2" style="margin-top:12px"><label class="field"><span class="lbl">Cardio only session</span><input class="input" type="number" inputmode="numeric" min="1" max="180" data-solo-min value="20" aria-label="Cardio only minutes"></label>
      <div style="align-self:end"><button class="btn small primary" data-solo>${icon('play')} Start cardio</button></div></div></section>`; };

  /** Ready-made Pilates, yoga and mobility routines. They count as a trained day and never move your lifting programme on. */
  const routinesHTML = () => `<section class="card" style="margin-top:16px" aria-label="Pilates, yoga and mobility routines"><div class="card-h"><h3>Pilates, yoga and mobility</h3></div>
    <p class="mut" style="margin-bottom:12px">Timed routines you follow on screen, with a timer for each hold. They count as a trained day, and your lifting programme stays where it is.</p>
    <div class="list">${ROUTINES.map((r) => `<div class="li" style="flex-wrap:wrap"><div style="min-width:0;flex:1"><div class="t">${esc(r.name)} <span class="chip">${esc(KIND_LABEL[r.kind])}</span></div><div class="s">~${routineMinutes(r)} min · ${plural(r.moves.length, 'move')} · ${esc(r.level)}. ${esc(r.blurb)}</div>
      <details class="more" style="margin-top:6px"><summary>See the moves</summary><ol style="margin:8px 0 0 18px;padding:0">${r.moves.map((m) => `<li>${esc(BY_ID[m.id]?.name || m.id)} · ${m.sets > 1 ? (BY_ID[m.id]?.sides ? `${m.secs}s each side` : `${m.sets} × ${m.secs}s`) : `${m.secs}s`}</li>`).join('')}</ol></details></div>
      <button class="btn small primary" data-routine="${esc(r.id)}">${icon('play')} Start</button></div>`).join('')}</div></section>`;

  const view = (s, si, u) => `<section class="card" aria-label="${esc(s.name)}"><div class="card-h"><h3>${esc(s.name)}</h3><span class="lbl">${s.items.length} exercises · ~${estMinutes(s.items) + 5} min</span></div>
    ${s.note ? `<p class="note" style="margin-bottom:10px">${icon('info')}<span>${esc(s.note)}</span></p>` : ''}
    <div class="list">${s.items.map((it, ii) => { const ex = BY_ID[it.exId]; if (!ex) return ''; const pl = plannedFor(it.exId, it); return `<div class="li"><div><a class="t" href="#/library/${ex.id}">${esc(ex.name)}</a><div class="s">${it.sets} × ${rng(it)} · rest ${it.restSec}s${pl.loaded ? ' · ' + fmtW(pl.weight, u, true) : ''}</div></div><button class="icon-btn" data-swap="${si}:${ii}" aria-label="Swap ${esc(ex.name)}">${icon('swap')}</button></div>`; }).join('')}</div>
    ${s.items.length ? '' : '<p class="mut" style="margin-top:10px">No exercises yet. Use Edit programme to add some.</p>'}<button class="btn primary block" style="margin-top:14px" data-start="${si}" ${s.items.length ? '' : 'disabled'}>${icon('play')} Start this workout</button></section>`;

  const editor = (s, si) => `<section class="card" aria-label="Edit ${esc(s.name)}"><div class="row" style="margin-bottom:6px"><input class="input" data-name="${si}" value="${esc(s.name)}" maxlength="40" aria-label="Session name"><button class="icon-btn" data-del-session="${si}" aria-label="Delete session">${icon('trash')}</button></div>
    <textarea class="input" data-note="${si}" rows="2" maxlength="300" placeholder="Workout notes (optional): cues, tempo, what to focus on" aria-label="Workout notes" style="margin-bottom:8px">${esc(s.note || '')}</textarea>
    ${s.items.map((it, ii) => { const ex = BY_ID[it.exId]; if (!ex) return ''; return `<div class="ed-item"><div class="row sb"><b>${esc(ex.name)}</b><div class="row" style="gap:0"><button class="icon-btn" data-move="${si}:${ii}:-1" aria-label="Move up" ${ii === 0 ? 'disabled' : ''}>${icon('up')}</button><button class="icon-btn" data-move="${si}:${ii}:1" aria-label="Move down" ${ii === s.items.length - 1 ? 'disabled' : ''}>${icon('down')}</button><button class="icon-btn" data-swap="${si}:${ii}" aria-label="Swap exercise">${icon('swap')}</button><button class="icon-btn" data-rm="${si}:${ii}" aria-label="Remove exercise">${icon('trash')}</button></div></div>
      <div class="ed-ctl">${mini('Sets', it.sets, `${si}:${ii}:sets`)}${mini(ex.unit === 'min' ? 'Min minutes' : ex.unit === 'sec' ? 'Min s' : 'Min reps', it.repLo, `${si}:${ii}:lo`)}${mini(ex.unit === 'min' ? 'Max minutes' : ex.unit === 'sec' ? 'Max s' : 'Max reps', it.repHi, `${si}:${ii}:hi`)}${mini('Rest', it.restSec + 's', `${si}:${ii}:rest`)}</div></div>`; }).join('')}
    <button class="btn small block" style="margin-top:8px" data-add="${si}">${icon('plus')} Add exercise</button></section>`;
  const saved = () => `<section class="card" style="margin-top:16px" aria-label="Saved programmes"><div class="card-h"><h3>Saved programmes</h3><span class="lbl">${state.programs.length} of 20</span></div>
    <div class="btn-row" style="margin-bottom:${state.programs.length ? 12 : 0}px"><button class="btn small" data-save-prog>${icon('plus')} Save current</button><button class="btn small" data-scratch>${icon('edit')} Build from scratch</button></div>
    ${state.programs.length ? `<div class="list">${state.programs.map((x) => `<div class="li"><div><div class="t">${esc(x.name)}</div><div class="s">${plural(x.program.sessions.length, 'session')} · saved ${esc(new Date(x.savedAt).toLocaleDateString('en', { day: 'numeric', month: 'short' }))}</div></div><div class="row" style="gap:4px"><button class="btn small" data-load-prog="${esc(x.id)}">Use</button><button class="icon-btn" data-del-prog="${esc(x.id)}" aria-label="Delete ${esc(x.name)}">${icon('trash')}</button></div></div>`).join('')}</div>` : '<p class="hint">Save the programme you have now so you can switch back later. Workout history is never affected.</p>'}</section>`;
  const mini = (l, v, key) => `<div class="mini" role="group" aria-label="${l}"><button data-adj="${key}:-1" aria-label="Decrease ${l}">${icon('minus')}</button><span>${l} ${esc(v)}</span><button data-adj="${key}:1" aria-label="Increase ${l}">${icon('plus')}</button></div>`;

  let keep = false;
  root.addEventListener('click', async (e) => {
    const t = (sel) => e.target.closest(sel);
    if (t('[data-start]')) { const si = +t('[data-start]').dataset.start; if (state.active && !(await confirmDialog({ title: 'Replace current workout?', text: 'You have a workout in progress. Starting a new one discards it.', confirm: 'Start new', danger: true }))) return; startWorkout(si); return go('workout'); }
    if (t('[data-routine]')) { if (state.active && !(await confirmDialog({ title: 'Replace current workout?', text: 'You have a workout in progress. Starting a new one discards it.', confirm: 'Start new', danger: true }))) return; if (startRoutine(t('[data-routine]').dataset.routine)) return go('workout'); return toast('That routine is not available', 'err'); }
    if (t('[data-solo]')) { if (state.active && !(await confirmDialog({ title: 'Replace current workout?', text: 'You have a workout in progress. Starting a new one discards it.', confirm: 'Start new', danger: true }))) return; const m = root.querySelector('[data-solo-min]').value; if (startCardio(state.settings.extras.cardioId, m)) return go('workout'); return toast('Enter cardio minutes between 1 and 180', 'err'); }
    if (t('[data-why]')) { showWhy = !showWhy; return draw(); }
    if (t('[data-regen]')) {
      const ok = await confirmDialog({ title: 'Regenerate programme?', text: `This builds a fresh programme from your profile with different exercise choices.${state.program.custom ? ' Your custom edits will be replaced.' : ''} Your workout history is not affected.`, confirm: 'Regenerate' });
      if (ok) { mutate((st) => { st.program = generateProgram(st.profile, { variant: (st.program.variant || 0) + 1 }); st.cursor = 0; }); toast('New programme generated'); } return;
    }
    if (t('[data-edit]')) { if (!can('customProgramme')) return upgradePrompt('Editing and building custom programmes'); editing = !editing; return draw(); }
    if (t('[data-swap]')) {
      const [si, ii] = t('[data-swap]').dataset.swap.split(':').map(Number), s = state.program.sessions[si], it = s.items[ii], ex = BY_ID[it.exId];
      return swapSheet(ex, (id) => { swapInProgram(s.id, ii, id); toast(`Swapped to ${BY_ID[id].name}`); }, { exclude: s.items.map((x) => x.exId) });
    }
    if (!editing) return;
    if (t('[data-save-prog]')) {
      if (state.programs.length >= 20) return toast('You can save up to 20 programmes', 'err');
      return sheet({ title: 'Save programme', html: `<form id="sp"><label class="field"><span class="lbl">Name</span><input class="input" name="n" maxlength="40" value="${esc(state.program.name)}" data-autofocus required></label><button class="btn primary block" type="submit">Save</button></form>`, onMount: (box, close) => box.querySelector('#sp').addEventListener('submit', (ev) => { ev.preventDefault(); const n = new FormData(ev.target).get('n').toString().trim().slice(0, 40); if (!n) return; mutate((st) => { st.programs.unshift({ id: uid(), name: n, savedAt: Date.now(), program: JSON.parse(JSON.stringify(st.program)) }); }); close(); toast('Programme saved'); }) });
    }
    if (t('[data-load-prog]')) { const x = state.programs.find((q) => q.id === t('[data-load-prog]').dataset.loadProg); if (!x) return; if (await confirmDialog({ title: `Use “${x.name}”?`, text: 'This replaces your current programme. Save it first if you want to keep it. Workout history is not affected.', confirm: 'Use programme' })) { mutate((st) => { st.program = { ...JSON.parse(JSON.stringify(x.program)), custom: true }; st.cursor = 0; }); toast('Programme loaded'); } return; }
    if (t('[data-del-prog]')) { const id = t('[data-del-prog]').dataset.delProg; if (await confirmDialog({ title: 'Delete saved programme?', text: 'Only the saved copy is deleted. Your current programme and history stay.', confirm: 'Delete', danger: true })) mutate((st) => { st.programs = st.programs.filter((q) => q.id !== id); }); return; }
    if (t('[data-scratch]')) { if (await confirmDialog({ title: 'Start an empty programme?', text: 'This replaces your current programme with one empty session. Save it first if you want to keep it. Workout history is not affected.', confirm: 'Start empty' })) mutate((st) => { st.program = { name: 'My programme', custom: true, sessions: [{ id: uid(), name: 'Session 1', items: [] }] }; st.cursor = 0; }); return; }
    const m = t('[data-move]'), rm = t('[data-rm]'), adj = t('[data-adj]'), add = t('[data-add]');
    if (m) { const [si, ii, d] = m.dataset.move.split(':').map(Number); mutate((st) => { const a = st.program.sessions[si].items; const j = ii + d; if (j >= 0 && j < a.length) [a[ii], a[j]] = [a[j], a[ii]]; st.program.custom = true; }); }
    else if (rm) { const [si, ii] = rm.dataset.rm.split(':').map(Number); mutate((st) => { st.program.sessions[si].items.splice(ii, 1); st.program.custom = true; }); }
    else if (adj) { const [si, ii, k, d] = adj.dataset.adj.split(':'); mutate((st) => { const it = st.program.sessions[+si].items[+ii], dd = +d; if (k === 'sets') it.sets = clamp(it.sets + dd, 1, 8); else if (k === 'rest') it.restSec = clamp(it.restSec + dd * 15, 15, 300); else { const step = repStep(BY_ID[it.exId]); if (k === 'lo') { it.repLo = clamp(it.repLo + dd * step, 1, 200); it.repHi = Math.max(it.repHi, it.repLo); } else { it.repHi = clamp(it.repHi + dd * step, 1, 200); it.repLo = Math.min(it.repLo, it.repHi); } } st.program.custom = true; }); }
    else if (add) { const si = +add.dataset.add; pickExercise((id) => { const ex = BY_ID[id]; mutate((st) => { st.program.sessions[si].items.push({ exId: id, ...prescribe(ex, st.profile.goal, st.profile.level, st.profile.style, false, { params: st.profile.params, goals2: st.profile.goals2 }) }); st.program.custom = true; }); }, { title: 'Add an exercise', recommended: true, exclude: state.program.sessions[si].items.map((x) => x.exId) }); }
    else if (t('[data-add-session]')) { mutate((st) => { st.program.sessions.push({ id: uid(), name: `Session ${st.program.sessions.length + 1}`, items: [] }); st.program.custom = true; }); }
    else if (t('[data-del-session]')) {
      const si = +t('[data-del-session]').dataset.delSession; if (state.program.sessions.length <= 1) return toast('A programme needs at least one session', 'err');
      if (await confirmDialog({ title: 'Delete this session?', text: 'The session is removed from your programme. Logged workouts are kept.', confirm: 'Delete', danger: true })) mutate((st) => { st.program.sessions.splice(si, 1); st.cursor = 0; st.program.custom = true; });
    }
  });
  root.addEventListener('change', (e) => {
    // The fields keep their own value, so skip the redraw: redrawing here would replace a button the person is in the middle of tapping.
    const quiet = (patch) => { keep = true; try { setExtras(patch); } finally { keep = false; } };
    const ex = e.target.closest('[data-extra]'); if (ex) return quiet({ [ex.dataset.extra]: ex.checked });
    if (e.target.closest('[data-extra-cardio]')) { quiet({ cardio: e.target.value }); e.target.value = state.settings.extras.cardio; return; }
    if (e.target.closest('[data-extra-cardio-id]')) return quiet({ cardioId: e.target.value });
    const nt = e.target.closest('[data-note]'); if (nt) return mutate((st) => { const v = nt.value.trim().slice(0, 300); if (v) st.program.sessions[+nt.dataset.note].note = v; else delete st.program.sessions[+nt.dataset.note].note; st.program.custom = true; }, { silent: true });
    const n = e.target.closest('[data-name]'); if (n) mutate((st) => { st.program.sessions[+n.dataset.name].name = n.value.trim().slice(0, 40) || 'Session'; st.program.custom = true; }, { silent: true }); });
  draw();
  const un = subscribe(() => { if (!keep && root.isConnected && !root.querySelector('input:focus')) draw(); });
  return un;
}
