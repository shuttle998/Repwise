import { state, subscribe, visibleSessions, hiddenCount, units, isPro, mutate, addWater, latestWeightKg } from '../store.js';
import * as NU from '../nutrition.js';
import { fmtDayLong, esc, fmtW, fmtVol, fmtDur, relDay, plural, fmtClock, dateKey, startOfWeek, addDays, DOW, kgToUnit } from '../util.js';
import { GOALS, GOAL_NAME, SPLITS, estMinutes, equipmentLabel } from '../generator.js';
import { BY_ID } from '../exercises.js';
import { icon, empty } from '../ui.js';
import { levelCard, challengesCard } from './rewards.js';
import { openInbox } from './reminders-ui.js';
import { nextPlanned, upcomingSessions, plannedDays } from '../schedule.js';
import { currentChallenges } from '../gamify.js';
import { ring, barChart, sparkline } from '../charts.js';
import { totals, weekStreak, weekDays, prEvents, topLifts, sessionVolume, sessionSets, recoveryInfo, weeklyReport } from '../analytics.js';
import { plannedFor, startWorkout, elapsedMs } from '../workout-logic.js';
import { coachInsights, recoveryReport, suggestToday, motivation } from '../insights.js';

export const title = 'Home';
const greet = () => { const h = new Date().getHours(); return h < 5 ? 'Late session' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'; };
const prText = (e, u) => e.kind === 'weight' ? `${fmtW(e.value, u, true)} × ${e.reps}` : e.kind === 'e1rm' ? `est. 1RM ${fmtW(e.value, u, true)}` : `${e.value} reps`;

const L = (ml) => (ml >= 1000 ? `${+(ml / 1000).toFixed(2)} L` : `${ml} ml`);
function nutCard(p) {
  const d = dateKey(), n = state.nutrition, w = state.water, tot = NU.dayTotals(NU.dayMeals(n, d)), pr = NU.dayProgress(tot, n.targets), ml = NU.waterDay(w, d), tg = NU.waterTarget(w, latestWeightKg(), state.sessions.some((s) => s.date === d));
  const set = Object.values(n.targets).some(Boolean);
  return `<section class="card" aria-label="Nutrition and water today"><div class="card-h"><h3>Nutrition and water</h3><a class="link" href="#/nutrition">Open</a></div>
    <div class="grid2"><a class="stat" href="#/nutrition"><span class="lbl">${icon('meal')} Calories</span><b>${Math.round(tot.kcal)}</b><span class="sub">${pr.kcal.target ? (pr.kcal.left >= 0 ? pr.kcal.left + ' left of ' + pr.kcal.target : Math.abs(pr.kcal.left) + ' over') : tot.count ? `${tot.count} meal${tot.count === 1 ? '' : 's'} logged` : set ? 'nothing logged yet' : 'tap to log meals'}</span></a>
    <a class="stat" href="#/nutrition/water"><span class="lbl">${icon('drop')} Water</span><b>${L(ml)}</b><span class="sub">${tg ? 'of ' + L(tg) : 'set a target'}</span></a></div>
    <button class="btn small block" style="margin-top:12px" data-water="${w.bottleMl}">${icon('drop')} Add ${w.bottleMl} ml of water</button></section>`;
}

function programCard(p, now) {
  const prog = state.program, sess = prog.sessions || [], up = upcomingSessions(state, 3, now), plan = new Set(plannedDays(state));
  const goals = [p.goal, ...(p.goals2 || [])].filter(Boolean).map((g) => GOAL_NAME?.[g] || GOALS[g]?.n).filter(Boolean);
  const focus = p.focusMuscles || [], split = SPLITS?.[p.split]?.n || SPLITS?.[p.split]?.name || '';
  const when = (u) => u.inDays === 0 ? 'Today' : u.inDays === 1 ? 'Tomorrow' : fmtDayLong(u.date);
  return `<section class="card" aria-label="Your programme"><div class="card-h"><h3>Your programme</h3><a class="link" href="#/train">Open</a></div>
    <p style="margin-bottom:8px"><b>${esc(prog.name || 'My programme')}</b><span class="mut"> · ${plural(sess.length, 'session')}${split ? ' · ' + esc(split) : ''}</span></p>
    <div class="chips" style="margin-bottom:12px">${goals.map((g) => `<span class="chip blue">${icon('target')} ${esc(g)}</span>`).join('')}${p.gear || p.equipment ? `<span class="chip">${esc(equipmentLabel(p))}</span>` : ''}</div>
    ${focus.length ? `<p class="lbl" style="margin-bottom:6px">Target muscles</p><div class="chips" style="margin-bottom:12px">${focus.map((m) => `<span class="chip">${esc(m)}</span>`).join('')}</div>` : ''}
    <p class="lbl" style="margin-bottom:6px">Upcoming sessions</p>
    ${up.length ? `<div class="list">${up.map((x) => `<div class="li"><div><div class="t">${esc(x.name)}</div><div class="s">${esc(when(x))} · ${plural(x.count, 'exercise')}</div></div></div>`).join('')}</div><p class="hint" style="margin-top:8px">Shown in programme order on your planned days (${[...plan].map((d) => DOW[d].slice(0, 3)).join(', ')}). Change days in <a class="link" href="#/calendar">Calendar</a>.</p>` : '<p class="mut">No planned days left. Pick training days in Calendar.</p>'}
  </section>`;
}

const unread = () => state.inbox.filter((n) => !n.read);
function noticeBar() {
  const u = unread(); if (!u.length) return '';
  return `<button class="banner" data-inbox style="margin-bottom:12px;width:100%;text-align:left"><span>${icon('trophy')} ${esc(u[0].title)}${u.length > 1 ? ` and ${u.length - 1} more` : ''}</span><span class="link">View</span></button>`;
}
function chalCard(now) {
  const c = currentChallenges(state, now).week, done = c.filter((x) => x.done).length, nx = nextPlanned(state, now);
  return `<section class="card" aria-label="Challenges and calendar"><div class="card-h"><h3>This week’s challenges</h3><a class="link" href="#/calendar">Calendar</a></div><div class="stack" style="gap:12px">${c.slice(0, 3).map((x) => `<div><div class="row sb" style="gap:10px"><span style="font-size:14.5px">${esc(x.title)}</span><span class="num mut" style="font-size:13px">${Math.min(x.value, x.target)}/${x.target}</span></div><div class="pbar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(x.pct * 100)}" aria-label="${esc(x.title)}"><i style="width:${x.pct * 100}%"></i></div></div>`).join('')}</div><p class="hint" style="margin-top:10px">${done} of ${c.length} complete.${nx ? ` Next planned session: ${nx.inDays === 0 ? 'today' : nx.inDays === 1 ? 'tomorrow' : esc(fmtDayLong(nx.date))}.` : ''}</p></section>`;
}

export default function dashboard(root, { go }) {
  const draw = () => {
    const p = state.profile, u = units(), now = new Date(), all = state.sessions, vis = visibleSessions(now);
    const tot = totals(all), st = weekStreak(all, p.days, now), days = weekDays(all, now);
    const wkDone = days.reduce((a, d) => a + d.workouts, 0), prs = prEvents(all);
    const next = state.program.sessions[state.cursor % state.program.sessions.length], a = state.active;
    const items = next.items.filter((i) => BY_ID[i.exId]);
    const muscles = [...new Set(items.flatMap((i) => BY_ID[i.exId].pm))];
    const rec = recoveryInfo(all, muscles, now);
    const lastWeek = weeklyReport({ sessions: all, profile: p, working: state.working }, addDays(startOfWeek(now), -7));
    const showReport = isPro() && lastWeek.hasData && state.ui.reportSeen !== lastWeek.key;
    const lifts = topLifts(vis, 4), mine = [...vis].sort((x, y) => (x.date < y.date ? 1 : x.date > y.date ? -1 : (y.startedAt || 0) - (x.startedAt || 0))).slice(0, 5);
    const useVol = days.some((d) => d.volume > 0);
    const ins = coachInsights(state, now), rr = recoveryReport(all, now), sug = suggestToday(all, state.program, state.cursor, now);
    const briefing = `<section class="card brief" aria-label="Daily briefing">
      <div class="card-h"><h3>Today’s briefing</h3><a class="link" href="#/coach">Ask the Coach</a></div>
      <p class="brief-line">${esc(motivation(all, p, now))}</p>
      ${sug?.alt && !a ? `<p class="note warn">${icon('alert')}<span>${esc(sug.reason)}</span></p><div class="row wrap" style="gap:8px;margin-bottom:14px"><button class="btn small primary" data-start-idx="${sug.idx}">Start ${esc(sug.name)} instead</button><span class="hint">or start ${esc(sug.planned)} below if you feel recovered</span></div>` : ''}
      <div class="insight ${ins[0].tone}"><b>${esc(ins[0].title)}</b><p>${esc(ins[0].text)}</p>${ins[0].href ? `<a class="link" href="${ins[0].href}">Open</a>` : ''}</div>
      ${ins.length > 1 ? `<details class="more"><summary>${ins.length - 1} more insight${ins.length > 2 ? 's' : ''}</summary>${ins.slice(1, 4).map((x) => `<div class="insight ${x.tone}"><b>${esc(x.title)}</b><p>${esc(x.text)}</p>${x.href ? `<a class="link" href="${x.href}">Open</a>` : ''}</div>`).join('')}</details>` : ''}
      ${rr.hasData ? `<div class="rec-sum"><span class="lbl">Recovery</span><div class="chips">${rr.recent.length ? rr.recent.map((r) => `<span class="chip warn">${esc(r.muscle)} · ${r.hours}h ago</span>`).join('') : '<span class="chip">Nothing trained in 48h</span>'}</div><p class="hint">${esc(rr.note)}${rr.restDay ? ' ' + esc(rr.restDay) : ''} ${rr.week} workout${rr.week === 1 ? '' : 's'} in the last 7 days (target ${p.days}).</p></div>` : ''}
    </section>`;

    root.innerHTML = `
      <div class="page-h"><h1>${greet()}${p.name ? ', ' + esc(p.name) : ''}</h1><p><span class="chip blue">${icon('target')} ${esc(GOALS[p.goal].n)}</span> <span class="chip">${p.days} days a week</span></p></div>
      ${showReport ? `<a class="banner" href="#/progress/report" style="margin-bottom:12px"><span>Your weekly report for ${esc(lastWeek.start.getDate() + ' ' + lastWeek.start.toLocaleString('en', { month: 'short' }))} is ready.</span><span class="link">View</span></a>` : ''}
      ${noticeBar()}
      ${briefing}
      <div class="cols"><div class="stack">
        <section class="card hero-card" aria-label="Upcoming workout">
          <div class="row sb wrap"><span class="lbl">${a ? 'Workout in progress' : 'Up next'}</span><span class="chip">${plural(items.length, 'exercise')} · about ${estMinutes(items) + 5} min</span></div>
          <h2>${esc(a ? a.name : next.name)}</h2>
          <ul class="exlist">${items.slice(0, 5).map((it) => { const pl = plannedFor(it.exId, it), ex = BY_ID[it.exId]; return `<li><span>${esc(ex.name)}</span><span class="num">${it.sets} × ${it.repLo === it.repHi ? it.repLo : it.repLo + '–' + it.repHi}${pl.loaded ? ' · ' + fmtW(pl.weight, u, true) : ex.unit === 'sec' ? 's' : ''}</span></li>`; }).join('')}${items.length > 5 ? `<li><span class="mut">+ ${items.length - 5} more</span><span></span></li>` : ''}</ul>
          ${rec && !a ? `<p class="note ${rec.level === 'caution' ? 'warn' : ''}" style="margin-bottom:14px">${icon(rec.level === 'caution' ? 'alert' : 'check')}<span>${esc(rec.text)}</span></p>` : ''}
          <button class="btn primary block" data-start>${a ? `${icon('play')} Resume workout · <span class="num">${fmtClock(elapsedMs() / 1000)}</span>` : `${icon('play')} Start workout`}</button>
        </section>

        <section class="card" aria-label="This week">
          <div class="card-h"><h3>This week</h3><span class="lbl">${wkDone} of ${p.days} workouts</span></div>
          <div class="row" style="gap:18px">${ring(Math.min(wkDone, p.days), p.days, { size: 96, stroke: 9, label: `${wkDone}/${p.days}`, sub: 'done' })}
          <div class="wdots">${days.map((d, i) => `<div class="wd ${d.workouts ? 'on' : ''} ${d.today ? 'today' : ''}"><i>${d.workouts ? icon('check') : ''}</i>${DOW[i][0]}<span class="sr-only">${DOW[i]}${d.workouts ? ' trained' : ''}</span></div>`).join('')}</div></div>
        </section>

        <section class="card" aria-label="Weekly activity">
          <div class="card-h"><h3>Weekly activity</h3><span class="lbl">${useVol ? 'Volume lifted per day' : 'Sets per day'}</span></div>
          ${wkDone ? `<div id="wk-chart"></div>` : empty('No workouts yet this week', 'Finish a workout and your activity appears here.')}
        </section>

        <section class="card" aria-label="Strength progression">
          <div class="card-h"><h3>Strength progression</h3><a class="link" href="#/progress">Details</a></div>
          ${lifts.length ? `<div class="list">${lifts.map((l) => `<a class="li" href="#/progress?ex=${l.exId}"><div><div class="t">${esc(l.name)}</div><div class="s">${l.loaded ? 'Estimated 1RM' : 'Best set (reps)'}: <span class="num">${l.loaded ? fmtW(l.last, u, true) : l.last}</span></div></div><div class="row" style="gap:10px">${sparkline(l.series.map((s) => s.y))}<span class="num ${l.delta >= 0 ? 'up' : 'down'}" style="min-width:58px;text-align:right">${l.delta >= 0 ? '+' : '−'}${Math.abs(l.pct).toFixed(0)}%</span></div></a>`).join('')}</div>` : empty('Progression shows up after two sessions', 'Log the same lift in two workouts and you will see how your estimated one-rep max is moving.')}
        </section>
      </div>

      <div class="stack">
        <div class="grid2">
          <div class="stat"><span class="lbl">${icon('check')} Workouts</span><b>${tot.workouts}</b><span class="sub">total completed</span></div>
          <div class="stat"><span class="lbl">${icon('flame')} Streak</span><b>${st.current}</b><span class="sub">${st.current === 1 ? 'week' : 'weeks'} hitting target</span></div>
          <div class="stat"><span class="lbl">${icon('dumbbell')} Volume</span><b>${fmtVol(tot.volume, u).split(' ')[0]}</b><span class="sub">${esc(fmtVol(tot.volume, u).split(' ')[1] || u)} lifted</span></div>
          <a class="stat" href="#/progress/records"><span class="lbl">${icon('trophy')} Records</span><b>${prs.length}</b><span class="sub">personal records</span></a>
        </div>
        ${programCard(p, now)}
        ${levelCard(state, now, { link: true })}
        ${chalCard(now)}
        ${nutCard(p)}
        <section class="card" aria-label="Recent records">
          <div class="card-h"><h3>Recent records</h3><a class="link" href="#/progress/records">All</a></div>
          ${prs.length ? `<div class="list">${prs.slice(-3).reverse().map((e) => `<div class="li"><div><div class="t">${esc(e.name)}</div><div class="s">${relDay(e.date)}</div></div><span class="pr">${icon('trophy')} ${esc(prText(e, u))}</span></div>`).join('')}</div>` : empty('No records yet', 'Beat a previous weight or estimated max and it shows up here.')}
        </section>
        <section class="card" aria-label="Recent workouts">
          <div class="card-h"><h3>Recent workouts</h3></div>
          ${mine.length ? `<div class="list">${mine.map((s) => `<div class="li"><div><div class="t">${esc(s.name)}</div><div class="s">${relDay(s.date)}${s.durationSec ? ' · ' + fmtDur(s.durationSec) : ''}</div></div><div class="r">${s.legacy ? '<span class="mut">No details</span>' : `${sessionSets(s)} sets<br><span class="mut">${esc(fmtVol(sessionVolume(s), u))}</span>`}</div></div>`).join('')}</div>${hiddenCount() ? `<p class="hint" style="margin-top:10px">${plural(hiddenCount(), 'older workout')} saved. Free shows the last 30 days. <a class="link" href="#/pricing">See Pro</a></p>` : ''}` : empty('Your history starts here', 'Finish your first workout and it will be logged automatically.')}
        </section>
      </div></div>`;
    const host = root.querySelector('#wk-chart');
    if (host) barChart(host, { items: days.map((d) => ({ label: DOW[days.indexOf(d)], value: useVol ? Math.round(kgToUnit(d.volume, u)) : d.sets, title: DOW[days.indexOf(d)], sub: `${plural(d.workouts, 'workout')} · ${d.sets} sets`, hi: d.today })), yFmt: undefined, height: 170, aria: useVol ? `Volume lifted per day this week in ${u}` : 'Sets per day this week', minLabelGap: 20 });
  };
  root.addEventListener('click', (e) => {
    if (e.target.closest('[data-inbox]')) return openInbox(draw);
    const wb = e.target.closest('[data-water]'); if (wb) { addWater(dateKey(), +wb.dataset.water); return; }
    const alt = e.target.closest('[data-start-idx]');
    if (alt) { if (!state.active) startWorkout(+alt.dataset.startIdx); return go('workout'); }
    if (!e.target.closest('[data-start]')) return;
    if (!state.active) startWorkout(state.cursor % state.program.sessions.length);
    go('workout');
  });
  draw();
  const un = subscribe(() => { if (root.isConnected) draw(); });
  return un;
}
