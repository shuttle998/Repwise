import { state, visibleSessions, hiddenCount, units, isPro } from '../store.js';
import { monthGrid, plannedDays, nextPlanned } from '../schedule.js';
import { esc, fmtDayLong, fmtDur, fmtVol, plural, dateKey, DOW, parseKey, relDay } from '../util.js';
import { sessionSets, sessionVolume, doneItems } from '../analytics.js';
import { icon } from '../ui.js';
import { openReminders } from './reminders-ui.js';
import { activityLine, openDevices } from './devices-ui.js';
import { importedOnly, classesOn, classesOf, upcomingClasses, unmarkedClasses, classLine } from '../classes.js';
import { classButtons, classClick } from './classes-ui.js';

export const title = 'Calendar';
const LABEL = { done: 'Trained', missed: 'Missed', upcoming: 'Planned', today: 'Planned today', rest: 'Rest day', madeup: 'Made up', before: 'Before you started' };

export default function calendar(root, { params }) {
  const now = new Date(), q = params[0] && /^\d{4}-\d{2}$/.test(params[0]) ? params[0] : null;
  let y = q ? +q.slice(0, 4) : now.getFullYear(), m = q ? +q.slice(5) - 1 : now.getMonth(), sel = dateKey(now);
  const view = () => ({ ...state, sessions: visibleSessions(now) });
  const upBlock = (todayK) => {
    const miss = unmarkedClasses(state, todayK).slice(0, 3), up = upcomingClasses(state, todayK, 4); if (!miss.length && !up.length) return '';
    const row = (c) => `<div class="li" style="flex-wrap:wrap"><div style="min-width:0"><div class="t">${esc(c.label)}${c.studio ? ' at ' + esc(c.studio) : ''}</div><div class="s">${esc(fmtDayLong(c.date))}${c.time ? ' at ' + esc(c.time) : ''}</div>${classButtons(c, todayK)}</div></div>`;
    return `<section class="card" style="margin-bottom:12px" aria-label="Booked classes">${miss.length ? `<h3>Did you go?</h3><p class="mut" style="margin-bottom:8px">These booked classes have passed. They only count once you mark them as done.</p><div class="list">${miss.map(row).join('')}</div>` : ''}${up.length ? `<h3${miss.length ? ' style="margin-top:14px"' : ''}>Booked classes</h3><div class="list">${up.map(row).join('')}</div>` : ''}</section>`;
  };
  const draw = () => {
    const actDays = new Set(importedOnly(state.activities).map((a) => a.date)), clsDays = new Set(classesOf(state.activities).map((c) => c.date)), todayK = dateKey(now), g = monthGrid(view(), y, m, now), u = units(), st = view(), cells = g.weeks.flatMap((w) => w.cells), cur = cells.find((c) => c.date === sel) || cells.find((c) => c.inMonth), nx = nextPlanned(st, now);
    const label = new Date(y, m, 1).toLocaleString('en', { month: 'long', year: 'numeric' }), isNow = y === now.getFullYear() && m === now.getMonth();
    const acts = (k) => importedOnly(state.activities).filter((a) => a.date === k);
    const clsHTML = (k) => { const l = classesOn(state, k); return `<h3 style="margin-top:14px">Classes</h3>${l.length ? `<div class="list">${l.map((c) => `<div class="li" style="flex-wrap:wrap"><div style="min-width:0"><div class="t">${esc(c.label)}${c.studio ? ' at ' + esc(c.studio) : ''} <span class="chip">${c.status === 'booked' ? (c.date < todayK ? 'Not marked' : 'Booked') : 'Done'}</span></div><div class="s">${esc(classLine({ ...c, label: '', studio: '' }).replace(/^( · )+/, ''))}${c.note ? '<br>' + esc(c.note) : ''}</div>${classButtons(c, todayK)}</div></div>`).join('')}</div>` : '<p class="mut">No class on this day.</p>'}<div class="btn-row" style="margin-top:10px;gap:8px;flex-wrap:wrap">${k <= todayK ? `<button class="btn small" data-cl-add="${k}" data-cl-status="done">${icon('plus')} Log a class</button>` : ''}${k >= todayK ? `<button class="btn small" data-cl-add="${k}" data-cl-status="booked">${icon('plus')} Book a class</button>` : ''}</div>`; };
    const actHTML = (k) => (acts(k).length ? `<h3 style="margin-top:14px">Imported activity</h3><div class="list">${acts(k).map((a) => `<div class="li"><div><div class="t">${esc(a.label || a.type)}</div><div class="s">${esc(activityLine(a))}</div></div></div>`).join('')}</div><p class="hint">Imported activities do not count towards streaks or challenges.</p>` : '');
    const detail = (c) => (detailMain(c) + clsHTML(c.date) + actHTML(c.date));
    const detailMain = (c) => {
      const ws = c.workouts || [];
      if (ws.length) return `<h3>${esc(fmtDayLong(c.date))}</h3><div class="list">${ws.map((s) => { const names = doneItems(s).map((i) => i.name).slice(0, 4); return `<div class="li"><div><div class="t">${esc(s.name)}</div><div class="s">${esc(names.join(', '))}${doneItems(s).length > 4 ? ' and more' : ''}</div></div><div class="r">${s.legacy ? '<span class="mut">No details</span>' : `${plural(sessionSets(s), 'set')}<br><span class="mut">${s.durationSec ? fmtDur(s.durationSec) + ' · ' : ''}${esc(fmtVol(sessionVolume(s), u))}${s.hr ? ` · ${s.hr.avg} bpm` : ''}</span>`}</div></div>`; }).join('')}</div>`;
      const msg = { missed: 'This was a planned training day with no workout logged.', madeup: 'You skipped this planned day but trained on another day that week, so it does not count as missed.', upcoming: 'A training day is planned for this date.', today: 'A training day is planned for today.', rest: 'Nothing planned. Rest is part of the plan.', before: 'This is before you started using Repwise.' }[c.status];
      const old = c.date < dateKey(new Date(now.getTime() - 30 * 864e5)) && hiddenCount() && !isPro() ? ' Free shows the last 30 days of workouts, so older days may be incomplete.' : '';
      return `<h3>${esc(fmtDayLong(c.date))}</h3><p class="mut">${esc(msg)}${old}</p>`;
    };
    root.innerHTML = `<div class="page-h"><h1>Calendar</h1><p>${nx ? `Next planned session: <b>${esc(nx.inDays === 0 ? 'today' : nx.inDays === 1 ? 'tomorrow' : fmtDayLong(nx.date))}</b>.` : 'Choose your training days to see them here.'} Planned days: ${plannedDays(state).map((i) => DOW[i]).join(', ')}.</p></div>
    <section class="card cal" aria-label="Workout calendar"><div class="row sb cal-h"><button class="btn small" data-nav="-1" aria-label="Previous month">${icon('right', 'flip')}</button><h2 aria-live="polite">${esc(label)}</h2><button class="btn small" data-nav="1" aria-label="Next month">${icon('right')}</button></div>
      <div class="cal-g" role="grid" aria-label="${esc(label)}"><div class="cal-r cal-dow" role="row">${DOW.map((d) => `<span role="columnheader">${d[0]}<span class="sr-only">${d.slice(1)}</span></span>`).join('')}<span class="wk" role="columnheader">Wk</span></div>
      ${g.weeks.map((w) => `<div class="cal-r" role="row">${w.cells.map((c) => `<button role="gridcell" class="cal-c ${c.status} ${c.inMonth ? '' : 'out'} ${c.date === cur.date ? 'sel' : ''} ${c.planned ? 'plan' : ''} ${actDays.has(c.date) || clsDays.has(c.date) ? 'act' : ''}" data-d="${c.date}" aria-label="${esc(fmtDayLong(c.date) + ': ' + LABEL[c.status])}" aria-pressed="${c.date === cur.date}"><span>${c.day}</span></button>`).join('')}<span class="wk num ${w.hit ? 'hit' : ''}" role="gridcell" aria-label="${w.done} of ${w.target} workouts this week">${w.done}/${w.target}</span></div>`).join('')}</div>
      <div class="cal-leg"><span><i class="done"></i>Trained</span><span><i class="upcoming"></i>Planned</span><span><i class="missed"></i>Missed</span><span><i class="rst"></i>Rest</span></div>
      ${isNow ? '' : `<button class="btn small" data-today style="margin-top:12px">Back to this month</button>`}</section>
    <div class="grid2" style="margin:12px 0"><div class="stat"><span class="lbl">${icon('check')} Trained</span><b>${g.totals.done}</b><span class="sub">days this month</span></div><div class="stat"><span class="lbl">${icon('target')} Weeks on target</span><b>${g.totals.weeksHit}</b><span class="sub">of ${g.weeks.filter((w) => w.cells.some((c) => c.inMonth)).length} weeks</span></div></div>
    ${upBlock(todayK)}
    <section class="card" aria-label="Selected day" aria-live="polite">${detail(cur)}</section>
    <div class="row wrap" style="gap:8px;margin-top:12px"><button class="btn small" data-rem>${icon('timer')} Reminders and planned days</button><button class="btn small" data-dev>${icon('heart')} Health and devices</button></div>`;
  };
  root.addEventListener('click', (e) => {
    const t = (s) => e.target.closest(s);
    if (t('[data-nav]')) { const d = new Date(y, m + +t('[data-nav]').dataset.nav, 1); y = d.getFullYear(); m = d.getMonth(); sel = ''; return draw(); }
    if (t('[data-today]')) { y = now.getFullYear(); m = now.getMonth(); sel = dateKey(now); return draw(); }
    if (t('[data-d]')) { sel = t('[data-d]').dataset.d; const d = parseKey(sel); if (d.getMonth() !== m) { y = d.getFullYear(); m = d.getMonth(); } draw(); return root.querySelector(`[data-d="${sel}"]`)?.focus(); }
    if (classClick(e, draw)) return;
    if (t('[data-rem]')) return openReminders(draw);
    if (t('[data-dev]')) return openDevices(draw);
  });
  draw();
}
