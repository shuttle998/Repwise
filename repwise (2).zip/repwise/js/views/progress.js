import { state, mutate, visibleSessions, units, isPro, can } from '../store.js';
import { esc, fmtW, fmtVol, fmtDay, fmtDayLong, relDay, plural, kgToUnit, dateKey, startOfWeek, addDays, parseKey, sum, fmtDur, MONTHS } from '../util.js';
import { BY_ID } from '../exercises.js';
import { VOLUME_RANGE } from '../generator.js';
import { icon, empty, lockCard, proBadge, upgradePrompt, seg } from '../ui.js';
import { lineChart, barChart, hbars, ring } from '../charts.js';
import * as A from '../analytics.js';
import bodyView from './body.js';
import { levelCard, challengesCard, xpExplain } from './rewards.js';
import reportView from './report.js';

export const title = 'Progress';
let period = 30, metric = 'e1rm', exSel = null, fEx = '', fMus = '', gran = 'auto', cust = { from: '', to: '' };
const TABS = [['', 'Analytics'], ['records', 'Records'], ['achievements', 'Achievements'], ['body', 'Body'], ['report', 'Report']];
const yearOf = (k) => k.slice(0, 4);
const prLabel = (e, u) => e.kind === 'weight' ? `${fmtW(e.value, u, true)} × ${e.reps}` : e.kind === 'e1rm' ? `est. 1RM ${fmtW(e.value, u, true)}` : `${e.value} reps`;

export default function progress(root, { params }) {
  const sub = params[0] || '';
  const q = new URLSearchParams((location.hash.split('?')[1]) || '');
  if (q.get('ex') && BY_ID[q.get('ex')]) exSel = q.get('ex');
  const u = units(), now = new Date();
  const tabs = `<nav class="tabs" aria-label="Progress sections">${TABS.map(([k, l]) => `<a href="#/progress${k ? '/' + k : ''}" ${k === sub ? 'aria-current="page"' : ''}>${l}${k === 'report' && !isPro() ? proBadge() : ''}</a>`).join('')}</nav>`;
  root.innerHTML = `<div class="page-h"><h1>Progress</h1><p>Everything here is calculated from the workouts you have logged.</p></div>${tabs}<div id="pane"></div>`;
  const pane = root.querySelector('#pane');
  root.querySelector('.tabs [aria-current]')?.scrollIntoView({ inline: 'center', block: 'nearest' });
  const views = { '': analytics, records, achievements, report, body: () => bodyView(pane) };
  const off = (views[sub] || analytics)();
  return typeof off === 'function' ? off : undefined;

  // ---------------- analytics ----------------
  function analytics() {
    const vis = visibleSessions(now);
    if (!state.sessions.length) { pane.innerHTML = empty('No data yet', 'Finish your first workout and your charts will appear here. Nothing on this page is placeholder data.', '<a class="btn primary" href="#/train">Go to training</a>'); return; }
    const draw = () => {
      const isCust = !!(cust.from || cust.to), days = period;
      const base = isCust ? A.filterSessions(vis, { from: cust.from || null, to: cust.to || null }) : A.rangeFilter(vis, days, now);
      const fs = A.filterSessions(base, { exId: fEx || null, muscle: fMus || null }), filtered = !!(fEx || fMus);
      const firstKey = base.map((x) => x.date).sort()[0];
      const startD = isCust ? (cust.from ? parseKey(cust.from) : firstKey ? parseKey(firstKey) : now) : days === Infinity ? (firstKey ? parseKey(firstKey) : now) : addDays(parseKey(dateKey(now)), -(days - 1));
      const endD = isCust && cust.to ? parseKey(cust.to) : now;
      const spanDays = Math.max(1, Math.round((endD - startD) / 864e5) + 1);
      const tot = A.totals(fs), all = A.totals(base), reps = sum(fs.flatMap((x) => (x.items || []).filter((i) => !i.skipped).flatMap((i) => (i.sets || []).map((q) => q.reps || 0))));
      const perWeek = tot.workouts ? tot.workouts / Math.max(1, spanDays / 7) : 0;
      let g = gran === 'auto' ? undefined : gran; const forced = g === 'day' && spanDays > 100; if (forced) g = 'week';
      const bopt = { gran: g, ...(isCust ? { from: startD, to: endD } : {}) };
      const bk = A.buckets(fs, isCust ? Infinity : days, now, bopt), useVol = bk.items.some((b) => b.volume > 0);
      const freq = A.buckets(base, isCust ? Infinity : days, now, { ...bopt, gran: g || (spanDays <= 7 ? 'day' : 'week') });
      const dur = A.buckets(base, isCust ? Infinity : days, now, bopt), hasDur = dur.items.some((b) => b.seconds > 0);
      const cons = A.consistency(vis, state.profile.days, startD, endD, now);
      const exs = A.records(fs).filter((r) => r.sessions >= 1), allEx = A.records(base);
      if (fEx) exSel = fEx; else if (!exSel || !exs.find((r) => r.exId === exSel)) exSel = exs[0]?.exId || null;
      const pdisp = (d) => seg('period', [[7, '7d'], [30, '30d'], [90, '90d', can('longPeriods') ? '' : icon('lock')], [365, '1y', can('longPeriods') ? '' : icon('lock')], ['all', 'All', can('longPeriods') ? '' : icon('lock')]], isCust ? '' : d === Infinity ? 'all' : d);
      const active = filtered || isCust || gran !== 'auto';
      pane.innerHTML = `<div class="row sb wrap" style="margin-bottom:12px">${pdisp(days)}</div>
        <details class="card flat filt" style="padding:6px 16px;margin-bottom:14px" ${active ? 'open' : ''}><summary class="row sb" style="min-height:44px;cursor:pointer"><b>Filters</b><span class="mut" style="font-size:13.5px">${[fEx && BY_ID[fEx]?.name, fMus && A.muscleLabel(fMus), isCust && 'Custom dates', gran !== 'auto' && 'By ' + gran].filter(Boolean).join(' · ') || 'None'}</span></summary>
          <div class="grid-fit" style="padding:8px 0 14px">
            <label class="fld"><span class="lbl">Exercise</span><select class="input" id="f-ex"><option value="">All exercises</option>${allEx.sort((x, y) => x.name.localeCompare(y.name)).map((r) => `<option value="${r.exId}" ${r.exId === fEx ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}</select></label>
            <label class="fld"><span class="lbl">Muscle group${can('muscleDistribution') ? '' : ' (Pro)'}</span><select class="input" id="f-mus"><option value="">All muscles</option>${A.ANALYTIC_MUSCLES.map((m) => `<option value="${m}" ${m === fMus ? 'selected' : ''}>${A.muscleLabel(m)}</option>`).join('')}</select></label>
            <label class="fld"><span class="lbl">Group by</span><select class="input" id="f-gran">${[['auto', 'Automatic'], ['day', 'Day'], ['week', 'Week'], ['month', 'Month']].map(([v, l]) => `<option value="${v}" ${v === gran ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
            <label class="fld"><span class="lbl">From</span><input class="input" type="date" id="f-from" value="${cust.from}" max="${dateKey(now)}"></label>
            <label class="fld"><span class="lbl">To</span><input class="input" type="date" id="f-to" value="${cust.to}" max="${dateKey(now)}"></label>
          </div>${active ? '<button class="btn small" data-reset>Reset filters</button>' : ''}${forced ? '<p class="hint" style="margin-top:8px">Day view is limited to 100 days, so this range is grouped by week.</p>' : ''}<p class="hint" style="margin:8px 0">With an exercise or muscle filter, volume, sets and frequency count only that work. Duration and consistency always use whole workouts.</p></details>
        <div class="grid-fit" style="margin-bottom:14px">
          <div class="stat"><span class="lbl">${filtered ? 'Sessions' : 'Workouts'}</span><b>${tot.workouts}</b><span class="sub">${perWeek ? perWeek.toFixed(1) + ' per week' : 'in this period'}</span></div>
          <div class="stat"><span class="lbl">Volume</span><b>${esc(fmtVol(tot.volume, u).split(' ')[0])}</b><span class="sub">${esc(fmtVol(tot.volume, u).split(' ')[1] || u)}</span></div>
          <div class="stat"><span class="lbl">Sets</span><b>${tot.sets}</b><span class="sub">${reps} reps</span></div>
          <div class="stat"><span class="lbl">Time</span><b style="font-size:22px">${all.seconds ? fmtDur(all.seconds) : '–'}</b><span class="sub">${all.seconds && all.workouts ? 'avg ' + fmtDur(Math.round(all.seconds / base.filter((x) => x.durationSec).length || 1)) : 'training'}</span></div>
          <div class="stat"><span class="lbl">Consistency</span><b>${cons.weeks ? Math.round(cons.pct * 100) + '%' : '–'}</b><span class="sub">${cons.weeks ? `${cons.met} of ${plural(cons.weeks, 'week')} on target` : 'no full weeks yet'}</span></div>
        </div>
        ${!isPro() && state.sessions.length > vis.length ? `<div class="banner warn" style="margin-bottom:14px"><span>Free shows the last 30 days. ${plural(state.sessions.length - vis.length, 'older workout')} stay saved.</span><a class="link" href="#/pricing">See Pro</a></div>` : ''}
        <div class="stack">
        <section class="card"><div class="card-h"><h3>Training volume</h3><span class="lbl">${useVol ? `${u} lifted per ${bk.gran}` : `sets per ${bk.gran}`}</span></div>${tot.workouts ? '<div id="c-vol"></div>' : empty('Nothing matches', filtered ? 'No logged work for this filter in the selected dates. Try another range or reset the filters.' : 'Try a longer period, or log a workout.')}</section>
        <section class="card"><div class="card-h"><h3>Workout frequency</h3><span class="lbl">Workouts per ${freq.gran}${freq.gran === 'week' ? ' · line is your target' : ''}</span></div>${base.length ? '<div id="c-freq"></div>' : empty('Nothing to show yet', 'Your weekly rhythm appears after your first workouts.')}</section>
        <section class="card"><div class="card-h"><h3>Workout duration</h3><span class="lbl">Minutes trained per ${dur.gran}</span></div>${hasDur ? '<div id="c-dur"></div>' : empty('No durations yet', 'Workouts logged with the timer record how long they took.')}</section>
        <section class="card"><div class="card-h"><h3>Strength progression</h3>${exs.length ? `<select class="input" id="exsel" aria-label="Exercise" style="max-width:220px;min-height:40px" ${fEx ? 'disabled' : ''}>${exs.map((r) => `<option value="${r.exId}" ${r.exId === exSel ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}</select>` : ''}</div>
          ${exSel ? `<div class="row wrap" style="margin-bottom:12px">${seg('metric', [['top', 'Top set'], ['e1rm', 'Estimated 1RM', can('exerciseAnalytics') ? '' : icon('lock')]], metric)}</div><div id="c-ex"></div><div id="ex-note" class="hint" style="margin-top:8px"></div>` : empty('No exercise data in this period', 'Log a lift to chart it.')}</section>
        ${can('exerciseAnalytics') && exSel ? `<section class="card"><div class="card-h"><h3>Exercise history</h3><span class="lbl">${esc(BY_ID[exSel].name)}</span></div><div id="hist"></div></section>` : exSel ? lockCard('Exercise history', 'See every session for a lift: sets, weights, reps and how it felt.') : ''}
        ${can('muscleDistribution') ? `<section class="card"><div class="card-h"><h3>Muscle groups</h3><span class="lbl">Sets${isCust || days === Infinity ? '' : ' · vs previous ' + days + ' days'}</span></div><div id="mus"></div></section>` : lockCard('Muscle group analytics', 'See sets per muscle, weekly volume, change over time and which muscles may be getting too little work.')}
        ${can('muscleDistribution') ? '<section class="card"><div class="card-h"><h3>Muscle training consistency</h3><span class="lbl">Last 4 weeks</span></div><div id="mfreq"></div></section>' : ''}
        </div>`;
      // charts
      const lbl = (b, gr) => (gr === 'week' ? 'Week of ' + b.label : b.label);
      if (tot.workouts) barChart(pane.querySelector('#c-vol'), { items: bk.items.map((b) => ({ label: b.label, value: useVol ? Math.round(kgToUnit(b.volume, u)) : b.sets, title: lbl(b, bk.gran), sub: `${plural(b.workouts, 'workout')} · ${b.sets} sets` })), aria: `${useVol ? 'Volume' : 'Sets'} per ${bk.gran}`, height: 190 });
      if (base.length) barChart(pane.querySelector('#c-freq'), { items: freq.items.map((b) => ({ label: b.label, value: b.workouts, title: lbl(b, freq.gran), sub: plural(b.workouts, 'workout') })), aria: `Workouts per ${freq.gran}`, height: 160, ref: freq.gran === 'week' ? { value: state.profile.days, label: `Target ${state.profile.days}` } : null });
      if (hasDur) barChart(pane.querySelector('#c-dur'), { items: dur.items.map((b) => ({ label: b.label, value: Math.round(b.seconds / 60), title: lbl(b, dur.gran), sub: `${plural(b.workouts, 'workout')}${b.workouts && b.seconds ? ' · avg ' + Math.round(b.seconds / 60 / b.workouts) + ' min' : ''}` })), aria: `Minutes trained per ${dur.gran}`, height: 160 });
      if (exSel) {
        const useE = metric === 'e1rm' && can('exerciseAnalytics'), loaded = BY_ID[exSel]?.unit === 'kg';
        const series = loaded ? (useE ? A.e1rmSeries(fs, exSel) : A.topSetSeries(fs, exSel)) : A.e1rmSeries(fs, exSel);
        const fmtY = loaded ? (v) => fmtW(v, u) : (v) => String(Math.round(v));
        const host = pane.querySelector('#c-ex');
        if (series.length) lineChart(host, { points: series.map((x) => ({ x: parseKey(x.date).getTime(), y: loaded ? kgToUnit(x.y, u) : x.y, title: fmtDayLong(x.date), sub: loaded ? (useE ? `${fmtW(x.w, u, true)} × ${x.reps}` : `${x.reps} reps`) : '' })), yFmt: (v) => String(+v.toFixed(1)), aria: `${BY_ID[exSel].name} ${loaded ? (useE ? 'estimated one-rep max' : 'top set weight') : 'best reps'} over time`, height: 220, yMin: 'auto' });
        const first = series[0], last = series[series.length - 1];
        pane.querySelector('#ex-note').textContent = series.length > 1 ? `${loaded ? (useE ? 'Estimated 1RM' : 'Top set') : 'Best set'} ${loaded ? fmtW(first.y, u, true) : first.y} → ${loaded ? fmtW(last.y, u, true) : last.y} across ${plural(series.length, 'session')}.` : series.length === 1 ? 'One session logged. Train it again to see a trend.' : '';
        const h = pane.querySelector('#hist');
        if (h) h.innerHTML = `<div class="list">${A.exerciseSessions(fs, exSel).slice(0, 12).map((x) => `<div class="li"><div><div class="t">${fmtDayLong(x.date)}</div><div class="s">${x.feedback ? 'Felt: ' + esc({ easy: 'too easy', good: 'just right', hard: 'hard', too_hard: 'too hard' }[x.feedback]) : 'No feedback'}</div></div><div class="r">${x.sets.map((q) => (q.w > 0 ? `${fmtW(q.w, u)}×${q.reps}` : `${q.reps}`)).join('<br>')}</div></div>`).join('')}</div>`;
      }
      const mf = pane.querySelector('#mfreq');
      if (mf) {
        const rows = A.muscleFrequency(vis, now, 4), hyp = ['muscle', 'gain'].includes(state.profile.goal) || state.profile.split === 'hypertrophy';
        mf.innerHTML = rows.length ? `<ul class="mfreq">${rows.map((x) => `<li><div><b>${esc(A.muscleLabel(x.muscle))}</b><div class="s">${x.weeksTrained} of ${x.weeks} weeks · ${x.perWeek.toFixed(1)} a week · last ${x.last ? esc(relDay(x.last)) : 'never'}</div></div>${hyp ? `<span class="chip ${x.setsThisWeek < VOLUME_RANGE.lo ? '' : x.setsThisWeek > VOLUME_RANGE.hi ? 'warn' : 'blue'}" title="Sets this week against the ${VOLUME_RANGE.lo}–${VOLUME_RANGE.hi} guide">${+x.setsThisWeek.toFixed(1)} sets</span>` : ''}</li>`).join('')}</ul><p class="hint" style="margin-top:10px">Counted from sets you logged, with the muscle as the main target. ${hyp ? `The chip shows this week's sets against the common ${VOLUME_RANGE.lo}–${VOLUME_RANGE.hi} hard sets per muscle guide (secondary work counts half; blue is within it). It is a guide, not a rule, and the week is part-way through until Sunday.` : 'Muscles missing from the list had no logged sets in this window.'}</p>` : '<p class="mut">No logged sets in the last 4 weeks.</p>';
      }
      const mus = pane.querySelector('#mus');
      if (mus) {
        const mbase = A.filterSessions(base, { exId: fEx || null }), rows = (isCust || days === Infinity) ? A.muscleDistribution(mbase).map((x) => ({ muscle: x.muscle, sets: x.sets, perWeek: x.sets / Math.max(1, spanDays / 7), prev: null, change: null })) : A.muscleTrend(A.filterSessions(vis, { exId: fEx || null }), days, now);
        const total = sum(rows.map((x) => x.sets)), max = Math.max(1, ...rows.map((x) => x.sets)), ng = A.neglectedMuscles(vis, now);
        mus.innerHTML = total ? `<div class="tbl-wrap"><table class="tbl mus"><thead><tr><th scope="col">Muscle</th><th scope="col">Sets</th><th scope="col">Per week</th><th scope="col">${rows[0].prev == null ? 'Share' : 'Change'}</th></tr></thead><tbody>${rows.map((x) => `<tr><th scope="row"><button class="linkbtn" data-musf="${x.muscle}" aria-pressed="${fMus === x.muscle}">${esc(A.muscleLabel(x.muscle))}</button><i class="mbar" style="width:${Math.round((x.sets / max) * 100)}%"></i></th><td class="num">${+x.sets.toFixed(1)}</td><td class="num">${x.perWeek.toFixed(1)}</td><td class="num">${x.prev == null ? Math.round((x.sets / total) * 100) + '%' : x.change === 0 ? '–' : (x.change > 0 ? '+' : '−') + Math.abs(+x.change.toFixed(1))}</td></tr>`).join('')}</tbody></table></div>
          <p class="hint" style="margin-top:10px">Secondary muscles count as half a set. Forearms are only worked indirectly, so treat that row as a rough guide. Tap a muscle to filter the charts above.</p>
          ${ng.enough ? (ng.muscles.length ? `<p class="note warn" style="margin-top:12px">${icon('alert')}<span>Over the last 4 weeks ${ng.muscles.map((m) => A.muscleLabel(m).toLowerCase()).join(', ')} got far fewer sets than your other muscles. That may be deliberate. ${ng.workouts} workouts is a limited view, so treat it as a prompt to check, not a verdict.</span></p>` : '<p class="hint" style="margin-top:12px">No muscle group looks neglected over the last 4 weeks.</p>') : `<p class="hint" style="margin-top:12px">Neglected-muscle checks need at least 6 workouts in 4 weeks. You have ${ng.workouts}.</p>`}` : '<p class="mut">No sets in this period.</p>';
      }
    };
    draw();
    pane.addEventListener('click', (e) => {
      const b = e.target.closest('[data-seg]');
      if (b) {
        if (b.dataset.seg === 'period') { const v = b.dataset.v === 'all' ? Infinity : +b.dataset.v; if (v > 30 && !can('longPeriods')) return upgradePrompt('Analytics for 90 days, a year and all time'); period = v; cust = { from: '', to: '' }; draw(); }
        if (b.dataset.seg === 'metric') { if (b.dataset.v === 'e1rm' && !can('exerciseAnalytics')) return upgradePrompt('Estimated one-rep max progression'); metric = b.dataset.v; draw(); }
        return;
      }
      if (e.target.closest('[data-reset]')) { fEx = ''; fMus = ''; gran = 'auto'; cust = { from: '', to: '' }; return draw(); }
      const m = e.target.closest('[data-musf]'); if (m) { fMus = fMus === m.dataset.musf ? '' : m.dataset.musf; draw(); pane.scrollIntoView?.(); }
    });
    pane.addEventListener('change', (e) => {
      const id = e.target.id;
      if (id === 'exsel') { exSel = e.target.value; draw(); }
      if (id === 'f-ex') { fEx = e.target.value; draw(); }
      if (id === 'f-mus') { if (e.target.value && !can('muscleDistribution')) { e.target.value = fMus; return upgradePrompt('Muscle group filters and analytics'); } fMus = e.target.value; draw(); }
      if (id === 'f-gran') { gran = e.target.value; draw(); }
      if (id === 'f-from' || id === 'f-to') { cust = { from: pane.querySelector('#f-from').value, to: pane.querySelector('#f-to').value }; if (cust.from && cust.to && cust.from > cust.to) cust = { from: cust.to, to: cust.from }; draw(); }
    });
  }

  // ---------------- records ----------------
  function records() {
    const ss = state.sessions, recs = A.records(ss), prs = A.prEvents(ss);
    if (!recs.length) { pane.innerHTML = empty('No records yet', 'Your heaviest lifts and best reps are tracked automatically once you log workouts.', '<a class="btn primary" href="#/train">Start training</a>'); return; }
    pane.innerHTML = `<div class="stack"><section class="card"><div class="card-h"><h3>Personal bests</h3><span class="lbl">${plural(recs.length, 'exercise')}</span></div><div class="list">${recs.map((r) => `<a class="li rec" href="#/progress?ex=${r.exId}"><div><div class="t">${esc(r.name)}</div><div class="s">${plural(r.sessions, 'session')} · last ${relDay(r.lastDate)}</div></div><div class="r">${r.loaded && r.heaviest ? `<b>${fmtW(r.heaviest.w, u, true)} × ${r.heaviest.reps}</b> <span class="mut">lifted · ${esc(fmtDay(r.heaviest.date))} ${yearOf(r.heaviest.date)}</span>${r.bestE1 ? `<br><span class="mut">Estimated 1RM ${fmtW(r.bestE1.v, u, true)} (calculated) · ${esc(fmtDay(r.bestE1.date))} ${yearOf(r.bestE1.date)}</span>` : ''}` : `<b>${r.mostReps.reps} reps</b> <span class="mut">in one set · ${esc(fmtDay(r.mostReps.date))} ${yearOf(r.mostReps.date)}</span>`}</div></a>`).join('')}</div>
      <p class="hint" style="margin-top:10px">“Lifted” is the heaviest weight you actually completed. “Estimated 1RM” is calculated from a set of up to 12 reps (Epley formula); it is not a weight you have lifted. Bodyweight exercises show the most reps in one set.</p></section>
      <section class="card"><div class="card-h"><h3>Record timeline</h3></div>${prs.length ? `<div class="list">${prs.slice(-15).reverse().map((e) => `<div class="li"><div><div class="t">${esc(e.name)}</div><div class="s">${fmtDayLong(e.date)}</div></div><span class="pr">${icon('trophy')} ${esc(prLabel(e, u))}</span></div>`).join('')}</div>` : '<p class="mut">The first time you log an exercise sets your baseline. Records appear when you beat it.</p>'}</section></div>`;
  }

  // ---------------- achievements ----------------
  function achievements() {
    const list = A.achievements({ sessions: state.sessions, profile: state.profile }, now), got = list.filter((x) => x.unlocked).length;
    const groups = [...new Set(list.map((x) => x.group))];
    pane.innerHTML = `${levelCard(state, now)}${xpExplain(state, now)}${challengesCard(state, now)}<h2 class="sec">Milestones</h2><p class="mut" style="margin-bottom:16px"><b class="num" style="color:var(--ink)">${got}</b> of ${list.length} unlocked. Milestones come from your real training history.</p>${groups.map((g) => `<h2 class="sec">${esc(g)}</h2><div class="ach-grid">${list.filter((x) => x.group === g).map((x) => `<div class="card ach ${x.unlocked ? 'on' : ''}"><div class="top"><div class="medal t${Math.min(3, x.tier)}">${icon(x.unlocked ? x.ic : 'lock')}</div><div><b>${esc(x.title)}</b><div class="s mut" style="font-size:13.5px">${x.unlocked ? (x.date ? 'Unlocked ' + fmtDay(x.date) + ' ' + yearOf(x.date) : 'Unlocked') : esc(x.desc)}</div></div></div>${x.unlocked ? '' : `<div class="pbar" role="progressbar" aria-valuemin="0" aria-valuemax="${x.target}" aria-valuenow="${Math.min(x.value, x.target)}" aria-label="${esc(x.title)} progress"><i style="width:${x.progress * 100}%"></i></div><div class="s mut num" style="font-size:12.5px">${x.unit ? fmtVol(Math.min(x.value, x.target), u) + ' / ' + fmtVol(x.target, u) : Math.min(x.value, x.target) + ' / ' + x.target}</div>`}</div>`).join('')}</div>`).join('')}`;
  }

  function report() { reportView(pane); }
}
