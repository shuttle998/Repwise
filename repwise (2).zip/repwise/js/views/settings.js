import { addNotice, state, mutate, isPro, can, exportJSON, exportCSV, importJSON, resetAll, subscribe } from '../store.js';
import { CONFIG } from '../config.js';
import { storage, account } from '../services.js';
import { esc, plural, dateKey } from '../util.js';
import { bodyMapHTML, bindBodyMap } from '../bodymap.js';
import { GOALS, GOAL_ORDER, GOAL_NAME, SPLITS, SPLIT_ORDER, EQUIPMENT, FOCUS_MUSCLES, FOCUS, LEVEL, DURATIONS, MIN_DURATION, MAX_DURATION, STYLE, generateProgram, normProfile, equipmentOf } from '../generator.js';
import { LIMITS, BY_ID, EXERCISES, available } from '../exercises.js';
import { openReminders, openInbox } from './reminders-ui.js';
import { openDevices } from './devices-ui.js';
import { THEMES, normTheme, applyTheme } from '../theme.js';
import { accountHTML, accountClick, refreshStatus } from './account-ui.js';
import { onStatus } from '../sync-engine.js';
import { configured as cloudOn, signedIn as cloudSignedIn } from '../cloud.js';
import { icon, toast, confirmDialog, upgradePrompt, proBadge, sheet, seg } from '../ui.js';

export const title = 'Settings';
const sel = (id, opts, cur) => `<select class="input" id="${id}">${opts.map(([v, l]) => `<option value="${esc(v)}" ${String(cur) === String(v) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
const tgl = (key, label, desc, on) => `<button class="toggle" role="switch" aria-checked="${on}" data-tgl="${key}"><span><b>${esc(label)}</b><span class="s">${esc(desc)}</span></span><span class="sw"></span></button>`;
function download(name, text, type) { const url = URL.createObjectURL(new Blob([text], { type })); const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); }

export default function settings(root, { go }) {
  const fresh = () => ({ ...state.profile, limits: [...(state.profile.limits || [])], equipment: equipmentOf(state.profile), goals2: [...(state.profile.goals2 || [])], focusMuscles: [...(state.profile.focusMuscles || [])], params: { ...(state.profile.params || {}) }, split: state.profile.split || 'auto' });
  let d = fresh(), perr = '';
  const norm = (o) => JSON.stringify({ ...o, limits: o.limits || [], equipment: equipmentOf(o), goals2: o.goals2 || [], focusMuscles: o.focusMuscles || [], params: o.params || {}, split: o.split || 'auto' });
  const draw = () => {
    const s = state.settings, p = state.profile, dirty = norm(d) !== norm(p);
    root.innerHTML = `<div class="page-h"><h1>Settings</h1><p>Changes never touch your workout history.</p></div>
    <section class="set-sec"><h2>Profile</h2><div class="card pad"><div class="field" style="margin:0"><label for="nm">Name</label><input class="input" id="nm" maxlength="30" value="${esc(d.name || '')}" autocomplete="given-name"></div></div></section>
    <section class="set-sec"><h2>Training calendar and reminders</h2><div class="card"><div class="list"><a class="li" href="#/calendar"><div><div class="t">Workout calendar</div><div class="s">Completed, planned, rest and missed days</div></div>${icon('right')}</a><button class="li" data-rem><div style="text-align:left"><div class="t">Reminders and planned days</div><div class="s">${state.reminders.enabled ? 'On' : 'Off'} · choose days, times and summaries</div></div>${icon('right')}</button><button class="li" data-dev><div style="text-align:left"><div class="t">Health and devices</div><div class="s">Import Apple Health, TCX or GPX · Bluetooth heart rate</div></div>${icon('right')}</button><button class="li" data-ibx><div style="text-align:left"><div class="t">Notices</div><div class="s">${state.inbox.length ? state.inbox.length + ' saved' : 'Milestones and reminders appear here'}</div></div>${icon('right')}</button></div></div></section>
    <section class="set-sec"><h2>Nutrition and water</h2><div class="card"><div class="list"><a class="li" href="#/nutrition"><div><div class="t">Meals and macros</div><div class="s">Calories, protein, carbs, fat and saved meals</div></div>${icon('right')}</a><a class="li" href="#/nutrition/water"><div><div class="t">Water tracker</div><div class="s">Daily target, quick add and history</div></div>${icon('right')}</a></div></div></section>
    <section class="set-sec"><h2>Fitness goal and training</h2><div class="card pad">
      <div class="field"><label for="goal">Main goal</label>${sel('goal', GOAL_ORDER.map((k) => [k, GOAL_NAME[k] || GOALS[k].n]), d.goal)}</div>
      <div class="field"><span class="lbl">Also important (optional, up to 2)</span><div class="opts c2 multi">${GOAL_ORDER.filter((k) => k !== d.goal).map((k) => `<button type="button" class="opt" data-g2="${k}" aria-pressed="${d.goals2.includes(k)}"><span>${esc(GOAL_NAME[k] || GOALS[k].n)}</span><i></i></button>`).join('')}</div></div>
      <div class="field"><label for="level">Experience</label>${sel('level', Object.entries(LEVEL), d.level)}</div>
      <div class="field"><label for="days">Training days per week</label>${sel('days', [2, 3, 4, 5, 6, 7].map((n) => [n, `${n} days`]), d.days)}</div>
      <div class="field"><label for="split">Training split</label>${sel('split', SPLIT_ORDER.map((k) => [k, SPLITS[k].n]), d.split)}<p class="hint">${esc(SPLITS[d.split]?.h || '')}</p>${d.split === 'custom' ? '<p class="hint">Custom days are set up during onboarding. Edit the programme from the Train tab to change them.</p>' : ''}</div>
      <div class="field"><span class="lbl">Equipment</span><div class="opts c2 multi">${Object.entries(EQUIPMENT).map(([k, v]) => `<button type="button" class="opt" data-eq="${k}" aria-pressed="${d.equipment.includes(k)}"><span>${esc(v.n)}</span><i></i></button>`).join('')}</div></div>
      <div class="field"><span class="lbl">Areas to prioritise (optional)</span>${bodyMapHTML({ mode: 'select', selected: d.focusMuscles })}<div class="opts c2 multi">${Object.keys(FOCUS_MUSCLES).map((k) => `<button type="button" class="opt" data-fm="${k}" aria-pressed="${d.focusMuscles.includes(k)}"><span>${k}</span><i></i></button>`).join('')}</div></div>
      <div class="field"><label for="duration">Time per session (minutes, ${MIN_DURATION} to ${MAX_DURATION})</label><input class="input" id="duration" type="number" inputmode="numeric" min="${MIN_DURATION}" max="${MAX_DURATION}" value="${d.duration}" list="durs"><datalist id="durs">${DURATIONS.map((n) => `<option value="${n}">`).join('')}</datalist></div>
      <details class="fine" ${Object.keys(d.params).length ? 'open' : ''}><summary><b>Fine-tune sets, reps and rest</b> (optional)</summary><div class="grid2" style="margin-top:10px"><label class="field"><span class="lbl">Sets (1 to 8)</span><input class="input" type="number" inputmode="numeric" min="1" max="8" data-par="sets" value="${d.params.sets || ''}" placeholder="Default"></label><label class="field"><span class="lbl">Rest (seconds)</span><input class="input" type="number" inputmode="numeric" min="15" max="300" data-par="restSec" value="${d.params.restSec || ''}" placeholder="Default"></label><label class="field"><span class="lbl">Fewest reps</span><input class="input" type="number" inputmode="numeric" min="1" max="40" data-par="repLo" value="${d.params.repLo || ''}" placeholder="Default"></label><label class="field"><span class="lbl">Most reps</span><input class="input" type="number" inputmode="numeric" min="1" max="60" data-par="repHi" value="${d.params.repHi || ''}" placeholder="Default"></label></div></details>
      ${perr ? `<p class="note warn" role="alert">${esc(perr)}</p>` : ''}
      <div class="field"><label for="style">Training style</label>${sel('style', Object.entries(STYLE).map(([k, v]) => [k, v.split('|')[0]]), d.style)}</div>
      <div class="field"><span class="lbl">Areas to work around</span><div class="opts c2 multi" data-k="limits">${Object.entries(LIMITS).map(([k, v]) => `<button type="button" class="opt" data-lim="${k}" aria-pressed="${d.limits.includes(k)}"><span>${v}</span><i></i></button>`).join('')}</div></div>
      <div class="field"><span class="lbl">Exercises to avoid ${isPro() ? '' : proBadge()}</span><div class="row wrap" style="gap:6px">${(d.avoid || []).map((id) => `<button class="chip" data-unavoid="${id}" aria-label="Remove ${esc(BY_ID[id]?.name || id)}">${esc(BY_ID[id]?.name || id)} ${icon('x')}</button>`).join('')}<button class="chip blue" data-avoid>${icon('plus')} Add</button></div></div>
      <button class="btn primary block" data-save ${dirty ? '' : 'disabled'}>${dirty ? 'Save changes' : 'No changes to save'}</button></div></section>
    <section class="set-sec"><h2>Appearance</h2><div class="card pad"><div class="row sb" style="gap:12px;flex-wrap:wrap"><div><b>Theme</b><div class="hint">Dark is the default. System follows your device.</div></div>${seg('theme', THEMES, normTheme(s.theme))}</div></div></section>
    <section class="set-sec"><h2>Units</h2><div class="card pad"><div class="row sb"><div><b>Weight units</b><div class="hint">Your logged weights convert automatically.</div></div>${seg('units', [['kg', 'kg'], ['lb', 'lb']], s.units)}</div></div></section>
    <section class="set-sec"><h2>Notifications</h2><div class="card"><div class="list">${tgl('sound', 'Rest timer sound', 'Play a tone when rest is over', s.sound)}${tgl('vibrate', 'Vibration', 'Vibrate when rest is over (phones)', s.vibrate)}${tgl('notify', 'Background alert', 'Show a browser notification if the tab is hidden when rest ends', s.notify)}${tgl('wakeLock', 'Keep screen awake', 'Stops the screen sleeping during a workout', s.wakeLock)}</div></div><p class="hint" style="margin:8px 4px">Repwise has no server, so it cannot send reminders when the app is closed.</p></section>
    <section class="set-sec"><h2>Plan</h2><div class="card pad"><div class="row sb"><div><b>${isPro() ? 'Repwise Pro (preview)' : 'Free plan'}</b><div class="hint">${CONFIG.PAYMENTS_LIVE ? 'Manage your subscription.' : 'Payments are not live yet. Pro can be previewed on this device.'}</div></div><a class="btn small" href="#/pricing">${isPro() ? 'Plans' : 'See Pro'}</a></div></div></section>
    <section class="set-sec"><h2>Your data</h2><div class="card pad stack"><p class="mut" style="font-size:14.5px">${plural(state.sessions.length, 'workout')} stored on this device${storage.persistent ? '' : '. <b style="color:var(--warn)">Browser storage is unavailable, so data may be lost when you close this tab. Export a backup.</b>'}</p>
      <div class="row wrap" style="gap:8px"><button class="btn small" data-exp="json">${icon('download')} Export JSON</button><button class="btn small" data-exp="csv">${icon('download')} Export CSV</button><button class="btn small" data-imp>${icon('upload')} Import backup</button><input type="file" id="file" accept="application/json,.json" hidden></div></div></section>
    <section class="set-sec"><h2>Privacy</h2><div class="card pad"><p class="mut" style="font-size:14.5px">${cloudOn() ? 'Your data is stored on this device. If you create an account, a copy of your workouts, nutrition logs and settings is also stored in your private cloud account (protected so only you can read it) so you can use Repwise on other devices; progress photos never leave this device. Repwise has no analytics and no tracking. You can delete your account and its cloud data at any time.' : 'Your profile and workouts are stored in this browser only. Repwise has no analytics and no tracking, and nothing is sent to a server. Clearing your browser data deletes your workouts, so export a backup now and then.'} Fonts load from Google Fonts.</p></div></section>
    <section class="set-sec"><h2>Account and sync</h2>${accountHTML()}</section>
    <p class="foot-note">Repwise · Not medical advice. Check with a doctor if you have a health condition.</p>`;
  };

  const rebuild = (profile) => { mutate((st) => { st.program = generateProgram(profile, { variant: 0 }); st.cursor = 0; }); if (state.reminders.programme) addNotice({ kind: 'programme', title: 'Programme updated', body: `Rebuilt for ${profile.days} days a week.` }); };
  async function save() {
    const prev = state.profile, structural = ['goal', 'level', 'days', 'split', 'duration', 'style'].some((k) => String(d[k] ?? '') !== String(prev[k] ?? (k === 'split' ? 'auto' : ''))) || JSON.stringify(d.equipment) !== JSON.stringify(equipmentOf(prev)) || JSON.stringify(d.goals2) !== JSON.stringify(prev.goals2 || []) || JSON.stringify(d.focusMuscles) !== JSON.stringify(prev.focusMuscles || []) || JSON.stringify(d.params) !== JSON.stringify(prev.params || {}) || JSON.stringify(d.limits) !== JSON.stringify(prev.limits || []) || JSON.stringify(d.avoid || []) !== JSON.stringify(prev.avoid || []);
    const pr = d.params; if ((pr.repLo || pr.repHi) && !(pr.repLo && pr.repHi && pr.repHi >= pr.repLo)) { perr = 'Enter both fewest and most reps, with most at least as high as fewest. Or clear both.'; return draw(); }
    if (!d.equipment.length) { perr = 'Choose at least one piece of equipment.'; return draw(); }
    if (!(d.duration >= MIN_DURATION && d.duration <= MAX_DURATION)) { perr = `Enter a session length between ${MIN_DURATION} and ${MAX_DURATION} minutes.`; return draw(); }
    perr = '';
    const next = normProfile({ ...prev, ...d, name: (d.name || '').trim() });
    mutate((st) => { st.profile = next; });
    if (structural) {
      const ok = await confirmDialog({ title: 'Rebuild your programme?', text: state.program.custom ? 'Your custom edits will be replaced with a new programme that matches these settings.' : 'Update your programme to match these settings? Your workout history and working weights are kept.', confirm: 'Rebuild programme', cancel: 'Keep current programme' });
      if (ok) rebuild(next);
    }
    d = fresh(); toast('Settings saved'); draw();
  }

  bindBodyMap(root, (k) => { d.focusMuscles = d.focusMuscles.includes(k) ? d.focusMuscles.filter((x) => x !== k) : [...d.focusMuscles, k]; const y = scrollY; draw(); scrollTo(0, y); });
  root.addEventListener('input', (e) => {
    const par = e.target.dataset?.par, upd = () => { const b = root.querySelector('[data-save]'), dirty = norm(d) !== norm(state.profile); if (b) { b.disabled = !dirty; b.textContent = dirty ? 'Save changes' : 'No changes to save'; } };
    if (par) { const v = Math.round(Number(e.target.value)); if (e.target.value === '' || !(v > 0)) delete d.params[par]; else d.params[par] = v; return upd(); }
    if (e.target.id === 'duration') { d.duration = Math.round(Number(e.target.value)) || 0; return upd(); } if (e.target.id === 'nm') { d.name = e.target.value; const b = root.querySelector('[data-save]'); const dirty = norm(d) !== norm(state.profile); b.disabled = !dirty; b.textContent = dirty ? 'Save changes' : 'No changes to save'; } });
  root.addEventListener('change', (e) => {
    const id = e.target.id; if (['goal', 'level', 'days', 'split', 'style'].includes(id)) { d[id] = ['level', 'days'].includes(id) ? +e.target.value : e.target.value; if (id === 'goal') d.goals2 = d.goals2.filter((x) => x !== d.goal); draw(); root.querySelector('#' + id)?.focus(); }
    if (id === 'file') importFile(e.target.files[0]);
  });
  async function importFile(f) {
    if (!f) return;
    try {
      const text = await f.text(); const o = JSON.parse(text); if (!(await confirmDialog({ title: 'Replace your data?', text: `This replaces everything on this device with the backup (${plural((o.sessions || []).length, 'workout')}). Export first if you want to keep the current data.`, confirm: 'Replace', danger: true }))) return;
      importJSON(text); toast('Backup restored'); go('');
    } catch (err) { toast(err.message?.startsWith('This file') || err.message?.startsWith('Workout') ? err.message : 'That file could not be read as a Repwise backup.', 'err', 5000); }
    root.querySelector('#file').value = '';
  }
  root.addEventListener('click', async (e) => {
    const t = (s) => e.target.closest(s);
    if (t('[data-g2]')) { const k = t('[data-g2]').dataset.g2; if (d.goals2.includes(k)) d.goals2 = d.goals2.filter((x) => x !== k); else if (d.goals2.length < 2) d.goals2 = [...d.goals2, k]; return draw(); }
    if (t('[data-eq]')) { const k = t('[data-eq]').dataset.eq; d.equipment = k === 'bw' ? (d.equipment.includes('bw') ? [] : ['bw']) : d.equipment.includes(k) ? d.equipment.filter((x) => x !== k) : [...d.equipment.filter((x) => x !== 'bw'), k]; return draw(); }
    if (t('[data-fm]')) { const k = t('[data-fm]').dataset.fm; d.focusMuscles = d.focusMuscles.includes(k) ? d.focusMuscles.filter((x) => x !== k) : [...d.focusMuscles, k]; return draw(); }
    if (t('[data-lim]')) { const k = t('[data-lim]').dataset.lim; d.limits = d.limits.includes(k) ? d.limits.filter((x) => x !== k) : [...d.limits, k]; return draw(); }
    if (await accountClick(t, { redraw: draw, go })) return;
    if (t('[data-rem]')) return openReminders(draw);
    if (t('[data-ibx]')) return openInbox(draw);
    if (t('[data-dev]')) return openDevices(draw);
    if (t('[data-save]')) return save();
    if (t('[data-seg="theme"]')) { const v = normTheme(t('[data-seg]').dataset.v); mutate((st) => { st.settings.theme = v; }); applyTheme(v); return draw(); }
    if (t('[data-seg="units"]')) { mutate((st) => { st.settings.units = t('[data-seg]').dataset.v; }); toast(`Weights shown in ${state.settings.units}`); return draw(); }
    if (t('[data-tgl]')) {
      const k = t('[data-tgl]').dataset.tgl, on = !state.settings[k];
      if (k === 'notify' && on) { if (!('Notification' in window)) return toast('This browser does not support notifications', 'err'); const r = await Notification.requestPermission(); if (r !== 'granted') return toast('Notification permission was not granted', 'err'); }
      mutate((st) => { st.settings[k] = on; }); return draw();
    }
    if (t('[data-exp]')) { const j = t('[data-exp]').dataset.exp === 'json'; download(`repwise-${dateKey()}.${j ? 'json' : 'csv'}`, j ? exportJSON() : exportCSV(), j ? 'application/json' : 'text/csv'); return toast('Export downloaded'); }
    if (t('[data-imp]')) return root.querySelector('#file').click();
    if (t('[data-avoid]')) { if (!can('exercisePreferences')) return upgradePrompt('Excluding exercises from your programme'); return pickAvoid(); }
    if (t('[data-unavoid]')) { d.avoid = (d.avoid || []).filter((x) => x !== t('[data-unavoid]').dataset.unavoid); return draw(); }
    if (t('[data-wipe]')) {
      if (!(await confirmDialog({ title: 'Delete all data?', text: cloudSignedIn() ? 'This deletes your profile, programme and every logged workout from this device. Your cloud copy is NOT deleted, so signing in again would bring it back. To remove cloud data use Delete my account.' : 'This permanently deletes your profile, programme and every logged workout from this device. Export a backup first if you might want it back.', confirm: 'Delete everything', danger: true }))) return;
      if (!(await confirmDialog({ title: 'Really delete everything?', text: 'This cannot be undone.', confirm: 'Yes, delete', danger: true }))) return;
      resetAll(); toast('All data deleted'); go('');
    }
  });
  function pickAvoid() {
    sheet({ title: 'Exercises to avoid', wide: true, html: `<p class="mut" style="margin-bottom:10px">These are left out when your programme is rebuilt.</p><input class="input" id="q" placeholder="Search exercises" aria-label="Search" style="margin-bottom:10px"><div class="pick" id="pl"></div>`, onMount: (box, close) => {
      const pl = box.querySelector('#pl'), q = box.querySelector('#q');
      const r = () => { pl.innerHTML = EXERCISES.filter((e) => available(e, d.gear) && e.name.toLowerCase().includes(q.value.toLowerCase()) && !(d.avoid || []).includes(e.id)).map((e) => `<button class="ex-row" data-pick="${e.id}" style="text-align:left;width:100%"><span><b>${esc(e.name)}</b><br><span class="mut" style="font-size:13.5px">${esc(e.pm.join(', '))}</span></span>${icon('plus')}</button>`).join(''); };
      q.addEventListener('input', r); r();
      pl.addEventListener('click', (e) => { const b = e.target.closest('[data-pick]'); if (b) { d.avoid = [...(d.avoid || []), b.dataset.pick]; close(); draw(); } });
    } });
  }
  draw();
  const off = onStatus(() => { if (root.isConnected) refreshStatus(root); });
  return off;
}
