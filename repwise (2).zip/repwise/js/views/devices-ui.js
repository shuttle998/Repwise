import { state, importActivities, importWeights, removeActivity, clearActivities } from '../store.js';
import { parseHealthFile, dailyWeights } from '../wearables.js';
import { supported as btOk, hrState, connectHr, disconnectHr, onHr } from '../hr.js';
import { esc, fmtDayLong, fmtDur, plural } from '../util.js';
import { importedOnly } from '../classes.js';
import { icon, sheet, toast, confirmDialog } from '../ui.js';

const km = (m) => (m >= 1000 ? `${(m / 1000).toFixed(m >= 10000 ? 1 : 2)} km` : `${m} m`);
export const activityLine = (a) => [a.label || a.type, fmtDur(a.durationSec), a.distanceM ? km(a.distanceM) : '', a.kcal ? `${a.kcal} kcal` : '', a.avgHr ? `${a.avgHr} bpm avg${a.maxHr ? `, ${a.maxHr} max` : ''}` : ''].filter(Boolean).join(' · ');

export function openDevices(onChange) {
  const body = () => {
    const list = importedOnly(state.activities).slice(0, 15), h = hrState();
    return `<p class="mut" style="margin-bottom:14px">Bring in workouts and weight from your watch or phone. Imported activities appear in your calendar and are not counted towards streaks, XP or challenges, so nothing is double counted.</p>
    <h3 class="sec" style="margin-top:0">Import a file</h3>
    <div class="card flat stack" style="gap:10px"><p class="s mut" style="font-size:14px"><b>Apple Health:</b> Health app, tap your profile picture, then <i>Export All Health Data</i>, and choose the <b>export.zip</b> here. <b>Garmin, Polar, Strava, Fitbit and others:</b> export an activity as <b>.tcx</b> or <b>.gpx</b>. Files are read on this device and are never uploaded.</p>
      <input type="file" id="hf" accept=".zip,.xml,.tcx,.gpx,application/zip,text/xml" multiple hidden><button class="btn primary" data-pick>${icon('upload')} Choose file</button><div id="hp" hidden><div class="pbar" role="progressbar" aria-label="Import progress"><i style="width:0%"></i></div><p class="hint" id="ht">Reading…</p></div></div>
    <h3 class="sec">Heart rate monitor</h3>
    <div class="card flat stack" style="gap:8px">${btOk() ? `<p class="s mut" style="font-size:14px">Connect a Bluetooth chest strap or a watch that broadcasts heart rate to see it live in your workouts. Only the average and range are saved.</p>${h.connected ? `<div class="row sb"><span>${icon('heart')} <b>${esc(h.name || 'Connected')}</b> ${h.bpm ? `· <b class="num">${h.bpm}</b> bpm` : ''}</span><button class="btn small" data-hr="off">Disconnect</button></div>` : `<button class="btn" data-hr="on" style="justify-self:start" ${h.connecting ? 'disabled' : ''}>${icon('heart')} ${h.connecting ? 'Connecting…' : 'Connect monitor'}</button>`}${h.error ? `<p class="note warn">${icon('alert')}<span>${esc(h.error)}</span></p>` : ''}` : `<p class="note">${icon('info')}<span>This browser cannot connect to Bluetooth devices. Live heart rate works in Chrome or Edge on Android, Windows, macOS and Linux (not on iPhone browsers). Importing files works everywhere.</span></p>`}</div>
    <h3 class="sec">Imported activities</h3>
    ${list.length ? `<div class="list">${list.map((a) => `<div class="li"><div style="min-width:0"><div class="t">${esc(fmtDayLong(a.date))}</div><div class="s">${esc(activityLine(a))}</div></div><button class="btn small ghost" data-rm="${esc(a.id)}" aria-label="Remove activity">${icon('x')}</button></div>`).join('')}</div><div class="row sb" style="margin-top:10px"><span class="hint">${plural(state.activities.length, 'activity', 'activities')} imported${state.activities.length > 15 ? ', latest 15 shown' : ''}</span><button class="btn small ghost" data-clear>Remove all</button></div>` : '<p class="mut">Nothing imported yet.</p>'}
    <div class="btn-row" style="margin-top:14px"><button class="btn primary" data-close>Done</button></div>`;
  };
  let off = () => {};
  const s = sheet({ title: 'Health and devices', wide: true, html: '<div id="dv"></div>', onMount: (box) => {
    const host = box.querySelector('#dv'), draw = () => { host.innerHTML = body(); }; draw(); off = onHr(() => { if (box.isConnected && !host.querySelector('#hp:not([hidden])')) draw(); });
    box.addEventListener('click', async (e) => {
      const t = (q) => e.target.closest(q);
      if (t('[data-pick]')) return host.querySelector('#hf').click();
      if (t('[data-hr]')) { if (t('[data-hr]').dataset.hr === 'off') return void disconnectHr(); try { await connectHr(); } catch (err) { toast(err.message, 'err', 6000); } return; }
      if (t('[data-rm]')) { removeActivity(t('[data-rm]').dataset.rm); draw(); return; }
      if (t('[data-clear]')) { if (await confirmDialog({ title: 'Remove all imported activities?', text: 'This only removes imported activities. Your Repwise workouts and weight entries are not affected.', confirm: 'Remove all', danger: true })) { clearActivities(); draw(); } }
    });
    box.addEventListener('change', async (e) => {
      if (e.target.id !== 'hf' || !e.target.files.length) return;
      const files = [...e.target.files], p = host.querySelector('#hp'), bar = p.querySelector('i'), txt = host.querySelector('#ht'); p.hidden = false; let acts = 0, wts = 0, dup = 0;
      try {
        for (const f of files) {
          txt.textContent = `Reading ${f.name}…`; const r = await parseHealthFile(f, (x) => { bar.style.width = Math.round(x * 100) + '%'; });
          const n = importActivities(r.activities); acts += n; dup += r.activities.length - n; wts += importWeights(dailyWeights(r.weights));
          if (!r.activities.length && !r.weights.length) throw new Error(`No workouts or weight found in ${f.name}.`);
        }
        toast(`Imported ${plural(acts, 'activity', 'activities')}${wts ? ` and ${plural(wts, 'weight entry', 'weight entries')}` : ''}${dup ? `. ${dup} already imported were skipped.` : ''}`, 'ok', 6000); onChange?.();
      } catch (err) { toast(err.message || 'Could not read that file.', 'err', 7000); }
      e.target.value = ''; draw();
    });
  } });
  s.done.then(() => off());
}
