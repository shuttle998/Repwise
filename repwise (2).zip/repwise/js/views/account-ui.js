// Account, sign-in and cloud backup screens. All network calls are in cloud.js; syncing is in sync-engine.js.
import * as cloud from '../cloud.js';
import * as E from '../sync-engine.js';
import { state, exportJSON, importJSON, applySynced, mutate } from '../store.js';
import { esc, fmtDayLong, dateKey } from '../util.js';
import { icon, sheet, toast, confirmDialog } from '../ui.js';

const MSG = { idle: 'Up to date', syncing: 'Syncing…', offline: 'Offline', error: 'Sync problem', off: 'Not syncing' };
const ago = (t) => { if (!t) return 'not yet'; const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : m < 1440 ? `${Math.round(m / 60)} h ago` : new Date(t).toLocaleDateString('en', { day: 'numeric', month: 'short' }); };
const field = (id, label, type, extra = '') => `<div class="field"><label for="${id}">${esc(label)}</label><input class="input" id="${id}" type="${type}" ${extra}></div>`;
function download(name, text) { const url = URL.createObjectURL(new Blob([text], { type: 'application/json' })); const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); }

export function accountHTML() {
  if (!cloud.configured()) return `<div class="card pad stack"><p class="mut" style="font-size:14.5px">Accounts and cross-device sync are not switched on in this copy of the app. Your data stays on this device. The site owner can turn them on in a few minutes by following <b>supabase/README.md</b>.</p><button class="btn danger small" data-wipe style="justify-self:start">${icon('trash')} Delete all my data on this device</button></div>`;
  if (!cloud.signedIn()) return `<div class="card pad stack"><p class="mut" style="font-size:14.5px">Create a free account to back up your workouts and use Repwise on your phone and your laptop. Your existing data on this device is kept and uploaded safely. Nothing is lost if you skip this.</p><div class="row wrap" style="gap:8px"><button class="btn primary" data-acct="signup">Create account</button><button class="btn" data-acct="signin">Sign in</button></div><button class="btn danger small" data-wipe style="justify-self:start">${icon('trash')} Delete all my data on this device</button></div>`;
  const u = cloud.currentUser(), s = E.getStatus();
  return `<div class="card pad stack" aria-live="polite"><div class="row sb" style="gap:10px"><div style="min-width:0"><b style="overflow-wrap:anywhere">${esc(u.email || 'Signed in')}</b><div class="hint" id="syncline">${esc(MSG[s.state] || '')}${s.state === 'idle' || s.state === 'syncing' ? '' : ''} · last synced ${esc(ago(state.sync.lastSyncAt))}${state.sync.dirty ? ' · changes waiting' : ''}</div></div><span class="chip ${s.state === 'idle' ? 'ok' : s.state === 'error' ? 'warn' : ''}" id="syncchip">${esc(MSG[s.state] || '')}</span></div>
    ${s.message ? `<p class="note warn" id="syncmsg">${icon('alert')}<span>${esc(s.message)}</span></p>` : '<span id="syncmsg"></span>'}
    <div class="row wrap" style="gap:8px"><button class="btn small" data-acct="sync">${icon('repeat')} Sync now</button><button class="btn small" data-acct="backups">Cloud backups</button><button class="btn small" data-acct="password">Change password</button><button class="btn small" data-acct="signout">Sign out</button></div>
    ${E.preSyncBackup() ? `<p class="hint">Before your first sync, a copy of this device's data was saved. <button class="link" data-acct="presync" style="background:none;border:0;padding:0;font:inherit;cursor:pointer">Download it</button></p>` : ''}
    <button class="btn danger small" data-acct="delete" style="justify-self:start">${icon('trash')} Delete my account</button></div>`;
}
export function refreshStatus(root) {
  const s = E.getStatus(), l = root.querySelector('#syncline'), c = root.querySelector('#syncchip'), m = root.querySelector('#syncmsg'); if (!l) return;
  l.textContent = `${MSG[s.state] || ''} · last synced ${ago(state.sync.lastSyncAt)}${state.sync.dirty ? ' · changes waiting' : ''}`; c.textContent = MSG[s.state] || ''; c.className = 'chip ' + (s.state === 'idle' ? 'ok' : s.state === 'error' ? 'warn' : '');
  m.outerHTML = s.message ? `<p class="note warn" id="syncmsg">${icon('alert')}<span>${esc(s.message)}</span></p>` : '<span id="syncmsg"></span>';
}

/** After a successful sign-in: handle data from a different account on this device, then sync. */
async function afterSignIn(go) {
  const u = cloud.currentUser(), foreign = state.sync.accountId && state.sync.accountId !== u.id && state.sessions.length > 0;
  if (foreign) {
    const ok = await confirmDialog({ title: 'Different account on this device', text: 'This device holds workouts from another account. Signing in will combine them with this account. Nothing is deleted, and a copy of this device\'s data is saved first. Continue?', confirm: 'Combine and sign in', cancel: 'Sign out' });
    if (!ok) { await cloud.signOut(); toast('Signed out'); go?.('settings'); return; }
    mutate((st) => { st.sync.accountId = null; }, { silent: true }); // counts as a first sync, so a safety copy is taken
  }
  const r = await E.syncNow({ reason: 'signin' });
  if (r.state === 'idle') toast('Signed in. Your workouts are backed up.'); else if (r.state === 'offline') toast('Signed in. Syncing will happen when you are online.'); else toast(r.message || 'Signed in, but the first sync failed. Tap Sync now to retry.', 'err', 6000);
  go?.('settings');
}

export function openAuth(mode = 'signin', { onDone, go } = {}) {
  const copy = { signup: ['Create account', 'Create account'], signin: ['Sign in', 'Sign in'], forgot: ['Reset your password', 'Send reset link'] }[mode];
  const s = sheet({ title: copy[0], html: `<form id="af" novalidate>${field('em', 'Email', 'email', 'autocomplete="email" inputmode="email" required data-autofocus')}${mode !== 'forgot' ? field('pw', 'Password', 'password', `autocomplete="${mode === 'signup' ? 'new-password' : 'current-password'}" minlength="8" required`) : ''}${mode === 'signup' ? '<p class="hint" style="margin:-6px 0 12px">At least 8 characters.</p>' : ''}<p class="note warn" id="aerr" role="alert" hidden></p><div class="btn-row"><button class="btn ghost" type="button" data-close>Cancel</button><button class="btn primary" type="submit">${copy[1]}</button></div></form>
    <div class="row wrap" style="gap:12px;margin-top:12px">${mode === 'signin' ? '<button class="link" data-sw="forgot" style="background:none;border:0;padding:0;font:inherit;cursor:pointer">Forgot password?</button><button class="link" data-sw="signup" style="background:none;border:0;padding:0;font:inherit;cursor:pointer">Create account</button>' : '<button class="link" data-sw="signin" style="background:none;border:0;padding:0;font:inherit;cursor:pointer">Back to sign in</button>'}</div>`,
  onMount: (box, close) => {
    const err = (m) => { const e = box.querySelector('#aerr'); e.hidden = !m; e.innerHTML = m ? `${icon('alert')}<span>${esc(m)}</span>` : ''; };
    box.querySelectorAll('[data-sw]').forEach((b) => b.addEventListener('click', () => { close(); openAuth(b.dataset.sw, { onDone, go }); }));
    box.querySelector('#af').addEventListener('submit', async (e) => {
      e.preventDefault(); err(''); const btn = box.querySelector('[type=submit]'), email = box.querySelector('#em').value.trim(), pw = box.querySelector('#pw')?.value || '';
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return err('Enter a valid email address.');
      if (mode !== 'forgot' && pw.length < 8) return err(mode === 'signup' ? 'Choose a password with at least 8 characters.' : 'Enter your password.');
      btn.disabled = true; btn.textContent = 'Please wait…';
      try {
        if (mode === 'forgot') { await cloud.recover(email, location.origin + location.pathname); close(); toast('If that email has an account, a reset link is on its way.', 'ok', 6000); return; }
        if (mode === 'signup') { const r = await cloud.signUp(email, pw); if (!r.confirmed) { close(); toast('Check your email and tap the confirmation link, then sign in.', 'ok', 8000); return; } } else await cloud.signIn(email, pw);
        close(); await afterSignIn(go); onDone?.();
      } catch (x) { err(x.message); btn.disabled = false; btn.textContent = copy[1]; }
    });
  } });
  return s;
}

/** Opened from the password-reset email link. `rec` is the temporary session from the link. */
export function openRecovery(rec, { go } = {}) {
  sheet({ title: 'Set a new password', html: `<form id="rf" novalidate>${field('p1', 'New password', 'password', 'autocomplete="new-password" minlength="8" required data-autofocus')}${field('p2', 'Repeat new password', 'password', 'autocomplete="new-password" minlength="8" required')}<p class="note warn" id="rerr" role="alert" hidden></p><div class="btn-row"><button class="btn ghost" type="button" data-close>Cancel</button><button class="btn primary" type="submit">Save password</button></div></form>`,
    onMount: (box, close) => box.querySelector('#rf').addEventListener('submit', async (e) => {
      e.preventDefault(); const er = box.querySelector('#rerr'), a = box.querySelector('#p1').value, b = box.querySelector('#p2').value, fail = (m) => { er.hidden = false; er.innerHTML = `${icon('alert')}<span>${esc(m)}</span>`; };
      if (a.length < 8) return fail('Use at least 8 characters.'); if (a !== b) return fail('The two passwords do not match.');
      try { await cloud.updatePassword(a, rec.access); cloud.adoptSession(rec.rec); close(); toast('Password updated. You are signed in.'); await afterSignIn(go); } catch (x) { fail(x.message); }
    }) });
}
export function openChangePassword() {
  sheet({ title: 'Change password', html: `<form id="cf" novalidate>${field('p1', 'New password', 'password', 'autocomplete="new-password" minlength="8" required data-autofocus')}${field('p2', 'Repeat new password', 'password', 'autocomplete="new-password" minlength="8" required')}<p class="note warn" id="cerr" role="alert" hidden></p><div class="btn-row"><button class="btn ghost" type="button" data-close>Cancel</button><button class="btn primary" type="submit">Save password</button></div></form>`,
    onMount: (box, close) => box.querySelector('#cf').addEventListener('submit', async (e) => {
      e.preventDefault(); const er = box.querySelector('#cerr'), a = box.querySelector('#p1').value, b = box.querySelector('#p2').value, fail = (m) => { er.hidden = false; er.innerHTML = `${icon('alert')}<span>${esc(m)}</span>`; };
      if (a.length < 8) return fail('Use at least 8 characters.'); if (a !== b) return fail('The two passwords do not match.');
      try { await cloud.updatePassword(a); close(); toast('Password updated.'); } catch (x) { fail(x.message); }
    }) });
}

export async function openBackups(onDone) {
  const s = sheet({ title: 'Cloud backups', html: '<div id="bk"><p class="mut">Loading…</p></div><div class="btn-row"><button class="btn primary" data-close>Close</button></div>', onMount: async (box, close) => {
    const host = box.querySelector('#bk');
    try {
      const list = await cloud.listBackups();
      host.innerHTML = `<p class="mut" style="margin-bottom:10px">The server keeps automatic snapshots of your data (at most one every 12 hours, newest 10). Restoring replaces the data on this device and in your account; your current data is saved to a file first.</p>${list.length ? `<div class="list">${list.map((b) => `<div class="li"><div><div class="t">${esc(new Date(b.created_at).toLocaleString('en', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }))}</div><div class="s">Version ${b.rev}</div></div><button class="btn small" data-restore="${esc(b.id)}">Restore</button></div>`).join('')}</div>` : '<p class="mut">No backups yet. One is created automatically the first time your data changes after 12 hours.</p>'}`;
    } catch (e) { host.innerHTML = `<p class="note warn">${icon('alert')}<span>${esc(e.message)}</span></p>`; }
    host.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-restore]'); if (!b) return;
      if (!(await confirmDialog({ title: 'Restore this backup?', text: 'This replaces your workouts and settings on this device and in the cloud with this snapshot. A file with your current data will download first.', confirm: 'Restore', danger: true }))) return;
      try {
        const bk = await cloud.getBackup(b.dataset.restore); if (!bk?.data?.sessions) throw new Error('That backup could not be read.');
        download(`repwise-before-restore-${dateKey()}.json`, exportJSON());
        applySynced({ v: 1, sections: {}, stamps: {}, tomb: {}, sessions: [], customExercises: [], programs: [], body: [], mealSaved: [], activities: [], meals: {}, water: {}, ...bk.data }); await E.forcePush();
        close(); toast('Backup restored'); onDone?.();
      } catch (x) { toast(x.message || 'Restore failed', 'err', 5000); }
    });
  } });
  return s;
}

export async function deleteAccountFlow(go, redraw) {
  const s = sheet({ title: 'Delete your account?', html: `<p class="mut">This permanently deletes your account and every workout stored in the cloud. Data on this device stays here. This cannot be undone.</p><div class="field" style="margin-top:12px"><label for="dc">Type DELETE to confirm</label><input class="input" id="dc" autocomplete="off" autocapitalize="characters" data-autofocus></div><p class="note warn" id="derr" role="alert" hidden></p><div class="btn-row"><button class="btn ghost" data-close>Cancel</button><button class="btn danger" id="dok" disabled>Delete account</button></div>`, onMount: (box, close) => {
    const ok = box.querySelector('#dok'); box.querySelector('#dc').addEventListener('input', (e) => { ok.disabled = e.target.value.trim() !== 'DELETE'; });
    ok.addEventListener('click', async () => { ok.disabled = true; try { await cloud.deleteAccount(); mutate((st) => { st.sync.accountId = null; st.sync.rev = null; st.sync.lastSyncAt = null; st.sync.dirty = false; }, { silent: true }); close(); toast('Account deleted. Your data on this device is untouched.'); go?.('settings'); redraw?.(); } catch (x) { const e = box.querySelector('#derr'); e.hidden = false; e.innerHTML = `${icon('alert')}<span>${esc(x.message)}</span>`; ok.disabled = false; } });
  } });
  return s;
}

export async function accountClick(t, { redraw, go }) {
  const a = t('[data-acct]')?.dataset.acct; if (!a) return false;
  if (a === 'signup' || a === 'signin') openAuth(a, { onDone: redraw, go });
  else if (a === 'sync') { const r = await E.syncNow({ reason: 'manual' }); toast(r.state === 'idle' ? 'Everything is up to date' : r.message || 'Could not sync', r.state === 'idle' ? 'ok' : 'err'); redraw(); }
  else if (a === 'signout') { if (await confirmDialog({ title: 'Sign out?', text: 'Your workouts stay on this device. Sync stops until you sign in again.', confirm: 'Sign out' })) { await cloud.signOut(); toast('Signed out'); redraw(); } }
  else if (a === 'backups') openBackups(redraw);
  else if (a === 'password') openChangePassword();
  else if (a === 'delete') deleteAccountFlow(go, redraw);
  else if (a === 'presync') { const b = E.preSyncBackup(); if (b) download('repwise-before-first-sync.json', b); }
  return true;
}
