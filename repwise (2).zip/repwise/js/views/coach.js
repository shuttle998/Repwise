import { state, mutate, isPro } from '../store.js';
import { esc } from '../util.js';
import { CONFIG } from '../config.js';
import { icon, empty, toast } from '../ui.js';
import { buildContext } from '../coach-context.js';
import { dateKey } from '../util.js';

export const title = 'Coach';
const STARTERS = ['What should I train today?', 'Why am I not getting stronger?', 'Should I increase my dumbbell weight?', 'How can I improve my chest workout?', 'Am I training each muscle group enough?', 'What should I change about my programme?', 'Why am I struggling with a particular exercise?'];
let chat = []; // kept for this browser session only; never written to storage

const quota = () => (isPro() ? CONFIG.COACH.proPerDay : CONFIG.COACH.freePerDay);
const usedToday = () => { const u = state.ui.coachUsage; return u && u.date === dateKey() ? u.n : 0; };
const bump = () => mutate((st) => { const d = dateKey(), u = st.ui.coachUsage; st.ui.coachUsage = u && u.date === d ? { date: d, n: u.n + 1 } : { date: d, n: 1 }; });
// Light formatting only: paragraphs and "- " lists, after escaping.
const fmt = (t) => esc(t).split(/\n{2,}/).map((b) => /^\s*[-•*] /.test(b) ? `<ul class="bul">${b.split('\n').map((l) => `<li>${l.replace(/^\s*[-•*] /, '')}</li>`).join('')}</ul>` : `<p>${b.replace(/\n/g, '<br>')}</p>`).join('');

export default function coach(root) {
  const logged = state.sessions.filter((s) => (s.items || []).some((i) => !i.skipped && i.sets?.length)).length;
  const consented = () => !!state.ui.coachConsent;
  let busy = false, err = null, srv = null; // srv: { configured, provider, dataNote } from the server
  fetch(CONFIG.COACH.endpoint).then((r) => r.json()).then((d) => { srv = d; draw(); }).catch(() => {});

  const draw = () => {
    root.innerHTML = `
      <div class="page-h"><h1>Coach</h1><p class="mut">Ask about your training. Answers use your profile, programme and logged workouts.</p></div>
      <div class="coach">
        ${!consented() ? `<section class="card"><h3>Before you start</h3><p>To answer, the Coach sends a summary of your profile, programme and recent workouts to an AI service through this app’s server. Your name and email are not sent, and Repwise does not store your conversations.</p><button class="btn primary" data-consent>Continue</button></section>` : ''}
        ${srv && !srv.configured ? `<p class="note warn">${icon('alert')}<span>The Coach is not switched on for this site yet. The site owner needs to add an AI key on the server.</span></p>` : ''}
        ${logged === 0 ? `<p class="note">${icon('alert')}<span>You have no logged workouts yet, so the Coach can only talk about your plan, not your progress.</span></p>` : ''}
        <div class="chat" role="log" aria-live="polite" aria-label="Conversation">
          ${chat.length ? chat.map((m) => `<div class="msg ${m.role}"><div class="bub">${m.role === 'user' ? `<p>${esc(m.content)}</p>` : fmt(m.content)}</div></div>`).join('') : ''}
          ${busy ? `<div class="msg assistant"><div class="bub"><span class="spin small" role="status" aria-label="Thinking"></span> Thinking…</div></div>` : ''}
          ${err ? `<div class="msg assistant"><div class="bub err"><p>${esc(err.text)}</p>${err.retry ? '<button class="btn small" data-retry>Try again</button>' : ''}</div></div>` : ''}
        </div>
        ${!chat.length && !busy ? `<div class="starters"><span class="lbl">Try asking</span><div class="chips">${STARTERS.map((q, i) => `<button class="fchip" data-q="${i}" ${consented() && srv?.configured !== false ? '' : 'disabled'}>${esc(q)}</button>`).join('')}</div></div>` : ''}
        <form class="ask" data-ask><label class="sr-only" for="q">Your question</label><textarea id="q" rows="2" maxlength="600" placeholder="Ask the Coach…" ${consented() && !busy && srv?.configured !== false ? '' : 'disabled'}></textarea><button class="btn primary" ${consented() && !busy && srv?.configured !== false ? '' : 'disabled'}>Ask</button></form>
        <p class="hint">${usedToday()} of ${quota()} questions used today${isPro() ? '' : ' on Free. <a class="link" href="#/pricing">See Pro</a>'}. The Coach is an AI and can be wrong. It is not medical advice.</p>
        ${chat.length ? '<button class="btn small ghost" data-clear>Clear conversation</button>' : ''}
      </div>`;
    const log = root.querySelector('.chat'); log.lastElementChild?.scrollIntoView({ block: 'nearest' });
  };

  const ask = async (question) => {
    question = question.trim(); if (!question || busy || !consented()) return;
    if (!navigator.onLine) { err = { text: 'You are offline. The Coach needs an internet connection.', retry: false }; return draw(); }
    if (usedToday() >= quota()) { err = { text: isPro() ? 'You have reached today’s Coach limit. It resets tomorrow.' : `You have used your ${quota()} free questions today. Pro raises the limit to ${CONFIG.COACH.proPerDay} a day.`, retry: false }; return draw(); }
    err = null; const history = chat.slice(-6); chat.push({ role: 'user', content: question }); busy = true; draw();
    try {
      const r = await fetch(CONFIG.COACH.endpoint, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ question, history, context: buildContext(state) }) });
      let d = {}; try { d = await r.json(); } catch {}
      if (r.ok && d.answer) { chat.push({ role: 'assistant', content: d.answer }); bump(); }
      else { chat.pop(); err = { text: r.status === 503 || r.status === 404 ? 'The Coach is not switched on for this site yet. The site owner needs to add an AI key on the server.' : d.message || 'The Coach could not answer. Try again.', retry: r.status !== 503 && r.status !== 404 && r.status !== 429, q: question }; }
    } catch { chat.pop(); err = { text: 'Could not reach the Coach. Check your connection and try again.', retry: true, q: question }; }
    busy = false; draw(); root.querySelector('#q')?.focus();
  };

  root.addEventListener('click', (e) => {
    if (e.target.closest('[data-consent]')) { mutate((st) => { st.ui.coachConsent = true; }); return draw(); }
    const q = e.target.closest('[data-q]'); if (q) return ask(STARTERS[+q.dataset.q]);
    if (e.target.closest('[data-retry]')) return ask(err?.q || '');
    if (e.target.closest('[data-clear]')) { chat = []; err = null; draw(); }
  });
  root.addEventListener('submit', (e) => { e.preventDefault(); const t = root.querySelector('#q'); const v = t.value; t.value = ''; ask(v); });
  root.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && e.target.id === 'q') { e.preventDefault(); root.querySelector('[data-ask]').requestSubmit(); } });
  draw();
}
