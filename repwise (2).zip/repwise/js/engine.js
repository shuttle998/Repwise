/* Repwise engine: plan generation, progressive overload, stats, PRs, reports.
   Pure functions only (no DOM, no storage) so they can be tested in Node. */
(function (root) {
  const RW = (root.RW = root.RW || {});
  const D = RW.data;
  const KG = 0.45359237;

  /* ---- small helpers ----------------------------------------------------- */
  const pad = (n) => String(n).padStart(2, '0');
  const dkey = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const parseKey = (k) => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = (d, n) => { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() + n); return x; };
  const startOfDay = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const startOfWeek = (d) => addDays(startOfDay(d), -((d.getDay() + 6) % 7)); // Monday
  const val = (x, gear) => (x !== null && typeof x === 'object' ? x[gear] : x);
  const r1 = (x) => Math.round(x * 10) / 10;
  const roundTo = (x, s) => (s ? Math.round(x / s) * s : x);
  const same = (a, b) => Math.abs(a - b) < 0.05;
  const fmtNum = (x) => { const v = r1(x); return Number.isInteger(v) ? String(v) : v.toFixed(1); };
  const toUnit = (kg, units) => (units === 'lb' ? kg / KG : kg);
  const fromUnit = (v, units) => (units === 'lb' ? v * KG : v);
  const fmtW = (kg, units) => fmtNum(toUnit(kg, units));
  const days = (a, b) => Math.round((startOfDay(b) - startOfDay(a)) / 864e5);

  /* ---- exercise parameters ---------------------------------------------- */
  const stepKg = (ex, gear, units) => {
    const s = val(ex.step, gear) || 0;
    if (!s) return 0;
    if (units === 'lb') return (s >= 5 ? 10 : s >= 2 ? 5 : 2.5) * KG;
    return s;
  };
  const loadable = (ex, gear) => (val(ex.step, gear) || 0) > 0;
  const startWeight = (ex, gear, lvl, units) => {
    const step = stepKg(ex, gear, units);
    if (!step) return 0;
    const w = roundTo((val(ex.w0, gear) || 0) * [1, 1.5, 2][lvl || 0], step);
    return w > 0 ? w : step;
  };
  const repRange = (ex, goal) => {
    const G = D.GOALS[goal];
    if (ex.time) return ex.tr.slice();
    if (ex.r) return ex.r.slice();
    return (ex.type === 'compound' ? G.reps : G.iso).slice();
  };
  const setsFor = (ex, goal, lvl, idx) => {
    let s = D.GOALS[goal].sets;
    if (ex.type !== 'compound') return Math.max(2, s - 1);
    if (lvl === 0 && idx > 0) s = Math.max(2, s - 1);
    if (lvl === 2 && idx === 0) s += 1;
    return s;
  };
  const restFor = (ex, goal) => {
    const r = D.GOALS[goal].rest;
    return ex.type === 'compound' ? r : Math.max(30, Math.round((r * 0.7) / 5) * 5);
  };
  const sessionType = (name) => (/upper|arms/i.test(name) ? 'upper' : /lower|legs|glutes/i.test(name) ? 'lower' : 'full');

  /* ---- plan generation ---------------------------------------------------- */
  function pickExercise(slot, profile, variant, used) {
    const gear = profile.gear, rank = D.RANK[gear], limits = profile.limits || [];
    const style = profile.prefs && profile.prefs.style;
    let c = D.EXERCISES.filter((e) => e.p === slot && D.RANK[e.tier] <= rank);
    if (!c.length) return null;
    const safe = c.filter((e) => !e.stress.some((s) => limits.includes(s)));
    if (safe.length) c = safe;
    const top = Math.max(...c.map((e) => D.RANK[e.tier]));
    let pool = c.filter((e) => D.RANK[e.tier] >= top - (c.filter((e2) => D.RANK[e2.tier] === top).length < 2 ? 1 : 0));
    pool.sort((a, b) => D.RANK[b.tier] - D.RANK[a.tier]);
    if (style === 'free') pool.sort((a, b) => D.RANK[b.tier] - D.RANK[a.tier] || (a.m ? 1 : 0) - (b.m ? 1 : 0));
    if (style === 'machines') pool.sort((a, b) => D.RANK[b.tier] - D.RANK[a.tier] || (b.m ? 1 : 0) - (a.m ? 1 : 0));
    for (let i = 0; i < pool.length; i++) {
      const e = pool[(variant + i) % pool.length];
      if (!used.has(e.id)) return e;
    }
    return pool[variant % pool.length];
  }
  const DUR_COUNT = { 30: 3, 45: 4, 60: 5, 75: 6 };
  const estMinutes = (session) => {
    const sec = session.exercises.reduce((a, e) => a + e.sets * (45 + e.rest), 0);
    return Math.max(15, Math.round((sec / 60 + 5) / 5) * 5);
  };
  function muscleSets(plan) {
    const m = {};
    plan.sessions.forEach((s) => s.exercises.forEach((e) => {
      const ex = D.BY_ID[e.exId]; if (!ex) return;
      m[ex.mu] = (m[ex.mu] || 0) + e.sets;
      ex.sec.forEach((x) => (m[x] = (m[x] || 0) + e.sets * 0.5));
    }));
    return m;
  }
  function generatePlan(profile, variant) {
    variant = variant || 0;
    const p = Object.assign({ focus: 'balanced', days: 3, lvl: 0, gear: 'db', goal: 'muscle', dur: 60, limits: [], prefs: { core: true, style: 'balanced' } }, profile);
    p.prefs = Object.assign({ core: true, style: 'balanced' }, p.prefs);
    const L = D.SPLIT[p.focus][p.days <= 3 ? 3 : p.days].slice(0, p.days);
    const count = DUR_COUNT[p.dur] || 5;
    const sessions = L.map((s, si) => {
      let slots = s.k.slice();
      if (p.prefs.core === false) slots = slots.filter((k) => k !== 'core');
      if (slots.length > count) slots = slots.slice(0, count);
      const type = sessionType(s.n);
      D.EXTRAS[type].forEach((k) => { if (slots.length < count && !slots.includes(k)) slots.push(k); });
      const used = new Set(), exercises = [];
      slots.forEach((k, i) => {
        let ex = pickExercise(k, p, variant + si, used);
        // Keep the main lift, but swap accessory slots that stress a flagged joint for a safer movement
        if (ex && i > 0 && ex.stress.some((s) => p.limits.includes(s))) {
          const fallback = type === 'lower' ? ['thrust', 'hamcurl', 'abduct', 'calf', 'kick'] : ['rear', 'lateral', 'triceps', 'arms', 'hamcurl', 'calf'];
          for (const k2 of fallback) {
            if (slots.includes(k2)) continue;
            const alt = pickExercise(k2, p, variant + si, used);
            if (alt && !alt.stress.some((s) => p.limits.includes(s))) { ex = alt; break; }
          }
        }
        if (!ex) return;
        used.add(ex.id);
        exercises.push({ exId: ex.id, sets: setsFor(ex, p.goal, p.lvl, i), reps: repRange(ex, p.goal), rest: restFor(ex, p.goal) });
      });
      return { id: 's' + si, name: s.n, exercises };
    });
    const plan = { variant, createdAt: Date.now(), sessions, custom: false };
    plan.why = explain(p, plan);
    return plan;
  }
  function explain(p, plan) {
    const G = D.GOALS[p.goal], out = [];
    const goalWhy = {
      muscle: 'Sets of 8 to 12 reps balance heavy-enough loads with enough work per muscle to drive growth.',
      strength: 'Heavy sets of 4 to 6 reps with long rests let you lift as much as possible on every set, which is how strength is built.',
      fat: 'Higher reps with shorter rests keep you working hard and help you hold on to muscle while you eat a little less. Fat loss is mostly decided in the kitchen, so training is there to protect your muscle.',
      gain: 'Mid-range reps on big compound lifts, with solid rests, add size and strength while you eat more.',
    };
    out.push({ title: 'Built for: ' + G.n.toLowerCase(), text: goalWhy[p.goal] + ' You get ' + G.sets + ' sets, ' + G.t + ' and ' + G.restText + ' of rest on the main lifts.' });
    const split = { 2: 'Two full-body sessions let you train every major muscle twice a week with a rest day between.', 3: p.focus === 'balanced' ? 'Three full-body sessions train each muscle about three times a week, which is a strong rhythm for learning lifts and progressing quickly.' : 'Three sessions a week spread your work across the muscles you care about, with rest days between sessions that hit the same area.', 4: 'Four days lets us split upper and lower body, so each muscle is trained about twice a week and gets a few days to recover.', 5: 'Five days gives each muscle two hits a week plus a bonus session, with rest days placed so the same muscles are not trained back to back.' };
    out.push({ title: p.days + ' days a week', text: split[p.days] });
    if (p.focus !== 'balanced') out.push({ title: 'Focus: ' + D.FOCUS_NAME[p.focus].toLowerCase(), text: p.focus === 'glutes' ? 'Hip thrusts, split squats and glute isolation work come first in the sessions where they matter most.' : 'More of your weekly sets go to chest, back, shoulders and arms, while legs still get a dedicated day.' });
    const ex = D.GEAR[p.gear];
    out.push({ title: 'Equipment: ' + ex.toLowerCase(), text: p.gear === 'gym' ? 'Barbell and machine lifts where they give the best result.' : p.gear === 'db' ? 'Dumbbell and bodyweight versions of every main movement, so nothing in the plan needs a machine.' : 'Every exercise uses bodyweight. Progress comes from extra reps, slower tempo and harder variations.' });
    out.push({ title: 'Sized for about ' + (p.dur || 60) + ' minutes', text: 'Each session has ' + (DUR_COUNT[p.dur] || 5) + ' exercises, including rest between sets.' });
    if ((p.limits || []).length) out.push({ title: 'Protecting your ' + p.limits.map((l) => D.LIMITS[l].toLowerCase()).join(' and '), text: 'Where a safer option exists, we chose exercises that put less stress on those joints. Stop any exercise that hurts and use the "Something hurts" button.' });
    out.push({ title: 'How it progresses', text: 'Every exercise has a rep range. When you hit the top of the range on every set, Repwise adds weight. If you are inside the range it adds reps first, and if a lift felt hard or you missed reps it holds or lowers the weight. Weight never goes up just because you showed up.' });
    return out;
  }
  function substitutes(exId, profile) {
    const ex = D.BY_ID[exId], rank = D.RANK[profile.gear], lim = profile.limits || [];
    if (!ex) return [];
    return D.EXERCISES.filter((e) => e.id !== exId && D.RANK[e.tier] <= rank && (e.p === ex.p || (e.mu === ex.mu && e.type !== 'core' && ex.type !== 'core')))
      .map((e) => ({ ex: e, why: e.p === ex.p ? 'Same movement' : 'Same muscle', safe: !e.stress.some((s) => lim.includes(s)) }))
      .sort((a, b) => (b.safe - a.safe) || (a.why === b.why ? D.RANK[b.ex.tier] - D.RANK[a.ex.tier] : a.why === 'Same movement' ? -1 : 1));
  }
  function alternatives(exId) {
    const ex = D.BY_ID[exId];
    return D.EXERCISES.filter((e) => e.id !== exId && (e.p === ex.p || (e.mu === ex.mu && e.type === ex.type && ex.type !== 'core')));
  }

  /* ---- performance and records --------------------------------------------- */
  const e1rm = (w, r) => (w > 0 && r >= 1 && r <= 12 ? (r === 1 ? w : w * (1 + r / 30)) : 0);
  const exVolume = (e) => (e.skipped ? 0 : e.sets.reduce((a, s) => a + s.w * s.r, 0));
  const volume = (w) => w.exercises.reduce((a, e) => a + exVolume(e), 0);
  const setCount = (w) => w.exercises.reduce((a, e) => a + (e.skipped ? 0 : e.sets.length), 0);

  function perfs(workouts, exId) {
    const out = [];
    workouts.forEach((w) => w.exercises.forEach((e) => {
      if (e.exId === exId && !e.skipped && e.sets.length) out.push({ ts: w.ts, d: w.d, sets: e.sets, fb: e.fb || null, tgt: e.target });
    }));
    return out.sort((a, b) => a.ts - b.ts);
  }
  function modalWeight(sets) {
    const c = {};
    sets.forEach((s) => { const k = r1(s.w); c[k] = (c[k] || 0) + 1; });
    return Number(Object.keys(c).sort((a, b) => c[b] - c[a] || b - a)[0]);
  }

  /* ---- the progression engine ----------------------------------------------
     hist: performances of one exercise, oldest first, the last entry is the
     session that just ended. Returns what to do next time and why. */
  function recommend(o) {
    const { ex, hist, step, lo, hi, plannedSets, gear } = o;
    const cur = hist[hist.length - 1], prev = hist.length > 1 ? hist[hist.length - 2] : null;
    const sets = cur.sets.filter((s) => s.r > 0);
    const unit = ex.time ? ' sec' : ' reps';
    if (!sets.length) return { action: 'maintain', tone: 'hold', w: 0, reps: lo, label: 'Keep as is', reason: 'No sets were logged for this exercise, so nothing changes.', detail: {} };
    const w = modalWeight(sets);
    const atW = sets.filter((s) => same(s.w, w));
    const minR = Math.min(...atW.map((s) => s.r));
    const allSets = atW.length >= plannedSets;
    const fb = cur.fb;
    const inc = ex.time ? 5 : 1;
    const prevMod = prev ? modalWeight(prev.sets.filter((s) => s.r > 0)) : null;
    const prevAtW = prev && prevMod !== null && same(prevMod, w) ? prev.sets.filter((s) => s.r > 0 && same(s.w, w)) : null;
    const prevMin = prevAtW && prevAtW.length ? Math.min(...prevAtW.map((s) => s.r)) : null;
    const gap = o.gapDays;
    const e1 = Math.max(0, ...sets.map((s) => e1rm(s.w, s.r)));
    const first = hist.length > 2 ? hist[hist.length - 3] : prev;
    const e1First = first ? Math.max(0, ...first.sets.map((s) => e1rm(s.w, s.r))) : 0;
    const detail = { w, minR, prevMin, prevW: prevMod, e1Now: e1, e1Then: e1First, fbs: hist.slice(-3).map((h) => h.fb), sessionsAtWeight: hist.slice().reverse().findIndex((h) => { const m = modalWeight(h.sets.filter((s) => s.r > 0)); return !same(m, w); }) };
    if (detail.sessionsAtWeight === -1) detail.sessionsAtWeight = hist.length;
    const R = (action, nw, reps, reason, label, tone) => ({ action, w: Math.max(0, nw), reps, label, tone, reason, detail });
    const lower = (reasonStart) => {
      const nw = step ? Math.max(0, Math.min(w - step, roundTo(w * 0.9, step))) : 0;
      return step && w > 0 ? R('reduce', nw, lo, reasonStart + ' Drop to ' + o.fmt(nw) + ' and rebuild with clean reps.', 'Reduce weight', 'down') : R('adjust_exercise', w, lo, reasonStart + ' Try an easier variation of this exercise.', 'Adjust exercise', 'swap');
    };

    if (fb === 'pain') {
      if (prev && prev.fb === 'pain') return R('adjust_exercise', w, lo, 'You reported pain on this exercise two sessions in a row. Swap it for a similar movement and see a professional if it continues.', 'Adjust exercise', 'swap');
      return lower('You reported pain, so we back off.');
    }
    const hard3 = hist.length >= 3 && hist.slice(-3).every((h) => h.fb === 'hard') && hist.slice(-3).every((h) => same(modalWeight(h.sets.filter((s) => s.r > 0)), w));
    if (hard3) return lower('This has felt hard three sessions in a row, which is a sign you need a lighter week.');

    if (!allSets || minR < lo) {
      const missed = minR < lo;
      if (missed && prevAtW && prevMin !== null && prevMin < lo) {
        return lower('You fell short of ' + lo + o.unitWord + ' at ' + o.fmt(w) + ' in two sessions.');
      }
      const why = !allSets ? 'You did not finish all ' + plannedSets + ' planned sets, so the weight stays.' : 'Your lowest set was ' + minR + unit + ', under the ' + lo + ' target, so the weight stays.';
      return R('maintain', w, Math.max(lo, Math.min(hi, minR)), why + ' Aim for ' + lo + o.unitWord + ' or more on every set.', 'Keep weight', 'hold');
    }

    const hitTop = minR >= hi;
    if (gap !== null && gap !== undefined && gap < 2 && fb === 'hard') {
      return R('maintain', w, Math.max(lo, Math.min(hi, minR)), 'You trained this again within 48 hours and it felt hard, so recovery is the limit. Keep the weight and let your body catch up.', 'Keep weight', 'hold');
    }
    let res;
    if (hitTop) {
      if (fb === 'hard') {
        res = R('maintain', w, hi, 'You hit ' + hi + o.unitWord + ' on every set but it felt hard. Repeat it once more until it feels solid before adding weight.', 'Keep weight', 'hold');
      } else if (ex.time || (w === 0 && !step)) {
        res = R('adjust_exercise', w, lo, 'You reached the top of the range (' + hi + unit + ') on every set. Time to make it harder: ' + (gear === 'bw' ? 'try a harder variation of this exercise.' : 'add weight or use a harder variation.'), 'Make it harder', 'swap');
      } else {
        const wantJump = fb === 'easy' && minR >= hi + 2 ? 2 : 1;
        const maxJump = Math.max(step, w * 0.1);
        let jump = Math.min(step * wantJump, maxJump);
        jump = Math.max(step, roundTo(jump, step));
        res = R('increase_weight', w + jump, lo, 'You hit ' + hi + o.unitWord + ' on every set' + (fb === 'easy' ? ' and it felt easy' : '') + '. Add ' + o.fmt(jump) + ' and aim for ' + lo + o.unitWord + ' or more.', 'Increase weight', 'up');
      }
    } else {
      if (fb === 'hard') {
        res = R('maintain', w, minR, 'You completed every set but it felt hard. Repeat this weight and aim for ' + minR + ' or more reps on each set.', 'Keep weight', 'hold');
      } else {
        const t = Math.min(hi, minR + inc + (fb === 'easy' && !ex.time ? 1 : 0));
        res = R('increase_reps', w, t, 'You completed every set with ' + minR + unit + ' at the lowest. Same weight next time, aim for ' + t + o.unitWord + ' on every set. At ' + hi + ' on every set the weight goes up.', 'Add reps', 'up');
      }
    }
    if (res.action === 'maintain' && hist.length >= 3) {
      const l3 = hist.slice(-3);
      const ws = l3.map((h) => modalWeight(h.sets.filter((s) => s.r > 0)));
      const mins = l3.map((h) => Math.min(...h.sets.filter((s) => s.r > 0 && same(s.w, w)).map((s) => s.r)));
      if (ws.every((x) => same(x, w)) && mins[2] <= mins[0]) {
        return R('adjust_exercise', w, lo, 'You have stayed at ' + o.fmt(w) + ' for three sessions without adding reps. Try a variation of this exercise or a lighter week, then build back up.', 'Adjust exercise', 'swap');
      }
    }
    return res;
  }

  // Convenience: run the engine for one exercise given its plan target and all workouts
  function recommendFor(ctx) {
    const { exId, workouts, profile, units, target, current } = ctx;
    const ex = D.BY_ID[exId];
    const hist = perfs(workouts, exId);
    if (current) hist.push(current);
    if (!hist.length) return null;
    const step = stepKg(ex, profile.gear, units);
    const [lo, hi] = target.reps;
    const prev = hist.length > 1 ? hist[hist.length - 2] : null;
    const curTs = hist[hist.length - 1].ts;
    return recommend({
      ex, hist, step, lo, hi, plannedSets: target.sets, gear: profile.gear,
      gapDays: prev ? days(new Date(prev.ts), new Date(curTs)) : null,
      unitWord: ex.time ? ' sec' : ' reps',
      fmt: (kg) => fmtW(kg, units) + ' ' + units,
    });
  }

  // Weight to prefill for the next session, with a gentler return after long breaks
  function planWeight(prog, ex, profile, units, daysSince) {
    const step = stepKg(ex, profile.gear, units);
    if (prog && prog.w !== undefined && prog.w !== null) {
      let w = prog.w, note = null;
      if (step && w > 0 && daysSince !== null && daysSince >= 14) {
        const f = daysSince >= 28 ? 0.8 : 0.9;
        const nw = Math.max(step, Math.min(w - step, roundTo(w * f, step)));
        note = 'Welcome back: ' + daysSince + ' days since you last did this, so we start a little lighter.';
        w = nw;
      }
      return { w, note, fromHistory: true };
    }
    return { w: startWeight(ex, profile.gear, profile.lvl, units), note: null, fromHistory: false };
  }

  /* ---- records ------------------------------------------------------------ */
  function bestOf(entries) {
    // entries: array of {sets}
    let w = null, e = null, reps = null;
    entries.forEach((en) => en.sets.forEach((s) => {
      if (s.r < 1) return;
      if (s.w > 0 && (!w || s.w > w.v || (same(s.w, w.v) && s.r > w.r))) w = { v: s.w, r: s.r };
      const x = e1rm(s.w, s.r);
      if (x > 0 && (!e || x > e.v)) e = { v: x, w: s.w, r: s.r };
      if (!reps || s.r > reps.v) reps = { v: s.r, w: s.w };
    }));
    return { w, e, reps };
  }
  function findPRs(prior, workout) {
    const out = [];
    workout.exercises.forEach((e) => {
      if (e.skipped || !e.sets.length) return;
      const before = perfs(prior, e.exId);
      if (!before.length) return;
      const b = bestOf(before), c = bestOf([e]), ex = D.BY_ID[e.exId];
      const types = [];
      if (c.w && b.w && c.w.v > b.w.v + 0.01) types.push('weight');
      else if (c.w && !b.w) types.push('weight');
      if (c.e && b.e && c.e.v > b.e.v + 0.1) types.push('e1rm');
      if ((!c.w || !b.w) && c.reps && b.reps && c.reps.v > b.reps.v) types.push('reps');
      if (types.length) out.push({ exId: e.exId, types, w: c.w ? c.w.v : 0, r: c.w ? c.w.r : c.reps.v, e1: c.e ? c.e.v : 0, time: !!(ex && ex.time) });
    });
    return out;
  }
  function allBests(workouts) {
    const m = {};
    D.EXERCISES.forEach((ex) => {
      const p = perfs(workouts, ex.id);
      if (p.length) m[ex.id] = Object.assign({ sessions: p.length, last: p[p.length - 1].d }, bestOf(p));
    });
    return m;
  }
  const exSeries = (workouts, exId) => perfs(workouts, exId).map((p) => {
    const b = bestOf([p]);
    return { ts: p.ts, d: p.d, e1: b.e ? b.e.v : 0, w: b.w ? b.w.v : 0, reps: b.reps ? b.reps.v : 0, sets: p.sets, fb: p.fb };
  });

  /* ---- time-based stats ----------------------------------------------------- */
  function weekBuckets(workouts, now, n) {
    const out = [], s0 = startOfWeek(now);
    for (let i = n - 1; i >= 0; i--) {
      const s = addDays(s0, -7 * i), e = addDays(s, 7);
      const ws = workouts.filter((w) => w.ts >= s.getTime() && w.ts < e.getTime());
      out.push({ start: s, key: dkey(s), count: ws.length, vol: ws.reduce((a, w) => a + volume(w), 0), sets: ws.reduce((a, w) => a + setCount(w), 0) });
    }
    return out;
  }
  function dayBuckets(workouts, now, n) {
    const out = [], t0 = startOfDay(now);
    for (let i = n - 1; i >= 0; i--) {
      const s = addDays(t0, -i), e = addDays(s, 1);
      const ws = workouts.filter((w) => w.ts >= s.getTime() && w.ts < e.getTime());
      out.push({ start: s, key: dkey(s), count: ws.length, vol: ws.reduce((a, w) => a + volume(w), 0), sets: ws.reduce((a, w) => a + setCount(w), 0) });
    }
    return out;
  }
  function streakWeeks(workouts, target, now) {
    if (!workouts.length) return 0;
    target = Math.max(1, target || 1);
    const counts = {};
    workouts.forEach((w) => { const k = dkey(startOfWeek(new Date(w.ts))); counts[k] = (counts[k] || 0) + 1; });
    const firstWeek = startOfWeek(new Date(Math.min(...workouts.map((w) => w.ts))));
    let wk = startOfWeek(now), n = 0, cur = true;
    while (wk >= firstWeek) {
      if ((counts[dkey(wk)] || 0) >= target) n++;
      else if (!cur) break;
      cur = false;
      wk = addDays(wk, -7);
    }
    return n;
  }
  function bestStreakWeeks(workouts, target) {
    if (!workouts.length) return 0;
    target = Math.max(1, target || 1);
    const counts = {};
    workouts.forEach((w) => { const k = dkey(startOfWeek(new Date(w.ts))); counts[k] = (counts[k] || 0) + 1; });
    let wk = startOfWeek(new Date(Math.min(...workouts.map((w) => w.ts)))), end = startOfWeek(new Date(Math.max(...workouts.map((w) => w.ts)))), best = 0, run = 0;
    while (wk <= end) { if ((counts[dkey(wk)] || 0) >= target) { run++; best = Math.max(best, run); } else run = 0; wk = addDays(wk, 7); }
    return best;
  }
  function muscleDistribution(workouts) {
    const m = {}; let total = 0;
    workouts.forEach((w) => w.exercises.forEach((e) => {
      const ex = D.BY_ID[e.exId]; if (!ex || e.skipped) return;
      m[ex.mu] = (m[ex.mu] || 0) + e.sets.length; total += e.sets.length;
    }));
    return D.MUSCLES.filter((k) => m[k]).map((k) => ({ muscle: k, sets: m[k], pct: total ? m[k] / total : 0 })).sort((a, b) => b.sets - a.sets);
  }
  const inPeriod = (workouts, period, now) => {
    if (period === 'all') return workouts;
    const from = addDays(startOfDay(now), -(period - 1)).getTime();
    return workouts.filter((w) => w.ts >= from);
  };

  /* ---- weekly report --------------------------------------------------------- */
  function weeklyReport(state, weekStart, now) {
    const W = state.workouts, p = state.profile || {}, target = p.days || 3;
    const s = startOfDay(weekStart), e = addDays(s, 7), ps = addDays(s, -7);
    const inW = W.filter((w) => w.ts >= s.getTime() && w.ts < e.getTime());
    const prevW = W.filter((w) => w.ts >= ps.getTime() && w.ts < s.getTime());
    const before = W.filter((w) => w.ts < s.getTime());
    const vol = inW.reduce((a, w) => a + volume(w), 0), pvol = prevW.reduce((a, w) => a + volume(w), 0);
    const sets = inW.reduce((a, w) => a + setCount(w), 0);
    const exIds = [...new Set(inW.flatMap((w) => w.exercises.filter((x) => !x.skipped && x.sets.length).map((x) => x.exId)))];
    const improved = [];
    exIds.forEach((id) => {
      const b = bestOf(perfs(before, id)), c = bestOf(perfs(inW, id));
      if (!perfs(before, id).length) return;
      const ex = D.BY_ID[id];
      if (c.e && b.e && c.e.v > b.e.v + 0.1) improved.push({ exId: id, metric: 'e1rm', from: b.e.v, to: c.e.v });
      else if (c.w && b.w && c.w.v > b.w.v + 0.01) improved.push({ exId: id, metric: 'weight', from: b.w.v, to: c.w.v });
      else if (c.reps && b.reps && c.reps.v > b.reps.v && !(c.w && b.w)) improved.push({ exId: id, metric: ex.time ? 'time' : 'reps', from: b.reps.v, to: c.reps.v });
    });
    const prs = inW.flatMap((w) => (w.prs || []));
    const last4 = weekBuckets(W, addDays(s, 6), 4);
    const cons4 = last4.reduce((a, b) => a + Math.min(b.count, target), 0) / (4 * target);
    const planned = state.plan ? muscleSets(state.plan) : {};
    const done = {}; muscleDistribution(inW).forEach((m) => (done[m.muscle] = m.sets));
    const areas = [], recs = [];
    if (inW.length < target) areas.push('You finished ' + inW.length + ' of ' + target + ' planned sessions.');
    if (inW.length) Object.keys(planned).filter((m) => planned[m] >= 3 && !done[m]).slice(0, 3).forEach((m) => areas.push('No ' + m.toLowerCase() + ' sets were logged this week.'));
    inW.forEach((w) => w.exercises.forEach((x) => { if (x.fb === 'pain') areas.push((D.BY_ID[x.exId] || {}).name + ' was flagged as painful.'); }));
    exIds.forEach((id) => { const hs = inW.flatMap((w) => w.exercises.filter((x) => x.exId === id && !x.skipped)); if (hs.length >= 2 && hs.every((x) => x.fb === 'hard')) areas.push((D.BY_ID[id] || {}).name + ' felt hard every time.'); });
    if (pvol > 0 && vol > 0 && vol < pvol * 0.8) areas.push('Training volume fell ' + Math.round((1 - vol / pvol) * 100) + '% compared with the week before.');
    Object.keys(state.prog || {}).forEach((id) => { const g = state.prog[id]; if (g && g.action === 'adjust_exercise' && exIds.includes(id)) areas.push((D.BY_ID[id] || {}).name + ' has stalled: ' + g.reason); });
    exIds.forEach((id) => { const g = (state.prog || {})[id]; if (!g) return; const n = (D.BY_ID[id] || {}).name; if (g.action === 'increase_weight') recs.push({ exId: id, text: n + ': increase the weight next session.' }); if (g.action === 'reduce') recs.push({ exId: id, text: n + ': lower the weight and rebuild.' }); });
    if (inW.length < target) recs.unshift({ text: inW.length === 0 ? 'Start with one short session early in the week. Momentum matters more than perfection.' : 'Aim for ' + target + ' sessions next week. Pick your days now and book them like appointments.' });
    else recs.unshift({ text: 'You hit your target. Repeat the same schedule and focus on adding a rep on your main lifts.' });
    if (prs.length) recs.push({ text: 'You set ' + prs.length + ' personal record' + (prs.length > 1 ? 's' : '') + '. Keep sleep and protein steady so they stick.' });
    return { start: s, end: addDays(s, 6), completed: inW.length, target, vol, pvol, sets, improved, prs, cons: Math.min(1, inW.length / target), cons4, areas: areas.slice(0, 6), recs: recs.slice(0, 6), hasData: inW.length > 0, dur: inW.reduce((a, w) => a + (w.dur || 0), 0) };
  }

  /* ---- achievements ------------------------------------------------------------ */
  function achievementProgress(a, state, now) {
    const W = state.workouts, target = (state.profile && state.profile.days) || 3;
    switch (a.kind) {
      case 'workouts': return { cur: W.length, n: a.n };
      case 'streak': return { cur: bestStreakWeeks(W, target), n: a.n };
      case 'volume': return { cur: W.reduce((s, w) => s + volume(w), 0), n: a.n };
      case 'prs': return { cur: W.reduce((s, w) => s + (w.prs ? w.prs.length : 0), 0), n: a.n };
      case 'raised': return { cur: Object.keys(state.raised || {}).length, n: a.n };
    }
    return { cur: 0, n: a.n };
  }
  function newAchievements(state, now) {
    return D.ACHIEVEMENTS.filter((a) => !(state.ach || {})[a.id] && (() => { const p = achievementProgress(a, state, now); return p.cur >= p.n; })());
  }

  Object.assign(RW, {
    engine: {
      KG, dkey, parseKey, addDays, startOfDay, startOfWeek, days, r1, roundTo, same, fmtNum, toUnit, fromUnit, fmtW,
      stepKg, loadable, startWeight, repRange, setsFor, restFor, sessionType, pickExercise, generatePlan, explain, estMinutes, muscleSets,
      substitutes, alternatives, e1rm, volume, exVolume, setCount, perfs, modalWeight, recommend, recommendFor, planWeight,
      bestOf, findPRs, allBests, exSeries, weekBuckets, dayBuckets, streakWeeks, bestStreakWeeks, muscleDistribution, inPeriod,
      weeklyReport, achievementProgress, newAchievements,
    },
  });
  if (typeof module !== 'undefined') module.exports = RW;
})(typeof self !== 'undefined' ? self : globalThis);
