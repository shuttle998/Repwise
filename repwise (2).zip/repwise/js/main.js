import { load, state, subscribe, mutate } from './store.js';
import { $, esc, fmtClock } from './util.js';
import { icon, toast, sheet } from './ui.js';
import { elapsedMs } from './workout-logic.js';
import { startReminderEngine } from './reminder-engine.js';
import { startSync, syncNow } from './sync-engine.js';
import { initTheme } from './theme.js';
import { consumeAuthHash } from './cloud.js';

const NAV = [
  ['', 'Home', 'home'], ['train', 'Train', 'dumbbell'], ['progress', 'Progress', 'chart'], ['library', 'Library', 'book'], ['settings', 'More', 'sliders'],
];
const VIEWS = {
  '': () => import('./views/dashboard.js'), train: () => import('./views/train.js'), workout: () => import('./views/workout.js'),
  progress: () => import('./views/progress.js'), library: () => import('./views/library.js'), settings: () => import('./views/settings.js'),
  pricing: () => import('./views/pricing.js'), coach: () => import('./views/coach.js'), nutrition: () => import('./views/nutrition.js'), calendar: () => import('./views/calendar.js'), onboarding: () => import('./views/onboarding.js'),
};
const NAV_OF = { workout: 'train', coach: 'train', nutrition: '', calendar: '', pricing: 'settings', onboarding: '' };

let cleanup = null, token = 0, tick = null;
const parse = () => { const h = location.hash.replace(/^#\/?/, '').split('?')[0]; const [name = '', ...rest] = h.split('/'); return { name, params: rest.map(decodeURIComponent) }; };
export const go = (path) => { location.hash = '#/' + path; };

function renderNav(active) {
  $('#nav').innerHTML = NAV.map(([k, l, ic]) => `<a href="#/${k}" ${k === active ? 'aria-current="page"' : ''}>${icon(ic)}<span>${l}</span></a>`).join('');
  $('#side').innerHTML = `<a class="brand" href="#/" aria-label="Repwise home"><img src="favicon.svg" alt="" width="24" height="24">repwise</a>` + NAV.map(([k, l, ic]) => `<a href="#/${k}" ${k === active ? 'aria-current="page"' : ''}>${icon(ic)}<span>${l}</span></a>`).join('') + `<span class="spacer"></span><a href="#/pricing" ${active === 'settings' && parse().name === 'pricing' ? 'aria-current="page"' : ''}>${icon('bolt')}<span>Repwise Pro</span></a>`;
}

function renderResume(routeName) {
  const host = $('#resume'); clearInterval(tick);
  if (!state.active || routeName === 'workout') { host.innerHTML = ''; return; }
  host.innerHTML = `<a class="resume-bar" href="#/workout"><span>${icon('play')} Workout in progress</span><span class="num" id="rt">${fmtClock(elapsedMs() / 1000)}</span></a>`;
  tick = setInterval(() => { const n = $('#rt'); if (n && state.active) n.textContent = fmtClock(elapsedMs() / 1000); }, 1000);
}

async function route() {
  const my = ++token;
  let { name, params } = parse();
  if (!(name in VIEWS)) name = '';
  if (!state.profile && name !== 'pricing') name = 'onboarding';
  if (state.profile && name === 'onboarding') name = '';
  if (name === 'workout' && !state.active) { location.replace('#/train'); return; }
  document.body.classList.toggle('in-workout', name === 'workout');
  document.body.classList.toggle('in-onboarding', name === 'onboarding');
  const navKey = NAV_OF[name] ?? name;
  renderNav(name === 'onboarding' ? null : navKey); renderResume(name);
  $('.topbar').hidden = false; $('#side').style.visibility = name === 'onboarding' ? 'hidden' : '';
  $('#nav').style.display = name === 'onboarding' || name === 'workout' ? 'none' : '';
  try { cleanup?.(); } catch (e) { console.error(e); } cleanup = null;
  const main = $('#main'); main.innerHTML = '<div class="loading"><div class="spin" role="status" aria-label="Loading"></div></div>';
  try {
    const mod = await VIEWS[name]();
    if (my !== token) return;
    const root = document.createElement('div'); main.replaceChildren(root);
    const res = await mod.default(root, { params, go });
    if (my !== token) { res?.(); return; }
    cleanup = typeof res === 'function' ? res : null;
    document.title = (mod.title ? mod.title + ' · ' : '') + 'Repwise';
    window.scrollTo(0, 0); main.focus({ preventScroll: true });
  } catch (e) {
    console.error(e);
    main.innerHTML = `<div class="empty"><h3>Something went wrong loading this page</h3><p class="mut">Your data is safe on this device. Try again, or go back to the dashboard.</p><a class="btn primary" href="#/">Go home</a></div>`;
  }
}

function askName() {
  if (!state.profile || state.profile.name || state.ui.nameAsked) return;
  const s = sheet({ title: 'What should we call you?', html: `<p class="mut">Your plan and history from before are intact. Add a name to personalise the dashboard.</p><div class="field" style="margin-top:14px"><label for="nm" class="sr-only">Name</label><input class="input" id="nm" maxlength="30" autocomplete="given-name" placeholder="Your first name" data-autofocus></div><div class="btn-row"><button class="btn ghost" data-close>Skip</button><button class="btn primary" id="nmok">Save</button></div>`,
    onMount: (box, close) => box.querySelector('#nmok').addEventListener('click', () => { const v = box.querySelector('#nm').value.trim().slice(0, 30); mutate((st) => { st.profile.name = v; st.ui.nameAsked = true; }); close(); route(); }) });
  s.done.then(() => { if (!state.ui.nameAsked) mutate((st) => { st.ui.nameAsked = true; }, { silent: true }); });
}

/** Email links (confirm sign-up, reset password) come back as #access_token=...: take them out of the address bar before routing. */
function handleAuthLink() {
  if (!/access_token=/.test(location.hash)) return null;
  const r = consumeAuthHash(location.hash); history.replaceState(null, '', location.pathname + location.search + '#/settings'); return r;
}
function boot() {
  const status = load(); initTheme(state.settings.theme); const link = handleAuthLink();
  window.addEventListener('repwise:storage-error', () => toast('Could not save to this browser. Export your data from Settings to keep a backup.', 'err', 7000));
  window.addEventListener('hashchange', route);
  subscribe(() => { if (state.profile && parse().name === 'onboarding') route(); }); // data arrived from the cloud while on the set-up screen
  window.addEventListener('pageshow', (e) => { if (e.persisted) route(); });
  route().then(async () => {
    startSync();
    if (link?.type === 'recovery') { const m = await import('./views/account-ui.js'); m.openRecovery(link, { go }); }
    else if (link) { toast('Email confirmed. You are signed in.'); syncNow({ reason: 'confirm' }); }
    if (state.profile) startReminderEngine(); if (status === 'recovered') toast('Your data file was damaged, so Repwise restored the most recent automatic copy. Recent changes may be missing.', 'err', 9000); if (status === 'migrated') { toast('Your plan and workout history were carried over.'); setTimeout(askName, 600); } else setTimeout(askName, 400); });
  window.addEventListener('error', (e) => { console.error(e.error || e.message); });
  window.addEventListener('unhandledrejection', (e) => { console.error(e.reason); });
  navigator.storage?.persist?.().catch(() => {}); // ask the browser not to evict workout data when space is low
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    const had = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.register('sw.js').catch(() => {});
    navigator.serviceWorker.addEventListener('controllerchange', () => { if (had && !state.active) toast('Repwise was updated. Reload to use the latest version.', 'ok', 8000); });
  }
}
boot();
export { route };
