// Studio and class sessions (Pilates, yoga, barre, spin and so on): logged after the fact or booked ahead.
// They live in the same synced list as imported activities (source 'class') so backup, sync and deletion already work.
// Pure functions: nothing here touches the DOM or storage.
import { fmtDur } from './util.js';

/** `impact` is only a default for how much jumping and landing the class usually involves. The user can change it per class. */
export const CLASS_TYPES = [
  { id: 'pilates', label: 'Pilates', impact: 'low' },
  { id: 'yoga', label: 'Yoga', impact: 'low' },
  { id: 'barre', label: 'Barre', impact: 'low' },
  { id: 'mobility', label: 'Mobility or stretching', impact: 'low' },
  { id: 'swim', label: 'Swimming or aqua', impact: 'low' },
  { id: 'walk', label: 'Walking', impact: 'low' },
  { id: 'cycle', label: 'Cycling or spin', impact: 'medium' },
  { id: 'dance', label: 'Dance', impact: 'medium' },
  { id: 'strength', label: 'Strength class', impact: 'medium' },
  { id: 'hiit', label: 'HIIT or bootcamp', impact: 'high' },
  { id: 'boxing', label: 'Boxing or martial arts', impact: 'high' },
  { id: 'run', label: 'Running', impact: 'high' },
  { id: 'other', label: 'Other class', impact: 'medium' },
];
export const CLASS_BY_ID = Object.fromEntries(CLASS_TYPES.map((t) => [t.id, t]));
export const IMPACT = { low: 'Low impact', medium: 'Medium impact', high: 'High impact' };
export const EFFORT = { 1: 'Very easy', 2: 'Easy', 3: 'Moderate', 4: 'Hard', 5: 'Very hard' };
export const DEFAULT_MIN = { pilates: 50, yoga: 60, barre: 50, mobility: 30, swim: 45, walk: 30, cycle: 45, dance: 50, strength: 50, hiit: 45, boxing: 50, run: 40, other: 45 };

export const isClass = (a) => !!a && a.source === 'class';
/** Imported (watch and health file) activities only: class entries are managed separately. */
export const importedOnly = (list) => (list || []).filter((a) => !isClass(a));
export const classesOf = (list) => (list || []).filter(isClass);
const DATE = /^\d{4}-\d{2}-\d{2}$/, TIME = /^([01]\d|2[0-3]):[0-5]\d$/;

/**
 * Validates and cleans a class entry. `today` is a YYYY-MM-DD key.
 * Booked classes must be today or later; logged classes must be today or earlier.
 */
export function normClass(raw, today) {
  const r = raw || {}, type = CLASS_BY_ID[r.type] ? r.type : null;
  if (!type) return { error: 'Choose the type of class.' };
  if (!DATE.test(r.date || '')) return { error: 'Choose a date.' };
  const status = r.status === 'booked' ? 'booked' : 'done';
  if (status === 'booked' && r.date < today) return { error: 'A booked class cannot be in the past. Use “I did this class” instead.' };
  if (status === 'done' && r.date > today) return { error: 'You can only log a class that has already happened. Use “Booked ahead” for a future class.' };
  const time = TIME.test(r.time || '') ? r.time : '';
  if (status === 'booked' && !time) return { error: 'Add the start time so it shows correctly in your calendar.' };
  const mins = Math.round(Number(r.minutes));
  if (!(mins >= 5 && mins <= 300)) return { error: 'Enter the length in minutes, between 5 and 300.' };
  const impact = IMPACT[r.impact] ? r.impact : CLASS_BY_ID[type].impact;
  const out = { source: 'class', type, label: CLASS_BY_ID[type].label, date: r.date, time, start: `${r.date}T${time || '00:00'}`, durationSec: mins * 60, status, impact };
  const studio = String(r.studio || '').trim().slice(0, 60), note = String(r.note || '').trim().slice(0, 300), eff = Math.round(Number(r.effort));
  if (studio) out.studio = studio;
  if (note) out.note = note;
  if (status === 'done' && eff >= 1 && eff <= 5) out.effort = eff;
  return { value: out };
}

/** One line for lists: "Pilates · Studio name · 50 min · Low impact · Moderate". */
export const classLine = (c) => [c.label, c.studio, c.time ? c.time : '', c.durationSec ? fmtDur(c.durationSec) : '', IMPACT[c.impact], c.effort ? EFFORT[c.effort] : ''].filter(Boolean).join(' · ');
export const classesOn = (state, date) => classesOf(state.activities).filter((c) => c.date === date).sort((a, b) => (a.time || '') < (b.time || '') ? -1 : 1);
/** Dates on which a class was actually done. Booked-but-not-done classes never count as training. */
export const classDoneDates = (state) => new Set(classesOf(state.activities).filter((c) => c.status !== 'booked').map((c) => c.date));
/** Booked classes from `today` on, soonest first. */
export const upcomingClasses = (state, today, n = 5) => classesOf(state.activities).filter((c) => c.status === 'booked' && c.date >= today).sort((a, b) => (a.start < b.start ? -1 : 1)).slice(0, n);
/** Booked classes whose date has passed and were never marked done. */
export const unmarkedClasses = (state, today) => classesOf(state.activities).filter((c) => c.status === 'booked' && c.date < today).sort((a, b) => (a.start < b.start ? 1 : -1));

const esc = (s) => String(s).replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/[,;]/g, (c) => '\\' + c);
const fold = (l) => { const out = []; let s = l; while (s.length > 74) { out.push(s.slice(0, 74)); s = ' ' + s.slice(74); } out.push(s); return out.join('\r\n'); };
const pad = (n) => String(n).padStart(2, '0');
const stamp = (d) => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}T${pad(d.getHours())}${pad(d.getMinutes())}00`;
const utc = (d) => `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
/** A one-event calendar file for a booked class, with an alarm 60 minutes before. Times are floating local time. */
export function buildClassICS(c, now = new Date()) {
  const [y, mo, d] = c.date.split('-').map(Number), [hh, mm] = (c.time || '09:00').split(':').map(Number), start = new Date(y, mo - 1, d, hh, mm), end = new Date(start.getTime() + (c.durationSec || 3000) * 1000);
  const desc = [c.label, c.studio ? `at ${c.studio}` : '', c.note || ''].filter(Boolean).join('. ');
  return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Repwise//Classes//EN', 'CALSCALE:GREGORIAN', 'METHOD:PUBLISH', 'BEGIN:VEVENT', `UID:${String(c.id).replace(/[^\w:.-]/g, '')}@repwise`, `DTSTAMP:${utc(now)}`, `DTSTART:${stamp(start)}`, `DTEND:${stamp(end)}`, `SUMMARY:${esc(c.studio ? `${c.label} at ${c.studio}` : c.label)}`, `DESCRIPTION:${esc(desc)}`, 'BEGIN:VALARM', 'ACTION:DISPLAY', 'DESCRIPTION:Class starts in 1 hour', 'TRIGGER:-PT60M', 'END:VALARM', 'END:VEVENT', 'END:VCALENDAR'].map(fold).join('\r\n') + '\r\n';
}
