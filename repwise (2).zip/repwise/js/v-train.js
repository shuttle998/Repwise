/* Repwise: active workout, workout summary, workout detail sheet. */
(function () {
  const RW = window.RW, D = RW.data, E = RW.engine, S = RW.store, UI = RW.ui;
  const esc = UI.esc, ic = UI.ic, A = UI.acts, V = UI.views;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  const elapsed = (a) => ((a.pausedAt || Date.now()) - a.startedAt - (a.pausedMs || 0)) / 1000;
  UI.elapsed = elapsed;
  const restLeft = (a) => (a.rest ? (a.rest.end == null ? a.rest.left : Math.ceil((a.rest.end - Date.now()) / 1000)) : 0);
  const sinceLast = (ws, id) => { const p = E.perfs(ws, id); return p.length ? E.days(new Date(p[p.length - 1].ts), new Date()) : null; };

  /* wake lock keeps the screen on between sets */
  let lock = null;
  UI.wake = async (on) => {
    try {
      if (on && 'wakeLock' in navigator && !lock) { lock = await navigator.wakeLock.request('screen'); lock.addEventListener('release', () => { lock = null; }); }
      else if (!on && lock) { await lock.release(); lock = null; }
    } catch (e) { /* not supported or denied */ }
  };
  document.addEventListener('visibilitychange', () => { const a = S.act(); if (document.visibilityState === 'visible' && a && !a.pausedAt) UI.wake(true); });

  /* ---- build a workout from the plan ---------------------------------------- */
  function buildEx(pe, s, exId) {
    const id = exId || pe.exId, ex = D.BY_ID[id], p = s.profile, u = s.settings.units;
    const ld = E.loadable(ex, p.gear), pr = s.prog[id];
    const pw = E.planWeight(pr, ex, p, u, sinceLast(s.workouts, id));
    const rr = exId ? E.repRange(ex, p.goal) : pe.reps;
    const reps = pr && pr.reps ? clamp(pr.reps, rr[0], rr[1]) : ex.time ? Math.max(rr[0], 30) : rr[0];
    return {
      exId: id, from: exId ? pe.exId : null, target: { sets: pe.sets, reps: rr, rest: pe.rest },
      sets: Array.from({ length: pe.sets }, () => ({ w: ld ? pw.w : 0, r: reps, done: false })),
      cur: 0, fb: null, skipped: false, note: pw.note, first: !pw.fromHistory,
    };
  }
  function startWorkout(idx) {
    if (S.act()) { UI.go('#/workout'); return; }
    const s = S.get(), sess = s.plan && s.plan.sessions[idx];
    if (!sess || !sess.exercises.length) { UI.toast('That session has no exercises. Edit your programme first.', 'err'); return; }
    S.setActive({ id: 'w' + Date.now().toString(36), startedAt: Date.now(), pausedAt: null, pausedMs: 0, idx, name: sess.name, ex: sess.exercises.map((pe) => buildEx(pe, s)), i: 0, rest: null });
    UI.wake(true);
    UI.go('#/workout');
  }
  A.start = (el) => { UI.closeSheet(); const s = S.get(); startWorkout(el.dataset.idx !== undefined ? +el.dataset.idx : s.planIdx % s.plan.sessions.length); };
  A.resume = () => { UI.go('#/workout'); };

  /* ---- active workout view ------------------------------------------------------ */
  function stepper(label, unit, k, j, val, note) {
    return '<div class="stp"><div class="stp-l">' + label + ' <span>' + unit + '</span></div><div class="stp-r">' +
      '<button class="stp-b" data-act="adj" data-k="' + k + '" data-d="-1" data-j="' + j + '" aria-label="Decrease ' + label.toLowerCase() + '">' + ic('minus', 24) + '</button>' +
      '<input class="stp-i num" inputmode="decimal" autocomplete="off" data-in="set" data-k="' + k + '" data-j="' + j + '" value="' + val + '" aria-label="' + label + ' ' + unit + '">' +
      '<button class="stp-b" data-act="adj" data-k="' + k + '" data-d="1" data-j="' + j + '" aria-label="Increase ' + label.toLowerCase() + '">' + ic('plus', 24) + '</button></div></div>';
  }
  function lastTime(ws, id, u, ld, time) {
    const p = E.perfs(ws, id); if (!p.length) return null;
    const l = p[p.length - 1], w = E.modalWeight(l.sets);
    const reps = l.sets.filter((s) => E.same(s.w, w)).map((s) => s.r).join(', ');
    return { text: (ld && w > 0 ? UI.Wn(w) + ' ' + u + ' × ' : '') + reps + (time ? ' sec' : ''), d: l.d, fb: l.fb, w, sets: l.sets };
  }
  function setRow(a, e, ex, j, u, ld, last) {
    const s = e.sets[j], cur = e.cur === j;
    const val = (ld ? '<span>' + UI.Wn(s.w) + '<small>' + u + '</small></span><i>×</i>' : '') + '<span>' + s.r + (ex.time ? '<small>sec</small>' : '') + '</span>';
    if (!cur) return '<button class="set-c ' + (s.done ? 'done' : '') + '" data-act="set-open" data-j="' + j + '" aria-label="Set ' + (j + 1) + (s.done ? ' completed' : '') + '. Tap to edit"><span class="set-n">' + (s.done ? ic('check', 18) : j + 1) + '</span><span class="set-v num">' + val + '</span><span class="set-s">' + (s.done ? 'Done' : 'Edit') + '</span></button>';
    const unitLbl = u + (ex.pd ? ' each' : '');
    return '<div class="set-x ' + (s.done ? 'done' : '') + '"><div class="set-xh"><b>Set ' + (j + 1) + ' of ' + e.sets.length + '</b>' + (last ? '<span class="sm mut">Last time: ' + esc(last.text) + '</span>' : '') + '</div>' +
      (ld ? stepper('Weight', unitLbl, 'w', j, UI.Wn(s.w)) : '<p class="sm mut" style="margin-bottom:10px">Bodyweight exercise</p>') +
      stepper(ex.time ? 'Seconds' : 'Reps', '', 'r', j, s.r) +
      '<button class="btn lg block ' + (s.done ? 'alt' : 'ok') + '" data-act="set-done" data-j="' + j + '">' + (s.done ? 'Undo set ' + (j + 1) : ic('check', 20) + ' Complete set ' + (j + 1)) + '</button>' +
      (e.sets.length > 1 && !s.done ? '<button class="link xs" data-act="set-remove" data-j="' + j + '">Remove this set</button>' : '') + '</div>';
  }
  const TONE_IC = { up: 'up', hold: 'check', down: 'down', swap: 'swap' };
  function recCard(rec, opts) {
    opts = opts || {};
    const next = rec.w > 0 ? UI.W(rec.w) + ' × ' + rec.reps + (rec.reps ? '+' : '') : rec.reps + '+';
    const d = rec.detail || {};
    let det = '';
    if (UI.can('detail')) {
      const rows = [];
      if (d.prevMin) rows.push(['Previous session', d.prevMin + '+ reps' + (d.prevW ? ' at ' + UI.W(d.prevW) : '')]);
      if (d.minR) rows.push(['This session', d.minR + '+ ' + (opts.time ? 'sec' : 'reps') + (d.w ? ' at ' + UI.W(d.w) : '')]);
      if (d.e1Now && d.e1Then && Math.abs(d.e1Now - d.e1Then) > 0.05) rows.push(['Estimated 1RM', UI.W(d.e1Then) + ' → ' + UI.W(d.e1Now)]);
      else if (d.e1Now) rows.push(['Estimated 1RM', UI.W(d.e1Now)]);
      if (d.sessionsAtWeight) rows.push(['Sessions at this weight', String(d.sessionsAtWeight)]);
      const fbs = (d.fbs || []).filter(Boolean); if (fbs.length) rows.push(['Recent effort', fbs.map((f) => ({ easy: 'Easy', good: 'Just right', hard: 'Hard', pain: 'Pain' }[f])).join(', ')]);
      if (rows.length) det = '<dl class="det">' + rows.map((r) => '<div><dt>' + r[0] + '</dt><dd class="num">' + esc(r[1]) + '</dd></div>').join('') + '</dl>';
    } else if (!opts.compact) det = '<a class="link xs" href="#/pricing">See the trend behind this with Pro</a>';
    return '<div class="rec ' + rec.tone + '"><div class="rec-h"><span class="rec-i">' + ic(TONE_IC[rec.tone] || 'check', 18) + '</span><div><b>' + esc(rec.label) + '</b><div class="num rec-n">' + esc(opts.noNext ? '' : next) + '</div></div></div><p class="sm">' + esc(rec.reason) + '</p>' + det + '</div>';
  }
  UI.recCard = recCard;

  function liveRec(a, e) {
    const s = S.get(), done = e.sets.filter((x) => x.done && x.r > 0);
    if (!done.length) return null;
    return E.recommendFor({ exId: e.exId, workouts: s.workouts, profile: s.profile, units: s.settings.units, target: e.target, current: { ts: Date.now(), d: E.dkey(new Date()), sets: done.map((x) => ({ w: x.w, r: x.r })), fb: e.fb } });
  }

  V.workout = function () {
    const a = S.act();
    if (!a) return { redirect: '#/' };
    const s = S.get(), u = s.settings.units, p = s.profile, e = a.ex[a.i], ex = D.BY_ID[e.exId], ld = E.loadable(ex, p.gear);
    const n = a.ex.length, totalSets = a.ex.reduce((t, x) => t + (x.skipped ? 0 : x.sets.length), 0), doneSets = a.ex.reduce((t, x) => t + x.sets.filter((y) => y.done).length, 0);
    const allDone = e.sets.every((x) => x.done), anyDone = e.sets.some((x) => x.done), last = lastTime(s.workouts, e.exId, u, ld, ex.time), pr = s.prog[e.exId];
    const dots = a.ex.map((x, i) => { const d = x.sets.length && x.sets.every((y) => y.done); return '<button class="dot ' + (i === a.i ? 'on' : '') + (d ? ' fin' : '') + (x.skipped ? ' skp' : '') + '" data-act="ex-go" data-i="' + i + '" aria-label="Exercise ' + (i + 1) + ': ' + esc(UI.name(x.exId)) + (d ? ', complete' : x.skipped ? ', skipped' : '') + '"' + (i === a.i ? ' aria-current="step"' : '') + '>' + (d ? ic('check', 14) : i + 1) + '</button>'; }).join('');
    let recNote = '';
    if (e.first && !anyDone) recNote = '<div class="note-b">' + ic('info', 16) + '<span>First time on this exercise. The starting weight is light on purpose. Add weight when every set feels solid.</span></div>';
    else if (pr && !anyDone) recNote = '<details class="why"><summary><span class="chip ' + (pr.tone === 'up' ? 'ok' : pr.tone === 'down' ? 'bad' : pr.tone === 'swap' ? 'warn' : '') + '">' + esc(pr.label || 'Plan') + '</span><span class="sm">Today\'s target, and why</span></summary><p class="sm">' + esc(pr.reason || '') + '</p></details>';
    if (e.note && !anyDone) recNote += '<div class="note-b warn">' + ic('info', 16) + '<span>' + esc(e.note) + '</span></div>';
    const rec = anyDone ? liveRec(a, e) : null;
    const left = restLeft(a);
    const fbOpts = [['easy', 'Easy'], ['good', 'Just right'], ['hard', 'Hard']].map((o) => '<button class="fb" data-act="fb" data-v="' + o[0] + '" aria-pressed="' + (e.fb === o[0]) + '">' + o[1] + '</button>').join('');
    const body = e.skipped
      ? '<div class="card tight skipped"><p class="h3">Skipped</p><p class="sm mut">This exercise will not count toward your workout.</p><button class="btn alt sm" data-act="unskip" style="margin-top:12px">Undo skip</button></div>'
      : '<div class="sets">' + e.sets.map((x, j) => setRow(a, e, ex, j, u, ld, last)).join('') + '</div>' +
        '<div class="ex-acts"><button class="ghost-b" data-act="add-set">' + ic('plus', 16) + ' Add set</button>' + (anyDone ? '' : '<button class="ghost-b" data-act="swap">' + ic('swap', 16) + ' Swap</button>') + '<button class="ghost-b" data-act="skip">' + ic('skip', 16) + ' Skip</button></div>' +
        (anyDone ? '<div class="fb-box"><div class="lbl">How did that feel?</div><div class="fb-r" role="group" aria-label="How did that feel">' + fbOpts + '</div>' + (ld ? '<button class="hurt" data-act="hurt">Something hurts: lower the weight</button>' : '<button class="hurt" data-act="hurt">Something hurts: stop and skip this</button>') + '</div>' : (ld ? '<button class="hurt" data-act="hurt">Something hurts: lower the weight</button>' : '')) +
        (rec ? '<div class="rec-w"><div class="lbl">Next time</div>' + recCard(rec, { time: ex.time }) + '</div>' : '');
    const restBar = a.rest ? '<div class="rest ' + (left <= 0 ? 'over' : '') + (a.pausedAt ? ' held' : '') + '" role="timer" aria-label="Rest timer"><div class="rest-m"><span class="lbl">' + (left <= 0 ? 'Rest over' : 'Rest') + '</span><b class="num" id="rest-t">' + (left > 0 ? UI.clock(left) : 'Go') + '</b></div><div class="rest-a"><button class="rb" data-act="rest-add" data-s="-15" aria-label="Subtract 15 seconds">−15</button><button class="rb" data-act="rest-add" data-s="15" aria-label="Add 15 seconds">+15</button><button class="rb skip" data-act="rest-skip">Skip</button></div></div>' : '';
    const html =
      '<div class="wk">' +
      '<header class="wk-top"><button class="ibtn" data-act="leave" aria-label="Back to dashboard. Your workout keeps running">' + ic('left') + '</button><div class="wk-title"><b>' + esc(a.name) + '</b><span class="num sm mut" data-live="elapsed">' + UI.clock(elapsed(a)) + '</span></div><button class="btn sm alt" data-act="pause" aria-label="' + (a.pausedAt ? 'Resume' : 'Pause') + ' workout">' + ic(a.pausedAt ? 'play' : 'pause', 16) + (a.pausedAt ? 'Resume' : 'Pause') + '</button></header>' +
      '<div class="wk-prog"><div class="meter"><i style="width:' + (totalSets ? (doneSets / totalSets) * 100 : 0).toFixed(0) + '%"></i></div><span class="xs mut num">' + doneSets + ' of ' + totalSets + ' sets</span></div>' +
      '<nav class="dots" aria-label="Exercises">' + dots + '</nav>' +
      '<section class="wk-ex" aria-live="polite"><div class="wk-eh"><p class="lbl">Exercise ' + (a.i + 1) + ' of ' + n + (e.from ? ' · swapped from ' + esc(UI.name(e.from)) : '') + '</p><h1 class="ex-name">' + esc(ex.name) + '</h1>' +
      '<div class="ex-meta"><span class="chip blue">' + esc(ex.mu) + '</span>' + ex.sec.slice(0, 2).map((m) => '<span class="chip">' + esc(m) + '</span>').join('') + '<button class="chip how" data-act="how" data-id="' + ex.id + '">' + ic('info', 14) + ' How to</button></div>' +
      '<p class="target sm"><b class="num">' + e.target.sets + ' × ' + UI.range(ex, e.target.reps) + '</b><span class="mut"> · rest ' + UI.clock(e.target.rest) + (ex.pd && ld ? ' · weight per dumbbell' : '') + '</span></p></div>' +
      recNote + body + '</section>' +
      '<div class="wk-pad"></div>' + restBar +
      '<footer class="wk-bar"><button class="btn lg alt wk-prev" data-act="ex-prev" ' + (a.i === 0 ? 'disabled' : '') + ' aria-label="Previous exercise">' + ic('left', 22) + '</button>' +
      (a.i < n - 1 ? '<button class="btn lg block ' + (allDone || e.skipped ? '' : 'alt') + '" data-act="ex-next">Next exercise ' + ic('right', 20) + '</button>' : '<button class="btn lg block ok" data-act="finish">Finish workout</button>') + '</footer>' +
      (a.pausedAt ? '<div class="paused" role="dialog" aria-label="Workout paused"><div class="card"><p class="title" style="font-size:30px">Paused</p><p class="mut" style="margin:6px 0 20px">The timer is stopped. Your sets are saved.</p><button class="btn lg block" data-act="pause" data-autofocus>' + ic('play', 18) + ' Resume workout</button></div></div>' : '') +
      '</div>';
    return { html, title: a.name, chrome: 'workout' };
  };

  /* ---- actions ----------------------------------------------------------------- */
  const save = (a, keep) => { S.setActive(a); UI.render(keep !== false); };
  function setVal(e, j, k, v) {
    const s = e.sets[j]; s[k] = v; s.touched = true;
    for (let x = j + 1; x < e.sets.length; x++) { const t = e.sets[x]; if (!t.done && !t.touched) t[k] = v; }
  }
  A['set-open'] = (el) => { const a = S.act(), e = a.ex[a.i]; e.cur = +el.dataset.j; save(a); };
  A.adj = (el) => {
    const a = S.act(), e = a.ex[a.i], ex = D.BY_ID[e.exId], s = S.get(), u = s.settings.units, j = +el.dataset.j, d = +el.dataset.d, k = el.dataset.k;
    if (k === 'w') {
      const stepKg = E.stepKg(ex, s.profile.gear, u), stepD = u === 'lb' ? stepKg / E.KG : stepKg;
      const nd = Math.max(0, E.r1(E.toUnit(e.sets[j].w, u) + d * stepD));
      setVal(e, j, 'w', E.fromUnit(u === 'lb' ? Math.round(nd * 2) / 2 : nd, u));
    } else {
      setVal(e, j, 'r', clamp(e.sets[j].r + d * (ex.time ? 5 : 1), 0, 999));
    }
    save(a);
  };
  UI.inputs.set = (el) => {
    const a = S.act(), e = a.ex[a.i], u = UI.units(), j = +el.dataset.j, k = el.dataset.k;
    const v = parseFloat(String(el.value).replace(',', '.'));
    if (!isFinite(v) || v < 0) { UI.render(true); return; }
    if (k === 'w') setVal(e, j, 'w', E.fromUnit(Math.min(v, 1000), u)); else setVal(e, j, 'r', clamp(Math.round(v), 0, 999));
    save(a);
  };
  function startRest(a, e) { a.rest = { end: a.pausedAt ? null : Date.now() + e.target.rest * 1000, left: e.target.rest, dur: e.target.rest, fired: false }; }
  function livePR(e, s) {
    if (!UI.st().settings.celebrate || !s.r) return;
    e.pr = e.pr || {};
    const prior = E.bestOf(E.perfs(UI.st().workouts, e.exId)), ex = D.BY_ID[e.exId];
    if (s.w > 0 && prior.w && s.w > prior.w.v + 0.01 && !e.pr.w) { e.pr.w = 1; UI.toast('New personal best: ' + ex.name + ' at ' + UI.W(s.w), 'pr'); }
    else if (!(s.w > 0) && prior.reps && s.r > prior.reps.v && !e.pr.r) { e.pr.r = 1; UI.toast('New personal best: ' + ex.name + ', ' + s.r + (ex.time ? ' sec' : ' reps'), 'pr'); }
  }
  A['set-done'] = (el) => {
    UI.unlockAudio();
    const a = S.act(), e = a.ex[a.i], j = +el.dataset.j, s = e.sets[j];
    if (s.done) { s.done = false; e.cur = j; if (a.rest) a.rest = null; }
    else {
      s.done = true; e.skipped = false; livePR(e, s);
      const nx = e.sets.findIndex((x, k) => !x.done && k > j), any = e.sets.findIndex((x) => !x.done);
      e.cur = nx >= 0 ? nx : any;
      const finishedAll = a.i === a.ex.length - 1 && e.sets.every((x) => x.done);
      if (!finishedAll) startRest(a, e);
    }
    save(a);
  };
  A['set-remove'] = (el) => { const a = S.act(), e = a.ex[a.i]; e.sets.splice(+el.dataset.j, 1); e.cur = Math.min(e.cur, e.sets.length - 1); save(a); };
  A['add-set'] = () => { const a = S.act(), e = a.ex[a.i], l = e.sets[e.sets.length - 1]; e.sets.push({ w: l.w, r: l.r, done: false }); if (e.cur < 0) e.cur = e.sets.length - 1; save(a); };
  A.fb = (el) => { const a = S.act(), e = a.ex[a.i]; e.fb = e.fb === el.dataset.v ? null : el.dataset.v; save(a); };
  A.hurt = () => {
    const a = S.act(), e = a.ex[a.i], s = S.get(), ex = D.BY_ID[e.exId], u = s.settings.units, step = E.stepKg(ex, s.profile.gear, u);
    e.fb = 'pain';
    if (step && E.loadable(ex, s.profile.gear)) {
      e.sets.forEach((x) => { if (!x.done && x.w > 0) x.w = Math.max(step, E.roundTo(x.w - step * 2, step)); });
      UI.toast('Weight lowered for your remaining sets. Stop if it still hurts.', 'ok');
    } else UI.toast('Stop this exercise if it hurts. You can skip it.', 'ok');
    save(a);
  };
  A.skip = () => { const a = S.act(), e = a.ex[a.i]; e.skipped = true; if (a.i < a.ex.length - 1) a.i++; window.scrollTo(0, 0); save(a, false); };
  A.unskip = () => { const a = S.act(); a.ex[a.i].skipped = false; save(a); };
  A['ex-go'] = (el) => { const a = S.act(); a.i = +el.dataset.i; window.scrollTo(0, 0); save(a, false); };
  A['ex-next'] = () => { const a = S.act(); if (a.i < a.ex.length - 1) a.i++; window.scrollTo(0, 0); save(a, false); };
  A['ex-prev'] = () => { const a = S.act(); if (a.i > 0) a.i--; window.scrollTo(0, 0); save(a, false); };
  A.leave = () => UI.go('#/');
  A.pause = () => {
    const a = S.act(), now = Date.now();
    if (a.pausedAt) { a.pausedMs += now - a.pausedAt; a.pausedAt = null; if (a.rest && a.rest.end == null) a.rest.end = now + a.rest.left * 1000; UI.wake(true); }
    else { a.pausedAt = now; if (a.rest && a.rest.end != null) { a.rest.left = Math.ceil((a.rest.end - now) / 1000); a.rest.end = null; } UI.wake(false); }
    save(a);
  };
  A['rest-add'] = (el) => { const a = S.act(), d = +el.dataset.s; if (!a.rest) return; if (a.rest.end == null) a.rest.left = Math.max(0, a.rest.left + d); else a.rest.end += d * 1000; a.rest.fired = false; save(a); };
  A['rest-skip'] = () => { const a = S.act(); a.rest = null; save(a); };
  A.how = (el) => {
    const ex = D.BY_ID[el.dataset.id];
    UI.sheet(UI.sheetHead(ex.name, esc(ex.equip)) + '<h3 class="h3">How to do it</h3><ol class="steps">' + ex.how.map((x, i) => '<li><span class="num">' + (i + 1) + '</span><span>' + esc(x) + '.</span></li>').join('') + '</ol><h3 class="h3" style="margin-top:20px">Common mistakes</h3><ul class="mist">' + ex.err.map((x) => '<li>' + ic('x', 14) + '<span>' + esc(x) + '</span></li>').join('') + '</ul><a class="link" href="#/library/' + ex.id + '" data-act="sheet-close">Open in exercise library</a>', ex.name);
  };
  A.swap = () => {
    const a = S.act(), e = a.ex[a.i], s = S.get(), list = E.substitutes(e.exId, s.profile);
    UI.sheet(UI.sheetHead('Swap ' + UI.name(e.exId), 'Alternatives that fit your equipment.') + (list.length ? '<ul class="pick">' + list.slice(0, 10).map((x) => '<li><button class="opt" data-act="swap-do" data-id="' + x.ex.id + '"><span>' + esc(x.ex.name) + '<small>' + x.why + ' · ' + esc(x.ex.equip) + (x.safe ? '' : ' · stresses a joint you flagged') + '</small></span>' + ic('right', 18) + '</button></li>').join('') + '</ul>' : UI.empty('No alternatives', 'There is no other exercise for your equipment that trains the same area.')), 'Swap exercise');
  };
  A['swap-do'] = (el) => {
    const a = S.act(), e = a.ex[a.i], s = S.get(), nx = buildEx({ exId: e.exId, sets: e.target.sets, reps: e.target.reps, rest: e.target.rest }, s, el.dataset.id);
    nx.from = e.from || e.exId; a.ex[a.i] = nx; UI.closeSheet(); UI.toast('Swapped to ' + UI.name(nx.exId) + '.'); save(a);
  };

  /* ---- finishing -------------------------------------------------------------------- */
  A.finish = () => {
    const a = S.act(), done = a.ex.reduce((t, x) => t + x.sets.filter((y) => y.done).length, 0), total = a.ex.reduce((t, x) => t + (x.skipped ? 0 : x.sets.length), 0);
    const open = a.ex.filter((x) => !x.skipped && x.sets.some((y) => !y.done)).map((x) => UI.name(x.exId));
    if (!done) { UI.sheet(UI.sheetHead('No sets logged') + '<p class="mut" style="margin:-4px 0 20px">Complete at least one set to save this workout, or discard it.</p><div class="stack"><button class="btn lg block alt" data-act="sheet-close" data-autofocus>Keep training</button><button class="btn lg block danger" data-act="discard-do">Discard workout</button></div>', 'No sets logged'); return; }
    UI.sheet(UI.sheetHead('Finish workout?', done + ' of ' + total + ' sets completed.') + (open.length ? '<p class="sm mut" style="margin:-6px 0 16px">Not finished: ' + esc(open.join(', ')) + '. Only completed sets are saved.</p>' : '') + '<div class="stack"><button class="btn lg block ok" data-act="finish-do" data-autofocus>Finish and save</button><button class="btn lg block alt" data-act="sheet-close">Keep training</button><button class="btn block ghost" data-act="discard">Discard workout</button></div>', 'Finish workout');
  };
  A.discard = () => UI.confirm({ title: 'Discard this workout?', text: 'Nothing from this session will be saved and your weights will not change.', ok: 'Discard workout', danger: true, act: 'discard-do' });
  A['discard-do'] = () => { S.clearActive(); UI.wake(false); UI.closeSheet(); UI.toast('Workout discarded.'); UI.go('#/'); };
  A['finish-do'] = () => {
    const a = S.act(), s = S.get(), now = new Date();
    const exercises = a.ex.map((e) => ({ exId: e.exId, from: e.from || undefined, fb: e.fb, target: e.target, skipped: !e.sets.some((x) => x.done), sets: e.sets.filter((x) => x.done && x.r > 0).map((x) => ({ w: x.w, r: x.r })) }));
    if (!exercises.some((e) => e.sets.length)) { UI.closeSheet(); return; }
    const wk = { id: a.id, ts: now.getTime(), d: E.dkey(now), name: a.name, dur: Math.round(elapsed(a)), exercises, prs: [] };
    wk.prs = E.findPRs(s.workouts, wk);
    const all = s.workouts.concat([wk]);
    let newAch = [];
    S.update((st) => {
      exercises.forEach((e) => {
        if (e.skipped) return;
        const rec = E.recommendFor({ exId: e.exId, workouts: all, profile: st.profile, units: st.settings.units, target: e.target });
        if (!rec) return;
        st.prog[e.exId] = { w: rec.w, reps: rec.reps, action: rec.action, tone: rec.tone, label: rec.label, reason: rec.reason, date: wk.d, fb: e.fb, detail: rec.detail };
        if (rec.action === 'increase_weight') st.raised[e.exId] = true;
      });
      st.workouts.push(wk);
      st.planIdx = (a.idx + 1) % st.plan.sessions.length;
      newAch = E.newAchievements(st, now);
      newAch.forEach((x) => (st.ach[x.id] = wk.d));
    });
    S.clearActive(); UI.wake(false); UI.closeSheet();
    UI.s.summary = { id: wk.id, ach: newAch.map((x) => x.id) };
    if (!S.ok()) UI.toast('Your browser would not save this workout. Export your data from Settings.', 'err');
    UI.go('#/summary/' + wk.id);
  };

  /* ---- tick: clock, rest timer ---------------------------------------------------------- */
  UI.tick = () => {
    const a = S.act(); if (!a) return;
    document.querySelectorAll('[data-live="elapsed"]').forEach((el) => (el.textContent = UI.clock(elapsed(a))));
    if (!a.rest) return;
    const left = restLeft(a), t = document.getElementById('rest-t');
    if (t) t.textContent = left > 0 ? UI.clock(left) : 'Go';
    if (left <= 0 && !a.rest.fired && !a.pausedAt) { a.rest.fired = true; S.setActive(a); UI.beep(); if (document.getElementById('rest-t')) UI.render(true); }
  };

  /* ---- workout detail sheet and summary ---------------------------------------------------- */
  UI.workoutDetail = (w) => {
    const u = UI.units();
    const rows = w.exercises.length ? w.exercises.map((e) => { const ex = D.BY_ID[e.exId]; return '<div class="wd"><div class="wd-h"><b>' + esc(ex.name) + '</b>' + (e.fb ? '<span class="chip ' + (e.fb === 'pain' ? 'bad' : '') + '">' + ({ easy: 'Easy', good: 'Just right', hard: 'Hard', pain: 'Pain' }[e.fb]) + '</span>' : '') + '</div>' + (e.skipped ? '<p class="sm mut">Skipped</p>' : '<p class="num sm">' + e.sets.map((s) => (s.w > 0 ? UI.Wn(s.w) + '×' : '') + s.r + (ex.time ? 's' : '')).join('  ·  ') + '<span class="mut"> ' + (e.sets.some((s) => s.w > 0) ? u : '') + '</span></p>') + '</div>'; }).join('') : UI.empty('No exercise details', 'This workout was logged in an earlier version of Repwise, before sets were recorded.');
    UI.sheet(UI.sheetHead(w.name, UI.rel(w.d) + (w.dur ? ' · ' + UI.mins(w.dur) : '') + (E.volume(w) ? ' · ' + UI.vol(E.volume(w)) : '')) + rows, w.name);
  };
  A.wk = (el) => { const w = S.get().workouts.find((x) => x.id === el.dataset.id); if (w) UI.workoutDetail(w); };

  V.summary = function (arg) {
    const s = S.get(), w = s.workouts.find((x) => x.id === arg);
    if (!w) return { redirect: '#/' };
    const ach = (UI.s.summary && UI.s.summary.id === w.id ? UI.s.summary.ach : []).map((id) => D.ACHIEVEMENTS.find((x) => x.id === id)).filter(Boolean);
    const sets = E.setCount(w), vol = E.volume(w), done = w.exercises.filter((e) => !e.skipped).length;
    const prs = (w.prs || []).map((p) => { const ex = D.BY_ID[p.exId]; const bits = []; if (p.types.includes('weight')) bits.push('Heaviest: ' + UI.W(p.w) + ' × ' + p.r); if (p.types.includes('e1rm')) bits.push('Est. 1RM ' + UI.W(p.e1)); if (p.types.includes('reps')) bits.push('Most ' + (p.time ? 'seconds' : 'reps') + ': ' + p.r); return '<li class="pr-i"><span class="pr-ic">' + ic('trophy', 18) + '</span><div><b>' + esc(ex.name) + '</b><div class="sm mut">' + esc(bits.join(' · ')) + '</div></div></li>'; }).join('');
    const recs = w.exercises.filter((e) => !e.skipped && e.sets.length).map((e) => { const g = s.prog[e.exId]; if (!g || g.date !== w.d) return ''; return '<div class="card tight rec-row"><div class="rec-top"><b>' + esc(UI.name(e.exId)) + '</b></div>' + recCard(g, { compact: true, time: D.BY_ID[e.exId].time }) + '</div>'; }).join('');
    const html = '<section class="done-hero"><div class="done-ring">' + ic('check', 34) + '</div><p class="lbl">Workout complete</p><h1 class="title">' + esc(w.name) + '</h1><p class="mut">' + UI.rel(w.d) + (w.dur ? ' · ' + UI.mins(w.dur) : '') + '</p></section>' +
      '<div class="tiles t4"><div class="tile"><b class="num">' + sets + '</b><span>sets</span></div><div class="tile"><b class="num">' + done + '</b><span>exercises</span></div><div class="tile"><b class="num">' + (vol ? UI.volNum(vol) : '0') + '</b><span>' + UI.units() + ' lifted</span></div><div class="tile"><b class="num">' + (w.dur ? Math.round(w.dur / 60) : 0) + '</b><span>minutes</span></div></div>' +
      (ach.length ? '<h2 class="h2 sect">Milestone' + (ach.length > 1 ? 's' : '') + ' unlocked</h2><div class="ach-new">' + ach.map((x) => '<div class="card ach-card"><span class="ach-ic pop">' + ic('trophy', 22) + '</span><div><b>' + esc(x.name) + '</b><p class="sm mut">' + esc(x.desc) + '</p></div></div>').join('') + '</div>' : '') +
      (prs ? '<h2 class="h2 sect">Personal records</h2><ul class="card prs">' + prs + '</ul>' : '') +
      (recs ? '<h2 class="h2 sect">What to do next time</h2><div class="stack">' + recs + '</div>' : '') +
      '<div class="stack sect"><a class="btn lg block" href="#/">Back to dashboard</a><a class="btn lg block alt" href="#/progress">See progress</a></div>';
    return { html, title: 'Workout complete' };
  };
})();
