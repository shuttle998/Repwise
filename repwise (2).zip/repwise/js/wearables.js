// Importing workouts and body weight from health exports and activity files. Pure parsing, no DOM, so it is unit-tested.
// Supported: Apple Health export (export.zip or export.xml), TCX and GPX files (Garmin, Polar, Strava, Fitbit and others can export these).
// Imported activities are shown in your calendar and history but never count towards streaks, XP or challenges, so nothing is double counted.

const TYPES = [[/strength|weight|functionalstrength|crosstraining|hiit|highintensity/i, 'Strength'], [/running|run\b/i, 'Run'], [/walking|walk|hiking|hike/i, 'Walk'], [/cycling|biking|bike|ride/i, 'Cycle'], [/swimming|swim/i, 'Swim'], [/yoga|pilates|flexibility|mindandbody|stretch/i, 'Mobility'], [/rowing|row\b/i, 'Row'], [/elliptical|stairclimber|stepper/i, 'Cardio']];
export const labelFor = (raw) => { const s = String(raw || '').replace(/^HKWorkoutActivityType/, ''); for (const [re, l] of TYPES) if (re.test(s)) return l; return s ? s.replace(/([a-z])([A-Z])/g, '$1 $2').slice(0, 24) : 'Workout'; };
const attr = (tag, name) => { const m = new RegExp(`\\b${name}="([^"]*)"`).exec(tag); return m ? m[1].replace(/&amp;/g, '&').replace(/&quot;/g, '"') : null; };
const num = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : null; };
const hash = (str) => { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h * 33) ^ str.charCodeAt(i)) | 0; return (h >>> 0).toString(36); };
/** "2024-03-02 07:15:00 +0100" -> {date:'2024-03-02' (as written, i.e. local to the person), ms} */
export function parseHealthDate(s) {
  const m = /^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})\s*(Z|[+-]\d{2}:?\d{2})?/.exec(String(s || '')); if (!m) return null;
  const tz = m[3] ? (m[3] === 'Z' ? '+00:00' : m[3].replace(/^([+-]\d{2})(\d{2})$/, '$1:$2')) : '+00:00', ms = Date.parse(`${m[1]}T${m[2]}${tz}`);
  return Number.isFinite(ms) ? { date: m[1], ms } : null;
}
const toSeconds = (v, unit) => (v == null ? null : /min/i.test(unit || '') ? v * 60 : /hr|hour/i.test(unit || '') ? v * 3600 : v);
const toKcal = (v, unit) => (v == null ? null : /kj/i.test(unit || '') ? v / 4.184 : v);
const toMetres = (v, unit) => (v == null ? null : /km/i.test(unit || '') ? v * 1000 : /mi/i.test(unit || '') ? v * 1609.344 : /^m$/i.test(unit || 'm') || !unit ? v : v);
const toKg = (v, unit) => (v == null ? null : /lb/i.test(unit || '') ? v * 0.45359237 : /g$/i.test(unit || '') && !/kg/i.test(unit) ? v / 1000 : v);
const mk = (o) => ({ ...o, id: `${o.source}:${hash(o.start)}:${o.type}`, durationSec: Math.round(o.durationSec), kcal: o.kcal ? Math.round(o.kcal) : undefined, distanceM: o.distanceM ? Math.round(o.distanceM) : undefined, avgHr: o.avgHr ? Math.round(o.avgHr) : undefined, maxHr: o.maxHr ? Math.round(o.maxHr) : undefined });
const valid = (a) => a && a.durationSec >= 60 && a.durationSec < 86400 && /^\d{4}-\d{2}-\d{2}$/.test(a.date);

/** Incremental Apple Health parser: feed text chunks with push(), then call end(). Keeps only workouts, body weight and resting heart rate. */
export function appleHealthParser() {
  let buf = '', cur = null; const out = { activities: [], weights: [], restingHr: [], scanned: 0 };
  const finish = () => { if (cur) { const a = cur; cur = null; if (valid(a)) out.activities.push(mk(a)); } };
  const scan = (final) => {
    const re = /<(Workout|WorkoutStatistics|Record|\/Workout)\b[^>]*>/g; let m, last = 0;
    while ((m = re.exec(buf))) {
      last = re.lastIndex; const tag = m[0], kind = m[1];
      if (kind === 'Workout') {
        finish(); const st = parseHealthDate(attr(tag, 'startDate')); if (!st) continue; out.scanned++;
        let dur = toSeconds(num(attr(tag, 'duration')), attr(tag, 'durationUnit')); const en = parseHealthDate(attr(tag, 'endDate')); if (dur == null && en) dur = (en.ms - st.ms) / 1000;
        cur = { source: 'apple', type: attr(tag, 'workoutActivityType') || 'Workout', label: labelFor(attr(tag, 'workoutActivityType')), date: st.date, start: new Date(st.ms).toISOString(), durationSec: dur ?? 0, kcal: toKcal(num(attr(tag, 'totalEnergyBurned')), attr(tag, 'totalEnergyBurnedUnit')), distanceM: toMetres(num(attr(tag, 'totalDistance')), attr(tag, 'totalDistanceUnit')), device: attr(tag, 'sourceName') || undefined };
        cur.type = cur.label; if (/\/>$/.test(tag)) finish();
      } else if (kind === '/Workout') finish();
      else if (kind === 'WorkoutStatistics' && cur) {
        const t = attr(tag, 'type') || '';
        if (/HeartRate$/.test(t) && !/Resting|Variability/.test(t)) { cur.avgHr = num(attr(tag, 'average')); cur.maxHr = num(attr(tag, 'maximum')); }
        else if (/ActiveEnergyBurned$/.test(t) && cur.kcal == null) cur.kcal = toKcal(num(attr(tag, 'sum')), attr(tag, 'unit'));
        else if (/Distance/.test(t) && cur.distanceM == null) cur.distanceM = toMetres(num(attr(tag, 'sum')), attr(tag, 'unit'));
      } else if (kind === 'Record') {
        const t = attr(tag, 'type');
        if (t === 'HKQuantityTypeIdentifierBodyMass') { const d = parseHealthDate(attr(tag, 'startDate')), kg = toKg(num(attr(tag, 'value')), attr(tag, 'unit')); if (d && kg > 20 && kg < 400) out.weights.push({ date: d.date, ms: d.ms, kg: Math.round(kg * 10) / 10 }); }
        else if (t === 'HKQuantityTypeIdentifierRestingHeartRate') { const d = parseHealthDate(attr(tag, 'startDate')), v = num(attr(tag, 'value')); if (d && v > 25 && v < 150) out.restingHr.push({ date: d.date, bpm: Math.round(v) }); }
      }
    }
    // keep only what could be an unfinished tag
    if (final) { buf = ''; return; }
    const lt = buf.lastIndexOf('<'), keep = lt > last ? lt : buf.length > 4000 ? buf.length - 200 : last; buf = buf.slice(Math.min(keep, buf.length));
  };
  return { push(t) { buf += t; scan(false); }, end() { scan(true); finish(); return out; } };
}
export function parseAppleHealthXML(text) { const p = appleHealthParser(); p.push(text); return p.end(); }

/** TCX: one or more Activity elements. */
export function parseTCX(text) {
  const out = [];
  for (const m of String(text).matchAll(/<Activity\b[^>]*Sport="([^"]*)"[^>]*>([\s\S]*?)<\/Activity>/g)) {
    const body = m[2], id = (/<Id>([^<]+)<\/Id>/.exec(body) || [])[1]; const st = parseHealthDate((id || '').replace('T', ' ').replace(/\.\d+/, '')); const t0 = id ? Date.parse(id) : NaN; if (!st && !Number.isFinite(t0)) continue;
    const sum = (re) => [...body.matchAll(re)].reduce((a, x) => a + (parseFloat(x[1]) || 0), 0), hrs = [...body.matchAll(/<AverageHeartRateBpm[^>]*>\s*<Value>(\d+)<\/Value>/g)].map((x) => +x[1]), mx = [...body.matchAll(/<MaximumHeartRateBpm[^>]*>\s*<Value>(\d+)<\/Value>/g)].map((x) => +x[1]);
    const dur = sum(/<TotalTimeSeconds>([\d.]+)<\/TotalTimeSeconds>/g), date = st?.date || new Date(t0).toISOString().slice(0, 10);
    const a = mk({ source: 'tcx', type: labelFor(m[1]), label: labelFor(m[1]), date, start: new Date(Number.isFinite(t0) ? t0 : st.ms).toISOString(), durationSec: dur, kcal: sum(/<Calories>(\d+)<\/Calories>/g) || null, distanceM: sum(/<DistanceMeters>([\d.]+)<\/DistanceMeters>/g) || null, avgHr: hrs.length ? hrs.reduce((x, y) => x + y, 0) / hrs.length : null, maxHr: mx.length ? Math.max(...mx) : null });
    if (valid(a)) out.push(a);
  }
  return out;
}
const hav = (a, b) => { const R = 6371000, r = Math.PI / 180, dLat = (b[0] - a[0]) * r, dLon = (b[1] - a[1]) * r, x = Math.sin(dLat / 2) ** 2 + Math.cos(a[0] * r) * Math.cos(b[0] * r) * Math.sin(dLon / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(x)); };
/** GPX: one activity per <trk>, duration from first to last point, distance from the track, heart rate if the file has it. */
export function parseGPX(text) {
  const out = [];
  for (const m of String(text).matchAll(/<trk>([\s\S]*?)<\/trk>/g)) {
    const body = m[1], pts = [...body.matchAll(/<trkpt\b[^>]*lat="([-\d.]+)"[^>]*lon="([-\d.]+)"[^>]*>([\s\S]*?)<\/trkpt>/g)].map((p) => ({ ll: [+p[1], +p[2]], t: Date.parse((/<time>([^<]+)<\/time>/.exec(p[3]) || [])[1] || ''), hr: +((/<(?:\w+:)?hr>(\d+)<\/(?:\w+:)?hr>/.exec(p[3]) || [])[1] || NaN) }));
    const timed = pts.filter((p) => Number.isFinite(p.t)); if (timed.length < 2) continue;
    let dist = 0; for (let i = 1; i < pts.length; i++) dist += hav(pts[i - 1].ll, pts[i].ll);
    const hrs = pts.map((p) => p.hr).filter(Number.isFinite), type = (/<type>([^<]+)<\/type>/.exec(body) || [])[1] || (/<name>([^<]+)<\/name>/.exec(body) || [])[1] || '';
    const st = new Date(timed[0].t), a = mk({ source: 'gpx', type: labelFor(type), label: labelFor(type), date: `${st.getFullYear()}-${String(st.getMonth() + 1).padStart(2, '0')}-${String(st.getDate()).padStart(2, '0')}`, start: st.toISOString(), durationSec: (timed[timed.length - 1].t - timed[0].t) / 1000, distanceM: dist, avgHr: hrs.length ? hrs.reduce((x, y) => x + y, 0) / hrs.length : null, maxHr: hrs.length ? Math.max(...hrs) : null });
    if (valid(a)) out.push(a);
  }
  return out;
}

// ---- ZIP (just enough to read export.xml out of Apple's export.zip) ----
const u16 = (v, o) => v.getUint16(o, true), u32 = (v, o) => v.getUint32(o, true);
/** Finds a file in a zip and returns {name, method, size, offset, csize}. Reads only the end of the archive. */
export async function findZipEntry(file, pick = /(^|\/)export\.xml$/i) {
  const tail = Math.min(file.size, 66000), buf = await file.slice(file.size - tail).arrayBuffer(), v = new DataView(buf);
  let e = -1; for (let i = buf.byteLength - 22; i >= 0; i--) if (u32(v, i) === 0x06054b50) { e = i; break; }
  if (e < 0) throw new Error('This does not look like a zip file.');
  let cdSize = u32(v, e + 12), cdOff = u32(v, e + 16), n = u16(v, e + 10);
  if (cdOff === 0xffffffff) throw new Error('This zip is too large to read in the browser. Unzip it and choose export.xml instead.');
  const cd = new DataView(await file.slice(cdOff, cdOff + cdSize).arrayBuffer()); let p = 0;
  for (let i = 0; i < n && p + 46 <= cd.byteLength; i++) {
    const method = u16(cd, p + 10), csize = u32(cd, p + 20), size = u32(cd, p + 24), nl = u16(cd, p + 28), xl = u16(cd, p + 30), cl = u16(cd, p + 32), off = u32(cd, p + 42), name = new TextDecoder().decode(new Uint8Array(cd.buffer, p + 46, nl));
    if (pick.test(name) && !/__MACOSX/.test(name) && !/cda|electrocardiogram|workout-routes/i.test(name)) return { name, method, size, csize, offset: off };
    p += 46 + nl + xl + cl;
  }
  throw new Error('No export.xml found inside the zip. Choose the file you got from Apple Health > Export All Health Data.');
}
/** A ReadableStream of the entry's bytes (decompressed). */
export async function zipEntryStream(file, entry) {
  const h = new DataView(await file.slice(entry.offset, entry.offset + 30).arrayBuffer()); if (u32(h, 0) !== 0x04034b50) throw new Error('The zip file looks damaged.');
  const start = entry.offset + 30 + u16(h, 26) + u16(h, 28), raw = file.slice(start, start + entry.csize).stream();
  if (entry.method === 0) return raw; if (entry.method !== 8) throw new Error('This zip uses a compression method the browser cannot read. Unzip it and choose export.xml instead.');
  if (typeof DecompressionStream === 'undefined') throw new Error('This browser cannot unzip files. Unzip it first and choose export.xml.');
  return raw.pipeThrough(new DecompressionStream('deflate-raw'));
}
/** Parses any supported file. onProgress(0..1). Returns {activities, weights, restingHr, kind}. */
export async function parseHealthFile(file, onProgress = () => {}) {
  const name = (file.name || '').toLowerCase();
  const streamParse = async (stream, total) => { const p = appleHealthParser(), dec = new TextDecoder(), r = stream.getReader(); let read = 0; for (;;) { const { done, value } = await r.read(); if (done) break; read += value.byteLength; p.push(dec.decode(value, { stream: true })); onProgress(Math.min(1, read / (total || read || 1))); if (read % 4 === 0) await new Promise((x) => setTimeout(x)); } p.push(dec.decode()); return p.end(); };
  if (name.endsWith('.zip')) { const e = await findZipEntry(file); const r = await streamParse(await zipEntryStream(file, e), e.size); return { ...r, kind: 'Apple Health' }; }
  if (name.endsWith('.xml')) { const head = await file.slice(0, 4000).text(); if (/HealthData|<Workout|<Record/.test(head)) { const r = await streamParse(file.stream(), file.size); return { ...r, kind: 'Apple Health' }; } throw new Error('This XML file is not an Apple Health export.'); }
  const text = await file.text();
  if (name.endsWith('.tcx') || /<TrainingCenterDatabase/.test(text.slice(0, 2000))) return { activities: parseTCX(text), weights: [], restingHr: [], kind: 'TCX' };
  if (name.endsWith('.gpx') || /<gpx\b/.test(text.slice(0, 2000))) return { activities: parseGPX(text), weights: [], restingHr: [], kind: 'GPX' };
  throw new Error('Unsupported file. Choose an Apple Health export (.zip or export.xml), or a .tcx or .gpx activity file.');
}
/** Latest weight per day (kg). */
export const dailyWeights = (list) => { const m = new Map(); [...list].sort((a, b) => a.ms - b.ms).forEach((w) => m.set(w.date, w)); return [...m.values()]; };
export const hrZoneText = (avg, max) => (avg ? `${avg} bpm avg${max ? `, ${max} max` : ''}` : '');
