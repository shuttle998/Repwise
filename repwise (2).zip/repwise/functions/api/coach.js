// Cloudflare Pages Functions entry for /api/coach. Logic is shared with netlify/functions/coach.mjs.
import handler from '../../netlify/functions/coach.mjs';
export async function onRequest({ request, env }) {
  // Cloudflare passes secrets in `env`; the shared handler reads process.env.
  const g = globalThis; g.process = g.process || { env: {} }; g.process.env = g.process.env || {};
  for (const [k, v] of Object.entries(env || {})) if (typeof v === 'string') g.process.env[k] = v;
  return handler(request);
}
