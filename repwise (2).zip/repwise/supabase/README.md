# Setting up accounts and cloud sync (about 10 minutes, free)

1. Create a free project at https://supabase.com (Dashboard > New project). Pick a region near your users and save the database password.
2. Open **SQL Editor > New query**, paste the whole of `schema.sql`, and run it. This creates the tables, the row-level security rules, automatic backups and account deletion.
3. **Project Settings > API**: copy the *Project URL* and the *anon public* key into `CONFIG.CLOUD` in `js/config.js`:
   ```js
   CLOUD: { url: 'https://YOURPROJECT.supabase.co', anonKey: 'eyJ...' },
   ```
   The anon key is meant to be public. It cannot read anyone's data on its own; row-level security enforces that. **Never** put the `service_role` key anywhere in this app.
4. **Authentication > URL Configuration**: set *Site URL* to your Netlify address (for example `https://frabjous-marigold-eaaf81.netlify.app`) and add the same address under *Redirect URLs*. Password-reset and confirmation emails link back to it.
5. **Authentication > Providers > Email**: keep email sign-in on. "Confirm email" can stay on (recommended). Supabase's built-in email sender is rate-limited (a few emails an hour) which is fine for testing; add your own SMTP provider under *Authentication > SMTP* before launch.
6. Deploy. The Content-Security-Policy in `_headers` already allows `https://*.supabase.co`.

Backups: the trigger in `schema.sql` keeps your 10 most recent snapshots (at most one per 12 hours) per user, and the app can restore them. For project-level backups of the whole database, use Supabase's own backup features (paid plans) or run `pg_dump` on a schedule.

## First-run checklist (10 minutes, with your own project)

The sync code is tested against an in-memory imitation of Supabase, so run this once against the real thing:

1. Open the deployed site, **Settings > Account and sync > Create account**. If email confirmation is on, tap the link in the email; you should land back in the app, signed in.
2. Log a workout, then in Supabase **Table editor > user_data** confirm one row with your user id and `rev` increasing as you make changes.
3. Open the site on a second device (or a private window), **Sign in** from the first screen: your workouts should appear.
4. Add a workout on each device, tap **Sync now** on both: both devices should have both workouts.
5. Delete a workout on one device, sync both: it should disappear from both and stay gone.
6. **Settings > Account > Cloud backups** should list a snapshot after your second change (one is made at most every 12 hours). Try **Restore** on a test account only.
7. **Forgot password** sends an email; the link should open the app with a "Set a new password" form.
8. In a second test account, **Delete my account** and confirm the user disappears from **Authentication > Users** and its row from `user_data`.
9. Row-level security: sign in as user A, then in the SQL editor run `select count(*) from user_data` as the `anon` role (or call the REST API with only the anon key). You should get 0 rows.

If something fails, the browser console shows the server's message, and **Authentication > Logs** in Supabase shows the other side.
