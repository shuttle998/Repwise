-- Repwise cloud schema. Run this once in the Supabase SQL editor (Dashboard > SQL Editor > New query).
-- Every table has row-level security: a signed-in user can only ever see and change their own rows.

create table if not exists public.user_data (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  data       jsonb not null,
  rev        integer not null default 1,
  updated_at timestamptz not null default now()
);
alter table public.user_data enable row level security;
drop policy if exists "own data select" on public.user_data;
drop policy if exists "own data insert" on public.user_data;
drop policy if exists "own data update" on public.user_data;
drop policy if exists "own data delete" on public.user_data;
create policy "own data select" on public.user_data for select using (auth.uid() = user_id);
create policy "own data insert" on public.user_data for insert with check (auth.uid() = user_id);
create policy "own data update" on public.user_data for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own data delete" on public.user_data for delete using (auth.uid() = user_id);

-- Automatic database backups: the previous version of your data is copied here at most once per 12 hours; the newest 10 are kept.
create table if not exists public.user_backups (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  data       jsonb not null,
  rev        integer not null,
  created_at timestamptz not null default now()
);
create index if not exists user_backups_user_created on public.user_backups (user_id, created_at desc);
alter table public.user_backups enable row level security;
drop policy if exists "own backups select" on public.user_backups;
create policy "own backups select" on public.user_backups for select using (auth.uid() = user_id);
-- No insert/update/delete policies: only the trigger below (security definer) writes backups, and users cannot alter them.

create or replace function public.touch_and_backup() returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.updated_at := now();
  if not exists (select 1 from public.user_backups b where b.user_id = old.user_id and b.created_at > now() - interval '12 hours') then
    insert into public.user_backups (user_id, data, rev) values (old.user_id, old.data, old.rev);
    delete from public.user_backups where user_id = old.user_id and id not in (select id from public.user_backups where user_id = old.user_id order by created_at desc limit 10);
  end if;
  return new;
end $$;
drop trigger if exists user_data_backup on public.user_data;
create trigger user_data_backup before update on public.user_data for each row execute function public.touch_and_backup();

-- Account deletion: removes the signed-in user and (through cascades) all of their cloud data.
create or replace function public.delete_my_account() returns void language plpgsql security definer set search_path = public, auth as $$
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  delete from auth.users where id = auth.uid();
end $$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;
