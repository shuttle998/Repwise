// Vercel entry for the AI Coach. The logic lives in netlify/functions/coach.mjs so both hosts share one copy.
import handler from '../netlify/functions/coach.mjs';
export const GET = (req) => handler(req);
export const POST = (req) => handler(req);
