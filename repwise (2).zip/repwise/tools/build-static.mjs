// Copies only the files the site needs into dist/ (keeps tests, docs and server code out of the public folder).
import { cpSync, rmSync, mkdirSync, existsSync } from 'node:fs';
rmSync('dist', { recursive: true, force: true }); mkdirSync('dist');
for (const f of ['index.html', 'app.html', 'favicon.svg', 'manifest.webmanifest', 'sw.js', 'sw-manifest.js', '_headers', 'css', 'js', 'icons']) if (existsSync(f)) cpSync(f, 'dist/' + f, { recursive: true });
console.log('dist ready');
