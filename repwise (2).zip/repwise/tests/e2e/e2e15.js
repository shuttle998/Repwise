const { chromium } = require('playwright'); const { seed, key } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 375, height: 800 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true, serviceWorkers: 'block' }); const p = await c.newPage();
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(async () => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 1, working: {}, sessions: [], active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: false }, plan: 'free', ui: { nameAsked: true } })); });
  await p.reload(); await p.waitForSelector('.page-h');
  const noOverflow = async (m) => ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'no horizontal overflow: ' + m);
  const go = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(500); };
  const S = (f) => p.evaluate(async (src) => { const m = await import('/js/store.js'); return eval('(' + src + ')')(m.state); }, f.toString());
  await go('#/train'); await p.waitForSelector('[data-extra="warmup"]'); await noOverflow('train with session structure');
  ok(/Session structure/.test(await p.textContent('#main')), 'session structure card present');
  // library category filters
  await go('#/library'); await p.waitForSelector('#list'); await p.click('summary');
  for (const [ty, nm] of [['Cardio', 'Treadmill walk or run'], ['Warm-up', 'Arm circles'], ['Stretching', 'Hamstring stretch'], ['Glute activation', 'Clamshell']]) { await p.click(`[data-f="type"][data-v="${ty}"]`); await p.waitForTimeout(200); const names = await p.$$eval('.ex-row b', (l) => l.map((x) => x.textContent)); ok(names.includes(nm), ty + ' filter lists ' + nm + ' (' + names.length + ')'); }
  await go('#/library/clamshell'); await p.waitForSelector('h1'); ok(/Clamshell/.test(await p.textContent('h1')) && /Lie on your side/.test(await p.textContent('#main')) && !/undefined/.test(await p.textContent('#main')), 'extra move detail opens with steps');
  await go('#/library/treadmill'); await p.waitForSelector('h1'); ok(!/undefined/.test(await p.textContent('#main')), 'cardio detail has no undefined text');
  // turn on all extras + cardio
  await go('#/train'); await p.waitForSelector('[data-extra="warmup"]');
  for (const k of ['warmup', 'activation', 'cooldown']) { await p.check(`[data-extra="${k}"]`); await p.waitForTimeout(100); }
  await p.fill('[data-extra-cardio]', '12'); await p.dispatchEvent('[data-extra-cardio]', 'change'); await p.waitForTimeout(200);
  let x = await S((s) => s.settings.extras); ok(x.warmup && x.activation && x.cooldown && x.cardio === 12, 'extras saved in settings');
  await p.waitForTimeout(400); await p.click('[data-start="0"]'); await p.waitForTimeout(500); await p.waitForSelector('.ex-name'); await noOverflow('workout with extras');
  const act = await S((s) => s.active.items.map((i) => i.phase)); const order = ['warmup', 'activation', 'main', 'cardio', 'cooldown'];
  ok(act[0] === 'warmup' && act.includes('main') && act.includes('cardio') && act.includes('cooldown'), 'workout is built in phases: ' + [...new Set(act)].join(', '));
  ok(act.slice().sort((a, b) => order.indexOf(a) - order.indexOf(b)).join() === act.join(), 'phases in order');
  ok(/Warm-up/.test(await p.textContent('.lbl')), 'phase label shown on first exercise');
  // finish after marking main sets only: guided work must not write progression
  await p.evaluate(async () => { const m = await import('/js/store.js'); m.mutate((s) => { s.active.items.forEach((it) => { if (it.phase === 'main') it.sets.forEach((x) => { x.done = true; }); else it.skipped = true; }); }, { silent: true }); });
  await go('#/'); await go('#/workout'); await p.waitForSelector('.ex-name'); await p.click('[data-finish]'); await p.waitForSelector('.sheet [data-v="finish"]'); await p.click('.sheet [data-v="finish"]'); await p.waitForTimeout(900);
  const cele = await p.$('.cele'); if (cele) { await p.click('.cele [data-close]'); await p.waitForTimeout(300); }
  const sv = await S((s) => ({ n: s.sessions.length, cursor: s.cursor, a: !!s.active, g: Object.keys(s.working).filter((id) => /clamshell|leg-swings|treadmill|hip-circles|banded|quad|hamstring/.test(id)).length })); ok(sv.n === 1 && sv.cursor === 1 && !sv.a, 'session saved and programme advanced'); ok(sv.g === 0, 'no weight progression for guided items');
  // cardio only session
  await go('#/train'); await p.waitForSelector('[data-solo]'); await p.fill('[data-solo-min]', '20'); await p.click('[data-solo]'); await p.waitForSelector('.ex-name');
  const cs = await S((s) => ({ r: s.active.routineId, n: s.active.items.length, v: s.active.items[0].sets[0].reps, ex: s.active.items[0].exId })); ok(cs.r === 'cardio' && cs.n === 1 && cs.v === 20, 'cardio-only session starts: ' + cs.ex); ok(/min/.test(await p.textContent('#main')), 'minutes shown'); await noOverflow('cardio session');
  await p.evaluate(async () => { const m = await import('/js/store.js'); m.mutate((s) => { s.active.items[0].sets[0].done = true; }, { silent: true }); }); await go('#/'); await go('#/workout'); await p.waitForSelector('.ex-name'); await p.click('[data-finish]'); await p.waitForSelector('.sheet [data-v="finish"]'); await p.click('.sheet [data-v="finish"]'); await p.waitForTimeout(900);
  const c2 = await S((s) => ({ n: s.sessions.length, cursor: s.cursor, rid: s.sessions[s.sessions.length - 1].routineId })); ok(c2.n === 2 && c2.cursor === 1 && c2.rid === 'cardio', 'cardio session saved, programme cursor unchanged');
  console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no console errors'); console.log(fails.length ? fails.length + ' FAILED' : 'ALL PASSED'); await b.close(); process.exit(fails.length || errs.length ? 1 : 0);
})();
