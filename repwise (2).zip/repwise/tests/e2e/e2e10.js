const { chromium } = require('playwright'); const { seed, key } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 375, height: 800 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, acceptDownloads: true }); const p = await c.newPage();
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(async (sessions) => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 0, working: {}, sessions, active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: true }, plan: 'free', ui: { nameAsked: true } })); }, seed());
  await p.reload(); await p.waitForSelector('.page-h');
  const noOverflow = async (m) => ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'no horizontal overflow: ' + m);
  const go = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(500); };
  const txt = (s) => p.textContent(s);
  // old data loads with new fields
  const shape = await p.evaluate(async () => { const m = await import('/js/store.js'); return { r: m.state.reminders.enabled, i: Array.isArray(m.state.inbox) }; }); ok(shape.r === false && shape.i, 'old save hydrates with reminders and inbox defaults');
  // dashboard
  ok(await p.$('[aria-label="Level and XP"]') !== null, 'dashboard level card'); ok(await p.$('[aria-label="Challenges and calendar"]') !== null, 'dashboard challenges card'); await noOverflow('dashboard');
  // progress achievements
  await go('#/progress/achievements'); await p.waitForSelector('.lvl'); ok(/Level \d/.test(await txt('.lvl')), 'achievements shows level'); ok(/This week/.test(await txt('#pane')), 'weekly challenges listed'); await p.click('summary:has-text("How XP works")'); ok(/Extra workouts beyond your plan earn nothing/.test(await txt('#pane')), 'XP explained'); await noOverflow('achievements'); await p.screenshot({ path: require('os').tmpdir() + '/g-ach.png', fullPage: true });
  // calendar
  await go('#/calendar'); await p.waitForSelector('.cal-g'); ok((await p.$$('.cal-c')).length >= 28, 'calendar renders days'); ok(await p.$('.cal-c.done') !== null, 'completed workouts marked'); await noOverflow('calendar');
  const todayK = key(new Date()); ok(await p.$(`.cal-c[data-d="${todayK}"].sel`) !== null, 'today selected by default');
  const done = await p.$('.cal-c.done:not(.out)'); if (done) { await done.click(); await p.waitForTimeout(200); ok(/sets|Upper|Lower/.test(await txt('[aria-label="Selected day"]')), 'tapping a trained date shows workout history'); }
  const label0 = await txt('.cal-h h2'); await p.click('[data-nav="-1"]'); ok((await txt('.cal-h h2')) !== label0, 'previous month'); await p.click('[data-today]'); ok((await txt('.cal-h h2')) === label0, 'back to this month');
  await p.screenshot({ path: require('os').tmpdir() + '/g-cal.png', fullPage: true });
  // reminders
  await p.click('[data-rem]'); await p.waitForSelector('.dayp'); ok((await p.$$('.dayp[aria-pressed="true"]')).length === 3, 'default 3 planned days'); await noOverflow('reminders sheet');
  await p.click('.dayp[aria-pressed="false"] >> nth=0'); ok((await p.$$('.dayp[aria-pressed="true"]')).length === 4, 'toggle a planned day');
  await p.click('[data-rt="enabled"]'); await p.waitForSelector('#rt-time'); await p.fill('#rt-time', '07:15'); await p.dispatchEvent('#rt-time', 'change'); await p.waitForTimeout(200); ok(await p.inputValue('#rt-time') === '07:15', 'reminder time saved');
  const saved = await p.evaluate(async () => { const m = await import('/js/store.js'); return m.state.reminders; }); ok(saved.enabled && saved.time === '07:15' && saved.days.length === 4, 'reminders persisted in state');
  const dl = p.waitForEvent('download'); await p.click('[data-ics]'); const d = await dl; ok(d.suggestedFilename() === 'repwise-training.ics', 'ics downloads'); const fs = require('fs'); const body = fs.readFileSync(await d.path(), 'utf8'); ok(/BEGIN:VCALENDAR/.test(body) && (body.match(/BEGIN:VALARM/g) || []).length >= 4 && /T0715/.test(body), 'ics has alarms at chosen time');
  await p.screenshot({ path: require('os').tmpdir() + '/g-rem.png' }); await p.click('.sheet [data-close]'); await p.waitForTimeout(300);
  // reminder engine: force a due reminder
  const n = await p.evaluate(async () => { const m = await import('/js/store.js'), e = await import('/js/reminder-engine.js'); const now = new Date(); const wd = (now.getDay() + 6) % 7; m.setReminders({ enabled: true, days: [wd], time: '00:01' }); m.mutate((s) => { s.sessions = s.sessions.filter((x) => x.date !== (new Date().toISOString().slice(0, 10))); s.ui.remDelivered = []; }, { silent: true }); const c = e.checkReminders(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 9, 0)); return { c, inbox: m.state.inbox.map((x) => x.title), again: e.checkReminders(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 9, 1)) }; });
  ok(n.c === 1 && n.inbox.includes('Workout today'), 'due reminder delivered and put in inbox'); ok(n.again === 0, 'not delivered twice');
  // inbox from dashboard
  await go('#/'); await p.waitForSelector('[data-inbox]'); await p.click('[data-inbox]'); await p.waitForSelector('.sheet .li'); ok(/Workout today/.test(await txt('.sheet')), 'inbox lists notice'); await p.click('[data-dis]'); await p.waitForTimeout(100); await p.click('.sheet [data-close]');
  // settings entries
  await go('#/settings'); ok(/Workout calendar/.test(await txt('#main')) && /Reminders and planned days/.test(await txt('#main')), 'settings entries'); await noOverflow('settings');
  // finish a workout -> XP section
  await go('#/'); await p.click('[data-start]'); await p.waitForSelector('[data-done]'); await p.click('[data-done="0"]'); await p.waitForTimeout(300);
  await p.click('[data-finish]'); await p.click('.sheet [data-v="finish"]'); await p.waitForTimeout(900);
  const cele = await p.$('.cele'); if (cele) { await p.click('.cele [data-close]'); await p.waitForTimeout(300); }
  ok(/\+\d+ XP/.test(await txt('#main')) , 'workout summary shows XP earned'); await noOverflow('summary'); await p.screenshot({ path: require('os').tmpdir() + '/g-sum.png', fullPage: true });
  console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no console errors'); console.log(fails.length ? fails.length + ' FAILED' : 'ALL PASSED'); await b.close(); process.exit(fails.length || errs.length ? 1 : 0);
})();
