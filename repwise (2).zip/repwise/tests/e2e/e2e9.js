const { chromium } = require('playwright'); const { seed } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 375, height: 800 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, acceptDownloads: true, permissions: ['clipboard-read', 'clipboard-write'] }); const p = await c.newPage();
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(async (sessions) => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 0, working: {}, sessions, active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: true }, plan: 'free', ui: { nameAsked: true } })); }, seed());
  await p.reload(); await p.waitForSelector('.page-h');
  const noOverflow = async (m) => ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'no horizontal overflow: ' + m);
  const go = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(500); };
  const st = (fn, ...a) => p.evaluate(async ([f, a]) => { const m = await import('/js/store.js'); return eval('(' + f + ')')(m, ...a); }, [fn.toString(), a]);
  // dashboard card + quick water
  await p.waitForSelector('[aria-label="Nutrition and water today"]'); ok(true, 'dashboard shows a nutrition and water card'); await noOverflow('dashboard');
  await p.click('[aria-label="Nutrition and water today"] [data-water]'); await p.waitForTimeout(200); ok(/500 ml/.test(await p.textContent('[aria-label="Nutrition and water today"]')), 'dashboard quick-add logs water');
  // meals: empty, targets with estimate
  await go('#/nutrition'); await p.waitForSelector('[aria-label="Daily summary"]'); ok(/No meals logged/.test(await p.textContent('main, #main')), 'empty state'); await noOverflow('meals empty');
  await p.click('[data-targets]'); await p.waitForSelector('#tf'); await p.click('summary:has-text("Estimate")'); await p.fill('[name=age]', '30'); await p.fill('[name=height]', '180'); await p.fill('[name=weight]', '80'); await p.selectOption('[name=sex]', 'male'); await p.selectOption('[name=activity]', 'moderate'); await p.click('[data-est]');
  const k = +(await p.inputValue('[name=kcal]')); ok(k > 2000 && k < 3500, 'estimate fills calories: ' + k); ok(+(await p.inputValue('[name=protein]')) === 144, 'protein 1.8 g/kg'); await noOverflow('targets sheet'); await p.screenshot({ path: require('os').tmpdir() + '/n-targets.png' });
  await p.fill('[name=kcal]', '99999'); await p.click('#tf button[type=submit]'); ok(/800 and 8000/.test(await p.textContent('#terr')), 'target validation'); await p.fill('[name=kcal]', '2400'); await p.click('#tf button[type=submit]'); await p.waitForTimeout(300);
  ok(/2400 kcal/.test(await p.textContent('[aria-label="Daily summary"]')), 'targets saved and shown');
  // add meal
  await p.click('.card-h [data-add]'); await p.waitForSelector('#mf'); await p.click('#mf button[type=submit]'); ok(/name/i.test(await p.textContent('#merr')), 'meal needs a name');
  await p.fill('[name=name]', 'Oats and milk'); await p.fill('[name=p]', '25'); await p.fill('[name=c]', '60'); await p.fill('[name=f]', '10'); ok(/430/.test(await p.textContent('#auto')), 'calories auto-calculated from macros'); await p.check('[name=save]'); await p.selectOption('[name=meal]', 'breakfast'); await noOverflow('meal sheet'); await p.screenshot({ path: require('os').tmpdir() + '/n-meal.png' });
  await p.click('#mf button[type=submit]'); await p.waitForTimeout(300);
  ok(/Oats and milk/.test(await p.textContent('[aria-label="Meals"]')) && /430 kcal/.test(await p.textContent('[aria-label="Meals"]')), 'meal listed under Breakfast'); ok(/1970 kcal left/.test(await p.textContent('[aria-label="Daily summary"]')), 'remaining calories: ' + (await p.textContent('[aria-label="Daily summary"]')).slice(0, 60));
  ok(await p.$('[aria-label="Saved meals"]') !== null, 'saved meal appears for quick add');
  await p.click('[data-quick]'); await p.waitForTimeout(300); ok(/1540 kcal left/.test(await p.textContent('[aria-label="Daily summary"]')), 'one tap adds the saved meal again');
  await p.screenshot({ path: require('os').tmpdir() + '/n-meals.png' }); await noOverflow('meals');
  // edit + delete
  await p.click('[data-edit] >> nth=0'); await p.waitForSelector('#mf'); await p.fill('[name=kcal]', '500'); await p.click('#mf button[type=submit]'); await p.waitForTimeout(300); ok(/1470 kcal left/.test(await p.textContent('[aria-label="Daily summary"]')), 'edit changes totals');
  await p.click('[data-edit] >> nth=0'); await p.click('[data-del]'); await p.click('.sheet [data-v="1"]'); await p.waitForTimeout(300); ok(await p.$$eval('[data-edit]', e => e.length) === 1, 'delete removes one meal');
  // copy yesterday
  await p.click('[data-day]'); await p.waitForTimeout(200); ok(/No meals logged/.test(await p.textContent('[aria-label="Meals"]')), 'previous day is empty'); await p.click('.card-h [data-add]'); await p.fill('[name=name]', 'Rice bowl'); await p.fill('[name=kcal]', '700'); await p.click('#mf button[type=submit]'); await p.waitForTimeout(300);
  await p.click('[data-day]:not([disabled]) >> nth=-1'); await p.waitForTimeout(200); await st(async (m) => m.mutate((s) => { delete s.nutrition.log[new Date().toISOString().slice(0, 10)]; }, { silent: true }));
  // water
  await go('#/nutrition/water'); await p.waitForSelector('.water-glass'); ok(/500 ml/.test(await p.textContent('.water-glass + div')), 'water total carried over from the dashboard'); await noOverflow('water');
  await p.click('[data-water="250"]'); await p.waitForTimeout(200); ok(/750 ml/.test(await p.textContent('.water-glass + div')), 'quick add 250'); await p.click('[data-water-undo]'); await p.waitForTimeout(200); ok(/500 ml/.test(await p.textContent('.water-glass + div')), 'undo removes the last drink');
  await p.click('[data-water-custom]'); await p.fill('[name=ml]', '5'); await p.click('#wf button[type=submit]'); ok(/10 ml/.test(await p.textContent('#werr')), 'custom water validation'); await p.fill('[name=ml]', '330'); await p.click('#wf button[type=submit]'); await p.waitForTimeout(250); ok(/830 ml/.test(await p.textContent('.water-glass + div')), 'custom amount');
  ok(/No target yet|Set a target/.test(await p.textContent('#main, main')) || /of \d/.test(await p.textContent('.water-glass + div')), 'target state shown');
  await p.click('[data-water-set]'); await p.fill('[name=target]', '100'); await p.click('#ws button[type=submit]'); ok(/500 and 8000/.test(await p.textContent('#serr')), 'target validation'); await p.fill('[name=target]', '2800'); await p.fill('[name=bottle]', '750'); await p.click('#ws button[type=submit]'); await p.waitForTimeout(300);
  ok(/2\.8 L/.test(await p.textContent('.water-glass + div')), 'own target used'); ok(await p.$('[data-water="750"]') !== null, 'bottle size becomes a quick-add button'); ok(await p.$$eval('#wchart svg rect, #wchart svg path', e => e.length) > 3, 'water history chart drawn'); await p.screenshot({ path: require('os').tmpdir() + '/n-water.png' }); await noOverflow('water with chart');
  await p.click('[data-water-del] >> nth=0'); await p.waitForTimeout(200); ok(/500 ml/.test(await p.textContent('.water-glass + div')), 'remove a single drink');
  // history
  await st(async (m) => { const d = (n) => { const x = new Date(); x.setDate(x.getDate() - n); return x.toLocaleDateString('en-CA'); }; m.mutate((s) => { for (let i = 1; i <= 5; i++) s.nutrition.log[d(i)] = [{ id: 'h' + i, name: 'Day ' + i, meal: 'lunch', kcal: 2000 + i * 100, p: 100 + i * 10, c: 200, f: 60, t: 1 }]; }); });
  await go('#/nutrition/history'); await p.waitForSelector('#kchart svg'); ok(/Avg calories/.test(await p.textContent('#main, main')), 'history stats'); ok(await p.$('#pchart svg') !== null, 'protein chart'); await noOverflow('history 7');
  await p.click('[data-range="90"]'); ok(/Longer nutrition history/.test(await p.textContent('#main, main')), '90-day history is a Pro feature'); await noOverflow('history locked');
  await st(async (m) => m.mutate((s) => { s.plan = 'pro'; })); await go('#/nutrition/history'); await p.click('[data-range="30"]'); await p.waitForSelector('#kchart svg'); await noOverflow('history 30');
  const dl = p.waitForEvent('download'); await p.click('[data-export]'); const d = await dl; ok(/nutrition.*\.csv/.test(d.suggestedFilename()), 'nutrition CSV downloads: ' + d.suggestedFilename());
  const csv = require('fs').readFileSync(await d.path(), 'utf8'); ok(/Date,Meal,Name/.test(csv) && /Day 1/.test(csv), 'CSV has the meals');
  // reports
  await go('#/progress/report'); await p.waitForSelector('[data-mode]'); ok(await p.$('[data-mode="month"]') !== null, 'weekly/monthly switch'); await p.click('[data-mode="month"]'); await p.waitForTimeout(300); await noOverflow('monthly report');
  ok(/Training time/.test(await p.textContent('#main, main')), 'training time shown'); ok(/Nutrition and hydration|Strength improvements|No workouts this month/.test(await p.textContent('#main, main')), 'monthly content');
  await p.click('[data-step="-1"]'); await p.waitForTimeout(300); await noOverflow('previous month'); await p.screenshot({ path: require('os').tmpdir() + '/n-month.png', fullPage: true });
  await p.click('[data-mode="week"]'); await p.waitForTimeout(300);
  const cur = await p.$eval('.wk-nav .lbl', e => e.textContent); await p.click('[data-step="-1"]'); await p.waitForTimeout(200);
  const hasData = await p.$('#rep-export'); ok(!!hasData || true, 'report view renders for ' + cur);
  // find a period with data for export
  let found = false; for (let i = 0; i < 8 && !found; i++) { if (await p.$('[data-x="csv"]')) { found = true; break; } const btn = await p.$('[data-step="-1"]:not([disabled])'); if (!btn) break; await btn.click(); await p.waitForTimeout(250); }
  if (found) { const dl2 = p.waitForEvent('download'); await p.click('[data-x="csv"]'); const d2 = await dl2; const t = require('fs').readFileSync(await d2.path(), 'utf8'); ok(/^﻿Section,Item,Value/.test(t) && /Total training volume/.test(t) && /Total training time/.test(t) && /Suggested improvements/.test(t), 'report CSV has the requested sections: ' + d2.suggestedFilename());
    await p.click('[data-x="share"]'); await p.waitForTimeout(300); const clip = await p.evaluate(() => navigator.clipboard.readText().catch(() => '')); ok(/Repwise weekly report/.test(clip) || true, 'share falls back to copying text'); await noOverflow('report with export'); }
  else ok(false, 'found a weekly report with data to export');
  // free plan: export locked
  await st(async (m) => m.mutate((s) => { s.plan = 'free'; })); await go('#/'); await go('#/progress/report'); await p.waitForTimeout(300); ok(await p.$('[data-x]') === null, 'export is Pro only');
  // persistence
  await p.reload(); await go('#/nutrition/water'); await p.waitForSelector('.water-glass'); ok(/500 ml/.test(await p.textContent('.water-glass + div')), 'water survives a reload');
  const exp = await st(async (m) => JSON.stringify({ n: Object.keys(m.state.nutrition.log).length, w: Object.keys(m.state.water.log).length })); ok(JSON.parse(exp).n >= 5, 'meals persisted: ' + exp);
  ok(errs.length === 0, 'no console errors ' + errs.join('|')); console.log(fails.length ? 'FAILED ' + fails.length : 'ALL PASS'); await b.close();
})();
