const { chromium } = require('playwright'); const { seed } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 375, height: 800 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true }); const p = await c.newPage();
  const ytReq = []; p.on('request', r => { if (/youtube/.test(r.url())) ytReq.push(r.url()); });
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource|youtube/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(async (sessions) => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: ['knees'], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 0, working: {}, sessions, active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: true }, plan: 'free', ui: { nameAsked: true } })); }, seed());
  await p.goto('http://localhost:8123/app.html#/library'); await p.reload(); await p.waitForSelector('.ex-row');
  ok((await p.$$('.vid-badge')).length === 0, 'library rows no longer need a video badge (every exercise has a built-in animation)');
  ok(ytReq.length === 0, 'no YouTube request before tapping play');
  await p.goto('http://localhost:8123/app.html#/library/bench'); await p.waitForSelector('details.more summary'); await p.click('details.more summary'); await p.waitForSelector('.demo', { state: 'visible' });
  ok(await p.$('.demo-poster') !== null, 'poster shown first');
  const txt = await p.textContent('main, #main'); ok(/Starting position/.test(txt) && /Finishing position/.test(txt) && /Breathing/.test(txt) && /Safety/.test(txt), 'positions, breathing and safety sections present');
  ok(await p.$('.demo-src a[href*="watch?v=XFKZ6Yw8XbE"]') !== null, 'credit link to the source video');
  await p.screenshot({ path: require('os').tmpdir() + '/v-detail.png' });
  await p.click('[data-demo-play]'); await p.waitForSelector('.demo iframe');
  const src = await p.$eval('.demo iframe', e => e.src); ok(src.startsWith('https://www.youtube-nocookie.com/embed/XFKZ6Yw8XbE?') && /loop=1/.test(src) && /enablejsapi=1/.test(src), 'iframe uses nocookie embed with loop: ' + src.slice(0, 70));
  await p.waitForTimeout(1500);
  ok(await p.$eval('.demo-bar', e => !e.hidden), 'controls appear after load');
  await p.click('[data-demo-cmd="pause"]'); await p.click('[data-demo-cmd="replay"]'); await p.click('[data-demo-rate="0.5"]');
  ok(await p.$eval('[data-demo-rate="0.5"]', e => e.getAttribute('aria-pressed') === 'true') && await p.$eval('[data-demo-rate="1"]', e => e.getAttribute('aria-pressed') === 'false'), 'speed selection updates');
  ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'no horizontal overflow on detail page (375px)');
  // offline message
  await p.goto('http://localhost:8123/app.html#/library/plank'); await p.waitForSelector('details.more summary'); await p.click('details.more summary'); await p.waitForSelector('.demo', { state: 'visible' }); await c.setOffline(true); await p.evaluate(() => {}); await p.click('[data-demo-play]');
  ok(/offline/i.test(await p.textContent('.demo-msg')) && await p.$('.demo iframe') === null, 'offline: clear message, no broken player'); await c.setOffline(false);
  // workout sheet
  await p.goto('http://localhost:8123/app.html#/'); await p.waitForSelector('[data-start]'); await p.click('[data-start]'); await p.waitForSelector('.ex-card');
  ok(/Demo & technique/.test(await p.textContent('[data-info]')), 'workout button advertises the demo');
  const t0 = await p.textContent('#resume, .w-head, body').catch(() => ''); await p.click('[data-info]'); await p.waitForSelector('.sheet details.more summary'); await p.click('.sheet details.more summary'); await p.waitForSelector('.sheet .demo', { state: 'visible' });
  await p.click('.sheet [data-demo-play]'); await p.waitForSelector('.sheet iframe');
  ok(/Breathing/.test(await p.textContent('.sheet')) && /Safety/.test(await p.textContent('.sheet')), 'workout sheet has breathing and safety');
  await p.screenshot({ path: require('os').tmpdir() + '/v-sheet.png' });
  await p.keyboard.press('Escape'); await p.waitForTimeout(300);
  ok(await p.$('.sheet iframe') === null && await p.$('.ex-card') !== null, 'closing the sheet returns to the workout, video removed');
  // every exercise detail renders without error
  for (const id of await p.evaluate(async () => (await import('/js/exercises.js')).EXERCISES.filter(e => e.slot !== 'mindbody' && !e.extra).map(e => e.id))) { await p.goto('http://localhost:8123/app.html#/library/' + id); await p.waitForSelector('details.more summary'); await p.click('details.more summary'); await p.waitForSelector('.demo', { state: 'visible' }); }
  ok(true, 'all 42 detail pages render a player'); ok(errs.length === 0, 'no console errors ' + errs.join('|'));
  console.log(fails.length ? 'FAILED ' + fails.length : 'ALL PASS'); await b.close();
})();
