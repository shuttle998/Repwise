const { chromium } = require('playwright'); const { seed, key } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
const today = key(new Date());
const AH = `<HealthData><Record type="HKQuantityTypeIdentifierBodyMass" unit="kg" value="81.2" startDate="2025-01-05 07:30:00 +0100"/><Workout workoutActivityType="HKWorkoutActivityTypeRunning" duration="30" durationUnit="min" totalDistance="5" totalDistanceUnit="km" startDate="${today} 07:00:00 +0100"><WorkoutStatistics type="HKQuantityTypeIdentifierHeartRate" average="150" maximum="171"/></Workout></HealthData>`;
const TCX = `<TrainingCenterDatabase><Activities><Activity Sport="Biking"><Id>2025-01-04T06:30:00Z</Id><Lap><TotalTimeSeconds>2400</TotalTimeSeconds><DistanceMeters>15000</DistanceMeters><Calories>400</Calories></Lap></Activity></Activities></TrainingCenterDatabase>`;
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 375, height: 800 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, serviceWorkers: 'block' }), p = await c.newPage();
  await p.addInitScript(() => { // a fake heart-rate strap
    const listeners = {}; let n = 0;
    const chr = { addEventListener: (t, f) => (listeners[t] = f), removeEventListener() {}, startNotifications: async () => { let i = 0; setInterval(() => { const v = new DataView(new Uint8Array([0, 120 + (i++ % 10)]).buffer); listeners.characteristicvaluechanged?.({ target: { value: v } }); }, 100); }, stopNotifications: async () => {} };
    const dev = { name: 'Test Strap', addEventListener() {}, gatt: { connected: false, connect: async () => { dev.gatt.connected = true; return { getPrimaryService: async () => ({ getCharacteristic: async () => chr }) }; }, disconnect() { dev.gatt.connected = false; } } };
    Object.defineProperty(navigator, 'bluetooth', { value: { requestDevice: async () => dev }, configurable: true });
  });
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(async (sessions) => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 0, working: {}, sessions, active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: true }, plan: 'free', ui: { nameAsked: true } })); }, seed());
  await p.reload(); await p.waitForSelector('.page-h');
  const noOverflow = async (m) => ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'no horizontal overflow: ' + m);
  const go = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(500); };
  await go('#/settings'); await p.click('[data-dev]'); await p.waitForSelector('#hf', { state: 'attached' }); ok(true, 'devices sheet opens'); await noOverflow('devices sheet');
  await p.setInputFiles('#hf', [{ name: 'export.xml', mimeType: 'text/xml', buffer: Buffer.from(AH) }, { name: 'ride.tcx', mimeType: 'text/xml', buffer: Buffer.from(TCX) }]); await p.waitForTimeout(1500); console.log('DBG', await p.evaluate(() => [...document.querySelectorAll('#toasts *, .toast')].map(e=>e.textContent).join('|') + ' :: ' + document.querySelector('#dv')?.textContent.slice(-200))); await p.waitForSelector('[data-rm]', { timeout: 8000 }); await p.waitForTimeout(400);
  const acts = await p.evaluate(async () => (await import('/js/store.js')).state.activities.map((a) => a.label)); ok(acts.includes('Run') && acts.includes('Cycle'), 'imported Apple Health run and TCX ride: ' + acts);
  ok(await p.evaluate(async () => (await import('/js/store.js')).state.body.entries.some((e) => e.weight === 81.2)), 'weight imported into body entries'); ok(/150 bpm avg/.test(await p.textContent('#dv')), 'heart rate shown in list');
  await p.setInputFiles('#hf', [{ name: 'export.xml', mimeType: 'text/xml', buffer: Buffer.from(AH) }]); await p.waitForTimeout(800); ok((await p.evaluate(async () => (await import('/js/store.js')).state.activities.length)) === 2, 're-import adds no duplicates');
  await p.setInputFiles('#hf', [{ name: 'notes.txt', mimeType: 'text/plain', buffer: Buffer.from('hello') }]); await p.waitForTimeout(600); ok(/Unsupported file/.test(await p.textContent('#toasts, .toast, body')), 'unsupported file explained');
  await p.screenshot({ path: require('os').tmpdir() + '/w-dev.png' });
  await p.click('[data-hr="on"]'); await p.waitForTimeout(500); ok(/Test Strap/.test(await p.textContent('#dv')), 'strap connected from settings'); await p.click('.sheet [data-close]'); await p.waitForTimeout(300);
  // calendar shows imported activity
  await go('#/calendar'); await p.waitForSelector('.cal-g'); ok(await p.$(`.cal-c[data-d="${today}"].act`) !== null, 'calendar marks day with imported activity'); await p.click(`.cal-c[data-d="${today}"]`); ok(/Imported activity/.test(await p.textContent('[aria-label="Selected day"]')) && /Run/.test(await p.textContent('[aria-label="Selected day"]')), 'day detail lists imported activity'); await noOverflow('calendar');
  // activities never count for XP / streak
  const xp = await p.evaluate(async () => { const g = await import('/js/gamify.js'), s = await import('/js/store.js'); const a = g.xpSummary(s.state).total; s.importActivities([{ id: 'zz', source: 'tcx', type: 'Run', label: 'Run', date: '2026-01-01', durationSec: 600 }]); return [a, g.xpSummary(s.state).total]; }); ok(xp[0] === xp[1], 'imported activities do not change XP');
  // workout with live heart rate
  await go('#/'); await p.click('[data-start]'); await p.waitForSelector('[data-done]'); await p.waitForSelector('.hr-live'); ok(await p.evaluate(() => /\d{3}/.test(document.querySelector('.hr-live').textContent)), 'live bpm shown in workout'); await noOverflow('workout with HR bar'); await p.screenshot({ path: require('os').tmpdir() + '/w-hr.png' });
  await p.click('[data-done="0"]'); await p.waitForTimeout(1500); await p.click('[data-finish]'); await p.click('.sheet [data-v="finish"]'); await p.waitForTimeout(900); const cele = await p.$('.cele'); if (cele) { await p.click('.cele [data-close]'); await p.waitForTimeout(300); }
  ok(/bpm average/.test(await p.textContent('#main')), 'summary shows heart rate'); const hr = await p.evaluate(async () => { const s = (await import('/js/store.js')).state.sessions; return s[s.length - 1].hr; }); ok(hr && hr.avg >= 120 && hr.n >= 10, 'heart rate summary saved with the session ' + JSON.stringify(hr)); await noOverflow('summary');
  console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no console errors'); console.log(fails.length ? fails.length + ' FAILED' : 'ALL PASSED'); await b.close(); process.exit(fails.length || errs.length ? 1 : 0);
})();
