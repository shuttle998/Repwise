const { chromium } = require('playwright'); const { seed } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 375, height: 800 }, isMobile: true, hasTouch: true }), p = await c.newPage();
  p.on('pageerror', e => errs.push('PAGEERROR ' + e.message)); p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource|net::/.test(m.text())) errs.push(m.text()); });
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(async (sessions) => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 0, working: {}, sessions, active: null, settings: { units: 'kg' }, plan: 'free', ui: { nameAsked: true } })); }, seed());
  await p.reload(); await p.evaluate(() => navigator.serviceWorker.ready); await p.waitForTimeout(1500);
  const info = await p.evaluate(async () => { const ks = await caches.keys(), k = ks.find((x) => x.startsWith('repwise-')); const n = k ? (await (await caches.open(k)).keys()).length : 0; const man = await (await fetch('/sw-manifest.js')).text(); return { ks, n, expect: JSON.parse(man.split('= ')[1].replace(/;\s*$/, '')).files.length }; });
  ok(info.ks.length === 1 && /^repwise-[0-9a-f]{12}$/.test(info.ks[0]), 'one content-versioned cache: ' + info.ks); ok(info.n >= info.expect, `all ${info.expect} app files precached (${info.n})`);
  await p.reload(); ok(await p.evaluate(() => !!navigator.serviceWorker.controller), 'service worker controls the page');
  await c.setOffline(true); await p.reload(); await p.waitForSelector('.page-h', { timeout: 8000 }); ok(/Ada/.test(await p.textContent('.page-h h1')), 'app opens fully offline after reload');
  for (const h of ['#/train', '#/progress', '#/progress/achievements', '#/progress/records', '#/progress/body', '#/progress/report', '#/library', '#/calendar', '#/nutrition', '#/water', '#/settings', '#/pricing', '#/coach']) {
    await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(350); const bad = await p.evaluate(() => /Something went wrong/.test(document.querySelector('#main').textContent) || !document.querySelector('#main').children.length); ok(!bad, 'route renders offline: ' + h);
  }
  // library + animation modules load offline
  await p.evaluate(() => { location.hash = '#/library'; }); await p.waitForTimeout(400); const card = await p.$('.li, .ex-row, [data-ex]'); if (card) { await card.click(); await p.waitForTimeout(600); ok(!!(await p.$('.anim-stage, .anim-svg, .demo')), 'exercise detail and animation open offline'); await p.keyboard.press('Escape'); }
  // log a workout set offline
  await p.evaluate(() => { location.hash = '#/'; }); await p.waitForTimeout(400); await p.click('[data-start]'); await p.waitForSelector('[data-done]'); await p.click('[data-done="0"]'); await p.waitForTimeout(300);
  ok(await p.evaluate(() => JSON.parse(localStorage.getItem('repwise:v2')).active.items[0].sets[0].done === true), 'set logged and saved while offline');
  // coming back online
  await c.setOffline(false); await p.waitForTimeout(500); await p.reload(); await p.waitForTimeout(600); ok(await p.evaluate(() => JSON.parse(localStorage.getItem('repwise:v2')).active !== null), 'workout still active after reconnect');
  console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no console errors'); console.log(fails.length ? fails.length + ' FAILED' : 'ALL PASSED'); await b.close(); process.exit(fails.length || errs.length ? 1 : 0);
})();
