const { chromium } = require('playwright'); const { seed } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 375, height: 800 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true }); const p = await c.newPage();
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(async (sessions) => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 0, working: { bench: { w: 55, repTarget: 8, action: 'increase_reps', title: 'Add reps', reasons: ['Test reason'], date: '2026-11-10' } }, sessions, active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: true }, plan: 'free', ui: { nameAsked: true } })); }, seed());
  await p.reload(); await p.waitForTimeout(500);
  await p.click('[data-start]'); await p.waitForSelector('.ex-card');
  const name1 = await p.textContent('.ex-name'); console.log('first exercise:', name1);
  ok(await p.$('.prev') !== null, 'previous performance shown');
  ok((await p.textContent('.rec')).includes('Recommended'), 'recommended weight shown');
  // edit weight by typing, propagates to later sets
  await p.fill('[data-in="w:0"]', '42.5'); await p.press('[data-in="w:0"]', 'Enter'); await p.waitForTimeout(100);
  ok(await p.inputValue('[data-in="w:2"]') === '42.5', 'weight edit carries to later sets');
  await p.click('[data-adj="r:0:1"]'); await p.click('[data-done="0"]'); await p.waitForTimeout(100);
  ok(await p.$('#rest') !== null, 'rest timer starts after a set');
  ok(await p.$eval('.srow', e => e.classList.contains('done')), 'completed set visibly marked');
  // pause / resume
  await p.click('[data-pause]'); ok(await p.$('.paused') !== null, 'pause overlay'); await p.click('.paused [data-pause]'); await p.waitForTimeout(100); ok(await p.$('.paused') === null, 'resume');
  // substitute
  await p.click('[data-sub]'); await p.waitForSelector('.sheet [data-pick]'); const pick = await p.$eval('.sheet [data-pick]', e => e.dataset.pick); await p.click('.sheet [data-pick]'); await p.waitForTimeout(300);
  ok((await p.textContent('.ex-name')) !== name1, `substituted exercise (${pick})`); ok(await p.$('.chip.warn') !== null, 'substitution is labelled');
  // add set + skip
  const before = (await p.$$('.srow')).length; await p.click('[data-addset]'); ok((await p.$$('.srow')).length === before + 1, 'add set');
  await p.click('[data-skip]'); await p.waitForTimeout(300); ok(await p.$('.dot.skip') !== null, 'skip marks exercise');
  // hurt flow on second exercise
  await p.click('[data-hurt]'); await p.waitForSelector('.sheet [data-a=lower]'); await p.click('.sheet [data-a=lower]'); await p.waitForTimeout(200);
  ok(await p.evaluate(() => JSON.parse(localStorage.getItem('repwise:v2')).active.items[1].hurt === true), 'pain flag recorded');
  // complete all sets of exercise 2 then feedback -> recommendation
  const n = (await p.$$('.srow')).length; for (let i = 0; i < n; i++) await p.click(`[data-done="${i}"]`);
  await p.click('[data-fb=hard]'); await p.waitForTimeout(150); ok((await p.textContent('.fb .rec')).length > 20, 'recommendation shown after feedback'); console.log('   rec:', (await p.textContent('.fb .rec')).slice(0, 140));
  // persistence: navigate away and back, reload
  await p.goto('http://localhost:8123/app.html#/'); await p.waitForTimeout(400); ok(await p.$('.resume-bar') !== null, 'resume bar visible away from workout'); await p.reload(); await p.waitForTimeout(500);
  ok(await p.$('.resume-bar') !== null, 'active workout survives reload');
  await p.click('.resume-bar'); await p.waitForSelector('.ex-card'); ok((await p.$$('.dot.done')).length >= 1, 'progress restored');
  await p.screenshot({ path: process.env.SP + '/w-final.png' });
  await p.click('[data-finish]'); await p.click('[data-v=finish]'); await p.waitForTimeout(600); if (await p.$('.cele')) await p.click('.cele .btn'); await p.waitForTimeout(300);
  const st = await p.evaluate(() => JSON.parse(localStorage.getItem('repwise:v2'))); const last = st.sessions[st.sessions.length - 1];
  ok(st.active === null && last.items.some(i => i.skipped), 'finished: session saved with skipped exercise recorded');
  ok(st.working[last.items.find(i => i.feedback === 'hard' && i.hurt).exId]?.action === 'adjust', 'pain flag leads to "adjust" recommendation');
  console.log('errors', JSON.stringify(errs), 'fails', fails.length); await b.close(); process.exit(fails.length || errs.length ? 1 : 0);
})().catch(e => { console.log('CRASH', e.message, JSON.stringify(errs)); process.exit(2); });
