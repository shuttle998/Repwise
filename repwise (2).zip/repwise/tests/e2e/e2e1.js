const { chromium } = require('playwright');
const SP = process.env.SP; const errs = [];
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const p = await ctx.newPage();
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); });
  p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  const log = (...a) => console.log(...a);
  await p.goto('http://localhost:8123/app.html'); await p.waitForTimeout(400);
  // onboarding
  await p.fill('#nm', 'Ada'); await p.click('[data-next]');
  await p.click('[data-next]'); // about you (optional, skipped)
  await p.click('[data-k=level] [data-v="1"]'); await p.click('[data-next]');
  await p.click('[data-next]'); // how to train (smart recommendations)
  await p.click('[data-k=goal] [data-v=strength]'); await p.click('[data-next]');
  await p.click('[data-next]'); // body focus (skipped)
  await p.click('[data-k=equipment] [data-v=gym]'); await p.click('[data-next]');
  await p.click('[data-k=dband] [data-v="55"]'); await p.click('[data-next]');
  await p.click('[data-k=days] [data-v="4"]'); await p.screenshot({ path: SP + '/o-days.png' }); await p.click('[data-next]');
  await p.screenshot({ path: SP + '/o-prefs.png', fullPage: true });
  await p.click('[data-next]'); // split (recommended)
  await p.click('[data-next]'); await p.waitForSelector('[data-start]');
  await p.screenshot({ path: SP + '/o-result.png', fullPage: true });
  await p.click('[data-start]'); await p.waitForSelector('.ex-card');
  log('hash', await p.evaluate(() => location.hash));
  // log first exercise sets
  const sets = await p.$$('.srow'); log('sets rows', sets.length);
  await p.screenshot({ path: SP + '/w-1.png' });
  for (let i = 0; i < sets.length; i++) { await p.click(`[data-done="${i}"]`); await p.waitForTimeout(60); }
  await p.waitForSelector('.fb'); await p.click('[data-fb=good]');
  await p.screenshot({ path: SP + '/w-2.png', fullPage: false });
  // reload mid-workout
  await p.reload(); await p.waitForSelector('.ex-card');
  const doneAfter = await p.$$eval('.srow.done', e => e.length); log('done after reload', doneAfter);
  // next exercise, log one set, then finish
  await p.click('.w-nav [data-next]'); await p.waitForTimeout(100);
  await p.click('[data-done="0"]'); await p.waitForTimeout(100);
  await p.screenshot({ path: SP + '/w-3.png' });
  await p.click('[data-finish]'); await p.waitForSelector('[data-v=finish]'); await p.click('[data-v=finish]');
  await p.waitForTimeout(500);
  await p.screenshot({ path: SP + '/w-cele.png' });
  const cele = await p.$('.cele'); if (cele) { await p.click('.cele .btn'); await p.waitForTimeout(300); }
  await p.screenshot({ path: SP + '/w-sum.png', fullPage: true });
  await p.click('.btn.primary:has-text("Done")'); await p.waitForTimeout(500);
  await p.screenshot({ path: SP + '/dash.png', fullPage: true });
  log('storage sessions', await p.evaluate(() => JSON.parse(localStorage.getItem('repwise:v2')).sessions.length));
  log('errors', JSON.stringify(errs));
  await b.close();
})().catch(e => { console.log('FAILED', e.message); console.log('errors', JSON.stringify(errs)); process.exit(1); });
