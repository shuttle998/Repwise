const { chromium } = require('playwright'); const { seed } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 375, height: 800 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true }); const p = await c.newPage();
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(async (sessions) => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 0, working: {}, sessions, active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: true }, plan: 'pro', ui: { nameAsked: true } })); }, seed());
  await p.reload(); await p.waitForSelector('.page-h');
  const noOverflow = async (m) => ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'no horizontal overflow: ' + m);
  const go = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(500); };
  const count = async () => +(await p.textContent('#count')).match(/^\d+/)[0];
  // ---- library search + filters
  await go('#/library'); await p.waitForSelector('#list .ex-row'); const total = await count(); await noOverflow('library');
  await p.fill('#q', 'db row'); await p.waitForTimeout(100); const n1 = await count(); ok(n1 > 0 && n1 < total, 'abbreviation search "db row" narrows: ' + n1);
  await p.fill('#q', 'zzzz'); ok(/No exercises match/.test(await p.textContent('#list')), 'empty state for no matches'); await p.fill('#q', '');
  await p.click('summary:has-text("Filters")'); await p.click('[data-f="loc"][data-v="home"]'); const nHome = await count(); ok(nHome > 0 && nHome < total, 'location filter Home: ' + nHome);
  ok(await p.$$eval('#list .ex-row', r => r.every(x => !/Needs more equipment/.test(x.textContent))), 'home exercises need no extra equipment');
  await p.click('[data-f="muscle"][data-v="Chest"]'); ok(await count() <= nHome, 'filters combine'); await noOverflow('filters open');
  await p.click('[data-clear]'); await p.waitForSelector('#list .ex-row'); ok(await count() === total, 'clear all restores list');
  // ---- favourites
  await p.click('#list .fav >> nth=0'); const favId = await p.$eval('#list .fav[aria-pressed="true"]', e => e.dataset.fav); ok(!!favId, 'heart toggles favourite');
  await p.click('[data-view="fav"]'); ok(await count() === 1, 'Favourites view lists it'); await p.click('[data-view="recent"]'); const nr = await count(); ok(nr > 0 && /last/.test(await p.textContent('#list')), 'Recent view shows logged exercises with last date: ' + nr);
  await p.click('[data-view="all"]');
  // ---- custom exercise
  await p.click('[data-new]'); await p.waitForSelector('#cf'); await p.fill('[name=name]', 'a'); await p.click('#cf button[type=submit]'); ok(/2 to 40/.test(await p.textContent('#cerr')), 'validation: name');
  await p.fill('[name=name]', 'Zottman curl'); await p.click('#cf button[type=submit]'); ok(/main muscle/.test(await p.textContent('#cerr')), 'validation: muscle'); await noOverflow('custom form');
  await p.screenshot({ path: require('os').tmpdir() + '/l-form.png' });
  await p.check('input[name=pm][value=Biceps]'); await p.check('input[name=sm][value=Forearms]'); await p.fill('[name=steps]', 'Curl up with palms up\nLower with palms down'); await p.click('#cf button[type=submit]');
  await p.waitForSelector('.page-h h1:has-text("Zottman curl")'); ok(await p.$('.chip:has-text("Custom")') !== null, 'custom detail page with badge'); ok(/Lower with palms down/.test(await p.textContent('.ol')), 'steps shown'); await noOverflow('custom detail');
  await p.click('[data-edit]'); await p.fill('[name=name]', 'Zottman curl v2'); await p.click('#cf button[type=submit]'); await p.waitForSelector('h1:has-text("Zottman curl v2")'); ok(true, 'edit custom exercise');
  const cid = await p.evaluate(() => location.hash.split('/').pop());
  await p.evaluate(async () => { const m = await import('/js/store.js'); m.state.customExercises.length && 0; }); await go('#/library'); await p.fill('#q', 'zottman'); ok(await count() === 1, 'custom exercise searchable');
  // ---- picker in builder
  await go('#/train'); await p.click('[data-edit]'); await p.waitForSelector('.ed-item');
  ok(await p.$$eval('.ed-ctl', e => e.every(x => x.querySelectorAll('.mini').length === 4)), 'editor has Sets, Min, Max, Rest steppers'); await noOverflow('editor');
  const r0 = await p.$eval('[data-adj$=":lo:-1"]', e => e.parentElement.textContent); await p.click('[data-adj$=":lo:1"] >> nth=0'); await p.click('[data-adj$=":hi:-1"] >> nth=0');
  const st = await p.evaluate(async () => { const m = await import('/js/store.js'); const i = m.state.program.sessions[0].items[0]; return [i.repLo, i.repHi]; }); ok(st[0] <= st[1], 'min never exceeds max: ' + st);
  for (let k = 0; k < 20; k++) await p.click('[data-adj$=":lo:1"] >> nth=0'); const st2 = await p.evaluate(async () => { const m = await import('/js/store.js'); const i = m.state.program.sessions[0].items[0]; return [i.repLo, i.repHi]; }); ok(st2[1] >= st2[0], 'raising min pushes max up: ' + st2);
  await p.fill('[data-note="0"]', 'Pause 1s at the bottom'); await p.click('[data-name="0"]'); await p.waitForTimeout(100);
  await p.click('[data-add="0"]'); await p.waitForSelector('#pl .ex-row'); await p.fill('#q', 'zottman'); ok((await p.$$('#pl .ex-row')).length === 1, 'picker finds custom exercise'); await p.click('#pl [data-pick]'); await p.waitForSelector('.ed-item >> nth=-1');
  ok(await p.evaluate(async () => { const m = await import('/js/store.js'); return m.state.program.sessions[0].items.some(i => i.exId.startsWith('c-')); }), 'custom exercise added to programme');
  await p.evaluate(async () => { const m = await import('/js/store.js'), x = await import('/js/exercises.js'); const used = m.state.program.sessions[0].items.map(i => i.exId); const e = x.activeExercises().find(q => !used.includes(q.id) && !m.isFav(q.id)); m.toggleFav(e.id); });
  await p.click('[data-add="0"]'); await p.waitForSelector('#pl .ex-row'); await p.click('.sheet [data-view="fav"]'); ok((await p.$$('#pl [data-pick]')).length === 1, 'picker Favourites view'); await p.click('.sheet [data-view="recent"]'); ok((await p.$$('#pl [data-pick]')).length > 0, 'picker Recent view'); await noOverflow('picker'); await p.screenshot({ path: require('os').tmpdir() + '/l-pick.png' }); await p.keyboard.press('Escape'); await p.waitForTimeout(250);
  // ---- ranked swap
  await p.click('[data-swap="0:0"]'); await p.waitForSelector('.sheet [data-pick]'); ok(await p.$$eval('.sheet .hint', h => h.length > 0 && h.every(x => x.textContent.trim().length > 3)), 'swap suggestions show reasons'); await noOverflow('swap sheet'); await p.screenshot({ path: require('os').tmpdir() + '/l-swap.png' });
  const before = await p.evaluate(async () => (await import('/js/store.js')).state.program.sessions[0].items[0].exId); await p.click('.sheet [data-pick] >> nth=0'); await p.waitForTimeout(300);
  ok(await p.evaluate(async (b) => (await import('/js/store.js')).state.program.sessions[0].items[0].exId !== b, before), 'swap applies');
  // ---- saved programmes
  await p.click('[data-save-prog]'); await p.fill('#sp [name=n]', 'My push pull'); await p.click('#sp button[type=submit]'); await p.waitForSelector('[data-load-prog]'); ok(true, 'save programme');
  await p.click('[data-scratch]'); await p.click('.sheet-wrap:last-child [data-v="1"], .sheet [data-v="1"]'); await p.waitForTimeout(300); ok(await p.$$eval('.ed-item', e => e.length === 0), 'build from scratch gives an empty session'); await noOverflow('scratch');
  await p.click('[data-load-prog]'); await p.click('.sheet [data-v="1"]'); await p.waitForTimeout(300); ok(await p.$$eval('.ed-item', e => e.length > 0) && /Pause 1s/.test(await p.$eval('[data-note="0"]', e => e.value)), 'load saved programme restores items and notes');
  await p.click('[data-edit]'); await p.waitForTimeout(200); ok(/Pause 1s at the bottom/.test(await p.textContent('main, #main')), 'note shown in view');
  // ---- note reaches workout; history untouched
  const hist = await p.evaluate(async () => (await import('/js/store.js')).state.sessions.length);
  await p.click('[data-start="0"]'); await p.waitForSelector('.wnote'); ok(/Pause 1s/.test(await p.textContent('.wnote')), 'workout shows session note'); await noOverflow('workout note');
  await p.click('[data-sub]'); await p.waitForSelector('.sheet [data-pick]'); ok(await p.$('.sheet .hint') !== null, 'in-workout substitute is ranked with reasons'); await p.click('.sheet [data-pick] >> nth=0'); await p.waitForTimeout(300);
  ok(await p.evaluate(async () => (await import('/js/store.js')).state.active.items[0].origExId !== (await import('/js/store.js')).state.active.items[0].exId), 'substitution keeps original reference');
  await p.evaluate(async () => (await import('/js/store.js')).mutate((s) => { s.active = null; })); await go('#/train');
  ok(await p.evaluate(async () => (await import('/js/store.js')).state.sessions.length) === hist, 'history intact after editing');
  // ---- removing a used custom exercise archives it
  await p.evaluate(async (cid) => { const m = await import('/js/store.js'); m.mutate((s) => { s.sessions.push({ id: 'zz', date: '2026-11-01', name: 'T', items: [{ exId: cid, name: 'x', sets: [{ w: 10, reps: 8 }] }] }); }); }, cid);
  await go('#/library/' + cid); await p.click('[data-remove]'); await p.click('.sheet [data-v="1"]'); await p.waitForTimeout(400);
  ok(await p.evaluate(async (cid) => { const m = await import('/js/store.js'); return m.state.customExercises.find(c => c.id === cid)?.archived === true; }, cid), 'removed custom exercise archived, history kept');
  await go('#/progress/records'); await noOverflow('records with archived exercise'); await go('#/progress'); await noOverflow('progress with archived exercise');
  await p.reload(); await p.waitForSelector('.page-h'); ok(await p.evaluate(async (cid) => { const m = await import('/js/store.js'); const x = await import('/js/exercises.js'); return !!x.BY_ID[cid] && !x.activeExercises().some(e => e.id === cid); }, cid), 'archived exercise survives reload, hidden from lists');
  // ---- free plan gating
  await p.evaluate(async () => (await import('/js/store.js')).mutate((s) => { s.plan = 'free'; })); await go('#/train'); await p.click('[data-edit]'); await p.waitForTimeout(300); ok(await p.$('.sheet') !== null, 'builder is Pro-gated for free users'); await p.keyboard.press('Escape');
  ok(errs.length === 0, 'no console errors ' + errs.join('|')); console.log(fails.length ? 'FAILED ' + fails.length : 'ALL PASS'); await b.close();
})();
