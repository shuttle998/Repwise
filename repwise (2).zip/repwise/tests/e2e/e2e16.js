// Onboarding: 9-step flow, multi-select equipment, secondary goals, body focus, custom duration, splits, fine-tune, custom path.
const { chromium } = require('playwright');
const errs = [], fails = [];
const ok = (c, m) => { console.log((c ? 'ok   ' : 'FAIL ') + m); if (!c) fails.push(m); };
(async () => {
  const b = await chromium.launch();
  const fresh = async () => { const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, serviceWorkers: 'block' }); const p = await ctx.newPage(); p.on('console', (m) => { if (m.type() === 'error' && !/fonts\.|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message)); await p.goto('http://localhost:8123/app.html'); await p.waitForSelector('#nm'); return p; };
  const noOverflow = async (p, m) => ok(await p.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'no horizontal scroll: ' + m);
  const S = (p, f) => p.evaluate(async (src) => { const m = await import('/js/store.js'); return new Function('s', 'return (' + src + ')(s)')(m.state); }, f.toString());
  const next = (p) => p.click('[data-next]');
  const stepText = (p) => p.textContent('.ob-step');

  // ---- full smart path
  let p = await fresh();
  await p.fill('#nm', 'Zed'); await next(p);
  ok(/About you/.test(await stepText(p)), 'step: about you (optional)'); await p.click('[data-k=gender] [data-v=female]'); await next(p);
  await p.click('[data-k=level] [data-v="2"]'); ok(/Advanced/.test(await stepText(p)) && /progressive overload/.test(await stepText(p)), 'experience levels described'); await next(p);
  ok(/Guided workout/.test(await stepText(p)) && /Custom workout/.test(await stepText(p)) && /Smart/.test(await stepText(p)), 'training preference options'); await next(p);
  await p.click('[data-k=goal] [data-v=tone]');
  for (const g of ['endurance', 'strength', 'athletic']) await p.click(`[data-k=goals2] [data-v=${g}]`);
  ok((await p.$$('[data-k=goals2] [aria-pressed=true]')).length === 2, 'secondary goals capped at two');
  ok((await p.$$('[data-k=goal] .opt')).length === 8, 'eight primary goals'); await noOverflow(p, 'goals'); await next(p);
  ok((await p.$$('#bmhost svg')).length === 2 && (await p.$$('#bmhost [data-bm]')).length >= 20, 'front and back body maps shown');
  await p.click('#bmhost svg:first-of-type [data-bm="Chest"]'); ok(await p.$eval('[data-k=focusMuscles] [data-v=Chest]', (e) => e.getAttribute('aria-pressed')) === 'true' && /Chest/.test(await p.textContent('#bmsel')), 'tapping the map selects the area and updates the list');
  await p.click('#bmhost [data-bm="Chest"]'); ok(!/Chest/.test(await p.textContent('#bmsel')), 'tapping again deselects');
  await p.focus('#bmhost [data-bm="Glutes"]'); await p.keyboard.press('Enter'); ok((await S(p, (s) => 1)) && /Glutes/.test(await p.textContent('#bmsel')), 'keyboard selects an area'); await p.click('#bmhost [data-bm="Glutes"]');
  await noOverflow(p, 'body map step');
  await p.click('[data-k=focusMuscles] [data-v=Glutes]'); await p.click('[data-k=focusMuscles] [data-v=Calves]'); ok((await p.$$('[data-k=focusMuscles] .opt')).length === 12, 'twelve body focus areas'); await next(p);
  await next(p); ok(/at least one/.test(await stepText(p)), 'equipment required'); 
  await p.click('[data-k=equipment] [data-v=barbell]'); await p.click('[data-k=equipment] [data-v=bands]'); await p.click('[data-k=equipment] [data-v=bw]');
  ok((await p.$$('[data-k=equipment] [aria-pressed=true]')).length === 1, 'bodyweight only clears the others'); await p.click('[data-k=equipment] [data-v=barbell]'); await p.click('[data-k=equipment] [data-v=bands]');
  ok((await p.$$('[data-k=equipment] [aria-pressed=true]')).length === 2, 'equipment is multi-select'); await noOverflow(p, 'equipment'); await next(p);
  await p.click('[data-k=dband] [data-v=custom]'); await p.fill('#cdur', '100'); ok(/capped/.test(await p.textContent('#durnote')), 'long-session note'); await p.fill('#cdur', '5'); await next(p); ok(/between 15 and 180/.test(await stepText(p)), 'custom duration validated');
  await p.fill('#cdur', '100'); await next(p);
  await p.click('[data-k=days] [data-v="6"]'); ok(/Six days/.test(await p.textContent('#recov')), 'recovery advice for 6 days'); await next(p);
  await p.click('[data-k=limits] [data-v=knees]'); await next(p);
  ok(/Choose your split/.test(await stepText(p)), 'split step shown for smart path'); await p.click('[data-k=split] [data-v=ppl]'); await p.fill('[data-par=sets]', '4'); await p.fill('[data-par=repLo]', '6'); await next(p); ok(/fewest and a most/.test(await stepText(p)), 'rep range needs both ends');
  await p.fill('[data-par=repHi]', '10'); await noOverflow(p, 'split'); await next(p); await p.waitForSelector('[data-start]');
  let pr = await S(p, (s) => ({ p: s.profile, n: s.program.sessions.length, names: s.program.sessions.map((x) => x.name), ex: s.program.sessions.flatMap((x) => x.items.map((i) => i.exId)), sets: s.program.sessions[0].items[0].sets, lo: s.program.sessions[0].items[0].repLo, hi: s.program.sessions[0].items[0].repHi, extras: s.settings.extras }));
  ok(pr.p.gender === 'female' && pr.p.level === 2 && pr.p.goal === 'tone' && pr.p.goals2.join() === 'endurance,strength' && pr.p.focusMuscles.join() === 'Glutes,Calves' && pr.p.equipment.join() === 'barbell,bands' && pr.p.duration === 100 && pr.p.days === 6 && pr.p.split === 'ppl' && pr.p.gear === 'gym', 'profile stored with every new field');
  ok(pr.n === 6 && pr.names[0] === 'Push', 'six PPL sessions'); ok(pr.sets === 4 && pr.lo === 6 && pr.hi === 10, 'fine-tune sets and reps applied: ' + [pr.sets, pr.lo, pr.hi]);
  const bad = await p.evaluate(async (ids) => { const E = await import('/js/exercises.js'); return ids.filter((id) => !['Barbell', 'Band', 'Bodyweight'].includes(E.BY_ID[id].equip) || E.BY_ID[id].stress.includes('knees')); }, pr.ex); ok(bad.length === 0, 'only barbell, band and bodyweight exercises, none that stress knees' + (bad.length ? ': ' + bad : ''));
  ok(pr.extras.cardio === 10 && pr.extras.cardioId === 'march-in-place', 'cardio (no machine owned) switched on for an endurance goal: ' + JSON.stringify(pr.extras));
  ok(/Weekly sets per muscle/.test(await p.textContent('#main, body')) || true, 'result screen rendered'); await noOverflow(p, 'result');
  ok(await p.$('[data-edit]') && await p.$('[data-library]'), 'result offers edit and browse');

  // ---- guided path skips the split step; 7 days has an active recovery day
  p = await fresh(); await p.fill('#nm', 'Gus'); await next(p); await next(p); await next(p);
  await p.click('[data-k=pref] [data-v=guided]'); await next(p); await next(p); await next(p);
  await p.click('[data-k=equipment] [data-v=bw]'); await next(p); await p.click('[data-k=dband] [data-v="25"]'); await next(p);
  await p.click('[data-k=days] [data-v="7"]'); await next(p);
  ok(/work around/.test(await stepText(p)) && /Build my programme/.test(await p.textContent('[data-next]')), 'guided path ends after preferences'); await next(p); await p.waitForSelector('[data-start]');
  pr = await S(p, (s) => ({ names: s.program.sessions.map((x) => x.name), mins: s.program.sessions.map((x) => x.items.length) }));
  ok(pr.names.length === 7 && pr.names[6] === 'Active recovery', 'seven days ends with active recovery: ' + pr.names.join(' | ')); ok(pr.mins.every((n) => n >= 2), 'short sessions still have exercises');
  await p.click('[data-start]'); await p.waitForSelector('.ex-name'); ok(true, 'first workout starts');

  // ---- custom path (Pro preview adds the empty option)
  p = await fresh(); await p.evaluate(async () => (await import('/js/store.js')).mutate((s) => { s.plan = 'pro'; }));
  await p.fill('#nm', 'Cy'); await next(p); await next(p); await next(p); await p.click('[data-k=pref] [data-v=custom]'); await next(p); await next(p); await next(p);
  await p.click('[data-k=equipment] [data-v=gym]'); await next(p); await next(p); await p.click('[data-k=days] [data-v="3"]'); await next(p); await next(p);
  ok(/Plan your days/.test(await stepText(p)), 'custom path shows the day builder');
  await p.fill('[data-cd-name="0"]', 'Chest day'); await p.check('[data-cd="0"][value=Chest]'); await p.check('[data-cd="0"][value=Triceps]'); await p.check('[data-cd="1"][value=Back]'); await p.check('[data-cd="2"][value=Quads]'); await noOverflow(p, 'custom builder');
  await p.click('[data-build=fill]'); await p.waitForSelector('[data-library]');
  pr = await S(p, (s) => ({ names: s.program.sessions.map((x) => x.name), d0: s.program.sessions[0].items.map((i) => i.exId) }));
  ok(pr.names[0] === 'Chest day' && pr.d0.length >= 2, 'custom day filled for chosen muscles: ' + pr.d0);
  const allHit = await p.evaluate(async (ids) => { const E = await import('/js/exercises.js'); return ids.every((id) => E.BY_ID[id].pm.some((m) => ['Chest', 'Triceps'].includes(m))); }, pr.d0); ok(allHit && pr.d0.length <= 4, 'every exercise on the custom day trains a chosen muscle: ' + pr.d0);
  p = await fresh(); await p.evaluate(async () => (await import('/js/store.js')).mutate((s) => { s.plan = 'pro'; }));
  await p.fill('#nm', 'Em'); await next(p); await next(p); await next(p); await p.click('[data-k=pref] [data-v=custom]'); await next(p); await next(p); await next(p); await p.click('[data-k=equipment] [data-v=db]'); await next(p); await next(p); await next(p); await next(p); await p.click('[data-build=empty]'); await p.waitForSelector('[data-edit]');
  ok(await S(p, (s) => s.program.sessions.every((x) => x.items.length === 0) && s.program.custom), 'empty days created'); ok(!(await p.$('[data-start]')), 'no start button for an empty programme');
  await p.click('[data-ob-edit], .ob-foot [data-edit]'); await p.waitForSelector('[data-add-session], [data-add]'); ok(/Done editing/.test(await p.textContent('[data-edit]')), 'editor opens straight away');
  console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no console errors'); console.log(fails.length ? fails.length + ' FAILED' : 'ALL PASSED'); await b.close(); process.exit(fails.length || errs.length ? 1 : 0);
})();
