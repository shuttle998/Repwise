const { chromium } = require('playwright'); const { seed } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
(async () => {
  const { startMock } = await import(require('url').pathToFileURL(require('path').join(__dirname, '..', 'mock-supabase.mjs')).href); const mock = await startMock(8130);
  const b = await chromium.launch(); const sessions = seed();
  const mkDevice = async (seeded) => {
    const c = await b.newContext({ viewport: { width: 375, height: 800 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, acceptDownloads: true, serviceWorkers: 'block' }), p = await c.newPage();
    await p.route('**/js/config.js', async (r) => { const res = await r.fetch(); let t = await res.text(); t = t.replace(/CLOUD: \{[^}]*\}/, `CLOUD: { url: '${mock.url}', anonKey: 'anon' }`); r.fulfill({ response: res, body: t }); });
    p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
    await p.goto('http://localhost:8123/app.html');
    if (seeded) { await p.evaluate(async (sessions) => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 0, working: {}, sessions, active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: true }, plan: 'free', ui: { nameAsked: true } })); }, sessions); await p.reload(); }
    await p.waitForSelector('.page-h, h1'); return { c, p };
  };
  const go = async (p, h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(500); };
  const st = (p, fn, ...a) => p.evaluate(async ([f, a]) => { const m = await import('/js/store.js'); const e = await import('/js/sync-engine.js'); return eval('(' + f + ')')(m, e, ...a); }, [fn.toString(), a]);
  const noOverflow = async (p, m) => ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'no horizontal overflow: ' + m);
  // ---------- device A: create account, migrate local data ----------
  const A = (await mkDevice(true)).p; await go(A, '#/settings'); await A.waitForSelector('[data-acct="signup"]'); ok(true, 'settings offers Create account'); await noOverflow(A, 'settings signed out');
  await A.click('[data-acct="signup"]'); await A.waitForSelector('#af'); await A.fill('#em', 'not-an-email'); await A.fill('#pw', 'abc'); await A.click('#af [type=submit]'); ok(/valid email/.test(await A.textContent('#aerr')), 'bad email message');
  await A.fill('#em', 'ada@example.com'); await A.click('#af [type=submit]'); ok(/at least 8/.test(await A.textContent('#aerr')), 'short password message'); await noOverflow(A, 'auth sheet'); await A.screenshot({ path: require('os').tmpdir() + '/a-auth.png' });
  await A.fill('#pw', 'correct horse battery'); await A.click('#af [type=submit]'); await A.waitForSelector('#syncline', { timeout: 8000 }); await A.waitForTimeout(800);
  const row = [...mock.rows.values()][0]; ok(row && row.data.sessions.length === sessions.length, 'existing local workouts uploaded (' + (row?.data.sessions.length) + ')'); ok(/Up to date/.test(await A.textContent('#syncline')), 'status shows up to date'); ok(/ada@example.com/.test(await A.textContent('#main')), 'account email shown'); await noOverflow(A, 'settings signed in'); await A.screenshot({ path: require('os').tmpdir() + '/a-acct.png', fullPage: true });
  ok(await st(A, (m) => m.state.sessions.length) === sessions.length, 'device A data untouched');
  // ---------- device B: new phone, sign in from onboarding ----------
  const B = (await mkDevice(false)).p; await B.waitForSelector('[data-signin]'); ok(true, 'onboarding offers Sign in'); await B.click('[data-signin]'); await B.fill('#em', 'ada@example.com'); await B.fill('#pw', 'wrong password!'); await B.click('#af [type=submit]'); await B.waitForTimeout(500); ok(/incorrect/.test(await B.textContent('#aerr')), 'wrong password message');
  await B.fill('#pw', 'correct horse battery'); await B.click('#af [type=submit]'); await B.waitForSelector('#syncline', { timeout: 8000 }); await B.waitForTimeout(500);
  ok(await st(B, (m) => m.state.sessions.length) === sessions.length && (await st(B, (m) => m.state.profile?.name)) === 'Ada', 'device B received workouts and profile'); await go(B, '#/'); ok(/Ada/.test(await B.textContent('.page-h h1')), 'device B shows the dashboard, not onboarding');
  // ---------- two-way changes ----------
  await st(B, (m, e) => { m.addWater('2026-11-10', 500); m.mutate((s) => { s.sessions.push({ id: 'fromB', date: '2026-11-08', name: 'B', durationSec: 60, items: [{ exId: 'bench', name: 'Bench', sets: [{ w: 20, reps: 5 }] }] }); }); return e.syncNow(); });
  await st(A, (m) => m.mutate((s) => { s.sessions.push({ id: 'fromA', date: '2026-11-09', name: 'A', durationSec: 60, items: [{ exId: 'bench', name: 'Bench', sets: [{ w: 20, reps: 5 }] }] }); }));
  await go(A, '#/settings'); await A.click('[data-acct="sync"]'); await A.waitForTimeout(1200);
  const ids = await st(A, (m) => m.state.sessions.map((x) => x.id)); ok(ids.includes('fromA') && ids.includes('fromB'), 'concurrent edits from both devices merged on A'); ok(await st(A, (m) => (m.state.water.log['2026-11-10'] || []).length) === 1, 'water from B arrived on A');
  await st(B, (m, e) => e.syncNow()); ok((await st(B, (m) => m.state.sessions.map((x) => x.id))).includes('fromA'), 'B receives A’s workout after its next sync');
  // deletion propagates
  await st(B, (m, e) => { m.mutate((s) => { s.sessions = s.sessions.filter((x) => x.id !== 'fromB'); }); return e.syncNow(); }); await go(A, '#/'); await go(A, '#/settings'); await A.click('[data-acct="sync"]'); await A.waitForTimeout(1000);
  ok(!(await st(A, (m) => m.state.sessions.map((x) => x.id))).includes('fromB'), 'deletion on B propagates to A and is not resurrected');
  // ---------- backups ----------
  await A.click('[data-acct="backups"]'); await A.waitForSelector('[data-restore]', { timeout: 5000 }); ok(true, 'cloud backups listed'); await noOverflow(A, 'backups sheet'); await A.screenshot({ path: require('os').tmpdir() + '/a-backups.png' });
  await A.click('[data-restore] >> nth=0'); const dl = A.waitForEvent('download'); await A.click('.sheet [data-v="1"]'); const d = await dl; ok(/repwise-before-restore/.test(d.suggestedFilename()), 'current data downloaded before restore'); await A.waitForTimeout(1200); ok(!!(await st(A, (m) => m.state.sessions.length)), 'restore completed with data present');
  await A.keyboard.press('Escape'); await A.waitForTimeout(300);
  // ---------- password reset link ----------
  const jwt = 'e30.' + Buffer.from(JSON.stringify({ sub: [...mock.users.keys()][0], email: 'ada@example.com' })).toString('base64url') + '.s';
  const R = (await mkDevice(false)).p; await R.goto('about:blank'); await R.goto('http://localhost:8123/app.html#access_token=' + jwt + '&refresh_token=x&expires_in=3600&type=recovery'); await R.waitForSelector('#rf', { timeout: 6000 }); ok(true, 'recovery link opens set-new-password'); ok(!/access_token/.test(R.url()), 'token removed from the address bar');
  await R.fill('#p1', 'new password 123'); await R.fill('#p2', 'different'); await R.click('#rf [type=submit]'); ok(/do not match/.test(await R.textContent('#rerr')), 'mismatch message'); await R.fill('#p2', 'new password 123'); await R.click('#rf [type=submit]'); await R.waitForTimeout(1500);
  ok([...mock.users.values()][0].password === 'new password 123', 'new password saved'); ok(await R.evaluate(() => !!localStorage.getItem('repwise:auth')), 'signed in after reset');
  // ---------- sign out / forgot / delete ----------
  await go(A, '#/settings'); await A.click('[data-acct="signout"]'); await A.click('.sheet [data-v="1"]'); await A.waitForSelector('[data-acct="signin"]'); ok(await st(A, (m) => m.state.sessions.length) > 0, 'sign out keeps local data');
  await A.click('[data-acct="signin"]'); await A.click('[data-sw="forgot"]'); await A.waitForTimeout(400); await A.fill('#em', 'ada@example.com'); await A.click('#af [type=submit]'); await A.waitForTimeout(600); ok(mock.log.includes('RECOVER ada@example.com'), 'forgot password sends a reset request');
  await A.click('[data-acct="signin"]'); await A.fill('#em', 'ada@example.com'); await A.fill('#pw', 'new password 123'); await A.click('#af [type=submit]'); await A.waitForSelector('[data-acct="delete"]', { timeout: 8000 });
  await A.click('[data-acct="delete"]'); await A.waitForSelector('#dc'); ok(await A.$eval('#dok', (e) => e.disabled), 'delete needs typed confirmation'); await A.fill('#dc', 'DELETE'); await A.click('#dok'); await A.waitForSelector('[data-acct="signup"]', { timeout: 6000 }); ok(mock.users.size === 0 && mock.rows.size === 0, 'account and cloud data deleted'); ok(await st(A, (m) => m.state.sessions.length) > 0, 'local data kept after account deletion');
  console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no console errors'); console.log(fails.length ? fails.length + ' FAILED' : 'ALL PASSED'); await b.close(); await mock.close(); process.exit(fails.length || errs.length ? 1 : 0);
})();
