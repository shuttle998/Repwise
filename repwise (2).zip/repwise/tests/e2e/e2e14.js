const { chromium } = require('playwright'); const { seed, key } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 375, height: 800 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true, serviceWorkers: 'block' }); const p = await c.newPage();
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(async () => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'bw', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 1, working: {}, sessions: [], active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: false }, plan: 'free', ui: { nameAsked: true } })); });
  await p.reload(); await p.waitForSelector('.page-h');
  const noOverflow = async (m) => ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'no horizontal overflow: ' + m);
  const go = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(500); };
  const S = (f) => p.evaluate(async (src) => { const m = await import('/js/store.js'); return eval('(' + src + ')')(m.state); }, f.toString());
  await go('#/train'); await p.waitForSelector('[data-routine]'); ok((await p.$$('[data-routine]')).length >= 4, 'routines listed on Train'); await noOverflow('train with routines');
  ok(/Pilates, yoga and mobility/.test(await p.textContent('#main')), 'section heading present');
  // library shows the moves, with a filter by Mind-body category
  await go('#/library'); await p.waitForSelector('#list'); await p.click('summary'); await p.click('[data-f="type"][data-v="Mind-body"]'); await p.waitForTimeout(200);
  const names = await p.$$eval('.ex-row b', (l) => l.map((x) => x.textContent)); ok(names.includes('Pelvic curl') && names.includes('Cat-cow') && names.length >= 15, 'Mind-body filter lists the moves (' + names.length + ')');
  await go('#/library/pelvic-curl'); await p.waitForSelector('h1'); ok(/Pelvic curl/.test(await p.textContent('h1')), 'move detail opens'); ok(/Lie on your back/.test(await p.textContent('#main')), 'steps shown'); ok(!/undefined/.test(await p.textContent('#main')), 'no undefined text on detail');
  // start Mat Pilates routine
  await go('#/train'); await p.waitForSelector('[data-routine="mat-pilates"]'); await p.click('[data-routine="mat-pilates"]'); await p.waitForSelector('.ex-name'); await noOverflow('workout screen');
  let act = await S((s) => ({ r: s.active.routineId, n: s.active.items.length, first: s.active.items[0].exId, secs: s.active.items[0].sets[0].reps, rest: s.active.items[0].restSec }));
  ok(act.r === 'mat-pilates' && act.n === 10 && act.first === 'cat-cow' && act.secs === 60 && act.rest === 10, 'routine starts with planned moves and times');
  ok(!(await p.$('.fb')), 'no how-did-it-feel prompt for a mind-body move');
  // timer: shorten the set to 2s, start timer, wait for auto-complete
  await p.fill('[data-in="r:0"]', '2'); await p.dispatchEvent('[data-in="r:0"]', 'change'); await p.waitForTimeout(150);
  ok(/Start 2s timer/.test(await p.textContent('[data-hold="0"]')), 'timer button shows seconds'); await p.click('[data-hold="0"]'); ok(/Stop timer/.test(await p.textContent('[data-hold="0"]')), 'timer running'); await p.waitForTimeout(3000);
  act = await S((s) => s.active.items[0].sets[0].done); ok(act === true, 'set completes automatically when the timer ends');
  // stop works
  await go('#/workout'); await p.waitForSelector('.ex-name');
  // finish: go through, mark remaining done fast by setting via state then finish
  await p.evaluate(async () => { const m = await import('/js/store.js'); m.mutate((s) => { s.active.items.forEach((it, i) => { if (i < 3) it.sets.forEach((x) => { x.done = true; }); else it.skipped = true; }); }, { silent: true }); });
  await go('#/'); await go('#/workout'); await p.waitForSelector('.ex-name');
  // sides label on a one-side move: jump to leg circles (index 5), but it's skipped; check text via library instead
  await p.click('[data-finish]'); await p.waitForSelector('.sheet [data-v="finish"]'); await p.click('.sheet [data-v="finish"]'); await p.waitForTimeout(900);
  const cele = await p.$('.cele'); if (cele) { await p.click('.cele [data-close]'); await p.waitForTimeout(300); }
  const after = await S((s) => ({ n: s.sessions.length, rid: s.sessions[0]?.routineId, name: s.sessions[0]?.name, cursor: s.cursor, working: Object.keys(s.working).length, active: !!s.active }));
  ok(after.n === 1 && after.rid === 'mat-pilates' && after.name === 'Mat Pilates core', 'routine saved as a workout'); ok(after.cursor === 1, 'lifting programme cursor unchanged'); ok(after.working === 0, 'no weight progression written for routine moves'); ok(after.active === false, 'workout ended');
  ok(!/Next time/.test(await p.textContent('#main')), 'summary has no next-time recommendations for a routine'); await noOverflow('summary');
  await go('#/calendar'); await p.waitForSelector('.cal-g'); const today = key(new Date()); ok(await p.$(`.cal-c[data-d="${today}"].done`) !== null, 'routine day counts as trained in the calendar');
  const prs = await p.evaluate(async () => { const m = await import('/js/store.js'); const a = await import('/js/analytics.js'); return a.prEvents(m.state.sessions).length; }); ok(prs === 0, 'no personal bests from routine moves');
  // one-side labels: start gentle flow and look at low-lunge
  await go('#/train'); await p.click('[data-routine="gentle-flow"]'); await p.waitForSelector('.ex-name'); await p.evaluate(async () => { const m = await import('/js/store.js'); m.mutate((s) => { s.active.pos = 3; }, { silent: true }); }); await go('#/'); await go('#/workout'); await p.waitForSelector('.ex-name');
  ok(/Low lunge/.test(await p.textContent('.ex-name')), 'reached low lunge'); const lbl = await p.$$eval('.srow .sh b', (l) => l.map((x) => x.textContent)); ok(lbl[0].includes('first side') && lbl[1].includes('other side'), 'one-side moves label each set (' + lbl.join(' | ') + ')');
  await p.screenshot({ path: require('os').tmpdir() + '/g-routine.png', fullPage: true });
  console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no console errors'); console.log(fails.length ? fails.length + ' FAILED' : 'ALL PASSED'); await b.close(); process.exit(fails.length || errs.length ? 1 : 0);
})();
