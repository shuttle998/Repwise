const { chromium } = require('playwright'); const { seed } = require('./seed.js');
const THEME = process.argv[2] || 'light', W = +process.argv[3] || 375;
(async () => {
  const b = await chromium.launch(), c = await b.newContext({ viewport: { width: W, height: 800 }, deviceScaleFactor: 1, serviceWorkers: 'block' }), p = await c.newPage(); const errs = [];
  p.on('pageerror', e => errs.push(e.message));
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(async ([sessions, theme]) => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:theme', theme); localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 0, working: {}, sessions, active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: true, theme }, plan: 'free', ui: { nameAsked: true } })); }, [seed(), THEME]);
  await p.reload(); await p.waitForSelector('.page-h');
  const lum = (r, g, b) => { const f = (v) => { v /= 255; return v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; }; return .2126 * f(r) + .7152 * f(g) + .0722 * f(b); };
  const audit = () => p.evaluate(() => {
    const parse = (s) => { const m = s.match(/rgba?\(([^)]+)\)/); if (!m) return null; const [r, g, b, a = 1] = m[1].split(/[ ,\/]+/).filter(Boolean).map(Number); return { r, g, b, a }; };
    const bgOf = (el) => { let layers = []; for (let e = el; e; e = e.parentElement) { const c = parse(getComputedStyle(e).backgroundColor); if (c && c.a > 0) { layers.push(c); if (c.a >= .99) break; } } let base = { r: 255, g: 255, b: 255 }; if (!layers.length || layers[layers.length - 1].a < .99) base = parse(getComputedStyle(document.body).backgroundColor) || base; for (const l of layers.reverse()) base = { r: base.r * (1 - l.a) + l.r * l.a, g: base.g * (1 - l.a) + l.g * l.a, b: base.b * (1 - l.a) + l.b * l.a }; return base; };
    const L = (c) => { const f = (v) => { v /= 255; return v <= .03928 ? v / 12.92 : ((v + .055) / 1.055) ** 2.4; }; return .2126 * f(c.r) + .7152 * f(c.g) + .0722 * f(c.b); };
    const bad = []; const w = document.createTreeWalker(document.querySelector('#main') || document.body, NodeFilter.SHOW_TEXT);
    for (let n; (n = w.nextNode());) { if (!n.textContent.trim()) continue; const el = n.parentElement; if (!el || !el.offsetParent) continue; const cs = getComputedStyle(el); if (cs.visibility === 'hidden' || +cs.opacity === 0) continue; const fg = parse(cs.color), bg = bgOf(el); if (!fg) continue; const a = fg.a, f = { r: fg.r * a + bg.r * (1 - a), g: fg.g * a + bg.g * (1 - a), b: fg.b * a + bg.b * (1 - a) }; const l1 = L(f), l2 = L(bg), ratio = (Math.max(l1, l2) + .05) / (Math.min(l1, l2) + .05), size = parseFloat(cs.fontSize), large = size >= 24 || (size >= 18.66 && +cs.fontWeight >= 700); if (ratio < (large ? 3 : 4.5)) bad.push(`${ratio.toFixed(1)} "${n.textContent.trim().slice(0, 28)}" <${el.tagName.toLowerCase()}.${(el.className + '').slice(0, 20)}>`); }
    return [...new Set(bad)].slice(0, 12);
  });
  for (const [h, name] of [['#/', 'home'], ['#/train', 'train'], ['#/progress', 'progress'], ['#/progress/achievements', 'ach'], ['#/library', 'lib'], ['#/calendar', 'cal'], ['#/nutrition', 'nut'], ['#/settings', 'set'], ['#/pricing', 'pricing']]) {
    await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(500);
    const bad = await audit(); const ov = await p.evaluate(() => document.documentElement.scrollWidth > innerWidth);
    console.log(`${name.padEnd(8)} contrast issues: ${bad.length}${ov ? '  OVERFLOW' : ''}`); bad.forEach((x) => console.log('    ' + x));
    await p.screenshot({ path: require('os').tmpdir() + `/th-${THEME}-${W}-${name}.png`, fullPage: false });
  }
  await p.evaluate(() => { location.hash = '#/'; }); await p.waitForTimeout(400); await p.click('[data-start]'); await p.waitForSelector('[data-done]'); await p.waitForTimeout(400);
  let bad = await audit(); console.log('workout contrast issues:', bad.length); bad.forEach((x) => console.log('    ' + x)); await p.screenshot({ path: require('os').tmpdir() + `/th-${THEME}-${W}-workout.png` });
  await p.click('[data-demo], summary:has-text("Demo")').catch(() => {}); await p.waitForTimeout(500); await p.screenshot({ path: require('os').tmpdir() + `/th-${THEME}-${W}-demo.png` });
  console.log(errs.length ? 'ERRORS ' + errs : 'no page errors'); await b.close();
})();
