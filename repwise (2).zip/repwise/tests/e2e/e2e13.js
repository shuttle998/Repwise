const { chromium } = require('playwright'); const { seed, key } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 375, height: 800 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true, acceptDownloads: true, serviceWorkers: 'block' }); const p = await c.newPage();
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(async (sessions) => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 0, working: {}, sessions: [], active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: true }, plan: 'free', ui: { nameAsked: true } })); }, seed());
  await p.reload(); await p.waitForSelector('.page-h');
  const noOverflow = async (m) => ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'no horizontal overflow: ' + m);
  const go = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(500); };
  const st = () => p.evaluate(async () => { const m = await import('/js/store.js'); return JSON.parse(JSON.stringify(m.state.activities)); });
  const now = new Date(), todayK = key(now), tomorrowK = key(new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1));
  await go('#/calendar'); await p.waitForSelector('.cal-g');
  // log a class done today
  ok(await p.$('[data-cl-add]') !== null, 'calendar offers Log a class');
  await p.click(`[data-cl-add="${todayK}"][data-cl-status="done"]`); await p.waitForSelector('#clf'); await noOverflow('class sheet');
  ok(await p.isHidden('#ef') === false, 'effort shown when logging a done class');
  await p.selectOption('[name="type"]', 'pilates'); ok(await p.inputValue('[name="minutes"]') === '50', 'length defaults from class type'); ok(await p.inputValue('[name="impact"]') === 'low', 'impact defaults from class type');
  await p.selectOption('[name="type"]', 'hiit'); ok(await p.inputValue('[name="impact"]') === 'high', 'impact follows type change'); await p.selectOption('[name="type"]', 'pilates');
  await p.fill('[name="studio"]', 'Core Studio'); await p.selectOption('[name="effort"]', '3'); await p.click('#clf [type="submit"]'); await p.waitForTimeout(500);
  let a = await st(); ok(a.length === 1 && a[0].source === 'class' && a[0].status === 'done' && a[0].studio === 'Core Studio' && a[0].effort === 3, 'class saved as done');
  ok(/Core Studio/.test(await p.textContent('[aria-label="Selected day"]')), 'class shown in the day detail');
  ok(await p.$(`.cal-c[data-d="${todayK}"].done`) !== null, 'a done class marks the day as trained');
  // validation: future logged class refused
  await p.click(`[data-cl-add="${todayK}"][data-cl-status="done"]`); await p.waitForSelector('#clf'); await p.fill('[name="date"]', tomorrowK); await p.click('#clf [type="submit"]'); await p.waitForTimeout(200);
  ok(/already happened/.test(await p.textContent('#clerr')), 'future logged class refused with a message'); a = await st(); ok(a.length === 1, 'nothing saved when refused'); await p.click('.sheet [data-close]'); await p.waitForTimeout(300);
  // book a class tomorrow
  await p.click(`[data-d="${tomorrowK}"]`).catch(() => {}); await p.waitForTimeout(200);
  await p.click(`[data-cl-add="${tomorrowK}"][data-cl-status="booked"]`); await p.waitForSelector('#clf');
  ok(await p.isHidden('#ef'), 'effort hidden when booking'); await p.check('input[value="booked"]'); await p.fill('[name="date"]', tomorrowK);
  await p.click('#clf [type="submit"]'); await p.waitForTimeout(200); ok(/time/.test(await p.textContent('#clerr')), 'booked class needs a start time');
  await p.fill('[name="time"]', '10:00'); await p.click('#clf [type="submit"]'); await p.waitForTimeout(500);
  a = await st(); const bk = a.find((x) => x.status === 'booked'); ok(bk && bk.time === '10:00' && bk.date === tomorrowK, 'booked class saved');
  ok(await p.$(`.cal-c[data-d="${tomorrowK}"].done`) === null, 'a booked class does not mark the day trained');
  ok(/Booked classes/.test(await p.textContent('#main')), 'booked classes listed');
  const dl = p.waitForEvent('download'); await p.click(`[data-cl-ics="${bk.id}"]`); const d = await dl; ok(d.suggestedFilename() === 'repwise-class.ics', 'class calendar file downloads'); const body = require('fs').readFileSync(await d.path(), 'utf8'); ok(/BEGIN:VEVENT/.test(body) && /TRIGGER:-PT60M/.test(body) && body.includes('T100000'), 'calendar file has event and alarm');
  // edit
  await p.click(`[data-cl-edit="${bk.id}"]`); await p.waitForSelector('#clf'); await p.fill('[name="studio"]', 'Reformer House'); await p.click('#clf [type="submit"]'); await p.waitForTimeout(400); a = await st(); ok(a.find((x) => x.id === bk.id).studio === 'Reformer House' && a.length === 2, 'edit keeps one entry');
  // past booked class appears under Did you go, only counts after marking done
  await p.evaluate(async (k) => { const m = await import('/js/store.js'); const d = new Date(); const y = new Date(d.getFullYear(), d.getMonth(), d.getDate() - 2); const yk = `${y.getFullYear()}-${String(y.getMonth() + 1).padStart(2, '0')}-${String(y.getDate()).padStart(2, '0')}`; m.mutate((s) => { s.activities.push({ id: 'class:old', source: 'class', type: 'yoga', label: 'Yoga', date: yk, time: '09:00', start: yk + 'T09:00', durationSec: 3600, status: 'booked', impact: 'low' }); }); }); await go('#/'); await go('#/calendar'); await p.waitForSelector('.cal-g');
  ok(/Did you go\?/.test(await p.textContent('#main')), 'passed booked class asks Did you go');
  await p.click('[data-cl-done="class:old"]'); await p.waitForSelector('#md'); await p.selectOption('#md [name="effort"]', '2'); await p.click('#md [type="submit"]'); await p.waitForTimeout(500);
  a = await st(); const old = a.find((x) => x.id === 'class:old'); ok(old.status === 'done' && old.effort === 2, 'marked done with effort'); ok(!/Did you go\?/.test(await p.textContent('#main')), 'prompt gone after marking');
  // imported list is not polluted and clearing imports keeps classes
  await p.evaluate(() => { location.hash = '#/calendar'; }); await p.click('[data-dev]'); await p.waitForSelector('#hf', { state: 'attached' }); ok(!/Core Studio|Reformer House/.test(await p.textContent('.sheet')), 'imported list excludes classes');
  await p.evaluate(async () => { const m = await import('/js/store.js'); m.importActivities([{ id: 'apple:1', source: 'apple', type: 'run', date: '2026-01-05', start: '2026-01-05T07:00', durationSec: 1800 }]); m.clearActivities(); }); a = await st(); ok(a.length === 3 && a.every((x) => x.source === 'class'), 'clearing imported activities keeps classes');
  await p.click('.sheet [data-close]'); await p.waitForTimeout(300);
  // delete
  await p.click(`[data-d="${todayK}"]`); const delId = (await st()).find((x) => x.date === todayK).id; await p.click(`[data-cl-del="${delId}"]`); await p.waitForSelector('[data-v="1"]'); await p.click('[data-v="1"]'); await p.waitForTimeout(500); a = await st(); ok(!a.find((x) => x.id === delId), 'class deleted');
  // library: Easy on filter
  await go('#/library'); await p.waitForSelector('#list'); const cnt = async () => +(/(\d+) exercise/.exec(await p.textContent('#count')) || [0, 0])[1]; const total = await cnt(); await p.click('summary'); await p.click('[data-f="easy"][data-v="knees"]'); await p.waitForTimeout(200);
  const easy = await p.$$eval('.ex-row b', (l) => l.map((x) => x.textContent)); const easyN = await cnt(); ok(easyN > 0 && easyN < total, 'Easy on knees narrows the list (' + easyN + ' of ' + total + ')');
  const bad = await p.evaluate(async (names) => { const e = await import('/js/exercises.js'); return names.filter((n) => e.EXERCISES.find((x) => x.name === n)?.stress.includes('knees')); }, easy); ok(bad.length === 0, 'no knee-stress exercises shown');
  ok(/Easy on/.test(await p.textContent('#filters')), 'filter group labelled'); await noOverflow('library filters'); await p.screenshot({ path: require('os').tmpdir() + '/g-cls.png', fullPage: true });
  console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no console errors'); console.log(fails.length ? fails.length + ' FAILED' : 'ALL PASSED'); await b.close(); process.exit(fails.length || errs.length ? 1 : 0);
})();
