const { chromium } = require('playwright'); const { seed } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 375, height: 800 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true }); const p = await c.newPage();
  const net = []; p.on('request', r => { if (!r.url().startsWith('http://localhost') && !r.url().startsWith('data:') && !r.url().startsWith('blob:') && !/fonts\.(googleapis|gstatic)/.test(r.url())) net.push(r.url()); });
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(async (sessions) => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 0, working: {}, sessions, active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: true }, plan: 'free', ui: { nameAsked: true } })); }, seed());
  await p.reload(); await p.waitForSelector('.page-h');
  const noOverflow = async (m) => ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'no horizontal overflow: ' + m);
  const go = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(600); };
  const fig = () => p.$eval('[data-fig]', e => e.innerHTML);
  await go('#/library/squat-bb'); await p.waitForSelector('.anim [data-fig] line');
  ok((await p.$$('.anim [data-fig] line')).length >= 6, 'figure is drawn'); ok(/\S/.test(await p.textContent('[data-cue]')), 'cue text shown'); await noOverflow('animation card');
  const f0 = await fig(); await p.waitForTimeout(700); ok(f0 !== await fig(), 'figure moves over time');
  ok(await p.$eval('.anim-count', e => !e.hidden && +e.textContent >= 1), 'rep counter shown'); ok(await p.$('.anim .demo-frame, .anim iframe') === null, 'no video loaded until asked');
  ok(await p.$$eval('[data-fig] .seg.hl', e => e.length > 0), 'target muscles highlighted'); ok(await p.$('details.more summary') !== null, 'optional real-life video kept behind a toggle');
  await p.screenshot({ path: require('os').tmpdir() + '/a-lib.png' });
  await p.click('[data-a="toggle"]'); const s1 = await fig(); await p.waitForTimeout(500); ok(s1 === await fig(), 'pause freezes the figure'); ok(/Play/.test(await p.textContent('[data-a="toggle"]')), 'button switches to Play');
  await p.click('[data-a="toggle"]'); await p.click('[data-a="rate"][data-r="0.5"]'); ok(await p.$eval('[data-a="rate"][data-r="0.5"]', e => e.getAttribute('aria-pressed') === 'true'), 'speed 0.5x selectable');
  await p.click('[data-a="rate"][data-r="1"]');
  // follow along
  await p.click('[data-a="follow"]'); ok(await p.$eval('[data-follow]', e => !e.hidden), 'follow-along panel opens'); await noOverflow('follow panel'); await p.screenshot({ path: require('os').tmpdir() + '/a-follow.png' });
  await p.click('[data-a="dur"][data-d="20"]'); ok(await p.textContent('[data-clock]') === '20', 'duration picker sets the clock');
  await p.click('[data-a="start"]'); await p.waitForTimeout(1200); ok(/get ready/.test(await p.textContent('[data-clock-sub]')), '3 second lead-in'); const lead = +(await p.textContent('[data-clock]')); ok(lead >= 1 && lead <= 3, 'lead-in counts down: ' + lead);
  await p.waitForTimeout(6000); const c1 = +(await p.textContent('[data-clock]')); ok(c1 < 20 && c1 >= 10, 'countdown running: ' + c1); ok(/rep \d/.test(await p.textContent('[data-clock-sub]')), 'shows the rep count while counting down');
  await p.screenshot({ path: require('os').tmpdir() + '/a-run.png' });
  await p.waitForFunction(() => /Done/.test(document.querySelector('[data-status]').textContent), null, { timeout: 25000 }); const st = await p.textContent('[data-status]'); const reps = +st.match(/(\d+) rep/)[1]; ok(reps >= 4 && reps <= 8, 'finishes with a rep total: ' + st);
  ok(await p.textContent('[data-clock]') === '20', 'clock resets after finishing'); ok(/Go again/.test(await p.textContent('[data-a="start"]')), 'offers to go again');
  await p.click('[data-a="start"]'); await p.waitForTimeout(800); await p.click('[data-a="start"]'); ok(/Stopped/.test(await p.textContent('[data-status]')), 'can stop a run early');
  // timed hold
  await go('#/library/plank'); await p.waitForSelector('.anim [data-fig] line'); ok(await p.$eval('.anim-count', e => e.hidden), 'hold exercises show no rep badge'); await p.click('[data-a="follow"]'); await p.click('[data-a="start"]'); await p.waitForTimeout(4600); ok(/hold/.test(await p.textContent('[data-clock-sub]')), 'hold exercises count a hold, not reps'); await p.click('[data-a="start"]'); await noOverflow('plank');
  // every exercise opens without errors and at 375px
  const ids = await p.evaluate(async () => (await import('/js/exercises.js')).EXERCISES.filter(e => e.slot !== 'mindbody' && !e.extra).map(e => e.id));
  for (const id of ids) { await go('#/library/' + id); const n = await p.$$eval('.anim [data-fig] line', e => e.length); if (n < 6) ok(false, 'animation draws for ' + id); if (!(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth))) ok(false, 'overflow on ' + id); }
  ok(true, 'all ' + ids.length + ' exercise pages render an animation without overflow');
  // Pilates, yoga and mobility moves have no animation yet: their pages must still open cleanly at 375px with steps and the search link
  for (const id of await p.evaluate(async () => (await import('/js/exercises.js')).EXERCISES.filter(e => (e.slot === 'mindbody' || e.extra)).map(e => e.id))) { await go('#/library/' + id); const t = await p.textContent('#main'); if (/undefined|NaN/.test(t) || !/Steps|steps|How to/.test(t) && t.length < 200) ok(false, 'mind-body page ok for ' + id); const hasA = await p.evaluate(async (i) => (await import('/js/anim-data.js')).hasAnim(i), id); const nl = await p.$$eval('.anim [data-fig] line', (e) => e.length); if (hasA && nl < 6) ok(false, 'mind-body animation draws for ' + id); if (!hasA && !/No demonstration video|search/i.test(t)) ok(false, 'mind-body fallback text for ' + id); if (!(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth))) ok(false, 'overflow on ' + id); }
  ok(true, 'all mind-body pages render without overflow');
  // custom exercise has no animation but does not break
  await p.evaluate(async () => { const m = await import('/js/store.js'); window.__cid = m.saveCustom({ name: 'Zottman curl', equip: 'Dumbbell', pm: ['Biceps'], unit: 'kg' }).id; }); const cid = await p.evaluate(() => window.__cid); await go('#/library/' + cid); ok(/no animation/.test(await p.textContent('#main')), 'custom exercise explains it has no animation');
  // workout technique sheet
  await go('#/train'); await p.click('[data-start="0"]'); await p.waitForSelector('[data-info]'); ok(/Demo/.test(await p.textContent('[data-info]')), 'workout button says Demo & technique'); await p.click('[data-info]'); await p.waitForSelector('.sheet .anim [data-fig] line'); ok(true, 'animation inside the workout technique sheet'); await noOverflow('technique sheet'); await p.screenshot({ path: require('os').tmpdir() + '/a-sheet.png' });
  await p.keyboard.press('Escape'); await p.waitForTimeout(300);
  ok(net.length === 0, 'no third-party requests: ' + net.join(','));
  ok(errs.length === 0, 'no console errors ' + errs.join('|')); console.log(fails.length ? 'FAILED ' + fails.length : 'ALL PASS'); await b.close();
})();
