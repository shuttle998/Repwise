// Settings: edit the new profile fields and rebuild the programme.
const { chromium } = require('playwright');
const errs = [], fails = [];
const ok = (c, m) => { console.log((c ? 'ok   ' : 'FAIL ') + m); if (!c) fails.push(m); };
(async () => {
  const b = await chromium.launch(); const ctx = await b.newContext({ viewport: { width: 375, height: 800 }, isMobile: true, hasTouch: true, serviceWorkers: 'block' }); const p = await ctx.newPage();
  p.on('console', (m) => { if (m.type() === 'error' && !/fonts\.|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', (e) => errs.push('PAGEERROR ' + e.message));
  await p.goto('http://localhost:8123/app.html'); await p.waitForSelector('#nm');
  await p.evaluate(async () => { const g = await import('/js/generator.js'); const m = await import('/js/store.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; m.mutate((s) => { s.profile = profile; s.program = g.generateProgram(profile); s.ui.welcomed = true; }); });
  const S = (f) => p.evaluate(async (src) => { const m = await import('/js/store.js'); return new Function('s', 'return (' + src + ')(s)')(m.state); }, f.toString());
  await p.goto('http://localhost:8123/app.html#/settings'); await p.reload(); await p.waitForSelector('#goal');
  ok((await p.$$('#goal option')).length === 8 && (await p.$$('#days option')).length === 6 && (await p.$$('#split option')).length === 10, 'goal, days and split lists are complete');
  ok(await p.$eval('[data-eq="gym"]', (e) => e.getAttribute('aria-pressed')) === 'true', 'legacy gear shows as the matching equipment');
  ok(await p.$eval('[data-save]', (e) => e.disabled), 'save disabled until something changes');
  await p.click('.bm [data-bm="Biceps"]'); await p.waitForTimeout(100); ok(await p.$eval('[data-fm="Biceps"]', (e) => e.getAttribute('aria-pressed')) === 'true', 'settings body map toggles an area'); await p.click('.bm [data-bm="Biceps"]');
  await p.goto('http://localhost:8123/app.html#/library/bench'); await p.reload(); await p.waitForSelector('.bm.show'); ok((await p.$$('.bm.show .bm-r.p')).length >= 2, 'exercise page highlights target muscles on the body'); await p.goto('http://localhost:8123/app.html#/settings'); await p.reload(); await p.waitForSelector('#goal');
  await p.selectOption('#days', '6'); await p.selectOption('#split', 'ppl'); await p.selectOption('#goal', 'endurance');
  await p.click('[data-g2="strength"]'); await p.click('[data-fm="Calves"]'); await p.fill('#duration', '90'); await p.click('details.fine summary'); await p.fill('[data-par="sets"]', '4');
  await p.click('[data-eq="gym"]'); await p.click('[data-save]'); ok(/at least one/.test(await p.textContent('#main')), 'empty equipment is refused');
  await p.click('[data-eq="db"]'); await p.click('[data-eq="bands"]'); await p.click('[data-save]'); await p.waitForSelector('.dialog, [role=dialog], .sheet'); await p.click('.dialog .btn.primary, [role=dialog] .btn.primary, .sheet .btn.primary'); await p.waitForTimeout(600);
  const r = await S((s) => ({ p: s.profile, n: s.program.sessions.length, eq: s.program.sessions.flatMap((x) => x.items.map((i) => i.exId)) }));
  ok(r.p.days === 6 && r.p.split === 'ppl' && r.p.goal === 'endurance' && r.p.goals2.join() === 'strength' && r.p.focusMuscles.join() === 'Calves' && r.p.duration === 90 && r.p.params.sets === 4 && r.p.gear === 'db', 'new profile fields saved: ' + JSON.stringify([r.p.days, r.p.split, r.p.gear]));
  ok(r.n === 6, 'programme rebuilt with 6 sessions');
  ok(await p.evaluate(async (ids) => { const E = await import('/js/exercises.js'); return ids.every((id) => ['Dumbbell', 'Band', 'Bodyweight'].includes(E.BY_ID[id].equip)); }, r.eq), 'rebuilt plan only uses dumbbells, bands and bodyweight');
  ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), 'no horizontal scroll');
  console.log(errs.length ? 'ERRORS:\n' + errs.join('\n') : 'no console errors'); console.log(fails.length ? fails.length + ' FAILED' : 'ALL PASSED'); await b.close(); process.exit(fails.length || errs.length ? 1 : 0);
})();
