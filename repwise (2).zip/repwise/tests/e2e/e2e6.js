const { chromium } = require('playwright'); const { seed } = require('./seed.js'); const errs = [], fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
const B = 'http://localhost:8123/app.html';
(async () => {
  const b = await chromium.launch(); const c = await b.newContext({ viewport: { width: 375, height: 800 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true }); const p = await c.newPage();
  const net = []; p.on('request', r => { if (!r.url().startsWith('http://localhost') && !r.url().startsWith('data:') && !r.url().startsWith('blob:')) net.push(r.url()); });
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto(B);
  await p.evaluate(async (sessions) => { const g = await import('/js/generator.js'); const profile = { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }; localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile, program: g.generateProgram(profile), cursor: 0, working: {}, sessions, active: null, settings: { units: 'kg', sound: false, vibrate: false, notify: false, wakeLock: true }, plan: 'free', ui: { nameAsked: true } })); }, seed());
  await p.reload(); await p.waitForSelector('.page-h');
  const noOverflow = async (m) => ok(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'no horizontal overflow: ' + m);
  const openF = async () => { if (!(await p.$eval('.filt', e => e.open))) await p.click('.filt summary'); };
  const go = async (h) => { await p.evaluate((x) => { location.hash = x; }, h); await p.waitForTimeout(500); };
  // ---- analytics
  await go('#/progress'); await p.waitForSelector('.grid-fit .stat');
  ok((await p.$$('.grid-fit .stat')).length === 5, '5 stat tiles incl. consistency'); ok(await p.$('#c-dur svg, #c-dur canvas, #c-dur *') !== null, 'duration chart rendered');
  const w0 = +(await p.textContent('.grid-fit .stat b')); await noOverflow('analytics'); await p.screenshot({ path: require('os').tmpdir() + '/p-an.png', fullPage: true });
  await p.click('.filt summary'); const opts = await p.$$eval('#f-ex option', o => o.map(x => x.value).filter(Boolean)); ok(opts.length > 1, 'exercise filter lists logged exercises');
  await p.selectOption('#f-ex', opts[0]); await p.waitForTimeout(200); const w1 = +(await p.textContent('.grid-fit .stat b')); ok(w1 <= w0 && w1 >= 1, `exercise filter narrows sessions (${w0} -> ${w1})`);
  ok(await p.$('#exsel:disabled') !== null, 'strength chart follows the exercise filter');
  await p.click('[data-reset]'); ok(+(await p.textContent('.grid-fit .stat b')) === w0, 'reset restores totals');
  await openF(); await p.selectOption('#f-mus', 'Chest'); await p.waitForTimeout(300); ok(await p.$('.sheet') !== null, 'muscle filter is a Pro feature for free users'); await p.keyboard.press('Escape'); await p.waitForTimeout(200);
  await openF(); await p.selectOption('#f-gran', 'month'); await p.waitForTimeout(200); ok(/month/.test(await p.textContent('#c-vol').catch(() => '') + await p.textContent('.card .lbl')), 'group by month applied');
  await openF(); await p.selectOption('#f-gran', 'auto');
  await openF(); await p.fill('#f-from', '2026-11-01'); await p.fill('#f-to', '2026-11-12'); await p.waitForTimeout(300); ok(await p.$('[data-seg="period"][aria-pressed="true"]') === null, 'custom dates replace the preset period'); await noOverflow('custom range');
  await p.click('[data-reset]');
  // Pro: muscle analytics
  await p.evaluate(async () => { const m = await import('/js/store.js'); m.mutate((s) => { s.plan = 'pro'; }); }); await go('#/progress/records'); await go('#/progress'); await p.waitForSelector('.mus');
  const rows = await p.$$eval('.mus tbody tr', r => r.map(x => x.querySelector('th').textContent.trim())); ok(rows.includes('Quadriceps') && rows.includes('Forearms') && rows.length === 11, '11 muscle groups incl. Quadriceps and Forearms: ' + rows.length);
  await p.$eval('[data-musf="Back"]', e => e.click()); await p.waitForTimeout(300); ok(/Back/.test(await p.textContent('.filt summary')), 'tapping a muscle filters the charts'); await noOverflow('muscle analytics'); await p.screenshot({ path: require('os').tmpdir() + '/p-mus.png', fullPage: true });
  await p.click('[data-reset]');
  // ---- records / achievements
  await go('#/progress/records'); await p.waitForSelector('.li'); const rt = await p.textContent('.stack'); ok(/lifted/.test(rt) && /Estimated 1RM .*\(calculated\)/.test(rt) && /20\d\d/.test(rt), 'records separate lifted vs estimated, with dates'); await noOverflow('records');
  await go('#/progress/achievements'); await p.waitForSelector('.ach'); ok((await p.$$('.medal.t0')).length > 0 && (await p.$$('.medal.t2')).length > 0, 'badges have tiers'); ok(/A month of consistency/.test(await p.textContent('.ach-grid')) && /Bench press 40 kg/.test(await p.textContent('body')), 'new achievements present'); await noOverflow('achievements'); await p.screenshot({ path: require('os').tmpdir() + '/p-ach.png' });
  // ---- body
  await go('#/progress/body'); await p.waitForSelector('#bf');
  ok(/No measurements yet/.test(await p.textContent('main, #main')), 'empty state before any entry');
  await p.click('#bf button.primary'); ok(/at least one/.test(await p.textContent('#bf-err')), 'validation: empty form');
  await p.fill('[name=weight]', '5'); await p.click('#bf button.primary'); ok(/out of range/.test(await p.textContent('#bf-err')), 'validation: implausible weight');
  await p.fill('[name=date]', '2026-10-01'); await p.fill('[name=weight]', '80.5'); await p.fill('[name=waist]', '90'); await p.click('#bf button.primary'); await p.waitForSelector('#bc svg, #bc *');
  await p.fill('[name=date]', '2026-11-10'); await p.fill('[name=weight]', '78.9'); await p.fill('[name=waist]', '87.5'); await p.fill('[name=chest]', '101'); await p.click('#bf button.primary'); await p.waitForTimeout(300);
  ok((await p.$$('#main .li [data-del]')).length === 2, 'two entries in history');
  ok(/80.5 kg on .* → 78.9 kg on/.test(await p.textContent('#bnote')), 'trend note from real entries'); await p.selectOption('#metric', 'waist'); ok(/90 cm/.test(await p.textContent('#bnote')), 'metric switch');
  const cmp = await p.textContent('.tbl'); ok(/Body weight/.test(cmp) && /−1.6 kg/.test(cmp) && /−2.5 cm/.test(cmp) && !/Chest/.test(cmp), 'compare shows deltas only for shared metrics');
  await p.click('[data-edit]:first-of-type'); await p.waitForSelector('[data-cancel]'); await p.click('[data-cancel]');
  const stored = await p.evaluate(() => JSON.parse(localStorage.getItem('repwise:v2')).body.entries.length); ok(stored === 2, 'entries persisted');
  await p.reload(); await p.waitForSelector('#bf'); ok((await p.$$('#main .li [data-del]')).length === 2, 'entries survive reload');
  await noOverflow('body'); await p.screenshot({ path: require('os').tmpdir() + '/p-body.png', fullPage: true });
  // lb units: stored kg unchanged
  await p.evaluate(async () => { const m = await import('/js/store.js'); m.mutate((s) => { s.settings.units = 'lb'; }); }); await go('#/progress'); await go('#/progress/body'); await p.waitForSelector('#bf');
  ok(/173.9 lb|174 lb/.test(await p.textContent('#main')) || /173/.test(await p.textContent('#main')), 'lb display converts kg'); ok(await p.evaluate(() => JSON.parse(localStorage.getItem('repwise:v2')).body.entries.some((e) => e.weight === 80.5)), 'stored value stays metric');
  await p.evaluate(async () => { const m = await import('/js/store.js'); m.mutate((s) => { s.settings.units = 'kg'; }); }); await go('#/progress'); await go('#/progress/body'); await p.waitForSelector('#bf');
  // export includes body
  ok(await p.evaluate(async () => (await import('/js/store.js')).exportJSON().includes('"body"')), 'export includes measurements');
  // delete
  await p.click('[data-del]'); await p.click('.sheet [data-v="1"]'); await p.waitForTimeout(300); ok((await p.$$('#main .li [data-del]')).length === 1, 'delete with confirmation');
  // photos
  const png = await p.evaluate(() => { const c = document.createElement('canvas'); c.width = 600; c.height = 800; const x = c.getContext('2d'); x.fillStyle = '#4a63ff'; x.fillRect(0, 0, 600, 800); return c.toDataURL('image/png').split(',')[1]; });
  const pre = net.length; await p.waitForSelector('#pf', { state: 'attached' });
  await p.setInputFiles('#pf', { name: 'a.png', mimeType: 'image/png', buffer: Buffer.from(png, 'base64') }); await p.waitForSelector('.pth'); ok((await p.$$('.pth')).length === 1, 'photo saved and shown');
  await p.setInputFiles('#pf', { name: 'b.png', mimeType: 'image/png', buffer: Buffer.from(png, 'base64') }); await p.waitForFunction(() => document.querySelectorAll('.pth').length === 2);
  await p.setInputFiles('#pf', { name: 'x.txt', mimeType: 'text/plain', buffer: Buffer.from('hi') }); await p.waitForTimeout(400); ok(/image/i.test(await p.textContent('#ph')), 'non-image rejected with message');
  await p.click('[data-pcmp]'); await p.waitForSelector('.pcmp img'); ok((await p.$$('.pcmp img')).length === 2, 'compare two photos'); await p.keyboard.press('Escape'); await p.waitForTimeout(250);
  await p.click('[data-pview]'); await p.waitForSelector('.sheet [data-d]'); await p.click('.sheet [data-d]'); await p.click('.sheet:last-of-type [data-v="1"], .sheet-wrap:last-child [data-v="1"]'); await p.waitForFunction(() => document.querySelectorAll('.pth').length === 1); ok(true, 'delete one photo');
  ok(!(await p.evaluate(() => JSON.stringify(localStorage)).then(x => x.includes('blob'))), 'photos are not in localStorage'); ok(!/photo|image/i.test(await p.evaluate(async () => (await import('/js/store.js')).exportJSON())), 'photos not in export');
  await p.click('[data-pclear]'); await p.click('.sheet [data-v="1"]'); await p.waitForFunction(() => !document.querySelector('.pth')); ok(true, 'delete all photos'); ok(net.length === pre, 'no network requests for photos: ' + net.slice(pre).join(','));
  // report tab + tabs overflow
  await go('#/progress/report'); await p.waitForSelector('.wk-nav, .empty, .stack'); await noOverflow('report');
  ok(errs.length === 0, 'no console errors ' + errs.join('|')); console.log(fails.length ? 'FAILED ' + fails.length : 'ALL PASS'); await b.close();
})();
