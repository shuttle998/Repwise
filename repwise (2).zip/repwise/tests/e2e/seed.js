const key = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
function seed() {
  const now = new Date(), sessions = []; let i = 0;
  for (let back = 100; back >= 1; back -= 3) {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - back), k = key(d), prog = (100 - back) / 100;
    const bw = Math.round((30 + prog * 20) / 2.5) * 2.5, sq = Math.round((40 + prog * 30) / 2.5) * 2.5;
    sessions.push({ id: 's' + i++, date: k, startedAt: d.getTime() + 36e5 * 10, endedAt: d.getTime() + 36e5 * 11, durationSec: 3300, name: i % 2 ? 'Upper body' : 'Lower body', sessionIdx: i % 2, items: i % 2
      ? [{ exId: 'bench', name: 'Bench press', sets: [{ w: bw, reps: 10 }, { w: bw, reps: 9 }, { w: bw, reps: 8 }], feedback: 'good', targetSets: 3, repLo: 8, repHi: 12 }, { exId: 'cablerow', name: 'Seated cable row', sets: [{ w: 30, reps: 10 }, { w: 30, reps: 10 }, { w: 30, reps: 9 }], feedback: 'good', targetSets: 3, repLo: 8, repHi: 12 }, { exId: 'pushup', name: 'Push-up', sets: [{ w: 0, reps: 12 }, { w: 0, reps: 11 }], targetSets: 2, repLo: 8, repHi: 12 }]
      : [{ exId: 'squat-bb', name: 'Barbell squat', sets: [{ w: sq, reps: 8 }, { w: sq, reps: 8 }, { w: sq, reps: 7 }], feedback: 'hard', targetSets: 3, repLo: 8, repHi: 12 }, { exId: 'plank', name: 'Plank', sets: [{ w: 0, reps: 40 }, { w: 0, reps: 35 }], targetSets: 2, repLo: 30, repHi: 60 }] });
  }
  return sessions;
}
module.exports = { seed, key };
