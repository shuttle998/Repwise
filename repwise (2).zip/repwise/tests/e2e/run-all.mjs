// Runs every end-to-end test in a real browser against a local static server. Needs: npm i -D playwright && npx playwright install chromium
// Run: node tests/e2e/run-all.mjs [filter]
import http from 'node:http';
import { readFileSync, existsSync, statSync, readdirSync } from 'node:fs';
import { join, dirname, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const here = dirname(fileURLToPath(import.meta.url)), root = join(here, '..', '..'), PORT = 8123;
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.webmanifest': 'application/manifest+json', '.ico': 'image/x-icon' };
const server = http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname); if (p.endsWith('/')) p += 'index.html'; const f = join(root, p);
  if (!f.startsWith(root) || !existsSync(f) || statSync(f).isDirectory()) { res.writeHead(404); return res.end('not found'); }
  res.writeHead(200, { 'Content-Type': MIME[extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' }); res.end(readFileSync(f));
});
await new Promise((r, j) => { server.once('error', (e) => (e.code === 'EADDRINUSE' ? r() : j(e))); server.listen(PORT, r); });
const filter = process.argv[2] || '';
const jobs = [...readdirSync(here).filter((f) => /^e2e[\d-].*\.js$|^e2e-\w+\.js$/.test(f) && f !== 'e2e-contrast.js').sort((a, b) => a.localeCompare(b, undefined, { numeric: true })).map((f) => [f, []]), ['e2e-contrast.js', ['light', '375']], ['e2e-contrast.js', ['dark', '375']], ['e2e-contrast.js', ['light', '1280']]].filter(([f, a]) => (f + a.join(' ')).includes(filter));
let failed = 0;
for (const [f, args] of jobs) {
  const code = await new Promise((r) => { let out = ''; const c = spawn('node', [join(here, f), ...args], { cwd: here }); c.stdout.on('data', (d) => (out += d)); c.stderr.on('data', (d) => (out += d)); const t = setTimeout(() => c.kill(), 240000); c.on('close', (k) => { clearTimeout(t); const bad = /^\s+FAIL |^FAIL |ERRORS:|contrast issues: [1-9]|PAGEERROR/m.test(out); if (k || bad) { console.log(out.split('\n').filter((l) => /FAIL|ERROR|issues: [1-9]|Error|^\s{4}\d/.test(l)).slice(0, 15).join('\n')); } r(k || (bad ? 1 : 0)); }); });
  console.log((code ? 'FAIL ' : 'ok   ') + f + (args.length ? ' ' + args.join(' ') : '')); if (code) failed++;
}
server.close(); console.log(failed ? `\n${failed} e2e file(s) failed` : '\nAll e2e tests passed'); process.exit(failed ? 1 : 0);
