const { chromium } = require('playwright'); const SP = process.env.SP; const errs = []; const fails = [];
const ok = (c, m) => { if (!c) { fails.push(m); console.log('  FAIL', m); } else console.log('  ok  ', m); };
const key = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
function seed() {
  const now = new Date(), sessions = []; let i = 0;
  for (let back = 100; back >= 1; back -= 3) {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - back), k = key(d), prog = (100 - back) / 100;
    const bw = Math.round((30 + prog * 20) / 2.5) * 2.5, sq = Math.round((40 + prog * 30) / 2.5) * 2.5;
    sessions.push({ id: 's' + i++, date: k, startedAt: d.getTime() + 36e5 * 10, endedAt: d.getTime() + 36e5 * 11, durationSec: 3300, name: i % 2 ? 'Upper body' : 'Lower body', sessionIdx: i % 2, items: i % 2
      ? [{ exId: 'bench', name: 'Bench press', sets: [{ w: bw, reps: 10 }, { w: bw, reps: 9 }, { w: bw, reps: 8 }], feedback: 'good', targetSets: 3, repLo: 8, repHi: 12 }, { exId: 'cablerow', name: 'Seated cable row', sets: [{ w: 30, reps: 10 }, { w: 30, reps: 10 }, { w: 30, reps: 9 }], feedback: 'good', targetSets: 3, repLo: 8, repHi: 12 }, { exId: 'pushup', name: 'Push-up', sets: [{ w: 0, reps: 12 }, { w: 0, reps: 11 }], targetSets: 2, repLo: 8, repHi: 12 }]
      : [{ exId: 'squat-bb', name: 'Barbell squat', sets: [{ w: sq, reps: 8 }, { w: sq, reps: 8 }, { w: sq, reps: 7 }], feedback: 'hard', targetSets: 3, repLo: 8, repHi: 12 }, { exId: 'plank', name: 'Plank', sets: [{ w: 0, reps: 40 }, { w: 0, reps: 35 }], targetSets: 2, repLo: 30, repHi: 60 }] });
  }
  return sessions;
}
(async () => {
  const b = await chromium.launch();
  const mk = async (vp = { width: 375, height: 800 }) => { const ctx = await b.newContext({ viewport: vp, deviceScaleFactor: 2, isMobile: vp.width < 600, hasTouch: vp.width < 600, acceptDownloads: true }); const p = await ctx.newPage();
    p.on('console', m => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_|Failed to load resource/.test(m.text())) errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message)); return [ctx, p]; };

  console.log('A. migration from v1');
  let [c, p] = await mk();
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate(() => localStorage.setItem('repwise', JSON.stringify({ p: { goal: 'muscle', focus: 'balanced', days: 3, lvl: 1, gear: 'gym' }, w: { squatgym: 32.5, pushgym: 25 }, log: [{ d: '2026-11-01', s: 'Full body A' }, { d: '2026-11-03', s: 'Full body B' }], idx: 2 })));
  await p.reload(); await p.waitForTimeout(900);
  let st = await p.evaluate(() => JSON.parse(localStorage.getItem('repwise:v2')));
  ok(st.profile && st.profile.goal === 'muscle' && st.profile.gear === 'gym', 'profile migrated');
  ok(st.sessions.length === 2 && st.sessions[0].legacy, 'legacy log migrated as workouts');
  ok(st.working['squat-bb']?.w === 32.5 && st.working['bench']?.w === 25, 'working weights carried over by exercise name');
  ok(st.cursor === 2, 'cursor kept');
  ok(await p.$('.sheet') !== null, 'name prompt shown');
  await p.fill('#nm', 'Tunde'); await p.click('#nmok'); await p.waitForTimeout(400);
  ok((await p.textContent('.page-h h1')).includes('Tunde'), 'name appears on dashboard');
  ok(await p.evaluate(() => localStorage.getItem('repwise') !== null), 'original v1 data left untouched');
  await c.close();

  console.log('B. all routes with rich data, free plan @375px');
  [c, p] = await mk();
  await p.goto('http://localhost:8123/app.html');
  await p.evaluate((sessions) => { localStorage.setItem('repwise:v2', JSON.stringify({ v: 2, profile: { name: 'Ada', goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], createdAt: '2026-01-01' }, program: null, cursor: 0, working: {}, sessions, active: null, settings: { units: 'kg', sound: true, vibrate: true, notify: false, wakeLock: true }, plan: 'free', ui: { nameAsked: true, welcomed: true } })); }, seed());
  // program must exist: let app handle by generating through onboarding? set via module
  await p.evaluate(async () => { const g = await import('/js/generator.js'); const s = JSON.parse(localStorage.getItem('repwise:v2')); s.program = g.generateProgram(s.profile); localStorage.setItem('repwise:v2', JSON.stringify(s)); });
  for (const r of ['', 'train', 'progress', 'progress/records', 'progress/achievements', 'progress/report', 'library', 'library/bench', 'settings', 'pricing']) {
    await p.goto('http://localhost:8123/app.html#/' + r); await p.reload(); await p.waitForTimeout(700);
    const ov = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
    ok(ov.sw <= ov.cw, `no horizontal scroll on #/${r} (${ov.sw}/${ov.cw})`);
    const empty = await p.evaluate(() => document.querySelector('#main').innerText.length);
    ok(empty > 40, `#/${r} renders content`);
    await p.screenshot({ path: `${SP}/r-${r.replace(/\//g, '_') || 'home'}.png`, fullPage: true });
  }
  console.log('C. gating');
  await p.goto('http://localhost:8123/app.html#/progress'); await p.reload(); await p.waitForTimeout(600);
  await p.click('[data-seg=period][data-v="90"]'); await p.waitForTimeout(300);
  ok((await p.textContent('.sheet')).includes('Pro feature'), '90 days gated on Free');
  await p.keyboard.press('Escape'); await p.waitForTimeout(300);
  ok(await p.$('.sheet') === null, 'sheet closes with Escape');
  const hidden = await p.textContent('.banner.warn').catch(() => ''); ok(/older workout/.test(hidden), 'free plan shows hidden older workouts note');
  await p.goto('http://localhost:8123/app.html#/pricing'); await p.reload(); await p.waitForTimeout(400);
  await p.click('[data-preview]'); await p.waitForTimeout(300);
  ok(JSON.parse(await p.evaluate(() => localStorage.getItem('repwise:v2'))).plan === 'pro', 'Pro preview toggles locally');
  const bodyTxt = await p.textContent('body'); ok(!/card number|credit card|checkout/i.test(bodyTxt.replace('Checkout is not available', '')), 'no fake payment UI');
  await p.goto('http://localhost:8123/app.html#/progress'); await p.reload(); await p.waitForTimeout(600);
  await p.click('[data-seg=period][data-v=all]'); await p.waitForTimeout(500);
  ok(await p.$('#c-vol svg') !== null && await p.$('#mus .mus') !== null, 'All time + muscle distribution available on Pro');
  await p.screenshot({ path: SP + '/prog-pro.png', fullPage: true });
  await p.goto('http://localhost:8123/app.html#/progress/report'); await p.reload(); await p.waitForTimeout(500); await p.screenshot({ path: SP + '/report-pro.png', fullPage: true });
  await p.goto('http://localhost:8123/app.html#/train'); await p.reload(); await p.waitForTimeout(400);
  await p.click('[data-edit]'); await p.waitForTimeout(300); ok(await p.$('[data-adj]') !== null, 'programme editor opens on Pro');
  await p.screenshot({ path: SP + '/editor.png', fullPage: true });
  console.log('D. settings');
  await p.goto('http://localhost:8123/app.html#/settings'); await p.reload(); await p.waitForTimeout(500);
  await p.click('[data-seg=units][data-v=lb]'); await p.waitForTimeout(200);
  await p.goto('http://localhost:8123/app.html#/'); await p.reload(); await p.waitForTimeout(600);
  ok(/lb/.test(await p.textContent('.exlist')), 'weights shown in lb after unit change');
  await p.goto('http://localhost:8123/app.html#/settings'); await p.reload(); await p.waitForTimeout(400);
  const [dl] = await Promise.all([p.waitForEvent('download'), p.click('[data-exp=csv]')]); ok(dl.suggestedFilename().endsWith('.csv'), 'CSV export downloads');
  const [dl2] = await Promise.all([p.waitForEvent('download'), p.click('[data-exp=json]')]); const pth = await dl2.path(); const exported = JSON.parse(require('fs').readFileSync(pth, 'utf8')); ok(exported.sessions.length > 30, 'JSON export contains history');
  await p.selectOption('#goal', 'strength'); await p.waitForTimeout(200); await p.click('[data-save]'); await p.waitForSelector('.sheet [data-v="1"]'); await p.click('.sheet [data-v="1"]'); await p.waitForTimeout(400);
  st = await p.evaluate(() => JSON.parse(localStorage.getItem('repwise:v2')));
  ok(st.profile.goal === 'strength' && st.program.sessions[0].items[0].repHi === 6 && st.sessions.length > 30, 'goal change rebuilds programme and keeps history');
  await p.screenshot({ path: SP + '/settings.png', fullPage: true });
  console.log('E. library');
  await p.goto('http://localhost:8123/app.html#/library'); await p.reload(); await p.waitForTimeout(400);
  await p.fill('#q', 'glute'); await p.waitForTimeout(200); const n1 = await p.$$eval('#list .ex-row', e => e.length); ok(n1 > 3 && n1 < 70, `search filters (${n1})`);
  await p.fill('#q', ''); await p.click('summary'); await p.click('[data-f=equip][data-v=Cable]'); const n2 = await p.$$eval('#list .ex-row', e => e.length); ok(n2 >= 4 && n2 < 15, `equipment filter (${n2})`);
  await c.close();
  console.log('\nconsole errors:', JSON.stringify(errs)); console.log('FAILS:', fails.length); await b.close(); process.exit(fails.length || errs.length ? 1 : 0);
})().catch(e => { console.log('CRASH', e.message); console.log('errors', JSON.stringify(errs)); process.exit(2); });
