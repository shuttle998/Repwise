// Offline completeness, data recovery and deploy-hygiene checks. Run: node tests/reliability.mjs
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, dirname, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const mem = new Map(); globalThis.localStorage = { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };
globalThis.window = { dispatchEvent() {}, addEventListener() {} };
let pass = 0, fail = 0; const t = async (n, fn) => { try { await fn(); pass++; console.log('  ok  ' + n); } catch (e) { fail++; console.log('FAIL  ' + n + '\n      ' + e.message); } };
const walk = (d) => readdirSync(join(root, d)).flatMap((n) => { const p = join(d, n); return statSync(join(root, p)).isDirectory() ? walk(p) : [p.split('\\').join('/')]; });
const manifest = () => { const src = readFileSync(join(root, 'sw-manifest.js'), 'utf8'); return JSON.parse(src.split('= ')[1].replace(/;\s*$/, '')); };

console.log('reliability');
await t('sw-manifest.js is up to date with the files on disk', () => { execFileSync('node', [join(root, 'tools/gen-precache.mjs'), '--check'], { stdio: 'pipe' }); });
await t('every JS import (static and dynamic) points at a file that exists and is precached for offline use', () => {
  const files = new Set(manifest().files), missing = [];
  for (const f of walk('js').filter((x) => x.endsWith('.js'))) {
    const src = readFileSync(join(root, f), 'utf8');
    for (const m of src.matchAll(/(?:from\s+|import\s*\(\s*|import\s+)['"](\.{1,2}\/[^'"]+)['"]/g)) { const target = normalize(join(dirname(f), m[1])).split('\\').join('/'); if (!existsSync(join(root, target))) missing.push(`${f} -> ${target} (missing on disk)`); else if (!files.has(target)) missing.push(`${f} -> ${target} (not precached)`); }
  }
  assert.deepEqual(missing, []);
});
await t('app.html assets (css, scripts, icons, manifest) are all precached', () => {
  const html = readFileSync(join(root, 'app.html'), 'utf8'), files = new Set(manifest().files), miss = [];
  for (const m of html.matchAll(/(?:href|src)="((?!https?:|data:|#)[^"]+)"/g)) { const f = m[1].replace(/^\.\//, ''); if (!files.has(f)) miss.push(f); }
  assert.deepEqual(miss, []);
});
await t('version changes when a file changes (so deploys refresh the offline cache)', async () => { const a = manifest().version; assert.match(a, /^repwise-[0-9a-f]{12}$/); });
await t('security headers: CSP allows only self, fonts, YouTube-nocookie and Supabase; no inline scripts; no unsafe-eval', () => {
  const h = readFileSync(join(root, '_headers'), 'utf8'), csp = /Content-Security-Policy:\s*(.+)/.exec(h)[1];
  assert.ok(/script-src 'self'(;|$)/.test(csp)); assert.ok(!/unsafe-eval|script-src[^;]*unsafe-inline/.test(csp)); assert.ok(/connect-src 'self' https:\/\/\*\.supabase\.co/.test(csp));
  for (const html of ['app.html', 'index.html']) assert.ok(!/<script(?![^>]*\bsrc=)[^>]*>[^<]/.test(readFileSync(join(root, html), 'utf8')), html + ' has an inline script that the CSP would block');
});
await t('no service_role key or secrets in the shipped code', () => {
  for (const f of [...walk('js'), 'app.html', 'index.html', 'sw.js', 'sw-manifest.js']) { const s = readFileSync(join(root, f), 'utf8'); assert.ok(!/service_role|sk-ant-|AIza[0-9A-Za-z_-]{20}/.test(s), f + ' contains something that looks like a secret'); }
});
const S = await import('../js/store.js'), { CONFIG } = await import('../js/config.js');
await t('save keeps a second automatic copy; a corrupted main copy is recovered from it', () => {
  S.load(); S.mutate((st) => { st.profile = { name: 'Keep', days: 3 }; st.sessions.push({ id: 's1', date: '2026-01-01', name: 'x', items: [] }); });
  assert.ok(mem.get(CONFIG.STORAGE_KEY + ':bak'), 'backup copy written'); mem.set(CONFIG.STORAGE_KEY, '{"this is": broken');
  assert.equal(S.load(), 'recovered'); assert.equal(S.state.profile.name, 'Keep'); assert.equal(S.state.sessions.length, 1); assert.ok(mem.get(CONFIG.STORAGE_KEY + ':corrupt'), 'the unreadable data was kept for inspection');
  JSON.parse(mem.get(CONFIG.STORAGE_KEY));
});
await t('with no usable backup a corrupted save starts fresh without crashing and keeps the damaged data', () => { mem.set(CONFIG.STORAGE_KEY, 'garbage'); mem.set(CONFIG.STORAGE_KEY + ':bak', 'also garbage'); assert.equal(S.load(), 'new'); assert.equal(S.state.sessions.length, 0); assert.equal(mem.get(CONFIG.STORAGE_KEY + ':corrupt'), 'garbage'); });
await t('imports of older exports (no reminders, inbox, activities, sync, theme) load with safe defaults', () => {
  const old = { v: 2, profile: { name: 'Old', days: 3 }, program: null, cursor: 0, working: {}, sessions: [{ id: 'a', date: '2026-01-01', name: 'x', items: [] }], active: null, settings: { units: 'lb' } };
  S.importJSON(JSON.stringify(old)); assert.equal(S.state.settings.units, 'lb'); assert.equal(S.state.settings.theme, 'dark'); assert.deepEqual(S.state.inbox, []); assert.deepEqual(S.state.activities, []); assert.equal(S.state.reminders.enabled, false); assert.equal(S.state.sync.dirty, false); assert.equal(S.state.sessions.length, 1);
});
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
