// Integration test of the cloud client and sync engine against the in-memory mock Supabase. Run: node tests/cloud.mjs
import assert from 'node:assert/strict';
const mem = new Map(); globalThis.localStorage = { getItem: (k) => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: (k) => mem.delete(k) };
globalThis.window = { dispatchEvent() {}, addEventListener() {} };
import { startMock } from './mock-supabase.mjs';
import { CONFIG } from '../js/config.js';

const mock = await startMock(8131);
CONFIG.CLOUD = { url: mock.url, anonKey: 'anon' };
const cloud = await import('../js/cloud.js'), S = await import('../js/store.js'), E = await import('../js/sync-engine.js'), SY = await import('../js/sync.js');
let pass = 0, fail = 0; const t = async (n, fn) => { try { await fn(); pass++; console.log('  ok  ' + n); } catch (e) { fail++; console.log('FAIL  ' + n + '\n      ' + e.message); } };
const sess = (id, date) => ({ id, date, name: 'x', durationSec: 60, items: [{ exId: 'bench', name: 'Bench', sets: [{ w: 20, reps: 5 }] }] });
S.load();

console.log('cloud client and sync engine');
await t('not signed in: sync does nothing and reports off', async () => { assert.equal(cloud.configured(), true); assert.equal(cloud.signedIn(), false); const r = await E.syncNow(); assert.equal(r.state, 'off'); });
await t('sign up validates password, rejects duplicates with friendly messages', async () => {
  await assert.rejects(() => cloud.signUp('a@b.co', 'short'), /stronger password/);
  assert.deepEqual(await cloud.signUp('a@b.co', 'correct horse'), { confirmed: true }); assert.equal(cloud.currentUser().email, 'a@b.co');
  await cloud.signOut(); assert.equal(cloud.signedIn(), false);
  await assert.rejects(() => cloud.signUp('a@b.co', 'correct horse'), /already exists/);
});
await t('wrong password gives a clear error; right one signs in', async () => { await assert.rejects(() => cloud.signIn('a@b.co', 'nope nope nope'), /incorrect/); await cloud.signIn('a@b.co', 'correct horse'); assert.equal(cloud.signedIn(), true); });
await t('first sync uploads local data (migration) and keeps a pre-sync backup', async () => {
  S.mutate((st) => { st.sessions.push(sess('s1', '2026-11-01'), sess('s2', '2026-11-02')); st.profile = { name: 'T', days: 3 }; });
  assert.equal(S.isDirty(), true); const r = await E.syncNow(); assert.equal(r.state, 'idle', r.message);
  const row = [...mock.rows.values()][0]; assert.equal(row.rev, 1); assert.equal(row.data.sessions.length, 2); assert.equal(S.isDirty(), false); assert.equal(S.state.sync.rev, 1);
});
await t('a later local change pushes with the next revision', async () => { S.mutate((st) => { st.sessions.push(sess('s3', '2026-11-03')); }); await E.syncNow(); const row = [...mock.rows.values()][0]; assert.equal(row.rev, 2); assert.equal(row.data.sessions.length, 3); });
await t('conflict: another device changed the cloud copy first, so we merge instead of overwriting', async () => {
  const row = [...mock.rows.values()][0]; row.data.sessions.push(sess('other', '2026-11-04')); row.rev++; // "another device" wrote
  S.mutate((st) => { st.sessions.push(sess('mine', '2026-11-05')); }); await E.syncNow();
  const ids = [...mock.rows.values()][0].data.sessions.map((x) => x.id).sort(); assert.deepEqual(ids, ['mine', 'other', 's1', 's2', 's3']); assert.deepEqual(S.state.sessions.map((x) => x.id).sort(), ids, 'local also has everything');
});
await t('deleting on this device removes it from the cloud and a re-sync does not resurrect it', async () => {
  S.mutate((st) => { st.sessions = st.sessions.filter((x) => x.id !== 's1'); }); await E.syncNow(); assert.ok(![...mock.rows.values()][0].data.sessions.some((x) => x.id === 's1')); await E.syncNow(); assert.ok(!S.state.sessions.some((x) => x.id === 's1'));
});
await t('a second device with its own data merges both ways without loss', async () => {
  const row = [...mock.rows.values()][0], before = row.data.sessions.length;
  S.mutate((st) => { st.sessions.push(sess('late', '2026-11-06')); }); await E.syncNow(); assert.equal([...mock.rows.values()][0].data.sessions.length, before + 1);
});
await t('offline: network failure reports offline, keeps data, dirty stays true; recovers later', async () => {
  const keep = CONFIG.CLOUD.url; CONFIG.CLOUD.url = 'http://localhost:1'; S.mutate((st) => { st.sessions.push(sess('off1', '2026-11-07')); });
  const r = await E.syncNow(); assert.equal(r.state, 'offline'); assert.equal(S.isDirty(), true); assert.ok(S.state.sessions.some((x) => x.id === 'off1'));
  CONFIG.CLOUD.url = keep; await E.syncNow(); assert.equal(S.isDirty(), false); assert.ok([...mock.rows.values()][0].data.sessions.some((x) => x.id === 'off1')); E.stopSyncTimers();
});
await t('expired access token is refreshed automatically', async () => { const a = JSON.parse(globalThis.__a ?? 'null'); const rec = cloud.readAuth(); rec.exp = Date.now() - 1000; const tk = await cloud.token(); assert.ok(tk && cloud.readAuth().exp > Date.now()); });
await t('cloud backups are created by updates and can be listed and read', async () => { const l = await cloud.listBackups(); assert.ok(l.length >= 1); const b = await cloud.getBackup(l[0].id); assert.ok(Array.isArray(b.data.sessions)); });
await t('password recovery email request succeeds; recovery link hash is parsed without signing in', async () => {
  await cloud.recover('a@b.co', 'http://x/'); assert.ok(mock.log.some((l) => l === 'RECOVER a@b.co'));
  const tok = `${Buffer.from('{}').toString('base64url')}.${Buffer.from(JSON.stringify({ sub: 'u', email: 'a@b.co' })).toString('base64url')}.s`;
  const r = cloud.consumeAuthHash(`#access_token=${tok}&refresh_token=r&expires_in=3600&type=recovery`); assert.equal(r.type, 'recovery'); assert.equal(cloud.consumeAuthHash('#/settings'), null);
});
await t('a corrupt cloud document is refused and nothing local changes', async () => { const row = [...mock.rows.values()][0], keep = row.data; row.data = { nonsense: true }; const n = S.state.sessions.length; const r = await E.syncNow(); assert.equal(r.state, 'error'); assert.equal(S.state.sessions.length, n); row.data = keep; E.stopSyncTimers(); });
await t('delete account removes cloud data and signs out; local data stays', async () => { const n = S.state.sessions.length; await cloud.deleteAccount(); assert.equal(cloud.signedIn(), false); assert.equal(mock.rows.size, 0); assert.equal(S.state.sessions.length, n); });
await t('a signed-out token error is surfaced as signed_out', async () => { await assert.rejects(() => cloud.token(), (e) => e.code === 'signed_out'); });
await mock.close(); console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
