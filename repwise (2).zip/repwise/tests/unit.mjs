// Run with: node tests/unit.mjs
import assert from 'node:assert/strict';
import { recommend, e1rm, layoffAdjust } from '../js/progression.js';
import { generateProgram, estMinutes, GOALS } from '../js/generator.js';
import { BY_ID, EXERCISES, SLOTS, available } from '../js/exercises.js';
import * as A from '../js/analytics.js';
import * as G from '../js/gamify.js';
import * as SC from '../js/schedule.js';
import * as RM from '../js/reminders.js';
import * as SY from '../js/sync.js';
import * as WB from '../js/wearables.js';
import * as HR from '../js/hr.js';
import * as CL from '../js/classes.js';
import * as MB from '../js/mindbody.js';
import { fmtW, stepKg, unitToKg } from '../js/util.js';

let pass = 0, fail = 0;
const t = (name, fn) => { try { fn(); pass++; console.log('  ok  ' + name); } catch (e) { fail++; console.log('FAIL  ' + name + '\n      ' + e.message); } };

const queue = []; const ta = (name, fn) => queue.push([name, fn]);
const cfg = { step: 2.5, unit: 'kg', loaded: true, repLo: 8, repHi: 12, targetSets: 3 };
const sets = (w, ...r) => r.map((reps) => ({ w, reps }));
const rec = (s, feedback, history = [], extra = {}) => recommend({ cfg: { ...cfg, ...extra.cfg }, perf: { sets: s, feedback, ...extra.perf }, history, opts: { today: '2026-11-10', ...extra.opts } });

console.log('progression');
t('e1RM Epley', () => { assert.equal(e1rm(100, 1), 100); assert.ok(Math.abs(e1rm(100, 10) - 133.33) < 0.01); assert.equal(e1rm(100, 15), 0); assert.equal(e1rm(0, 5), 0); });
t('completing a workout alone does NOT raise weight (mid-range, just right)', () => { const r = rec(sets(40, 10, 9, 8), 'good'); assert.equal(r.action, 'increase_reps'); assert.equal(r.weight, 40); assert.equal(r.repTarget, 9); });
t('top of range on all sets + just right => +1 step', () => { const r = rec(sets(40, 12, 12, 12), 'good'); assert.equal(r.action, 'increase_weight'); assert.equal(r.weight, 42.5); assert.equal(r.repTarget, 8); });
t('top of range but hard => maintain', () => { const r = rec(sets(40, 12, 12, 12), 'hard'); assert.equal(r.action, 'maintain'); assert.equal(r.weight, 40); });
t('too hard + below range => reduce, never below one step', () => { const r = rec(sets(40, 6, 5, 4), 'too_hard'); assert.equal(r.action, 'reduce'); assert.ok(r.weight < 40 && r.weight >= 2.5); const small = rec(sets(2.5, 4, 3, 3), 'too_hard'); assert.ok(small.weight >= 2.5); });
t('missing a set => maintain weight, not increase', () => { const r = rec(sets(40, 12, 12), 'good'); assert.equal(r.action, 'maintain'); assert.equal(r.weight, 40); });
t('easy with big rep surplus can jump 2 steps, but never >10%/week', () => { const r = rec(sets(60, 14, 14, 14), 'easy'); assert.equal(r.action, 'increase_weight'); assert.equal(r.weight, 65); const capped = rec(sets(45, 12, 12, 12), 'good', [{ date: '2026-11-08', sets: sets(40, 12, 12, 12), feedback: 'good' }]); assert.equal(capped.action, 'maintain'); assert.equal(capped.weight, 45); });
t('no feedback limits to one step', () => { const r = rec(sets(60, 14, 14, 14), undefined); assert.equal(r.weight, 62.5); });
t('pain flag => adjust with substitute suggestion', () => { const r = rec(sets(40, 10, 10, 10), 'good', [], { perf: { hurt: true } }); assert.equal(r.action, 'adjust'); assert.ok(r.substitute); assert.ok(r.weight < 40); });
t('two sessions under range on same weight while hard => reduce', () => { const r = rec(sets(40, 7, 6, 6), 'hard', [{ date: '2026-11-03', sets: sets(40, 7, 6, 6), feedback: 'hard' }]); assert.equal(r.action, 'reduce'); });
t('advanced: stall detection after 3 flat sessions', () => { const h = [{ date: '2026-11-05', sets: sets(40, 10, 9, 9), feedback: 'good' }, { date: '2026-11-01', sets: sets(40, 10, 9, 9), feedback: 'good' }]; const r = rec(sets(40, 10, 9, 9), 'good', h, { opts: { advanced: true } }); assert.ok(r.stalled); const basic = rec(sets(40, 10, 9, 9), 'good', h); assert.ok(!basic.stalled); });
t('bodyweight: reps first, then harder variation', () => { const bw = { cfg: { loaded: false, step: 0 } }; assert.equal(rec(sets(0, 10, 9, 9), 'good', [], bw).action, 'increase_reps'); assert.equal(rec(sets(0, 12, 12, 12), 'good', [], bw).action, 'adjust'); });
t('plank adds 5 seconds', () => { const r = rec(sets(0, 30, 30), 'good', [], { cfg: { loaded: false, step: 0, unit: 'sec', repLo: 30, repHi: 60, targetSets: 2 } }); assert.equal(r.repTarget, 35); });
t('layoff reduces starting weight', () => { assert.equal(layoffAdjust(40, '2026-11-01', '2026-11-10', 2.5).weight, 40); assert.equal(layoffAdjust(40, '2026-10-01', '2026-11-10', 2.5).weight, 35); assert.ok(layoffAdjust(40, '2026-10-01', '2026-11-10', 2.5).note); });

console.log('units');
t('kg/lb conversion and steps', () => { assert.equal(fmtW(20, 'kg'), '20'); assert.equal(fmtW(20.4117, 'lb'), '45'); assert.ok(Math.abs(stepKg(2.5, 'lb') * 2.20462 - 5) < 0.01); assert.ok(Math.abs(unitToKg(45, 'lb') - 20.41) < 0.01); });

console.log('generator');
const prof = (o) => ({ goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], ...o });
t('every goal/focus/days/gear combo yields valid sessions', () => {
  for (const goal of Object.keys(GOALS)) for (const focus of ['balanced', 'glutes', 'upper']) for (const days of [2, 3, 4, 5]) for (const gear of ['gym', 'db', 'bw']) for (const duration of [30, 45, 60, 75]) {
    const p = generateProgram(prof({ goal, focus, days, gear, duration }));
    assert.equal(p.sessions.length, days);
    for (const s of p.sessions) { assert.ok(s.items.length >= 3, `${focus}/${days}/${gear}/${duration}: ${s.name} has ${s.items.length}`); const ids = s.items.map((i) => i.exId); assert.equal(new Set(ids).size, ids.length, 'duplicate exercise'); for (const it of s.items) { assert.ok(BY_ID[it.exId], it.exId); assert.ok(available(BY_ID[it.exId], gear), `${it.exId} not available for ${gear}`); assert.ok(it.repLo <= it.repHi && it.sets >= 1); } assert.ok(estMinutes(s.items) <= duration, `${s.name} ${estMinutes(s.items)}min > ${duration}`); }
  }
});
t('limitations exclude stressful exercises', () => { const p = generateProgram(prof({ limits: ['knees', 'shoulders'], days: 4 })); for (const s of p.sessions) for (const i of s.items) { const e = BY_ID[i.exId]; assert.ok(!e.stress.includes('knees') && !e.stress.includes('shoulders'), `${e.name} has ${e.stress}`); } });
t('regenerate varies exercises but keeps structure', () => { const a = generateProgram(prof(), { variant: 0 }), b = generateProgram(prof(), { variant: 1 }); assert.equal(a.sessions.length, b.sessions.length); assert.notDeepEqual(a.sessions.map((s) => s.items.map((i) => i.exId)), b.sessions.map((s) => s.items.map((i) => i.exId))); });
t('beginners capped at 3 sets on compounds; strength uses 4-6 reps', () => { const p = generateProgram(prof({ level: 0, goal: 'strength' })); assert.ok(p.sessions[0].items[0].sets <= 3); assert.equal(p.sessions[0].items[0].repHi, 6); });
t('slot data references real exercises', () => { for (const [slot, tiers] of Object.entries(SLOTS)) for (const ids of Object.values(tiers)) for (const id of ids) assert.ok(BY_ID[id], `${slot}:${id}`); for (const e of EXERCISES) { assert.ok(e.steps.length >= 3 && e.mistakes.length >= 2, e.id); (e.subs || []).forEach((s) => assert.ok(BY_ID[s], `${e.id} sub ${s}`)); } });

console.log('analytics');
const mk = (date, items, extra = {}) => ({ id: date + Math.random(), date, startedAt: new Date(date + 'T10:00:00').getTime(), durationSec: 3000, name: 'Test', items: items.map(([exId, s]) => ({ exId, name: BY_ID[exId].name, sets: s, targetSets: 3, repLo: 8, repHi: 12 })), ...extra });
const S = [
  mk('2026-11-02', [['bench', sets(40, 10, 10, 9)], ['squat-bb', sets(50, 8, 8, 8)]]),
  mk('2026-11-04', [['bench', sets(42.5, 8, 8, 8)]]),
  mk('2026-11-09', [['bench', sets(42.5, 10, 9, 8)], ['pushup', sets(0, 15, 12, 10)]]),
  { id: 'legacy', date: '2026-10-30', legacy: true, items: [], name: 'Old' },
];
t('volume only counts real logged sets', () => { assert.equal(A.sessionVolume(S[0]), 40 * 29 + 50 * 24); assert.equal(A.sessionVolume(S[3]), 0); assert.equal(A.totals(S).workouts, 4); });
t('PR detection: first time is a baseline, later improvements are PRs', () => { const ev = A.prEvents(S); const bench = ev.filter((e) => e.exId === 'bench'); assert.ok(bench.some((e) => e.date === '2026-11-04' && e.kind === 'weight')); assert.ok(!ev.some((e) => e.date === '2026-11-02')); });
t('records per exercise', () => { const r = A.records(S).find((x) => x.exId === 'bench'); assert.equal(r.heaviest.w, 42.5); assert.ok(r.bestE1.v > 56); });
t('muscle distribution from real sets', () => { const d = A.muscleDistribution(S); assert.ok(d.find((x) => x.muscle === 'Chest').sets >= 9); });
t('week streak counts consecutive weeks meeting target', () => { const st = A.weekStreak(S, 2, new Date(2026, 10, 10)); assert.ok(st.current >= 1); });
t('achievements unlock from data', () => { const a = A.achievements({ sessions: S, profile: { days: 2 } }, new Date(2026, 10, 10)); assert.ok(a.find((x) => x.id === 'w1').unlocked); assert.ok(!a.find((x) => x.id === 'w100').unlocked); });
t('weekly report derives from logs', () => { const r = A.weeklyReport({ sessions: S, profile: { days: 3, goal: 'muscle' } }, new Date(2026, 10, 9)); assert.equal(r.workouts, 1); assert.ok(r.volume > 0); assert.ok(r.recommendations.length > 0); });

// ---- demonstrations ----
import { VIDEOS, hasVideo } from '../js/media.js';
import { breathing, safety } from '../js/guidance.js';
t('every exercise has a demonstration video', () => { const m = EXERCISES.filter((e) => e.slot !== 'mindbody' && !e.extra && !hasVideo(e.id)).map((e) => e.id); assert.deepEqual(m, []); });
t('video ids are well formed and unique', () => { const v = Object.values(VIDEOS); assert.ok(v.every((x) => /^[\w-]{11}$/.test(x.yt) && x.t)); assert.equal(new Set(v.map((x) => x.yt)).size, v.length); });
t('no video entry for an unknown exercise', () => assert.ok(Object.keys(VIDEOS).every((id) => BY_ID[id])));
t('breathing and safety guidance exist for every exercise', () => assert.ok(EXERCISES.every((e) => breathing(e) && safety(e).length >= 2)));

// ---- insights (Phase 2) ----
import { coachInsights, recoveryReport, suggestToday, motivation, muscleRecency } from '../js/insights.js';
{
  const mk = (date, exId, w, reps, n = 3, ts) => ({ id: date + exId, date, startedAt: ts, endedAt: ts, durationSec: 1800, items: [{ exId, sets: Array.from({ length: n }, () => ({ w, reps })) }] });
  const now = new Date(2026, 10, 12, 18, 0), T = (d, h) => new Date(2026, 10, d, h).getTime();
  const prof = { days: 3, goal: 'muscle' };
  t('no data: one honest empty insight, no numbers', () => { const r = coachInsights({ sessions: [], profile: prof, settings: { units: 'kg' } }, now); assert.equal(r.length, 1); assert.equal(r[0].kind, 'start'); assert.equal(recoveryReport([], now).hasData, false); });
  t('stall: same weight twice with reps below the range suggests more reps', () => {
    const ss = [mk('2026-11-05', 'db-floor-press', 7, 8, 3, T(5, 10)), mk('2026-11-09', 'db-floor-press', 7, 9, 3, T(9, 10))];
    const r = coachInsights({ sessions: ss, profile: prof, program: { sessions: [{ items: [{ exId: 'db-floor-press', repLo: 8, repHi: 12 }] }] }, settings: { units: 'kg' } }, now);
    const i = r.find((x) => x.kind === 'stall'); assert.ok(i); assert.match(i.text, /adding reps before adding weight/); assert.match(i.title, /7/);
  });
  t('no stall insight when the weight changed or the top of the range was reached', () => {
    const a = [mk('2026-11-05', 'bench', 40, 8, 3, T(5, 10)), mk('2026-11-09', 'bench', 42.5, 8, 3, T(9, 10))];
    assert.ok(!coachInsights({ sessions: a, profile: prof, settings: {} }, now).some((x) => x.kind === 'stall'));
    const b = [mk('2026-11-05', 'bench', 40, 12, 3, T(5, 10)), mk('2026-11-09', 'bench', 40, 12, 3, T(9, 10))];
    assert.ok(!coachInsights({ sessions: b, profile: prof, settings: {} }, now).some((x) => x.kind === 'stall'));
  });
  t('pain flag outranks everything', () => {
    const ss = [mk('2026-11-09', 'bench', 40, 8, 3, T(9, 10))];
    const r = coachInsights({ sessions: ss, profile: prof, settings: {}, working: { bench: { action: 'adjust', date: '2026-11-09', w: 40 }, 'db-curl': { action: 'increase_weight', w: 10, date: '2026-11-09' } } }, now);
    assert.equal(r[0].kind, 'pain');
  });
  t('recent muscles are reported with soft wording', () => {
    const ss = [mk('2026-11-12', 'bench', 40, 8, 3, T(12, 10))]; const r = recoveryReport(ss, now);
    assert.ok(r.recent.some((x) => x.muscle === 'Chest')); assert.match(r.note, /varies/);
    assert.equal(muscleRecency(ss, now).Quads.hours, null);
  });
  t('three days in a row suggests a rest day', () => {
    const ss = [mk('2026-11-10', 'bench', 40, 8, 3, T(10, 10)), mk('2026-11-11', 'squat-bb', 40, 8, 3, T(11, 10)), mk('2026-11-12', 'rev-lunge', 0, 10, 3, T(12, 10))];
    assert.ok(recoveryReport(ss, now).restDay);
  });
  t('suggestToday keeps the plan unless it clashes with the last 48h', () => {
    const prog = { sessions: [{ name: 'Push', items: [{ exId: 'bench' }, { exId: 'pushup' }, { exId: 'db-press' }] }, { name: 'Legs', items: [{ exId: 'squat-bb' }, { exId: 'rdl-bb' }] }] };
    const fresh = [mk('2026-11-12', 'bench', 40, 8, 3, T(12, 10)), mk('2026-11-12', 'db-press', 20, 8, 3, T(12, 11))];
    const s = suggestToday(fresh, prog, 0, now); assert.equal(s.alt, true); assert.equal(s.name, 'Legs');
    assert.equal(suggestToday([], prog, 0, now).alt, false);
  });
  t('motivation uses real counts only', () => { assert.match(motivation([], prof, now), /first workout/); const ss = [mk('2026-11-09', 'bench', 40, 8, 3, T(9, 10))]; assert.match(motivation(ss, prof, now), /1 of 3/); });
}

// ---- analytics (Phase 3) ----
{
  const mk = (id, date, exId, w, reps, n = 3) => ({ id, date, durationSec: 1800, items: [{ exId, sets: Array.from({ length: n }, () => ({ w, reps })) }] });
  const S3 = [mk('a', '2026-10-05', 'bench', 40, 10), mk('b', '2026-10-12', 'squat-bb', 60, 8), mk('c', '2026-10-19', 'bench', 42.5, 10), mk('d', '2026-10-26', 'db-curl', 8, 10), mk('e', '2026-11-02', 'bench', 45, 8), { id: 'f', date: '2026-11-04', name: 'old', legacy: true, items: [] }];
  const now = new Date(2026, 10, 9);
  t('filterSessions by exercise keeps only that exercise and drops others', () => { const f = A.filterSessions(S3, { exId: 'bench' }); assert.equal(f.length, 3); assert.ok(f.every((s) => s.items.every((i) => i.exId === 'bench'))); });
  t('filterSessions by muscle includes secondary muscles; legacy sessions drop out', () => { assert.equal(A.filterSessions(S3, { muscle: 'Triceps' }).length, 3); assert.equal(A.filterSessions(S3, { muscle: 'Forearms' }).length, 1); assert.ok(!A.filterSessions(S3, { muscle: 'Chest' }).some((s) => s.legacy)); });
  t('filterSessions by date range is inclusive', () => assert.equal(A.filterSessions(S3, { from: '2026-10-12', to: '2026-10-26' }).length, 3));
  t('filtered volume equals the filtered exercise only', () => { const f = A.filterSessions(S3, { exId: 'bench' }); assert.equal(A.totals(f).volume, 40 * 10 * 3 + 42.5 * 10 * 3 + 45 * 8 * 3); });
  t('consistency counts weeks meeting the target, skipping the unfinished current week', () => { const c = A.consistency(S3, 1, new Date(2026, 9, 5), now, now); assert.equal(c.weeks, 5); assert.equal(c.met, 5); const c2 = A.consistency(S3, 2, new Date(2026, 9, 5), now, now); assert.equal(c2.met, 1); assert.equal(c2.weeks, 5); });
  t('muscleTrend compares with the previous period and reports forearms', () => { const m = A.muscleTrend(S3, 14, now), chest = m.find((x) => x.muscle === 'Chest'); assert.equal(chest.sets, 3); assert.equal(chest.prev, 3); assert.equal(chest.change, 0); assert.ok(m.some((x) => x.muscle === 'Forearms')); assert.equal(A.muscleTrend(S3, Infinity, now)[0].prev, null); });
  t('neglectedMuscles refuses to judge on thin data', () => { const r = A.neglectedMuscles(S3, now); assert.equal(r.enough, false); assert.deepEqual(r.muscles, []); });
  t('neglectedMuscles flags a muscle far below the median once there is enough data', () => { const many = Array.from({ length: 8 }, (_, i) => ({ id: 'x' + i, date: `2026-11-0${i + 1}`, items: [{ exId: i % 2 ? 'squat-bb' : 'bench', sets: [{ w: 40, reps: 8 }, { w: 40, reps: 8 }, { w: 40, reps: 8 }] }, { exId: 'lat-pulldown', sets: [{ w: 30, reps: 10 }, { w: 30, reps: 10 }] }] })); const r = A.neglectedMuscles(many, new Date(2026, 10, 9)); assert.equal(r.enough, true); assert.ok(r.muscles.includes('Calves')); assert.ok(!r.muscles.includes('Chest')); });
  t('achievements: month of consistency and strength milestones unlock with dates and tiers', () => {
    const wk = Array.from({ length: 4 }, (_, i) => mk('w' + i, `2026-10-${String(5 + i * 7).padStart(2, '0')}`, 'bench', 60, 5)); const list = A.achievements({ sessions: wk, profile: { days: 3 } }, now);
    const m1 = list.find((x) => x.id === 'm1'); assert.equal(m1.unlocked, true); assert.equal(m1.date, '2026-10-26');
    const e = list.find((x) => x.id === 'e-bench-60'); assert.equal(e.unlocked, true); assert.ok(e.date); assert.equal(list.find((x) => x.id === 'e-bench-100').unlocked, false);
    assert.equal(list.find((x) => x.id === 'e-bench-40').tier, 0); assert.equal(list.find((x) => x.id === 'e-bench-100').tier, 2);
  });
}


console.log('library, custom exercises, builder data');
const X = await import('../js/exercises.js');
globalThis.localStorage ??= { _d: {}, getItem(k) { return this._d[k] ?? null; }, setItem(k, v) { this._d[k] = String(v); }, removeItem(k) { delete this._d[k]; } };
globalThis.document ??= { addEventListener() {}, documentElement: { dataset: {} }, querySelector: () => null };
globalThis.window ??= globalThis;
const ST = await import('../js/store.js');
const names = (l) => l.map((e) => e.name);
t('search: abbreviations and muscle words', () => { assert.ok(X.searchExercises('db row').every((e) => e.equip === 'Dumbbell' || /row/i.test(e.name))); assert.ok(X.searchExercises('rdl').length > 0); assert.ok(X.searchExercises('abs').every((e) => e.pm.includes('Core') || e.sm.includes('Core') || /abs|core/i.test(e.name + e.equip))); });
t('search: name prefix outranks muscle-only match', () => { const r = X.searchExercises('squat'); assert.match(r[0].name, /squat/i); });
t('search: every word must match, junk returns nothing, empty returns all', () => { assert.equal(X.searchExercises('zzzqqq').length, 0); assert.equal(X.searchExercises('').length, X.activeExercises().length); assert.ok(X.searchExercises('barbell chest').every((e) => e.equip === 'Barbell')); });
t('location tiers map to equipment', () => { assert.equal(X.locationOf({ tier: 'bw' }), 'home'); assert.equal(X.locationOf({ tier: 'db' }), 'dumbbells'); assert.equal(X.locationOf({ tier: 'gym' }), 'gym'); });
t('ranked substitutes: explain themselves, respect gear and limits', () => { const ex = BY_ID['squat-bb'] || X.EXERCISES.find((e) => e.slot === 'squat'); const r = X.rankedSubstitutes(ex, { gear: 'bw', limits: [] }); assert.ok(r.length); assert.ok(r.every((x) => x.ex.tier === 'bw' && x.reasons.length && x.ex.id !== ex.id)); const k = X.rankedSubstitutes(ex, { gear: 'gym', limits: ['knees'] }); assert.ok(k.every((x) => !x.ex.stress.includes('knees'))); for (let i = 1; i < r.length; i++) assert.ok(r[i - 1].score >= r[i].score); });
t('ranked substitutes: exclude and avoid are honoured', () => { const ex = X.EXERCISES.find((e) => e.slot === 'squat'), first = X.rankedSubstitutes(ex)[0].ex.id; assert.ok(!X.rankedSubstitutes(ex, { exclude: [first] }).some((x) => x.ex.id === first)); assert.ok(!X.rankedSubstitutes(ex, { avoid: [first] }).some((x) => x.ex.id === first)); });
t('validateCustom rejects bad input, accepts good, blocks duplicate names', () => { assert.ok(X.validateCustom({ name: 'a' }).error); assert.ok(X.validateCustom({ name: 'Zottman curl', equip: 'Nope', pm: ['Biceps'], unit: 'kg' }).error); assert.ok(X.validateCustom({ name: 'Zottman curl', equip: 'Dumbbell', pm: [], unit: 'kg' }).error); assert.ok(X.validateCustom({ name: 'zottman  CURL', equip: 'Dumbbell', pm: ['Biceps'], unit: 'kg' }, [{ id: 'c-x', name: 'Zottman curl' }]).error); assert.ok(X.validateCustom({ name: X.EXERCISES[0].name.toUpperCase(), equip: 'Dumbbell', pm: ['Biceps'], unit: 'kg' }).error); const ok = X.validateCustom({ name: ' Zottman curl ', equip: 'Dumbbell', pm: ['Biceps'], sm: ['Biceps', 'Forearms'], unit: 'kg', steps: 'one\n\ntwo' }); assert.equal(ok.ok.name, 'Zottman curl'); assert.deepEqual(ok.ok.sm, ['Forearms']); assert.deepEqual(ok.ok.steps, ['one', 'two']); });
t('save, favourite, archive vs delete custom exercises', () => {
  const r = ST.saveCustom({ name: 'Zottman curl', equip: 'Dumbbell', pm: ['Biceps'], unit: 'kg' }); assert.ok(r.id?.startsWith('c-')); assert.equal(BY_ID[r.id].custom, true); assert.ok(X.activeExercises().some((e) => e.id === r.id));
  assert.ok(ST.saveCustom({ name: 'Zottman curl', equip: 'Dumbbell', pm: ['Biceps'], unit: 'kg' }).error);
  assert.equal(ST.saveCustom({ name: 'Zottman curl x', equip: 'Dumbbell', pm: ['Biceps'], unit: 'kg' }, r.id).id, r.id); assert.equal(BY_ID[r.id].name, 'Zottman curl x');
  ST.toggleFav(r.id); assert.ok(ST.isFav(r.id)); ST.toggleFav(r.id); assert.ok(!ST.isFav(r.id)); ST.toggleFav(r.id);
  ST.state.program = generateProgram({ goal: 'muscle', focus: 'balanced', days: 3, level: 1, gear: 'gym', duration: 60, style: 'balanced', limits: [], avoid: [], favour: [] });
  ST.state.program.sessions[0].items.push({ exId: r.id, sets: 3, repLo: 8, repHi: 12, restSec: 60 });
  ST.state.sessions.push({ id: 's1', date: '2026-01-01', name: 'x', items: [{ exId: r.id, name: 'Zottman curl x', sets: [{ w: 10, reps: 10 }] }] });
  assert.equal(ST.removeCustom(r.id), 'archived'); assert.ok(BY_ID[r.id], 'archived stays resolvable for history'); assert.ok(!X.activeExercises().some((e) => e.id === r.id)); assert.ok(!ST.state.program.sessions[0].items.some((i) => i.exId === r.id)); assert.ok(!ST.isFav(r.id));
  assert.equal(ST.state.customExercises.find((c) => c.id === r.id).archived, true);
  ST.state.sessions.pop();
  const r2 = ST.saveCustom({ name: 'Unused move', equip: 'Bodyweight', pm: ['Core'], unit: 'sec' }); assert.equal(ST.removeCustom(r2.id), 'deleted'); assert.ok(!BY_ID[r2.id]);
});
t('archived custom name can be reused; normCustom drops junk', () => { assert.ok(ST.saveCustom({ name: 'Zottman curl x', equip: 'Dumbbell', pm: ['Biceps'], unit: 'kg' }).id); const n = ST.normCustom([{ id: 'c-a', name: 'Ok name', equip: 'Cable', pm: ['Back'], unit: 'kg' }, { id: 'c-a', name: 'Dup', equip: 'Cable', pm: ['Back'], unit: 'kg' }, { id: 'zz', name: 'bad id', equip: 'Cable', pm: ['Back'], unit: 'kg' }, { id: 'c-b', name: 'x', equip: 'Cable', pm: ['Back'], unit: 'kg' }, { id: 'c-c', name: 'No muscle', equip: 'Cable', pm: ['Nope'], unit: 'kg' }, null]); assert.deepEqual(n.map((c) => c.id), ['c-a']); assert.equal(n[0].type, 'Compound'); });
t('syncCustom replaces the previous custom set', () => { X.syncCustom([]); assert.ok(!X.EXERCISES.some((e) => e.custom)); X.syncCustom([{ id: 'c-q', name: 'Q', equip: 'Machine', type: 'Isolation', diff: 'Beginner', pm: ['Chest'], sm: [], unit: 'kg', steps: [] }]); assert.ok(BY_ID['c-q']); X.syncCustom([]); assert.ok(!BY_ID['c-q']); });
t('recentExercises: newest first, one row per exercise', () => { const id = X.EXERCISES[0].id, id2 = X.EXERCISES[1].id; const ss = [{ id: 'a', date: '2026-01-01', items: [{ exId: id, sets: [{ w: 1, reps: 1 }] }] }, { id: 'b', date: '2026-02-01', items: [{ exId: id2, sets: [{ w: 1, reps: 1 }] }, { exId: id, sets: [{ w: 1, reps: 1 }] }] }, { id: 'c', date: '2026-03-01', items: [{ exId: 'gone', sets: [{ w: 1, reps: 1 }] }] }]; const r = A.recentExercises(ss); assert.equal(r.length, 2); assert.ok(r.every((x) => x.date === '2026-02-01')); assert.deepEqual(A.recentExercises(ss, 1).length, 1); });


console.log('animations');
const AN = await import('../js/anim.js'), AD = await import('../js/anim-data.js');
t('every library exercise has an animation, and none are orphaned', () => { X.EXERCISES.filter((e) => !e.custom && e.slot !== 'mindbody' && !e.extra).forEach((e) => assert.ok(AD.ANIMS[e.id], 'missing ' + e.id)); Object.keys(AD.ANIMS).forEach((id) => assert.ok(BY_ID[id], 'orphan ' + id)); });
t('poses solve to finite numbers across the whole loop; limb lengths stay constant', () => {
  Object.keys(AD.ANIMS).forEach((id) => {
    const a = AD.ANIMS[id], total = a.seq.reduce((s, x) => s + x[1] + (x[3] || 0), 0);
    for (let k = 0; k <= 40; k++) {
      const fr = AN.frameAt(id, (k / 40) * total * 0.999), j = AN.solve(fr.pose), d = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1]);
      [j.H, j.S, j.head, j.near.knee, j.near.ankle, j.near.toe, j.far.knee, j.nArm.elbow, j.nArm.wrist, j.fArm.wrist].forEach((p) => p.forEach((v) => assert.ok(Number.isFinite(v), id + ' not finite')));
      assert.ok(Math.abs(d(j.H, j.near.knee) - 27) < 0.2 && Math.abs(d(j.near.knee, j.near.ankle) - 27) < 0.2, id + ' leg length');
      assert.ok(Math.abs(d(j.S, j.nArm.elbow) - 21) < 0.2 && Math.abs(d(j.nArm.elbow, j.nArm.wrist) - 19) < 0.2, id + ' arm length');
    }
  });
});
t('nothing sinks through the floor', () => {
  Object.keys(AD.ANIMS).forEach((id) => AN.poses(id).forEach((p, i) => { const j = AN.solve(p); [j.near.toe, j.near.ankle, j.far.toe, j.far.ankle, j.H, j.nArm.wrist, j.nArm.elbow, j.near.knee, j.far.knee].forEach((q) => assert.ok(q[1] > -3, `${id} kf${i} below floor: ${q[1].toFixed(1)}`)); }));
});
t('loops have cues, positive durations and valid keyframe indexes', () => { Object.entries(AD.ANIMS).forEach(([id, a]) => { assert.ok(a.seq.length >= 2, id); a.seq.forEach(([to, dur, cue]) => { assert.ok(a.kf[to], id + ' index'); assert.ok(dur > 0 && cue, id + ' step'); }); }); });
t('frameAt counts completed loops', () => { const a = AD.ANIMS['squat-bb'], total = a.seq.reduce((s, x) => s + x[1] + (x[3] || 0), 0); assert.equal(AN.frameAt('squat-bb', 0.1).loops, 0); assert.equal(AN.frameAt('squat-bb', total + 0.1).loops, 1); assert.equal(AN.frameAt('squat-bb', total * 5 + 0.1).loops, 5); });
t('viewBox is 4:3 and finite for every exercise', () => { Object.keys(AD.ANIMS).forEach((id) => { const v = AN.viewBox(id); v.forEach((n) => assert.ok(Number.isFinite(n))); assert.ok(Math.abs(v[2] / v[3] - 4 / 3) < 0.02, id); }); });


console.log('nutrition, hydration, monthly report');
const NU = await import('../js/nutrition.js');
t('validateMeal: needs a name and some numbers; kcal is derived from macros when blank', () => { assert.ok(NU.validateMeal({ name: '', kcal: 100 }).error); assert.ok(NU.validateMeal({ name: 'x' }).error); assert.ok(NU.validateMeal({ name: 'x', kcal: -5 }).error); assert.ok(NU.validateMeal({ name: 'x', kcal: 100, p: 'abc' }).error); const m = NU.validateMeal({ name: ' Oats  and milk ', p: 20, c: 60, f: 10 }).ok; assert.equal(m.kcal, 410); assert.equal(m.name, 'Oats and milk'); assert.equal(m.meal, 'snack'); assert.equal(NU.validateMeal({ name: 'x', kcal: 250, meal: 'lunch' }).ok.meal, 'lunch'); assert.equal(NU.validateMeal({ name: 'x', kcal: 250, meal: 'bogus' }).ok.meal, 'snack'); });
t('dayTotals and dayProgress', () => { const tot = NU.dayTotals([{ kcal: 400, p: 30, c: 40, f: 10 }, { kcal: 600.5, p: 20.5, c: 80, f: 20 }]); assert.deepEqual([tot.kcal, tot.p, tot.f, tot.count], [1000.5, 50.5, 30, 2]); const pr = NU.dayProgress({ kcal: 1500, p: 100, c: 0, f: 0 }, { kcal: 2000, protein: 160 }); assert.equal(pr.kcal.left, 500); assert.equal(pr.protein.pct, 0.625); assert.equal(pr.carbs.target, null); assert.equal(NU.dayProgress({ kcal: 2300, p: 0, c: 0, f: 0 }, { kcal: 2000 }).kcal.left, -300); });
t('estimateTargets: standard formula, goal changes calories, bad input is refused', () => { const m = NU.estimateTargets({ sex: 'male', age: 30, heightCm: 180, weightKg: 80, activity: 'moderate', goal: 'muscle' }); assert.equal(m.bmr, 1780); assert.equal(m.tdee, Math.round(1780 * 1.55)); assert.equal(m.kcal, Math.round(1780 * 1.55 * 1.1 / 10) * 10); assert.equal(m.protein, 144); const cut = NU.estimateTargets({ sex: 'male', age: 30, heightCm: 180, weightKg: 80, activity: 'moderate', goal: 'fat' }); assert.ok(cut.kcal < m.tdee && cut.protein === 160); assert.ok(Math.abs(m.protein * 4 + m.carbs * 4 + m.fat * 9 - m.kcal) <= 8); assert.equal(NU.estimateTargets({ age: 0, heightCm: 180, weightKg: 80 }), null); const f = NU.estimateTargets({ sex: 'female', age: 30, heightCm: 165, weightKg: 60, activity: 'light', goal: 'fat' }); assert.ok(f.kcal >= 1200); });
t('hydrationTarget: 33 ml/kg, +500 on training days, null without a weight', () => { assert.equal(NU.hydrationTarget(80), 2650); assert.equal(NU.hydrationTarget(80, true), 3150); assert.equal(NU.hydrationTarget(null), null); assert.equal(NU.hydrationTarget(0), null); });
t('normNutrition / normWater drop malformed data and keep good data', () => {
  const n = NU.normNutrition({ targets: { kcal: '2200', protein: 'x', carbs: 99999, fat: 70 }, log: { '2026-01-01': [{ id: 'a', name: 'Eggs', kcal: 300, p: 20, c: 2, f: 20, meal: 'breakfast' }, { name: '', kcal: 5 }, null], 'bad': [{ name: 'x', kcal: 1 }] }, saved: [{ name: 'Shake', kcal: 200, p: 30 }, { kcal: 1 }], calc: { sex: 'zzz', age: 30, heightCm: 180, activity: 'nope' } });
  assert.deepEqual(n.targets, { kcal: 2200, protein: null, carbs: null, fat: 70 }); assert.deepEqual(Object.keys(n.log), ['2026-01-01']); assert.equal(n.log['2026-01-01'].length, 1); assert.equal(n.saved.length, 1); assert.equal(n.calc.sex, 'avg'); assert.equal(n.calc.activity, 'light');
  assert.deepEqual(NU.normNutrition(null).targets, { kcal: null, protein: null, carbs: null, fat: null }); assert.deepEqual(NU.normNutrition('junk').log, {});
  const w = NU.normWater({ targetMl: 100, bottleMl: 'x', log: { '2026-01-01': [{ ml: 250 }, { ml: -5 }, { ml: 99999 }], 'x': [{ ml: 1 }] } }); assert.equal(w.targetMl, null); assert.equal(w.bottleMl, 500); assert.equal(w.log['2026-01-01'].length, 1); assert.equal(NU.normWater(undefined).bottleMl, 500);
});
t('store actions: add, edit, remove, copy, templates, water with undo', () => {
  ST.mutate((s) => { s.nutrition = NU.normNutrition(null); s.water = NU.normWater(null); });
  assert.ok(ST.addMeal('2026-03-02', { name: '', kcal: 5 }).error);
  const a = ST.addMeal('2026-03-02', { name: 'Chicken rice', kcal: 650, p: 45, c: 70, f: 12, meal: 'lunch' }); assert.ok(a.id); assert.equal(ST.state.nutrition.log['2026-03-02'].length, 1);
  assert.ok(ST.updateMeal('2026-03-02', a.id, { name: 'Chicken rice', kcal: 700, p: 45, c: 70, f: 12, meal: 'lunch' }).id); assert.equal(ST.state.nutrition.log['2026-03-02'][0].kcal, 700); assert.ok(ST.updateMeal('2026-03-02', 'nope', { name: 'x', kcal: 5 }).error);
  assert.equal(ST.copyDay('2026-03-02', '2026-03-03'), 1); assert.notEqual(ST.state.nutrition.log['2026-03-03'][0].id, a.id); assert.equal(ST.copyDay('2026-03-09', '2026-03-10'), 0);
  ST.removeMeal('2026-03-03', ST.state.nutrition.log['2026-03-03'][0].id); assert.ok(!ST.state.nutrition.log['2026-03-03'], 'empty days are removed');
  assert.ok(ST.saveMealTemplate({ name: 'Shake', kcal: 200, p: 30 }).ok); ST.saveMealTemplate({ name: 'shake', kcal: 220, p: 32 }); assert.equal(ST.state.nutrition.saved.length, 1); assert.equal(ST.state.nutrition.saved[0].kcal, 220); ST.removeMealTemplate(ST.state.nutrition.saved[0].id); assert.equal(ST.state.nutrition.saved.length, 0);
  ST.setNutritionTargets({ kcal: 2400, protein: 160, carbs: '', fat: 70 }, { sex: 'male', age: 30, heightCm: 180, activity: 'moderate' }); assert.equal(ST.state.nutrition.targets.kcal, 2400); assert.equal(ST.state.nutrition.targets.carbs, null); assert.equal(ST.state.nutrition.calc.age, 30);
  assert.ok(ST.addWater('2026-03-02', 5).error); assert.ok(ST.addWater('2026-03-02', 'x').error); ST.addWater('2026-03-02', 250); ST.addWater('2026-03-02', 500); assert.equal(NU.waterDay(ST.state.water, '2026-03-02'), 750); ST.undoWater('2026-03-02'); assert.equal(NU.waterDay(ST.state.water, '2026-03-02'), 250); ST.undoWater('2026-03-02'); assert.ok(!ST.state.water.log['2026-03-02']); ST.undoWater('2026-03-02');
  ST.setWaterSettings({ targetMl: 2800, bottleMl: 750 }); assert.equal(ST.state.water.targetMl, 2800); assert.equal(ST.state.water.bottleMl, 750); ST.setWaterSettings({ targetMl: null }); assert.equal(ST.state.water.targetMl, null); assert.equal(NU.waterTarget(ST.state.water, 70), 2300); assert.equal(NU.waterTarget({ ...ST.state.water, targetMl: 3000 }, 70), 3000);
});
t('history and summaries only count days with entries', () => {
  const n = NU.normNutrition({ targets: { kcal: 2000, protein: 100 }, log: { '2026-03-01': [{ name: 'a', kcal: 2000, p: 100 }], '2026-03-03': [{ name: 'b', kcal: 1000, p: 40 }] } }), w = NU.normWater({ log: { '2026-03-01': [{ ml: 2000 }], '2026-03-02': [{ ml: 1000 }] } });
  const h = NU.nutritionHistory(n, '2026-03-03', 3); assert.deepEqual(h.map((x) => x.logged), [true, false, true]); assert.equal(NU.waterHistory(w, '2026-03-03', 3)[1].ml, 1000);
  const s = NU.nutritionSummary(n, w, '2026-03-01', '2026-03-07', { weightKg: 60 }); assert.equal(s.loggedDays, 2); assert.equal(s.avgKcal, 1500); assert.equal(s.kcalDaysOnTarget, 1); assert.equal(s.proteinDaysOnTarget, 1); assert.equal(s.avgWaterMl, 1500); assert.equal(s.waterDaysOnTarget, 1); assert.ok(!NU.nutritionSummary(NU.normNutrition(null), NU.normWater(null), '2026-03-01', '2026-03-07').hasData);
});
t('exports keep nutrition and water; old exports without them still import', () => { ST.addWater('2026-03-05', 300); const j = JSON.parse(JSON.stringify(ST.state)); assert.equal(j.water.log['2026-03-05'][0].ml, 300); const old = { ...j }; delete old.nutrition; delete old.water; ST.importJSON(JSON.stringify(old)); assert.deepEqual(ST.state.water.log, {}); assert.equal(ST.state.water.bottleMl, 500); });
const MR = (ss, now) => A.monthlyReport({ sessions: ss, profile: { days: 3 }, working: {} }, now);
t('monthlyReport: totals, time, partial month, previous-month comparison', () => {
  const ex = X.EXERCISES.find((e) => e.unit === 'kg'), mk = (date, w, reps, dur = 3000) => ({ id: date, date, name: 'x', durationSec: dur, items: [{ exId: ex.id, name: ex.name, sets: [{ w, reps, done: true }, { w, reps, done: true }] }] });
  const ss = [mk('2026-01-20', 50, 8), mk('2026-02-03', 50, 8), mk('2026-02-10', 52.5, 8), mk('2026-02-17', 55, 8, 2400), mk('2026-02-24', 57.5, 8)];
  const r = MR(ss, new Date(2026, 1, 15)); assert.equal(r.label, 'February 2026'); assert.equal(r.workouts, 4); assert.equal(r.seconds, 3000 * 3 + 2400); assert.equal(r.prevVolume, 800); assert.equal(r.volume, 4 * 0 + (50 * 8 * 2) + (52.5 * 8 * 2) + (55 * 8 * 2) + (57.5 * 8 * 2)); assert.ok(r.volumeChangePct > 100); assert.equal(r.improved.length, 1); assert.equal(r.improved[0].kind, 'e1rm'); assert.ok(r.prs.length >= 1); assert.equal(r.sessionDates.length, 4);
  const e = MR([], new Date(2026, 1, 15)); assert.equal(e.hasData, false); assert.equal(e.workouts, 0); assert.ok(e.areas[0].includes('No workouts')); assert.ok(e.recommendations.length);
});
t('monthlyReport: missed weeks use only full weeks, planned sessions scale to the month', () => {
  const mk = (date) => ({ id: date, date, name: 'x', durationSec: 1800, items: [{ exId: X.EXERCISES[0].id, name: 'x', sets: [{ w: 20, reps: 10, done: true }] }] });
  const ss = ['2026-02-02', '2026-02-04', '2026-02-06', '2026-02-09', '2026-02-16', '2026-02-17', '2026-02-18'].map(mk), r = MR(ss, new Date(2026, 1, 1));
  assert.equal(r.planned, Math.round(3 * 28 / 7)); assert.equal(r.weeks.length, 3, 'only Mon-Sun weeks fully inside the month'); assert.equal(r.weeksHit, 2); assert.equal(r.weeksMissed, 1); assert.ok(r.areas.some((a) => /1 of 3 full weeks were below/.test(a))); assert.ok(r.consistency < 1 && r.consistency > 0.5);
});

console.log('phase 6: gamification, schedule, reminders');
const gs = (date, n = 3, exId = X.EXERCISES[0].id, w = 20) => ({ id: date + exId, date, durationSec: 1800, items: [{ exId, name: 'x', sets: Array.from({ length: n }, () => ({ w, reps: 10, done: true })) }] });
const gst = (ss, extra = {}) => ({ sessions: ss, profile: { days: 3, createdAt: '2026-11-01' }, reminders: {}, ...extra });
const NOW = new Date(2026, 10, 14, 12);
t('level curve: 100/300/600 XP boundaries and titles', () => { assert.equal(G.levelOf(0), 1); assert.equal(G.levelOf(99), 1); assert.equal(G.levelOf(100), 2); assert.equal(G.levelOf(299), 2); assert.equal(G.levelOf(300), 3); assert.equal(G.xpForLevel(4), 600); assert.equal(G.levelOf(-5), 1); assert.equal(G.titleOf(1), 'Starter'); assert.equal(G.titleOf(99), 'Legend'); });
t('XP: no history is zero; one workout = 40 + sets, same day twice counts once', () => {
  assert.equal(G.xpSummary(gst([]), NOW).total, 0);
  const one = G.xpSummary(gst([gs('2026-11-10', 3)]), NOW).parts; assert.equal(one.workouts, 40); assert.equal(one.sets, 3);
  const two = G.xpSummary(gst([gs('2026-11-10', 3), { ...gs('2026-11-10', 3), id: 'b' }]), NOW); assert.equal(two.parts.workouts, 40); assert.equal(two.ignored, 1);
});
t('XP: set bonus is capped, and workouts beyond target+1 per week earn nothing', () => {
  assert.equal(G.xpSummary(gst([gs('2026-11-10', 60)]), NOW).parts.sets, 20);
  const wk = ['2026-11-09', '2026-11-10', '2026-11-11', '2026-11-12', '2026-11-13', '2026-11-14'].map((d) => gs(d, 2));
  const r = G.xpSummary(gst(wk), NOW); assert.equal(r.parts.workouts, 40 * 4); assert.equal(r.ignored, 2);
});
t('XP: PR bonus is capped per day; levelling is monotonic', () => { const a = G.xpSummary(gst([gs('2026-11-09', 3)]), NOW).total, b = G.xpSummary(gst([gs('2026-11-09', 3), gs('2026-11-11', 3, undefined, 30)]), NOW).total; assert.ok(b > a); });
t('weekly challenges: progress, completion, optional water challenge only after logging water', () => {
  const ws = new Date(2026, 10, 9), st = gst([gs('2026-11-09', 4), gs('2026-11-11', 4)]), c = G.weeklyChallenges(st, ws, NOW);
  assert.equal(c.length, 3); const tg = c.find((x) => x.id.endsWith(':target')); assert.equal(tg.value, 2); assert.equal(tg.target, 3); assert.equal(tg.done, false); assert.equal(tg.final, false);
  const done = G.weeklyChallenges(gst([gs('2026-11-09'), gs('2026-11-11'), gs('2026-11-13')]), ws, NOW).find((x) => x.id.endsWith(':target')); assert.ok(done.done);
  const w = G.weeklyChallenges({ ...st, water: { log: { '2026-11-09': [{ ml: 500 }] } } }, ws, NOW); assert.equal(w.length, 4);
});
t('monthly challenges: weeks hit counts only full weeks and a "new exercise" needs earlier history', () => {
  const ms = new Date(2026, 10, 1), ids = X.EXERCISES.slice(0, 4).map((e) => e.id);
  const st = gst([gs('2026-10-05', 3, ids[0]), gs('2026-11-03', 3, ids[0]), gs('2026-11-05', 3, ids[1]), gs('2026-11-06', 3, ids[2])]);
  const c = G.monthlyChallenges(st, ms, NOW), nw = c.find((x) => x.id.endsWith(':new')); assert.equal(nw.value, 2); assert.ok(nw.done); assert.equal(c.find((x) => x.id.endsWith(':weeks')).value, 1);
  assert.equal(G.monthlyChallenges(gst([gs('2026-11-03', 3, ids[0])]), ms, NOW).find((x) => x.id.endsWith(':new')).value, 0, 'first-ever workout is not "new"');
});
t('xpDelta reports gain, level-up and newly completed challenges', () => {
  const before = gst([gs('2026-11-09'), gs('2026-11-11')]), after = gst([gs('2026-11-09'), gs('2026-11-11'), gs('2026-11-13')]), d = G.xpDelta(before, after, NOW);
  assert.ok(d.gained >= 100); assert.ok(d.completed.some((c) => c.id.endsWith(':target')));
});
t('schedule: default plan days follow the weekly target; custom days win', () => { assert.deepEqual(SC.plannedDays({ profile: { days: 4 } }), [0, 1, 3, 4]); assert.deepEqual(SC.plannedDays({ profile: { days: 3 }, reminders: { days: [6, 2, 2, 9] } }), [2, 6]); assert.deepEqual(SC.normPlanDays('x'), null); });
t('schedule: day statuses (done / missed / madeup / upcoming / rest / before)', () => {
  const st = gst([gs('2026-11-09'), gs('2026-11-10')]), m = SC.dayStatuses(st, '2026-10-26', '2026-11-15', NOW);
  assert.equal(m.get('2026-10-26').status, 'before'); assert.equal(m.get('2026-11-09').status, 'done'); assert.equal(m.get('2026-11-10').status, 'done');
  assert.equal(m.get('2026-11-11').status, 'madeup', 'Tuesday extra covers skipped Wednesday'); assert.equal(m.get('2026-11-13').status, 'missed'); assert.equal(m.get('2026-11-12').status, 'rest'); assert.equal(m.get('2026-11-15').status, 'rest');
  const f = SC.dayStatuses(gst([]), '2026-11-16', '2026-11-22', NOW); assert.equal(f.get('2026-11-16').status, 'upcoming'); assert.equal(f.get('2026-11-17').status, 'rest');
  assert.equal(SC.dayStatuses(gst([]), '2026-11-14', '2026-11-14', NOW).get('2026-11-14').status, 'rest');
});
t('schedule: today is flagged when planned and untrained', () => { const t0 = SC.dayStatuses(gst([], { reminders: { days: [5] } }), '2026-11-14', '2026-11-14', NOW).get('2026-11-14'); assert.equal(t0.status, 'today'); });
t('schedule: month grid is Monday-first, 7 columns, with weekly counts', () => {
  const g = SC.monthGrid(gst([gs('2026-11-09'), gs('2026-11-11'), gs('2026-11-13')]), 2026, 10, NOW); assert.ok(g.weeks.every((w) => w.cells.length === 7)); assert.equal(g.weeks[0].cells[0].date, '2026-10-26'); assert.equal(g.weeks[0].cells[0].inMonth, false);
  const w2 = g.weeks.find((w) => w.start === '2026-11-09'); assert.equal(w2.done, 3); assert.ok(w2.hit); assert.equal(g.totals.done, 3); assert.equal(g.totals.weeksHit, 1);
});
t('schedule: nextPlanned skips days already trained', () => { const n = SC.nextPlanned(gst([gs('2026-11-16')]), new Date(2026, 10, 16, 9)); assert.equal(n.date, '2026-11-18'); });
t('reminders: normaliser rejects junk and keeps good values', () => {
  const n = RM.normReminders({ enabled: 'yes', time: '25:00', days: [1, 'x', 9], summaryDay: 8, upcoming: true, time2: 1 }); assert.equal(n.enabled, false); assert.equal(n.time, '18:00'); assert.deepEqual(n.days, [1]); assert.equal(n.summaryDay, 6); assert.equal(n.upcoming, true);
  assert.deepEqual(RM.normReminders(null), RM.DEFAULT_REMINDERS); assert.equal(RM.normReminders({ time: '07:30' }).time, '07:30');
  assert.equal(RM.normInbox([{ id: 'a', title: 'x', t: 1 }, null, { title: 'no id' }]).length, 1);
});
t('reminders: only on planned days, after the time, once, and never after you trained', () => {
  const st = gst([], { reminders: { enabled: true, time: '18:00' } });
  assert.equal(RM.dueReminders(st, new Date(2026, 10, 13, 17, 59)).length, 0, 'not yet');
  const d = RM.dueReminders(st, new Date(2026, 10, 13, 18, 5)); assert.equal(d.length, 1); assert.equal(d[0].key, 'w:2026-11-13');
  assert.equal(RM.dueReminders(st, new Date(2026, 10, 13, 18, 5), ['w:2026-11-13']).length, 0, 'already delivered');
  assert.equal(RM.dueReminders(st, new Date(2026, 10, 12, 19, 0)).length, 0, 'Thursday is a rest day');
  assert.equal(RM.dueReminders({ ...st, sessions: [gs('2026-11-13')] }, new Date(2026, 10, 13, 18, 5)).length, 0, 'already trained');
  assert.equal(RM.dueReminders(st, new Date(2026, 10, 14, 5, 0)).length, 1, 'still useful until 12 h late');
  assert.equal(RM.dueReminders({ ...st, reminders: { enabled: false } }, new Date(2026, 10, 13, 18, 5)).length, 0, 'disabled');
});
t('reminders: day-before heads-up and weekly summary respect their own switches', () => {
  const st = gst([], { reminders: { enabled: true, upcoming: true, summary: true, summaryDay: 6 } });
  assert.ok(RM.dueReminders(st, new Date(2026, 10, 12, 19, 30)).some((x) => x.kind === 'upcoming' && x.key === 'u:2026-11-13'));
  assert.ok(RM.dueReminders(st, new Date(2026, 10, 15, 18, 30)).some((x) => x.kind === 'summary'));
  assert.ok(!RM.dueReminders({ ...st, reminders: { ...st.reminders, summary: false } }, new Date(2026, 10, 15, 18, 30)).some((x) => x.kind === 'summary'));
});
t('reminders: .ics is valid, folded, with an alarm per planned day', () => {
  const ics = RM.buildICS(gst([], { reminders: { enabled: true, time: '07:30' } }), NOW), lines = ics.split('\r\n');
  assert.equal(lines[0], 'BEGIN:VCALENDAR'); assert.equal(ics.match(/BEGIN:VEVENT/g).length, 4); assert.equal(ics.match(/BEGIN:VALARM/g).length, 4); assert.ok(ics.includes('BYDAY=MO') && ics.includes('BYDAY=WE') && ics.includes('BYDAY=FR') && ics.includes('BYDAY=SU'));
  assert.ok(ics.includes('T073000')); assert.ok(lines.every((l) => l.length <= 75)); assert.ok(ics.endsWith('END:VCALENDAR\r\n'));
});

console.log('phase 7: sync merge');
const sdev = (o = {}) => ({ sessions: [], customExercises: [], programs: [], body: { entries: [] }, nutrition: { targets: { kcal: null }, calc: null, saved: [], log: {} }, water: { targetMl: null, bottleMl: 500, log: {} }, activities: [], profile: { days: 3 }, program: { id: 'p', sessions: [] }, cursor: 0, working: {}, settings: { units: 'kg', sound: true, vibrate: true, wakeLock: true, notify: false }, reminders: { enabled: false }, favs: [], sync: { stamps: {}, tomb: {} }, ...o });
const ss1 = (id, date) => ({ id, date, items: [] });
t('extract/inject round-trip keeps synced data and leaves local-only fields alone', () => {
  const st = sdev({ sessions: [ss1('a', '2026-01-01')], active: { id: 'live' }, plan: 'pro' }), d = SY.extract(st), t2 = sdev({ active: { id: 'mine' }, plan: 'free' }); SY.inject(t2, d);
  assert.equal(t2.sessions.length, 1); assert.equal(t2.active.id, 'mine'); assert.equal(t2.plan, 'free'); assert.equal(d.sessions[0] === st.sessions[0], false, 'deep copy');
});
t('merge: two devices that each added workouts end with both (nothing lost)', () => {
  const a = SY.extract(sdev({ sessions: [ss1('a', '2026-01-01'), ss1('c', '2026-01-03')] })), b = SY.extract(sdev({ sessions: [ss1('a', '2026-01-01'), ss1('b', '2026-01-02')] }));
  const m = SY.merge(a, b); assert.deepEqual(m.sessions.map((x) => x.id).sort(), ['a', 'b', 'c']); assert.deepEqual(SY.merge(b, a).sessions.map((x) => x.id).sort(), ['a', 'b', 'c'], 'order does not matter');
});
t('merge: a deletion on one device is not undone by the other, and tombstones win', () => {
  const st = sdev({ sessions: [ss1('a', '2026-01-01'), ss1('b', '2026-01-02')], nutrition: { saved: [], log: { '2026-01-01': [{ id: 'm1' }, { id: 'm2' }] } } }), prev = SY.idKeys(st);
  const after = sdev({ sessions: [ss1('b', '2026-01-02')], nutrition: { saved: [], log: { '2026-01-01': [{ id: 'm2' }] } } }); after.sync = { stamps: {}, tomb: {} }; const n = SY.recordDeletions(prev, after, 1000); assert.equal(n, 2); assert.ok(after.sync.tomb['s:a'] && after.sync.tomb['m:m1']);
  const m = SY.merge(SY.extract(after), SY.extract(st)); assert.deepEqual(m.sessions.map((x) => x.id), ['b']); assert.deepEqual(m.meals['2026-01-01'].map((x) => x.id), ['m2']);
});
t('merge: tombstone is lifted if the id comes back; old tombstones are pruned', () => { const st = sdev({ sessions: [ss1('a', '2026-01-01')] }); st.sync.tomb['s:a'] = 5; SY.recordDeletions(new Set(), st, 10); assert.equal(st.sync.tomb['s:a'], undefined); const tomb = { x: 1, y: Date.now() }; SY.pruneTomb(tomb); assert.ok(!tomb.x && tomb.y); });
t('merge: single-value sections take the most recently changed copy', () => {
  const a = SY.extract(sdev({ profile: { days: 4 }, sync: { stamps: { profile: 200 }, tomb: {} } })), b = SY.extract(sdev({ profile: { days: 2 }, sync: { stamps: { profile: 100 }, tomb: {} } }));
  assert.equal(SY.merge(a, b).sections.profile.days, 4); assert.equal(SY.merge(b, a).sections.profile.days, 4); assert.equal(SY.merge(a, b).stamps.profile, 200);
});
t('merge: same id on both sides, preferLocal decides; nested meals and water merge per day', () => {
  const a = SY.extract(sdev({ sessions: [{ id: 'a', date: 'L', items: [] }], water: { log: { d1: [{ id: 'w1', ml: 250 }] }, targetMl: null, bottleMl: 500 } })), b = SY.extract(sdev({ sessions: [{ id: 'a', date: 'R', items: [] }], water: { log: { d1: [{ id: 'w2', ml: 500 }], d2: [{ id: 'w3', ml: 1 }] }, targetMl: null, bottleMl: 500 } }));
  assert.equal(SY.merge(a, b, { preferLocal: true }).sessions[0].date, 'L'); assert.equal(SY.merge(a, b, { preferLocal: false }).sessions[0].date, 'R');
  const m = SY.merge(a, b); assert.equal(m.water.d1.length, 2); assert.equal(m.water.d2.length, 1);
});
t('merge: empty remote or local returns the other; sameData ignores order', () => { const a = SY.extract(sdev({ sessions: [ss1('a', 'x'), ss1('b', 'y')] })), b = SY.extract(sdev({ sessions: [ss1('b', 'y'), ss1('a', 'x')] })); assert.ok(SY.sameData(a, b)); assert.deepEqual(SY.merge(a, null).sessions.length, 2); assert.equal(SY.merge(null, a).sessions.length, 2); assert.ok(!SY.hasUserData(SY.extract(sdev()))); assert.ok(SY.hasUserData(a)); });
t('stampSections only stamps sections that changed', () => { const st = sdev(), prev = SY.stampSections(st, null); st.profile = { days: 5 }; SY.stampSections(st, prev, 777); assert.equal(st.sync.stamps.profile, 777); assert.equal(st.sync.stamps.favs, undefined); });

console.log('phase 7: wearables');
const AH = `<?xml version="1.0"?><HealthData locale="en_GB">
 <Record type="HKQuantityTypeIdentifierStepCount" value="10" startDate="2026-03-01 08:00:00 +0100"/>
 <Record type="HKQuantityTypeIdentifierBodyMass" sourceName="Scale" unit="lb" value="176.4" startDate="2026-03-01 07:30:00 +0100"/>
 <Record type="HKQuantityTypeIdentifierBodyMass" unit="kg" value="79.9" startDate="2026-03-01 21:30:00 +0100"/>
 <Record type="HKQuantityTypeIdentifierBodyMass" unit="kg" value="5" startDate="2026-03-02 07:30:00 +0100"/>
 <Record type="HKQuantityTypeIdentifierRestingHeartRate" unit="count/min" value="58" startDate="2026-03-01 06:00:00 +0100"/>
 <Workout workoutActivityType="HKWorkoutActivityTypeTraditionalStrengthTraining" duration="52.5" durationUnit="min" totalEnergyBurned="310" totalEnergyBurnedUnit="kcal" sourceName="Apple Watch" startDate="2026-03-01 18:00:00 +0100" endDate="2026-03-01 18:52:30 +0100">
  <WorkoutStatistics type="HKQuantityTypeIdentifierHeartRate" average="121.4" minimum="80" maximum="162" unit="count/min"/>
 </Workout>
 <Workout workoutActivityType="HKWorkoutActivityTypeRunning" duration="1800" durationUnit="s" totalDistance="5.2" totalDistanceUnit="km" startDate="2026-03-02 07:00:00 +0100" endDate="2026-03-02 07:30:00 +0100"/>
 <Workout workoutActivityType="HKWorkoutActivityTypeWalking" duration="20" durationUnit="s" startDate="2026-03-03 07:00:00 +0100"/>
</HealthData>`;
t('Apple Health: workouts, heart rate, weights and resting HR are read; junk is ignored', () => {
  const r = WB.parseAppleHealthXML(AH); assert.equal(r.activities.length, 2, 'the 20 second workout is dropped');
  const s = r.activities.find((a) => a.label === 'Strength'); assert.equal(s.durationSec, 3150); assert.equal(s.kcal, 310); assert.equal(s.avgHr, 121); assert.equal(s.maxHr, 162); assert.equal(s.date, '2026-03-01'); assert.equal(s.source, 'apple');
  const run = r.activities.find((a) => a.label === 'Run'); assert.equal(run.distanceM, 5200); assert.equal(run.durationSec, 1800);
  assert.equal(r.weights.length, 2, 'implausible 5 kg dropped'); assert.equal(r.weights[0].kg, 80); assert.equal(WB.dailyWeights(r.weights).length, 1); assert.equal(WB.dailyWeights(r.weights)[0].kg, 79.9, 'latest of the day wins'); assert.equal(r.restingHr[0].bpm, 58);
});
t('Apple Health: parsing in tiny chunks gives the same result (stream boundaries)', () => { const p = WB.appleHealthParser(); for (let i = 0; i < AH.length; i += 7) p.push(AH.slice(i, i + 7)); const r = p.end(); assert.equal(r.activities.length, 2); assert.equal(r.weights.length, 2); assert.equal(r.activities.find((a) => a.label === 'Strength').avgHr, 121); });
t('imported ids are stable so re-importing the same file adds nothing', () => { const a = WB.parseAppleHealthXML(AH).activities.map((x) => x.id), b = WB.parseAppleHealthXML(AH).activities.map((x) => x.id); assert.deepEqual(a, b); assert.equal(new Set(a).size, a.length); });
t('date parsing keeps the local calendar day as written', () => { assert.equal(WB.parseHealthDate('2026-03-01 23:30:00 -0500').date, '2026-03-01'); assert.equal(WB.parseHealthDate('nope'), null); });
t('TCX: sport, time, distance, calories and heart rate', () => {
  const x = `<TrainingCenterDatabase><Activities><Activity Sport="Running"><Id>2026-04-05T06:30:00Z</Id><Lap StartTime="2026-04-05T06:30:00Z"><TotalTimeSeconds>1200.5</TotalTimeSeconds><DistanceMeters>3500.0</DistanceMeters><Calories>250</Calories><AverageHeartRateBpm><Value>150</Value></AverageHeartRateBpm><MaximumHeartRateBpm><Value>175</Value></MaximumHeartRateBpm></Lap><Lap><TotalTimeSeconds>600</TotalTimeSeconds><DistanceMeters>1500</DistanceMeters><Calories>100</Calories><AverageHeartRateBpm><Value>160</Value></AverageHeartRateBpm><MaximumHeartRateBpm><Value>180</Value></MaximumHeartRateBpm></Lap></Activity></Activities></TrainingCenterDatabase>`;
  const [a] = WB.parseTCX(x); assert.equal(a.label, 'Run'); assert.equal(a.durationSec, 1801); assert.equal(a.distanceM, 5000); assert.equal(a.kcal, 350); assert.equal(a.avgHr, 155); assert.equal(a.maxHr, 180); assert.equal(a.date, '2026-04-05'); assert.deepEqual(WB.parseTCX('<x/>'), []);
});
t('GPX: duration from timestamps, distance from the track, heart rate extension', () => {
  const pt = (lat, lon, tm, hr) => `<trkpt lat="${lat}" lon="${lon}"><time>${tm}</time><extensions><gpxtpx:TrackPointExtension><gpxtpx:hr>${hr}</gpxtpx:hr></gpxtpx:TrackPointExtension></extensions></trkpt>`;
  const x = `<gpx><trk><name>Morning ride</name><type>cycling</type><trkseg>${pt(51.5, -0.1, '2026-05-01T08:00:00Z', 120)}${pt(51.51, -0.1, '2026-05-01T08:10:00Z', 140)}${pt(51.52, -0.1, '2026-05-01T08:20:00Z', 160)}</trkseg></trk></gpx>`;
  const [a] = WB.parseGPX(x); assert.equal(a.label, 'Cycle'); assert.equal(a.durationSec, 1200); assert.ok(a.distanceM > 2200 && a.distanceM < 2260, 'about 2.2 km: ' + a.distanceM); assert.equal(a.avgHr, 140); assert.equal(a.maxHr, 160); assert.deepEqual(WB.parseGPX('<gpx><trk><trkseg></trkseg></trk></gpx>'), []);
});
t('activity labels map common Apple types and fall back to a readable name', () => { assert.equal(WB.labelFor('HKWorkoutActivityTypeFunctionalStrengthTraining'), 'Strength'); assert.equal(WB.labelFor('HKWorkoutActivityTypeHighIntensityIntervalTraining'), 'Strength'); assert.equal(WB.labelFor('HKWorkoutActivityTypeBadminton'), 'Badminton'); assert.equal(WB.labelFor(''), 'Workout'); });
ta('zip: finds export.xml and reads stored and deflated entries', async () => {
  const zlib = await import('node:zlib'); const name = 'apple_health_export/export.xml', data = Buffer.from(AH), comp = zlib.deflateRawSync(data);
  const crc = (b) => { let c, crc = ~0; for (const x of b) { c = (crc ^ x) & 0xff; for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xedb88320 : c >>> 1; crc = (crc >>> 8) ^ c; } return ~crc >>> 0; };
  const build = (payload, method) => { const nb = Buffer.from(name), lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(method, 8); lh.writeUInt32LE(crc(data), 14); lh.writeUInt32LE(payload.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(nb.length, 26);
    const cd = Buffer.alloc(46); cd.writeUInt32LE(0x02014b50, 0); cd.writeUInt16LE(20, 6); cd.writeUInt16LE(method, 10); cd.writeUInt32LE(crc(data), 16); cd.writeUInt32LE(payload.length, 20); cd.writeUInt32LE(data.length, 24); cd.writeUInt16LE(nb.length, 28); cd.writeUInt32LE(0, 42);
    const eo = Buffer.alloc(22); eo.writeUInt32LE(0x06054b50, 0); eo.writeUInt16LE(1, 8); eo.writeUInt16LE(1, 10); eo.writeUInt32LE(46 + nb.length, 12); eo.writeUInt32LE(30 + nb.length + payload.length, 16); return Buffer.concat([lh, nb, payload, cd, nb, eo]); };
  for (const [payload, method] of [[comp, 8], [data, 0]]) { const buf = build(payload, method), file = new Blob([buf]); const e = await WB.findZipEntry(file); assert.equal(e.name, name); assert.equal(e.method, method); const stream = await WB.zipEntryStream(file, e), txt = await new Response(stream).text(); assert.equal(txt, AH); }
  await assert.rejects(() => WB.findZipEntry(new Blob([Buffer.from('not a zip at all')])), /zip/i);
});
ta('parseHealthFile: end to end on an xml Blob, and unsupported files give a clear error', async () => { const f = new Blob([AH]); f.name = 'export.xml'; const r = await WB.parseHealthFile(f); assert.equal(r.kind, 'Apple Health'); assert.equal(r.activities.length, 2); const bad = new Blob(['hello']); bad.name = 'notes.txt'; await assert.rejects(() => WB.parseHealthFile(bad), /Unsupported/); });
t('Bluetooth heart rate: 8-bit and 16-bit measurements parse per the spec', () => { assert.equal(HR.parseHeartRate(new DataView(new Uint8Array([0, 72]).buffer)), 72); assert.equal(HR.parseHeartRate(new DataView(new Uint8Array([1, 0x2c, 0x01]).buffer)), 300); assert.equal(HR.parseHeartRate(new DataView(new Uint8Array([0x10, 150, 0x20, 0x03]).buffer)), 150); });
t('heart rate summary needs enough readings', () => { HR.resetHrSamples(); assert.equal(HR.hrSummary(), null); });

// ---- classes (studio sessions) ----
const TODAY = '2026-11-18';
t('class: valid logged class is cleaned, defaults impact from type, keeps effort', () => { const r = CL.normClass({ type: 'pilates', date: '2026-11-17', minutes: '50', status: 'done', effort: '3', studio: ' Core Studio ' }, TODAY); assert.ok(!r.error); assert.equal(r.value.impact, 'low'); assert.equal(r.value.durationSec, 3000); assert.equal(r.value.studio, 'Core Studio'); assert.equal(r.value.effort, 3); assert.equal(r.value.source, 'class'); });
t('class: future logged and past booked are refused with clear messages', () => { assert.match(CL.normClass({ type: 'yoga', date: '2026-11-20', minutes: 60, status: 'done' }, TODAY).error, /already happened/); assert.match(CL.normClass({ type: 'yoga', date: '2026-11-10', minutes: 60, status: 'booked', time: '10:00' }, TODAY).error, /past/); });
t('class: booked needs a time, minutes 5..300, a known type and a date', () => { assert.match(CL.normClass({ type: 'yoga', date: TODAY, minutes: 60, status: 'booked' }, TODAY).error, /time/); assert.match(CL.normClass({ type: 'yoga', date: TODAY, minutes: 2 }, TODAY).error, /minutes/); assert.match(CL.normClass({ type: 'nope', date: TODAY, minutes: 30 }, TODAY).error, /type/); assert.match(CL.normClass({ type: 'yoga', date: 'x', minutes: 30 }, TODAY).error, /date/); });
t('class: effort is dropped for booked classes and an invalid impact falls back to the type default', () => { const r = CL.normClass({ type: 'hiit', date: TODAY, minutes: 45, status: 'booked', time: '18:00', effort: 4, impact: 'weird' }, TODAY); assert.equal(r.value.effort, undefined); assert.equal(r.value.impact, 'high'); });
t('class: booked classes do not count as trained days; done ones do', () => { const st = { activities: [{ id: 'class:a', source: 'class', date: '2026-11-17', status: 'done' }, { id: 'class:b', source: 'class', date: '2026-11-18', status: 'booked' }, { id: 'imp:1', source: 'apple', date: '2026-11-16', type: 'run' }] }; const d = CL.classDoneDates(st); assert.ok(d.has('2026-11-17')); assert.ok(!d.has('2026-11-18')); assert.ok(!d.has('2026-11-16')); });
t('class: imported-only filter leaves classes out and classes-only the reverse', () => { const l = [{ id: '1', source: 'class' }, { id: '2', source: 'apple' }]; assert.deepEqual(CL.importedOnly(l).map((a) => a.id), ['2']); assert.deepEqual(CL.classesOf(l).map((a) => a.id), ['1']); });
t('class: upcoming and unmarked lists', () => { const mk = (id, date, status, time = '09:00') => ({ id, source: 'class', type: 'yoga', label: 'Yoga', date, time, start: date + 'T' + time, status, durationSec: 3600 }); const st = { activities: [mk('a', '2026-11-20', 'booked'), mk('b', '2026-11-18', 'booked', '07:00'), mk('c', '2026-11-15', 'booked'), mk('d', '2026-11-19', 'done')] }; assert.deepEqual(CL.upcomingClasses(st, TODAY).map((c) => c.id), ['b', 'a']); assert.deepEqual(CL.unmarkedClasses(st, TODAY).map((c) => c.id), ['c']); });
t('class: a done class makes the day trained in the calendar and counts for the weekly target', () => { const st = { sessions: [], profile: { days: 3, createdAt: '2026-11-01T00:00:00Z' }, reminders: null, activities: [{ id: 'class:a', source: 'class', date: '2026-11-17', status: 'done' }, { id: 'class:b', source: 'class', date: '2026-11-19', status: 'booked' }] }; const m = SC.dayStatuses(st, '2026-11-16', '2026-11-22', new Date(2026, 10, 18, 12)); assert.equal(m.get('2026-11-17').status, 'done'); assert.notEqual(m.get('2026-11-19').status, 'done'); assert.equal(m.get('2026-11-17').weekDone, 1); });
t('class: calendar file has the event, an alarm, escaped text and CRLF line endings', () => { const ics = CL.buildClassICS({ id: 'class:abc', label: 'Pilates', studio: 'Core, Studio', date: '2026-11-20', time: '10:00', durationSec: 3000, note: 'bring socks' }, new Date(Date.UTC(2026, 10, 18))); assert.match(ics, /BEGIN:VEVENT/); assert.match(ics, /DTSTART:20261120T100000/); assert.match(ics, /DTEND:20261120T105000/); assert.match(ics, /TRIGGER:-PT60M/); assert.match(ics, /Core\\, Studio/); assert.ok(ics.includes('\r\n')); assert.ok(ics.endsWith('END:VCALENDAR\r\n')); });
t('class: every library exercise has a stress list so the Easy on filter is reliable', () => { assert.ok(EXERCISES.every((e) => Array.isArray(e.stress))); });

// ---- Pilates, yoga and mobility routines ----
const MUSCLE_LIST = ['Chest', 'Back', 'Shoulders', 'Biceps', 'Triceps', 'Quads', 'Hamstrings', 'Glutes', 'Core', 'Calves'];
t('mind-body: only supine twist and figure-four lack an animation (they happen across the body, which a side-on figure cannot show)', () => { assert.deepEqual(MB.MINDBODY.filter((e) => !AD.ANIMS[e.id]).map((e) => e.id).sort(), ['figure-four', 'supine-twist']); });
t('mind-body: every move is complete, timed, uses known muscles and valid substitutes', () => { assert.ok(MB.MINDBODY.length >= 15); for (const e of MB.MINDBODY) { assert.equal(BY_ID[e.id], e); assert.equal(e.unit, 'sec'); assert.equal(e.slot, 'mindbody'); assert.ok(e.steps.length >= 3 && e.mistakes.length >= 2, e.id); assert.ok(e.reps[0] > 0 && e.reps[1] >= e.reps[0]); [...e.pm, ...e.sm].forEach((m) => assert.ok(MUSCLE_LIST.includes(m), e.id + ' ' + m)); (e.subs || []).forEach((x) => assert.ok(BY_ID[x], e.id + ' sub ' + x)); } });
t('mind-body: the programme generator never picks them', () => { for (const gear of ['gym', 'db', 'bw']) for (const goal of ['muscle', 'strength', 'fatloss']) { const prog = generateProgram({ name: 'x', goal, focus: 'balanced', days: 4, level: 1, gear, duration: 60, style: 'balanced', limits: [], avoid: [], favour: [] }); assert.ok(prog.sessions.every((s) => s.items.every((i) => BY_ID[i.exId]?.slot !== 'mindbody'))); } });
t('mind-body: routines reference real moves, one-side moves get two sets, and times are sensible', () => { assert.ok(MB.ROUTINES.length >= 4); for (const r of MB.ROUTINES) { assert.ok(MB.routineMinutes(r) >= 3 && MB.routineMinutes(r) <= 30, r.id); for (const m of r.moves) { const e = BY_ID[m.id]; assert.ok(e, m.id); assert.ok(m.secs >= 10 && m.secs <= 120); if (e.sides) assert.equal(m.sets, 2, r.id + ' ' + m.id); } } });
t('mind-body: holding longer is never a personal best', () => { const mk = (id, date, secs) => ({ id, date, startedAt: 1, items: [{ exId: 'cat-cow', name: 'Cat-cow', sets: [{ w: 0, reps: secs }] }] }); assert.equal(A.prEvents([mk('a', '2026-11-01', 30), mk('b', '2026-11-03', 90)]).length, 0); });
t('mind-body: the Easy on wrists filter data excludes wrist-loading moves', () => { const e = MB.MINDBODY.filter((m) => !m.stress.includes('wrists')).map((m) => m.id); assert.ok(e.includes('pelvic-curl') && !e.includes('down-dog') && !e.includes('cat-cow')); });

for (const [n, fn] of queue) { try { await fn(); pass++; console.log('  ok  ' + n); } catch (e) { fail++; console.log('FAIL  ' + n + '\n      ' + e.message); } }
// ---- Stage 1: library extras and session structure
import * as SS from '../js/sessions.js';
t('library extras: complete, valid muscles, valid subs, guided slots are timed or reps', () => { const L = X.EXERCISES.filter((e) => e.extra); assert.ok(L.length >= 40); for (const e of L) { assert.ok(e.steps.length >= 3 && e.mistakes.length >= 2, e.id); assert.ok(e.reps[1] >= e.reps[0] && e.reps[0] > 0, e.id); [...e.pm, ...e.sm].forEach((m) => assert.ok([...MUSCLE_LIST, 'Forearms'].includes(m), e.id + ' ' + m)); (e.subs || []).forEach((x) => assert.ok(BY_ID[x], e.id + ' sub ' + x)); if (X.isGuided(e)) assert.ok(['sec', 'reps', 'min'].includes(e.unit)); } });
t('library extras: cardio is in minutes and the new categories exist', () => { assert.ok(X.EXERCISES.filter((e) => e.slot === 'cardio').every((e) => e.unit === 'min')); for (const ty of ['Cardio', 'Warm-up', 'Stretching', 'Glute activation']) assert.ok(X.EXERCISES.some((e) => e.type === ty), ty); });
t('guided exercises are never offered as swaps for a lift', () => { for (const lift of ['squat-bb', 'bench', 'rdl-bb', 'plank']) assert.ok(X.rankedSubstitutes(BY_ID[lift], { gear: 'gym', limits: [] }).every((r) => !X.isGuided(r.ex)), lift); });
t('guided extras (warm-ups, cardio, stretches) never appear inside a programme', () => { for (const gear of ['gym', 'db', 'bw']) { const p = generateProgram({ name: 'x', goal: 'muscle', focus: 'balanced', days: 4, level: 1, gear, duration: 60, style: 'balanced', limits: [], avoid: [], favour: [] }); assert.ok(p.sessions.every((s) => s.items.every((i) => !(BY_ID[i.exId].extra && ['warmup', 'activation', 'stretch', 'cardio', 'mindbody'].includes(BY_ID[i.exId].slot))))); } });
t('extras: cleaning keeps booleans, whole minutes 0 to 60 and a real cardio id', () => { assert.deepEqual(SS.normExtras(null), SS.DEFAULT_EXTRAS); const x = SS.normExtras({ warmup: 'yes', cooldown: true, cardio: '25.4', cardioId: 'nope' }); assert.equal(x.warmup, false); assert.equal(x.cooldown, true); assert.equal(x.cardio, 25); assert.equal(x.cardioId, 'treadmill'); assert.equal(SS.normExtras({ cardio: 99 }).cardio, 0); });
t('session plan: with no extras it is just the main items', () => { const main = [{ exId: 'squat-bb', sets: 3, repLo: 5, repHi: 8, restSec: 90 }]; const p = SS.buildSessionPlan(main, SS.DEFAULT_EXTRAS, { gear: 'gym' }); assert.equal(p.length, 1); assert.equal(p[0].phase, 'main'); });
t('session plan: warm-up, activation, main, cardio, cool-down in order, respecting gear and limits', () => { const main = [{ exId: 'squat-bb', sets: 3, repLo: 5, repHi: 8, restSec: 90 }, { exId: 'hipthrust-bb', sets: 3, repLo: 8, repHi: 10, restSec: 90 }]; const x = { warmup: true, activation: true, cooldown: true, cardio: 15, cardioId: 'treadmill' }; const p = SS.buildSessionPlan(main, x, { gear: 'gym', limits: [] }); const ph = p.map((i) => i.phase); const order = ['warmup', 'activation', 'main', 'cardio', 'cooldown']; assert.deepEqual([...new Set(ph)], order); assert.deepEqual(ph.slice().sort((a, b) => order.indexOf(a) - order.indexOf(b)), ph); assert.equal(p.find((i) => i.phase === 'cardio').repLo, 15); assert.equal(new Set(p.map((i) => i.exId)).size, p.length);
  const bw = SS.buildSessionPlan([{ exId: 'bw-squat', sets: 3, repLo: 10, repHi: 15, restSec: 60 }], x, { gear: 'bw', limits: ['knees'] }); assert.ok(bw.filter((i) => i.phase !== 'main').every((i) => BY_ID[i.exId].tier === 'bw' && !BY_ID[i.exId].stress.includes('knees')), 'bodyweight and knee-safe'); assert.ok(!bw.some((i) => i.phase === 'cardio' && BY_ID[i.exId].tier !== 'bw')); });
t('session plan: standalone cardio is one timed item and refuses non-cardio', () => { assert.equal(SS.cardioPlan('cycling', 20).length, 1); assert.equal(SS.cardioPlan('squat-bb', 20).length, 0); });
t('guided items in a lifting session are never personal bests', () => { assert.ok(X.isGuided(BY_ID['clamshell']) && X.isGuided(BY_ID['treadmill'])); });


// ---- Stage 2: onboarding data, splits, equipment, durations, body focus
import * as GEN from '../js/generator.js';
import { recommend as recommendEx } from '../js/recommend.js';
console.log('generator stage 2');
const base2 = (o) => ({ name: 'x', goal: 'muscle', days: 4, level: 1, duration: 60, style: 'balanced', limits: [], avoid: [], favour: [], ...o });
t('normProfile keeps old profiles valid and derives gear from equipment', () => {
  const old = GEN.normProfile({ goal: 'fat', focus: 'glutes', days: 3, level: 1, gear: 'db', duration: 45, style: 'balanced', limits: ['knees'] });
  assert.equal(old.gear, 'db'); assert.equal(old.split, 'auto'); assert.deepEqual(GEN.equipmentOf(old), ['db']);
  assert.equal(GEN.normProfile({ equipment: ['barbell', 'bands'], gear: 'bw' }).gear, 'gym'); assert.equal(GEN.normProfile({ equipment: ['bands', 'kettlebell'] }).gear, 'db'); assert.equal(GEN.normProfile({ equipment: ['bw'] }).gear, 'bw');
  const bad = GEN.normProfile({ goal: 'nope', days: 99, duration: 3, level: 9, split: 'x', goals2: ['strength', 'strength', 'tone', 'endurance'], focusMuscles: ['Glutes', 'Wings'], params: { sets: 99, repLo: 10, repHi: 5, restSec: 5 } });
  assert.equal(bad.goal, 'muscle'); assert.equal(bad.days, 3); assert.equal(bad.duration, 60); assert.equal(bad.level, 0); assert.equal(bad.split, 'auto'); assert.deepEqual(bad.goals2, ['strength', 'tone']); assert.deepEqual(bad.focusMuscles, ['Glutes']); assert.deepEqual(bad.params, {});
});
t('every split, day count, equipment set and level gives valid sessions', () => {
  const EQS = [['gym'], ['db'], ['bw'], ['barbell', 'bands'], ['cable'], ['kettlebell'], ['homegym']];
  for (const split of GEN.SPLIT_ORDER) for (const days of [2, 3, 4, 5, 6, 7]) for (const equipment of EQS) for (const level of [0, 2]) {
    const prof = base2({ split, days, equipment, level, limits: split === 'auto' ? ['knees'] : [], customDays: [{ name: 'A', muscles: ['Chest'] }] }), p = GEN.generateProgram(prof), eq = GEN.equipmentOf(GEN.normProfile(prof)), gear = GEN.normProfile(prof).gear, tag = `${split}/${days}/${equipment}/${level}`;
    assert.equal(p.sessions.length, days, tag);
    for (const s of p.sessions) {
      const ids = s.items.map((i) => i.exId); assert.equal(new Set(ids).size, ids.length, tag + ' duplicate');
      if (s.recovery) { assert.ok(ids.every((id) => X.isGuided(BY_ID[id])), tag + ' recovery is guided only'); continue; }
      assert.ok(s.items.length >= 3 || split === 'custom', `${tag}: ${s.name} has ${s.items.length}`);
      for (const it of s.items) { const e = BY_ID[it.exId]; assert.ok(e && available(e, gear) && GEN.equipOk(e, eq), `${tag}: ${it.exId} not usable`); assert.ok(it.sets >= 1 && it.repLo <= it.repHi, tag); if (split === 'auto') assert.ok(!e.stress.includes('knees'), tag + ' knees'); }
    }
  }
});
t('seven days always ends with active recovery; six does not', () => { for (const split of ['auto', 'ppl', 'upperlower', 'bro', 'strength', 'hypertrophy']) { assert.equal(GEN.generateProgram(base2({ split, days: 7, equipment: ['gym'] })).sessions[6].name, 'Active recovery', split); assert.ok(GEN.generateProgram(base2({ split, days: 6, equipment: ['gym'] })).sessions.every((s) => !s.recovery), split); } });
t('every major muscle is trained each week on the main splits (gym, 3+ days, 60 min)', () => {
  for (const split of ['auto', 'full', 'upperlower', 'ppl', 'hypertrophy']) for (const days of [3, 4, 5, 6]) { const p = GEN.generateProgram(base2({ split, days, equipment: ['gym'], duration: 75 })), hit = new Set(p.sessions.flatMap((s) => s.items.flatMap((i) => BY_ID[i.exId].pm))); for (const m of GEN.MAJOR) assert.ok(hit.has(m), `${split}/${days} misses ${m}`); }
});
t('longer sessions hold more exercises, capped by experience', () => {
  const n = (duration, level) => GEN.generateProgram(base2({ days: 4, equipment: ['gym'], duration, level, split: 'upperlower' })).sessions[0].items.length;
  assert.ok(n(120, 1) > n(45, 1), 'more at 120 than 45'); assert.ok(n(120, 0) <= 8, 'beginner cap'); assert.ok(n(120, 2) <= 13, 'advanced cap');
  for (const d of [15, 20, 25, 30, 45, 60, 90, 120, 150, 180]) { const p = GEN.generateProgram(base2({ days: 3, equipment: ['gym'], duration: d })); for (const s of p.sessions) assert.ok(GEN.estMinutes(s.items) <= d - 5 + 5 || s.items.length <= 3, `${d} min: ${s.name} ${GEN.estMinutes(s.items)}`); }
});
t('body focus adds work for the chosen muscles', () => {
  const week = (focusMuscles) => GEN.generateProgram(base2({ days: 4, equipment: ['gym'], duration: 60, focusMuscles })).sessions.flatMap((s) => s.items.map((i) => BY_ID[i.exId]));
  const calves = (l) => l.filter((e) => e.pm.includes('Calves')).length;
  assert.ok(calves(week(['Calves'])) > calves(week([])), 'calves focus adds calf work');
  const sets = (l, m) => GEN.generateProgram(base2({ days: 4, equipment: ['gym'], focusMuscles: l })).sessions.flatMap((s) => s.items.filter((i) => BY_ID[i.exId].pm.includes(m)).map((i) => i.sets)).reduce((a, b) => a + b, 0);
  assert.ok(sets(['Glutes'], 'Glutes') > sets([], 'Glutes'), 'more glute sets');
});
t('the person\'s own sets, reps and rest win over defaults', () => {
  const p = GEN.generateProgram(base2({ days: 3, equipment: ['gym'], params: { sets: 5, repLo: 6, repHi: 8, restSec: 120 } })), main = p.sessions[0].items[0];
  assert.equal(main.sets, 5); assert.equal(main.repLo, 6); assert.equal(main.repHi, 8); assert.equal(main.restSec, 120);
  const iso = p.sessions.flatMap((s) => s.items).find((i) => BY_ID[i.exId].type === 'Isolation'); if (iso) assert.equal(iso.repLo, 6);
});
t('goals change rep ranges, and secondary goals shift accessory work', () => {
  const top = (goal, goals2 = []) => GEN.generateProgram(base2({ goal, goals2, days: 3, equipment: ['gym'] })).sessions[0].items[0];
  assert.ok(top('endurance').repLo >= 15 && top('endurance').restSec <= 45); assert.ok(top('athletic').repHi <= 8); assert.ok(top('tone').repLo >= 10);
  assert.ok(top('muscle', ['strength']).repLo < top('muscle').repLo, 'secondary strength lowers reps on compounds');
});
t('equipment limits exercises, and bodyweight-only never needs kit', () => {
  const all = (equipment) => GEN.generateProgram(base2({ days: 5, equipment, duration: 90 })).sessions.filter((s) => !s.recovery).flatMap((s) => s.items.map((i) => BY_ID[i.exId]));
  assert.ok(all(['bands']).every((e) => ['Band', 'Bodyweight'].includes(e.equip))); assert.ok(all(['bw']).every((e) => e.equip === 'Bodyweight')); assert.ok(all(['db']).every((e) => ['Dumbbell', 'Bodyweight'].includes(e.equip))); assert.ok(all(['cable']).every((e) => ['Cable', 'Bodyweight'].includes(e.equip)));
  assert.ok(all(['smith']).some((e) => e.equip === 'Barbell'), 'smith is treated like a barbell');
});
t('custom split fills each day only with the chosen muscles', () => {
  const p = GEN.generateProgram(base2({ days: 3, split: 'custom', equipment: ['gym'], customDays: [{ name: 'Arms', muscles: ['Biceps', 'Triceps'] }, { name: 'Legs', muscles: ['Quads', 'Hamstrings'] }, { name: 'Back', muscles: ['Back'] }] }));
  assert.deepEqual(p.sessions.map((s) => s.name), ['Arms', 'Legs', 'Back']); for (const s of p.sessions) assert.ok(s.items.length >= 1 && s.items.length <= 6, s.name);
  assert.ok(p.sessions[0].items.every((i) => BY_ID[i.exId].pm.some((m) => ['Biceps', 'Triceps'].includes(m))));
});
t('beginners are not given advanced lifts', () => { for (const split of ['strength', 'auto']) { const p = GEN.generateProgram(base2({ level: 0, split, days: 4, equipment: ['gym'] })); assert.ok(p.sessions.flatMap((s) => s.items).every((i) => BY_ID[i.exId].diff !== 'Advanced'), split); } });
t('volume report and explanation cover the new options', () => {
  const p = GEN.generateProgram(base2({ days: 4, split: 'hypertrophy', equipment: ['gym'], goals2: ['strength'], focusMuscles: ['Glutes'], params: { sets: 4 } })), v = GEN.volumeReport(p);
  assert.equal(v.length, X.MUSCLES.length); assert.ok(v.every((r) => ['low', 'ok', 'high'].includes(r.status)));
  const why = GEN.explainProgram(p, base2({ days: 4, split: 'hypertrophy', equipment: ['gym'], goals2: ['strength'], focusMuscles: ['Glutes'], params: { sets: 4 } })).points.map((x) => x.text).join(' ');
  assert.ok(/glutes/i.test(why) && /strong/i.test(why) && /4 sets/.test(why));
  for (const g of Object.keys(GEN.GOALS)) assert.ok(GEN.explainProgram(GEN.generateProgram(base2({ goal: g })), base2({ goal: g })).headline.length > 10, g);
});
t('recommendations respect equipment, limits and the session, and always give a reason', () => {
  const prof = GEN.normProfile(base2({ equipment: ['db'], limits: ['knees'], focusMuscles: ['Biceps'], level: 0 }));
  const recs = recommendEx({ profile: prof, sessionIds: ['db-press'], recent: [], favourites: [], byId: BY_ID }, 10);
  assert.ok(recs.length > 0); for (const r of recs) { assert.ok(r.why.length > 5); assert.ok(GEN.equipOk(r.ex, ['db']) && !r.ex.stress.includes('knees') && r.ex.id !== 'db-press' && !X.isGuided(r.ex)); }
  assert.ok(recs.some((r) => r.ex.pm.includes('Biceps')), 'focus muscle is suggested');
});


import * as BM from '../js/bodymap.js';
t('body map: every focus area is drawable and every library muscle lights up an area', () => {
  const html = BM.bodyMapHTML({ mode: 'select', selected: [] });
  for (const a of Object.keys(GEN.FOCUS_MUSCLES)) { assert.ok(html.includes(`data-bm="${a}"`), a); assert.equal(BM.AREA_MUSCLE[a], GEN.FOCUS_MUSCLES[a].m, a + ' maps to the generator muscle'); }
  for (const m of [...X.MUSCLES, 'Forearms']) assert.ok(BM.MUSCLE_AREAS[m]?.length, m);
  const show = BM.bodyMapHTML({ mode: 'show', primary: ['Quads'], secondary: ['Core'] }); assert.ok(show.includes('bm-r p') && show.includes('bm-r s') && !show.includes('data-bm'), 'show mode highlights and is not interactive');
  assert.ok(BM.bodyMapHTML({ mode: 'select', selected: ['Chest'] }).includes('aria-checked="true"'));
});

// ---- stage 4: muscle frequency and upcoming sessions ----
t('muscleFrequency counts only logged primary-muscle sessions', () => {
  const mk = (date, exId, n) => ({ id: date + exId, date, name: 'x', items: [{ exId, sets: Array.from({ length: n }, () => ({ w: 20, reps: 8, done: true })) }] });
  const now = new Date(2026, 5, 17), ss = [mk('2026-06-15', 'bench', 3), mk('2026-06-10', 'bench', 4)];
  const r = A.muscleFrequency(ss, now, 4), chest = r.find((x) => x.muscle === 'Chest');
  assert.ok(chest); assert.equal(chest.sessions, 2); assert.equal(chest.weeksTrained, 2); assert.equal(chest.setsThisWeek, 3);
  assert.ok(!r.find((x) => x.muscle === 'Glutes' && x.sessions > 0));
  assert.deepEqual(A.muscleFrequency([], now), []);
});
t('upcomingSessions follows programme order on planned days', () => {
  const prog = generateProgram({ goal: 'muscle', level: 1, gear: 'gym', days: 3, duration: 45, limits: [] });
  const st = { program: prog, cursor: 1, sessions: [], reminders: { days: [0, 2, 4] }, profile: { days: 3 } };
  const up = SC.upcomingSessions(st, 3, new Date(2026, 5, 17));
  assert.equal(up.length, 3); assert.equal(up[0].idx, 1 % prog.sessions.length); assert.ok(up[0].inDays <= up[1].inDays);
  assert.ok(up.every((x) => [0, 2, 4].includes(SC.weekdayOf(x.d))));
});

// ---- Part 13: generation matrix across levels, goals, equipment, days and durations ----
t('generation matrix: every combination gives a valid, equipment-safe programme', () => {
  const kits = [['gym'], ['db'], ['bw'], ['bands'], ['barbell', 'db'], ['bw', 'bands']];
  let n = 0;
  for (const level of [0, 1, 2]) for (const goal of GEN.GOAL_ORDER) for (const equipment of kits) for (const days of [2, 3, 4, 5, 6, 7]) for (const duration of [30, 60, 90]) {
    const profile = { goal, level, equipment, gear: GEN.gearFromEquipment(equipment), days, duration, limits: [], style: 'balanced' }, tag = JSON.stringify({ level, goal, equipment, days, duration });
    const prog = generateProgram(profile); n++;
    assert.equal(prog.sessions.length, days, 'one session per day ' + tag);
    for (const se of prog.sessions) {
      const ids = se.items.map((i) => i.exId);
      assert.equal(new Set(ids).size, ids.length, 'no repeated exercise in a session ' + tag);
      assert.ok(ids.length >= 3, 'at least 3 exercises ' + tag + ' ' + se.name);
      for (const it of se.items) {
        const ex = BY_ID[it.exId]; assert.ok(ex, 'exercise exists ' + it.exId);
        assert.ok(GEN.equipOk(ex, equipment), `${ex.id} (${ex.equip}) fits equipment ` + tag);
        if (level === 0) assert.notEqual(ex.diff, 'Advanced', 'beginner gets no Advanced exercise ' + tag);
        assert.ok(it.sets >= 1 && it.repLo >= 1 && it.repHi >= it.repLo && it.restSec >= 0, 'valid prescription ' + ex.id + ' ' + tag);
      }
    }
    if (days >= 3) { const hit = new Set(); prog.sessions.forEach((se) => se.items.forEach((i) => { BY_ID[i.exId].pm.forEach((m) => hit.add(m)); if (duration < 45) BY_ID[i.exId].sm.forEach((m) => { if (['Biceps', 'Triceps', 'Calves', 'Core', 'Shoulders'].includes(m)) hit.add(m); }); })); const direct = new Set(); X.EXERCISES.filter((e) => !['mindbody', 'stretch', 'warmup', 'activation', 'cardio'].includes(e.slot) && GEN.equipOk(e, equipment)).forEach((e) => e.pm.forEach((m) => direct.add(m))); const need = GEN.MAJOR.filter((m) => direct.has(m)); assert.ok(need.every((m) => hit.has(m)), 'every major muscle that this equipment can train directly is trained weekly ' + tag + ' missing ' + need.filter((m) => !hit.has(m))); }
  }
  assert.equal(n, 3 * 8 * 6 * 6 * 3);
});
t('substitutes keep the muscle, respect equipment, and never swap a lift for a guided move', () => {
  for (const id of ['bench', 'squat-bb', 'rdl-bb', 'row-bb']) { const ex = BY_ID[id]; if (!ex) continue;
    const subs = X.rankedSubstitutes(ex, { gear: 'bw', limits: [], level: 1, avoid: [], allow: GEN.allowedEquip(['bw']) });
    subs.forEach((r) => { assert.ok(r.ex.pm.some((m) => ex.pm.includes(m)), `${r.ex.id} shares a muscle with ${id}`); assert.ok(GEN.equipOk(r.ex, ['bw']), r.ex.id + ' fits bodyweight only'); assert.ok(!GEN.GUIDED_SLOTS?.includes?.(r.ex.slot) && !['stretch', 'warmup', 'activation', 'cardio', 'mindbody'].includes(r.ex.slot), r.ex.id + ' is not a guided move'); }); }
});
t('older saved profiles and programmes still load and generate', () => {
  const old = { name: 'Old', goal: 'muscle', level: 1, gear: 'db', days: 3, duration: 45, limits: [], style: 'balanced' };
  const np = GEN.normProfile(old); assert.deepEqual(GEN.equipmentOf(np).sort(), ['db']); assert.ok(generateProgram(np).sessions.length === 3);
  assert.doesNotThrow(() => GEN.normProfile({})); assert.doesNotThrow(() => GEN.normProfile({ goal: 'nonsense', level: 9, days: 99, duration: 5 }));
  const fixed = GEN.normProfile({ goal: 'nonsense', level: 9, days: 99, duration: 5 }); assert.ok(GEN.GOAL_ORDER.includes(fixed.goal) && fixed.level <= 2 && fixed.days <= 7 && fixed.duration >= GEN.MIN_DURATION);
});

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
