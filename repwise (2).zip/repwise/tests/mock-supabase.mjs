// A tiny in-memory stand-in for the parts of Supabase that Repwise uses, for automated tests.
// Run: node tests/mock-supabase.mjs [port]   (default 8130)
import http from 'node:http';
import { randomUUID } from 'node:crypto';

export function startMock(port = 8130, { confirmEmail = false } = {}) {
  const users = new Map(), byEmail = new Map(), rows = new Map(), backups = [], refresh = new Map(), log = [];
  const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
  const jwt = (u) => `${b64({ alg: 'none' })}.${b64({ sub: u.id, email: u.email, exp: Math.floor(Date.now() / 1000) + 3600 })}.sig`;
  const session = (u) => { const r = randomUUID(); refresh.set(r, u.id); return { access_token: jwt(u), refresh_token: r, expires_in: 3600, expires_at: Math.floor(Date.now() / 1000) + 3600, token_type: 'bearer', user: { id: u.id, email: u.email } }; };
  const userFrom = (req) => { const t = (req.headers.authorization || '').replace('Bearer ', ''); try { const p = JSON.parse(Buffer.from(t.split('.')[1], 'base64url')); return users.get(p.sub) || null; } catch { return null; } };
  const server = http.createServer(async (req, res) => {
    const send = (code, body) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*' }); res.end(body === undefined ? '' : JSON.stringify(body)); };
    if (req.method === 'OPTIONS') return send(204);
    let raw = ''; for await (const c of req) raw += c; const body = raw ? JSON.parse(raw) : {}, url = new URL(req.url, 'http://x'), p = url.pathname; log.push(`${req.method} ${p}${url.search}`);
    if (!req.headers.apikey) return send(401, { message: 'No API key' });
    if (p === '/auth/v1/signup') {
      if (byEmail.has(body.email)) return send(422, { error_code: 'user_already_exists', msg: 'User already registered' });
      if (!body.password || body.password.length < 8) return send(422, { error_code: 'weak_password', msg: 'Password should be at least 8 characters' });
      const u = { id: randomUUID(), email: body.email, password: body.password }; users.set(u.id, u); byEmail.set(u.email, u);
      return confirmEmail ? send(200, { id: u.id, email: u.email }) : send(200, session(u));
    }
    if (p === '/auth/v1/token') {
      if (url.searchParams.get('grant_type') === 'password') { const u = byEmail.get(body.email); if (!u || u.password !== body.password) return send(400, { error_code: 'invalid_credentials', msg: 'Invalid login credentials' }); return send(200, session(u)); }
      const id = refresh.get(body.refresh_token); if (!id) return send(400, { error_code: 'refresh_token_not_found', msg: 'Invalid Refresh Token' }); return send(200, session(users.get(id)));
    }
    if (p === '/auth/v1/recover') { log.push('RECOVER ' + body.email); return send(200, {}); }
    if (p === '/auth/v1/logout') return send(204);
    if (p === '/auth/v1/user' && req.method === 'PUT') { const u = userFrom(req); if (!u) return send(401, { msg: 'bad jwt' }); if (body.password === u.password) return send(422, { error_code: 'same_password', msg: 'same' }); u.password = body.password; return send(200, { id: u.id, email: u.email }); }
    const u = userFrom(req); if (p.startsWith('/rest/') && !u) return send(401, { message: 'JWT expired', code: 'PGRST301' });
    if (p === '/rest/v1/user_data') {
      const uid = url.searchParams.get('user_id')?.replace('eq.', '');
      if (req.method === 'GET') { if (uid !== u.id) return send(200, []); const r = rows.get(u.id); return send(200, r ? [{ data: r.data, rev: r.rev, updated_at: r.updated_at }] : []); }
      if (req.method === 'POST') { if (body.user_id !== u.id) return send(403, { code: '42501', message: 'rls' }); if (rows.has(u.id)) return send(409, { code: '23505', message: 'duplicate key' }); const r = { data: body.data, rev: 1, updated_at: new Date().toISOString() }; rows.set(u.id, r); return send(201, [{ ...r }]); }
      if (req.method === 'PATCH') { const want = +url.searchParams.get('rev').replace('eq.', ''), r = rows.get(u.id); if (!r || uid !== u.id || r.rev !== want) return send(200, []); if (!backups.some((b) => b.user_id === u.id && Date.now() - b.t < 12 * 36e5)) backups.push({ id: randomUUID(), user_id: u.id, data: r.data, rev: r.rev, created_at: new Date().toISOString(), t: Date.now() }); r.data = body.data; r.rev = body.rev; r.updated_at = new Date().toISOString(); return send(200, [{ rev: r.rev }]); }
    }
    if (p === '/rest/v1/user_backups') { const id = url.searchParams.get('id')?.replace('eq.', ''); const mine = backups.filter((b) => b.user_id === u.id); return send(200, id ? mine.filter((b) => b.id === id).map((b) => ({ data: b.data, created_at: b.created_at })) : mine.map(({ id, created_at, rev }) => ({ id, created_at, rev })).reverse()); }
    if (p === '/rest/v1/rpc/delete_my_account') { users.delete(u.id); byEmail.delete(u.email); rows.delete(u.id); return send(204); }
    send(404, { message: 'not found ' + p });
  });
  return new Promise((resolve) => server.listen(port, () => resolve({ port, url: `http://localhost:${port}`, server, users, rows, backups, log, close: () => new Promise((r) => server.close(r)) })));
}
if (process.argv[1] && process.argv[1].endsWith('mock-supabase.mjs')) { const m = await startMock(+process.argv[2] || 8130); console.log('mock supabase on ' + m.url); }
